import { useState, useEffect } from 'react';
import { fetchExchangeRates, FALLBACK_RATES_TO_AED, type ExchangeRates } from '../lib/currency';

type UseExchangeRatesReturn = {
  rates: ExchangeRates;
  loading: boolean;
  lastUpdated: Date | null;
};

export function useExchangeRates(): UseExchangeRatesReturn {
  const [rates, setRates] = useState<ExchangeRates>(FALLBACK_RATES_TO_AED);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  useEffect(() => {
    fetchExchangeRates().then((r) => {
      setRates(r);
      setLastUpdated(new Date());
      setLoading(false);
    });
  }, []);

  return { rates, loading, lastUpdated };
}
