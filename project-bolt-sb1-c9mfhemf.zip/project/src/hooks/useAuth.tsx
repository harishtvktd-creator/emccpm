import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/supabase';

type TeamMember = Database['public']['Tables']['team_members']['Row'];

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  teamMemberFetching: boolean;
  teamMember: TeamMember | null;
  isAdmin: boolean;
  isTimeKeeper: boolean;
  isAccountant: boolean;
  signUp: (email: string, password: string) => Promise<{ error: Error | null }>;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [teamMember, setTeamMember] = useState<TeamMember | null>(null);
  const [teamMemberFetching, setTeamMemberFetching] = useState(false);

  const fetchTeamMember = async (uid: string, email?: string) => {
    setTeamMemberFetching(true);
    // Try by user_id first
    let { data } = await supabase
      .from('team_members')
      .select('*')
      .eq('user_id', uid)
      .eq('is_active', true)
      .maybeSingle();

    // Fallback: match by email and patch user_id (handles sign-ups before the trigger existed)
    if (!data && email) {
      const { data: byEmail } = await supabase
        .from('team_members')
        .select('*')
        .eq('email', email)
        .is('user_id', null)
        .eq('is_active', true)
        .maybeSingle();

      if (byEmail) {
        await supabase
          .from('team_members')
          .update({ user_id: uid })
          .eq('id', byEmail.id);
        data = { ...byEmail, user_id: uid };
      }
    }

    setTeamMember(data ?? null);
    setTeamMemberFetching(false);
  };

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchTeamMember(session.user.id, session.user.email).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        // Do NOT set loading=true here — that would unmount the entire app and
        // destroy any in-progress form state (e.g. New MR form) on token refresh.
        fetchTeamMember(session.user.id, session.user.email);
      } else {
        setTeamMember(null);
        setTeamMemberFetching(false);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const signUp = async (email: string, password: string) => {
    const { error } = await supabase.auth.signUp({ email, password });
    return { error };
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error };
  };

  const signOut = async () => {
    // Clear local state immediately so the UI redirects to login without waiting
    // for the onAuthStateChange event (which may be delayed).
    setUser(null);
    setSession(null);
    setTeamMember(null);
    setTeamMemberFetching(false);
    await supabase.auth.signOut();
  };

  const isAdmin = teamMember?.is_admin === true;
  const isTimeKeeper = (teamMember as any)?.is_time_keeper === true;
  const isAccountant = (teamMember as any)?.is_accountant === true;

  return (
    <AuthContext.Provider value={{ user, session, loading, teamMemberFetching, teamMember, isAdmin, isTimeKeeper, isAccountant, signUp, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
