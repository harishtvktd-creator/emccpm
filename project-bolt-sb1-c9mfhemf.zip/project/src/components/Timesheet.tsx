import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import {
  Users, Plus, Search, X, ChevronLeft, ChevronRight,
  Download, RefreshCw, Edit2, Trash2, CheckCircle2, Clock, AlertCircle,
  User, Briefcase, Globe2, Building2, ChevronDown, ChevronUp, Save, Loader2,
  ArrowUpDown, BarChart3, FileText, Timer,
} from 'lucide-react';

// ── Types ────────────────────────────────────────────────────

type TimesheetTab = 'employees' | 'reports';

type EmploymentType = 'staff' | 'labour' | 'subcontractor';
type DayType = 'present' | 'absent' | 'leave' | 'holiday' | 'rest' | 'overtime';

type TSEmployee = {
  id: string;
  employee_code: string;
  name: string;
  designation: string | null;
  department: string | null;
  project_id: string | null;
  nationality: string | null;
  trade: string | null;
  employment_type: EmploymentType;
  basic_salary: number | null;
  joining_date: string | null;
  is_active: boolean;
  created_at: string;
  projects?: { name: string } | null;
};

type TSEntry = {
  id: string;
  employee_id: string;
  work_date: string;
  day_type: DayType;
  regular_hours: number;
  overtime_hours: number;
  project_id: string | null;
  work_description: string | null;
  remarks: string | null;
  approved_by: string | null;
  approved_at: string | null;
};

type Project = { id: string; name: string };

// ── Constants ────────────────────────────────────────────────

const EMP_TYPE_META: Record<EmploymentType, { label: string; color: string; bg: string }> = {
  staff:         { label: 'INDIRECT',     color: 'text-blue-700',  bg: 'bg-blue-100' },
  labour:        { label: 'DIRECT',        color: 'text-amber-700', bg: 'bg-amber-100' },
  subcontractor: { label: 'Subcontractor', color: 'text-purple-700',bg: 'bg-purple-100' },
};

const DAY_META: Record<DayType, { label: string; color: string; bg: string; border: string }> = {
  present:  { label: 'P',  color: 'text-green-800',  bg: 'bg-green-100',  border: 'border-green-300' },
  absent:   { label: 'A',  color: 'text-red-800',    bg: 'bg-red-100',    border: 'border-red-300' },
  leave:    { label: 'L',  color: 'text-blue-800',   bg: 'bg-blue-100',   border: 'border-blue-300' },
  holiday:  { label: 'H',  color: 'text-teal-800',   bg: 'bg-teal-100',   border: 'border-teal-300' },
  rest:     { label: 'R',  color: 'text-gray-600',   bg: 'bg-gray-100',   border: 'border-gray-300' },
  overtime: { label: 'OT', color: 'text-orange-800', bg: 'bg-orange-100', border: 'border-orange-300' },
};

const MONTHS = ['January','February','March','April','May','June',
  'July','August','September','October','November','December'];

function fmtDate(d: string) {
  const [y, m, day] = d.split('T')[0].split('-');
  return `${day}/${m}/${y}`;
}

function getDaysInMonth(year: number, month: number): number {
  return new Date(year, month + 1, 0).getDate();
}

function getDayOfWeek(year: number, month: number, day: number): number {
  return new Date(year, month, day).getDay();
}

// ── Employee Form ────────────────────────────────────────────

type EmpFormData = {
  employee_code: string; name: string; designation: string; department: string;
  project_id: string; nationality: string; trade: string;
  employment_type: EmploymentType; basic_salary: string; joining_date: string;
};

const BLANK_EMP: EmpFormData = {
  employee_code: '', name: '', designation: '', department: '', project_id: '',
  nationality: '', trade: '', employment_type: 'staff', basic_salary: '', joining_date: '',
};

function EmployeeForm({
  initial, projects, onSave, onClose,
}: {
  initial?: TSEmployee | null;
  projects: Project[];
  onSave: () => void;
  onClose: () => void;
}) {
  const [form, setForm] = useState<EmpFormData>(
    initial
      ? {
          employee_code: initial.employee_code,
          name: initial.name,
          designation: initial.designation ?? '',
          department: initial.department ?? '',
          project_id: initial.project_id ?? '',
          nationality: initial.nationality ?? '',
          trade: initial.trade ?? '',
          employment_type: initial.employment_type,
          basic_salary: initial.basic_salary != null ? String(initial.basic_salary) : '',
          joining_date: initial.joining_date ?? '',
        }
      : BLANK_EMP,
  );
  const [saving, setSaving] = useState(false);
  const [error, setError]   = useState<string | null>(null);

  const set = (k: keyof EmpFormData, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.employee_code.trim()) { setError('Employee code is required.'); return; }
    if (!form.name.trim())          { setError('Name is required.'); return; }
    setSaving(true); setError(null);
    const payload = {
      employee_code:   form.employee_code.trim().toUpperCase(),
      name:            form.name.trim(),
      designation:     form.designation.trim() || null,
      department:      form.department.trim() || null,
      project_id:      form.project_id || null,
      nationality:     form.nationality.trim() || null,
      trade:           form.trade.trim() || null,
      employment_type: form.employment_type,
      basic_salary:    form.basic_salary ? parseFloat(form.basic_salary) : null,
      joining_date:    form.joining_date || null,
    };
    let err;
    if (initial) {
      ({ error: err } = await supabase.from('timesheet_employees').update(payload).eq('id', initial.id));
    } else {
      ({ error: err } = await supabase.from('timesheet_employees').insert(payload));
    }
    setSaving(false);
    if (err) { setError(err.message); return; }
    onSave();
  };

  const field = (label: string, required = false) => (
    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">
      {label}{required && <span className="text-red-400 ml-0.5">*</span>}
    </label>
  );
  const inp = 'w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400';

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl my-4">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div>
            <h3 className="font-bold text-gray-900">{initial ? 'Edit Employee' : 'Add Employee'}</h3>
            <p className="text-xs text-gray-500 mt-0.5">Employee master record</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              {field('Employee Code', true)}
              <input value={form.employee_code} onChange={(e) => set('employee_code', e.target.value)}
                placeholder="e.g. EMP-001" className={inp} />
            </div>
            <div>
              {field('Full Name', true)}
              <input value={form.name} onChange={(e) => set('name', e.target.value)}
                placeholder="Full name" className={inp} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              {field('Designation')}
              <input value={form.designation} onChange={(e) => set('designation', e.target.value)}
                placeholder="e.g. Site Engineer" className={inp} />
            </div>
            <div>
              {field('Department')}
              <input value={form.department} onChange={(e) => set('department', e.target.value)}
                placeholder="e.g. Civil" className={inp} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              {field('Trade / Skill')}
              <input value={form.trade} onChange={(e) => set('trade', e.target.value)}
                placeholder="e.g. Mason, Electrician" className={inp} />
            </div>
            <div>
              {field('Nationality')}
              <input value={form.nationality} onChange={(e) => set('nationality', e.target.value)}
                placeholder="e.g. Indian" className={inp} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              {field('Employment Type', true)}
              <select value={form.employment_type} onChange={(e) => set('employment_type', e.target.value as EmploymentType)}
                className={inp}>
                <option value="staff">INDIRECT</option>
                <option value="labour">DIRECT</option>
                <option value="subcontractor">Subcontractor</option>
              </select>
            </div>
            <div>
              {field('Assigned Project')}
              <select value={form.project_id} onChange={(e) => set('project_id', e.target.value)} className={inp}>
                <option value="">— None —</option>
                {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              {field('Basic Salary (AED)')}
              <input type="number" min="0" step="0.01" value={form.basic_salary}
                onChange={(e) => set('basic_salary', e.target.value)}
                placeholder="0.00" className={inp} />
            </div>
            <div>
              {field('Joining Date')}
              <input type="date" value={form.joining_date} onChange={(e) => set('joining_date', e.target.value)} className={inp} />
            </div>
          </div>
          {error && (
            <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl px-3 py-2.5">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />{error}
            </div>
          )}
          <div className="flex items-center gap-3 pt-1">
            <button type="submit" disabled={saving}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm disabled:opacity-60 hover:from-teal-600 hover:to-blue-700 transition-all">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              {saving ? 'Saving…' : initial ? 'Save Changes' : 'Add Employee'}
            </button>
            <button type="button" onClick={onClose} className="px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ── Employee Master Tab ───────────────────────────────────────

function EmployeeMaster() {
  const { isAdmin } = useAuth();
  const [employees, setEmployees] = useState<TSEmployee[]>([]);
  const [projects,  setProjects]  = useState<Project[]>([]);
  const [loading,   setLoading]   = useState(true);
  const [search,    setSearch]    = useState('');
  const [filterType, setFilterType] = useState<EmploymentType | 'all'>('all');
  const [filterProject, setFilterProject] = useState('all');
  const [sortBy,  setSortBy]  = useState<'code' | 'name' | 'type' | 'department' | 'status'>('code');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [editEmp, setEditEmp]     = useState<TSEmployee | null | 'new'>('new' as never);
  const [showForm, setShowForm]   = useState(false);

  const fetchEmployees = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('timesheet_employees')
      .select('*, projects(name)')
      .order('employee_code');
    setEmployees((data as TSEmployee[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchEmployees();
    supabase.from('projects').select('id,name').order('name').then(({ data }) => setProjects(data ?? []));
  }, [fetchEmployees]);

  const handleDeactivate = async (emp: TSEmployee) => {
    if (!confirm(`${emp.is_active ? 'Deactivate' : 'Reactivate'} ${emp.name}?`)) return;
    await supabase.from('timesheet_employees').update({ is_active: !emp.is_active }).eq('id', emp.id);
    fetchEmployees();
  };

  const handleDelete = async (emp: TSEmployee) => {
    if (!confirm(`Permanently delete ${emp.name} (${emp.employee_code})? This will also delete all their timesheet entries.`)) return;
    await supabase.from('timesheet_employees').delete().eq('id', emp.id);
    fetchEmployees();
  };

  const exportCSV = () => {
    const header = ['Code','Name','Designation','Department','Trade','Nationality','Type','Project','Basic Salary (AED)','Joining Date','Status'];
    const rows = filtered.map((e) => [
      e.employee_code,
      `"${e.name.replace(/"/g, '""')}"`,
      e.designation ?? '',
      e.department ?? '',
      e.trade ?? '',
      e.nationality ?? '',
      EMP_TYPE_META[e.employment_type].label,
      `"${(e.projects as { name: string } | null)?.name ?? ''}"`,
      e.basic_salary != null ? e.basic_salary.toFixed(2) : '',
      e.joining_date ? fmtDate(e.joining_date) : '',
      e.is_active ? 'Active' : 'Inactive',
    ]);
    const csv = [header, ...rows].map((r) => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `employee-master-${new Date().toISOString().split('T')[0]}.csv`;
    a.click(); URL.revokeObjectURL(url);
  };

  const projectNames = Array.from(
    new Set(employees.filter((e) => e.projects).map((e) => (e.projects as { name: string }).name))
  );

  const filtered = employees
    .filter((e) => filterType === 'all' || e.employment_type === filterType)
    .filter((e) => filterProject === 'all' || (e.projects as { name: string } | null)?.name === filterProject)
    .filter((e) => {
      if (!search) return true;
      const q = search.toLowerCase();
      return (
        e.employee_code.toLowerCase().includes(q) ||
        e.name.toLowerCase().includes(q) ||
        (e.designation ?? '').toLowerCase().includes(q) ||
        (e.department ?? '').toLowerCase().includes(q) ||
        (e.trade ?? '').toLowerCase().includes(q)
      );
    })
    .sort((a, b) => {
      let cmp = 0;
      if      (sortBy === 'name')       cmp = a.name.localeCompare(b.name);
      else if (sortBy === 'type')       cmp = a.employment_type.localeCompare(b.employment_type);
      else if (sortBy === 'department') cmp = (a.department ?? '').localeCompare(b.department ?? '');
      else if (sortBy === 'status')     cmp = Number(b.is_active) - Number(a.is_active);
      else                              cmp = a.employee_code.localeCompare(b.employee_code);
      return sortDir === 'asc' ? cmp : -cmp;
    });

  const counts = {
    total:  employees.length,
    active: employees.filter((e) => e.is_active).length,
    staff:  employees.filter((e) => e.employment_type === 'staff').length,
    labour: employees.filter((e) => e.employment_type === 'labour').length,
    sub:    employees.filter((e) => e.employment_type === 'subcontractor').length,
  };

  return (
    <>
      {/* Summary cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-6">
        {[
          { label: 'Total',         value: counts.total,  color: 'text-gray-700',  bg: 'bg-gray-100',   border: 'border-gray-200', icon: Users },
          { label: 'Active',        value: counts.active, color: 'text-green-700', bg: 'bg-green-50',   border: 'border-green-100', icon: CheckCircle2 },
          { label: 'INDIRECT',      value: counts.staff,  color: 'text-blue-700',  bg: 'bg-blue-50',    border: 'border-blue-100', icon: Briefcase },
          { label: 'DIRECT',        value: counts.labour, color: 'text-amber-700', bg: 'bg-amber-50',   border: 'border-amber-100', icon: User },
          { label: 'Subcontractor', value: counts.sub,    color: 'text-purple-700',bg: 'bg-purple-50',  border: 'border-purple-100', icon: Building2 },
        ].map((c) => (
          <div key={c.label} className={`bg-white rounded-xl border ${c.border} p-4 flex items-center gap-3`}>
            <div className={`w-9 h-9 ${c.bg} rounded-lg flex items-center justify-center flex-shrink-0`}>
              <c.icon className={`w-4 h-4 ${c.color}`} />
            </div>
            <div>
              <p className={`text-xl font-bold ${c.color}`}>{c.value}</p>
              <p className="text-xs text-gray-500">{c.label}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        {/* Toolbar */}
        <div className="p-5 border-b border-gray-100 flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text" value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name, code, trade, designation…"
              className="w-full pl-9 pr-8 py-2 border border-gray-200 rounded-lg text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400"
            />
            {search && <button onClick={() => setSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"><X className="w-3.5 h-3.5" /></button>}
          </div>
          <select value={filterType} onChange={(e) => setFilterType(e.target.value as typeof filterType)}
            className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-teal-400">
            <option value="all">All Types</option>
            <option value="staff">Staff</option>
            <option value="labour">Labour</option>
            <option value="subcontractor">Subcontractor</option>
          </select>
          <select value={filterProject} onChange={(e) => setFilterProject(e.target.value)}
            className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-teal-400">
            <option value="all">All Projects</option>
            {projectNames.map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
          <select value={sortBy} onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
            className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-teal-400">
            <option value="code">Sort: Code</option>
            <option value="name">Sort: Name</option>
            <option value="type">Sort: Type</option>
            <option value="department">Sort: Dept</option>
            <option value="status">Sort: Status</option>
          </select>
          <button
            onClick={() => setSortDir((d) => d === 'asc' ? 'desc' : 'asc')}
            title={sortDir === 'asc' ? 'Ascending — click for Descending' : 'Descending — click for Ascending'}
            className="p-1.5 border border-gray-200 rounded-lg bg-white text-gray-600 hover:border-teal-300 hover:text-teal-600 transition-colors">
            <ArrowUpDown className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2 ml-auto">
            <button onClick={fetchEmployees} disabled={loading} className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm text-gray-600 hover:border-teal-300 hover:text-teal-600 transition-colors">
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button onClick={exportCSV} className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm text-gray-600 hover:border-teal-300 hover:text-teal-600 transition-colors">
              <Download className="w-4 h-4" />Export
            </button>
            {isAdmin && (
              <button
                onClick={() => { setEditEmp(null); setShowForm(true); }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-gradient-to-r from-teal-500 to-blue-600 text-white text-sm font-medium hover:from-teal-600 hover:to-blue-700 transition-all shadow-sm"
              >
                <Plus className="w-4 h-4" />Add Employee
              </button>
            )}
          </div>
        </div>

        {/* Table */}
        {loading ? (
          <div className="py-20 flex items-center justify-center"><RefreshCw className="w-7 h-7 animate-spin text-teal-400" /></div>
        ) : filtered.length === 0 ? (
          <div className="py-16 text-center">
            <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-600 font-medium">{employees.length === 0 ? 'No employees added yet' : 'No employees match the filter'}</p>
            {isAdmin && employees.length === 0 && (
              <button onClick={() => { setEditEmp(null); setShowForm(true); }}
                className="mt-4 px-5 py-2 bg-gradient-to-r from-teal-500 to-blue-600 text-white rounded-lg text-sm font-medium">
                Add First Employee
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Code</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Name</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Designation / Trade</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Department</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Nationality</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Type</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Project</th>
                  <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Basic Salary</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Status</th>
                  {isAdmin && <th className="px-4 py-3" />}
                </tr>
              </thead>
              <tbody>
                {filtered.map((emp) => {
                  const typeMeta = EMP_TYPE_META[emp.employment_type];
                  return (
                    <React.Fragment key={emp.id}>
                      <tr className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${!emp.is_active ? 'opacity-50' : ''}`}>
                        <td className="px-5 py-3 font-mono text-sm font-semibold text-teal-700">
                          <button onClick={() => setExpandedId(expandedId === emp.id ? null : emp.id)}
                            className="hover:underline flex items-center gap-1">
                            {emp.employee_code}
                            {expandedId === emp.id ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                          </button>
                        </td>
                        <td className="px-4 py-3 text-sm font-medium text-gray-800">{emp.name}</td>
                        <td className="px-4 py-3">
                          {emp.designation && <p className="text-sm text-gray-700">{emp.designation}</p>}
                          {emp.trade && <p className="text-xs text-gray-400">{emp.trade}</p>}
                          {!emp.designation && !emp.trade && <span className="text-gray-300 text-sm">—</span>}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600">{emp.department ?? '—'}</td>
                        <td className="px-4 py-3 text-sm text-gray-600 flex items-center gap-1.5">
                          {emp.nationality && <Globe2 className="w-3.5 h-3.5 text-gray-400" />}
                          {emp.nationality ?? '—'}
                        </td>
                        <td className="px-4 py-3">
                          <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${typeMeta.bg} ${typeMeta.color}`}>
                            {typeMeta.label}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600">{(emp.projects as { name: string } | null)?.name ?? '—'}</td>
                        <td className="px-4 py-3 text-sm text-right font-medium text-gray-800">
                          {emp.basic_salary != null ? `AED ${emp.basic_salary.toLocaleString('en-AE', { minimumFractionDigits: 2 })}` : '—'}
                        </td>
                        <td className="px-4 py-3">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold ${emp.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${emp.is_active ? 'bg-green-500' : 'bg-gray-400'}`} />
                            {emp.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </td>
                        {isAdmin && (
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-1">
                              <button onClick={() => { setEditEmp(emp); setShowForm(true); }}
                                className="p-1.5 text-gray-400 hover:text-teal-600 hover:bg-teal-50 rounded-lg transition-colors" title="Edit">
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button onClick={() => handleDeactivate(emp)}
                                className={`p-1.5 rounded-lg transition-colors ${emp.is_active ? 'text-gray-400 hover:text-amber-600 hover:bg-amber-50' : 'text-gray-400 hover:text-green-600 hover:bg-green-50'}`}
                                title={emp.is_active ? 'Deactivate' : 'Reactivate'}>
                                <CheckCircle2 className="w-3.5 h-3.5" />
                              </button>
                              <button onClick={() => handleDelete(emp)}
                                className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors" title="Delete">
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        )}
                      </tr>
                      {expandedId === emp.id && (
                        <tr className="border-b border-teal-100">
                          <td colSpan={isAdmin ? 10 : 9} className="px-5 py-4 bg-teal-50/40">
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
                              {[
                                { label: 'Employee Code', value: emp.employee_code },
                                { label: 'Full Name',     value: emp.name },
                                { label: 'Joining Date',  value: emp.joining_date ? fmtDate(emp.joining_date) : '—' },
                                { label: 'Basic Salary',  value: emp.basic_salary != null ? `AED ${emp.basic_salary.toLocaleString('en-AE', { minimumFractionDigits: 2 })}` : '—' },
                                { label: 'Designation',   value: emp.designation ?? '—' },
                                { label: 'Department',    value: emp.department ?? '—' },
                                { label: 'Trade',         value: emp.trade ?? '—' },
                                { label: 'Nationality',   value: emp.nationality ?? '—' },
                              ].map((f) => (
                                <div key={f.label} className="bg-white rounded-lg border border-gray-100 px-3 py-2.5">
                                  <p className="text-xs font-semibold text-gray-500 mb-0.5">{f.label}</p>
                                  <p className="text-sm font-medium text-gray-800">{f.value}</p>
                                </div>
                              ))}
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
          <p className="text-xs text-gray-400">Showing {filtered.length} of {employees.length} employees</p>
        </div>
      </div>

      {showForm && (
        <EmployeeForm
          initial={editEmp as TSEmployee | null}
          projects={projects}
          onSave={() => { setShowForm(false); fetchEmployees(); }}
          onClose={() => setShowForm(false)}
        />
      )}
    </>
  );
}

// ── Reports Tab ───────────────────────────────────────────────

type ReportTab = 'normal' | 'overtime';

function TimesheetReports() {
  const today = new Date();
  const firstOfMonth = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
  const todayStr = today.toISOString().split('T')[0];

  const [reportTab, setReportTab] = useState<ReportTab>('normal');
  const [dateFrom,      setDateFrom]      = useState(firstOfMonth);
  const [dateTo,        setDateTo]        = useState(todayStr);
  const [filterProject, setFilterProject] = useState('all');
  const [filterType,    setFilterType]    = useState<EmploymentType | 'all'>('all');
  const [search,        setSearch]        = useState('');
  const [sortBy,        setSortBy]        = useState<'name' | 'hours' | 'days'>('hours');
  const [sortDir,       setSortDir]       = useState<'asc' | 'desc'>('desc');
  const [projects,      setProjects]      = useState<Project[]>([]);
  const [entries,       setEntries]       = useState<TSEntry[]>([]);
  const [employees,     setEmployees]     = useState<TSEmployee[]>([]);
  const [loading,       setLoading]       = useState(false);

  useEffect(() => {
    supabase.from('projects').select('id,name').order('name').then(({ data }) => setProjects(data ?? []));
  }, []);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [empRes, entryRes] = await Promise.all([
      supabase.from('workforce_employees').select('id,employee_code,name,designation,department,trade,nationality,employment_type,is_active').order('employee_code'),
      supabase.from('timesheet_entries').select('*').gte('work_date', dateFrom).lte('work_date', dateTo),
    ]);
    setEmployees((empRes.data as TSEmployee[]) ?? []);
    setEntries((entryRes.data as TSEntry[]) ?? []);
    setLoading(false);
  }, [dateFrom, dateTo]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const reportRows = useMemo(() => {
    const empMap = new Map<string, {
      emp: TSEmployee;
      regularHours: number;
      overtimeHours: number;
      presentDays: number;
      otDays: number;
      projectId: string | null;
    }>();
    for (const entry of entries) {
      const emp = employees.find((em) => em.id === entry.employee_id);
      if (!emp) continue;
      if (filterType !== 'all' && emp.employment_type !== filterType) continue;
      if (filterProject !== 'all' && entry.project_id !== filterProject) continue;
      const prev = empMap.get(entry.employee_id) ?? { emp, regularHours: 0, overtimeHours: 0, presentDays: 0, otDays: 0, projectId: null };
      prev.regularHours  = Math.round((prev.regularHours  + Number(entry.regular_hours))  * 100) / 100;
      prev.overtimeHours = Math.round((prev.overtimeHours + Number(entry.overtime_hours)) * 100) / 100;
      if (entry.day_type === 'present' || entry.day_type === 'overtime') prev.presentDays += 1;
      if (Number(entry.overtime_hours) > 0) prev.otDays += 1;
      if (entry.project_id) prev.projectId = entry.project_id;
      empMap.set(entry.employee_id, prev);
    }
    return Array.from(empMap.values());
  }, [employees, entries, filterType, filterProject]);

  const displayRows = reportRows
    .filter((r) => {
      if (!search) return true;
      const q = search.toLowerCase();
      return r.emp.name.toLowerCase().includes(q) || r.emp.employee_code.toLowerCase().includes(q);
    })
    .sort((a, b) => {
      let cmp = 0;
      if      (sortBy === 'name')  cmp = a.emp.name.localeCompare(b.emp.name);
      else if (sortBy === 'hours') cmp = (reportTab === 'normal' ? a.regularHours - b.regularHours : a.overtimeHours - b.overtimeHours);
      else                         cmp = (reportTab === 'normal' ? a.presentDays  - b.presentDays  : a.otDays - b.otDays);
      return sortDir === 'asc' ? cmp : -cmp;
    });

  const totRegHours = displayRows.reduce((s, r) => s + r.regularHours, 0);
  const totOTHours  = displayRows.reduce((s, r) => s + r.overtimeHours, 0);

  const exportCSV = () => {
    const isNormal = reportTab === 'normal';
    const header = ['Code', 'Name', 'Designation', 'Project', 'Type',
      isNormal ? 'Regular Hours' : 'OT Hours',
      isNormal ? 'Days Present'  : 'OT Days',
      isNormal ? 'Avg Hrs/Day'   : 'Avg OT/Day'];
    const rows = displayRows.map((r) => {
      const days = isNormal ? r.presentDays : r.otDays;
      const hrs  = isNormal ? r.regularHours : r.overtimeHours;
      return [
        r.emp.employee_code,
        `"${r.emp.name.replace(/"/g, '""')}"`,
        r.emp.designation ?? '',
        `"${projects.find((p) => p.id === r.projectId)?.name ?? ''}"`,
        EMP_TYPE_META[r.emp.employment_type].label,
        hrs.toFixed(2),
        days,
        days > 0 ? (hrs / days).toFixed(2) : '0',
      ];
    });
    const csv = [header, ...rows].map((r) => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${isNormal ? 'normal-time' : 'overtime'}-report-${dateFrom}-to-${dateTo}.csv`;
    a.click(); URL.revokeObjectURL(url);
  };

  const sel = 'text-sm border border-gray-200 rounded-lg px-3 py-1.5 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-teal-400';

  return (
    <>
      {/* Sub-tab bar */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden mb-4">
        <div className="flex border-b border-gray-100">
          {([
            { id: 'normal'    as ReportTab, label: 'Normal Time Report', icon: FileText },
            { id: 'overtime'  as ReportTab, label: 'Overtime Report',    icon: Timer    },
          ]).map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setReportTab(id)}
              className={`flex items-center gap-2 px-6 py-3.5 text-sm font-medium border-b-2 transition-colors ${
                reportTab === id
                  ? 'border-teal-500 text-teal-700 bg-teal-50/40'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}>
              <Icon className="w-4 h-4" />{label}
            </button>
          ))}
        </div>
      </div>

      {/* Filter bar */}
          <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-4 mb-4">
            <div className="flex flex-wrap gap-3 items-end">
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">From</label>
                <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className={sel} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">To</label>
                <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className={sel} />
              </div>
              <select value={filterProject} onChange={(e) => setFilterProject(e.target.value)} className={sel}>
                <option value="all">All Projects</option>
                {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
              <select value={filterType} onChange={(e) => setFilterType(e.target.value as typeof filterType)} className={sel}>
                <option value="all">All Types</option>
                <option value="staff">INDIRECT</option>
                <option value="labour">DIRECT</option>
                <option value="subcontractor">Subcontractor</option>
              </select>
              <div className="relative flex-1 min-w-[180px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input type="text" value={search} onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search employee…"
                  className="w-full pl-9 pr-8 py-1.5 border border-gray-200 rounded-lg text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400" />
                {search && <button onClick={() => setSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400"><X className="w-3.5 h-3.5" /></button>}
              </div>
              <div className="flex items-center gap-2">
                <select value={sortBy} onChange={(e) => setSortBy(e.target.value as typeof sortBy)} className={sel}>
                  <option value="hours">Sort: Hours</option>
                  <option value="days">Sort: Days</option>
                  <option value="name">Sort: Name</option>
                </select>
                <button onClick={() => setSortDir((d) => d === 'asc' ? 'desc' : 'asc')}
                  title={sortDir === 'asc' ? 'Ascending' : 'Descending'}
                  className="p-1.5 border border-gray-200 rounded-lg bg-white text-gray-600 hover:border-teal-300 hover:text-teal-600 transition-colors">
                  <ArrowUpDown className="w-4 h-4" />
                </button>
                <button onClick={fetchData} disabled={loading}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-200 bg-white text-sm text-gray-600 hover:border-teal-300 hover:text-teal-600 transition-colors">
                  <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                </button>
                {displayRows.length > 0 && (
                  <button onClick={exportCSV}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-200 bg-white text-sm text-gray-600 hover:border-teal-300 hover:text-teal-600 transition-colors">
                    <Download className="w-4 h-4" />Export
                  </button>
                )}
              </div>
            </div>
          </div>

      {/* Sub-tabs + table card */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        {/* Summary cards */}
        <div className="p-4 border-b border-gray-100 bg-gray-50/40">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {reportTab === 'normal' ? (
              <>
                <div className="bg-white rounded-xl border border-teal-100 px-4 py-3">
                  <p className="text-2xl font-bold text-teal-700">{totRegHours.toFixed(1)}</p>
                  <p className="text-xs text-gray-500 font-semibold uppercase tracking-wide mt-0.5">Total Regular Hours</p>
                </div>
                <div className="bg-white rounded-xl border border-gray-100 px-4 py-3">
                  <p className="text-2xl font-bold text-blue-700">{displayRows.length}</p>
                  <p className="text-xs text-gray-500 font-semibold uppercase tracking-wide mt-0.5">Employees</p>
                </div>
                <div className="bg-white rounded-xl border border-gray-100 px-4 py-3">
                  <p className="text-2xl font-bold text-gray-800">
                    {displayRows.length > 0 ? (totRegHours / displayRows.length).toFixed(1) : '0'}
                  </p>
                  <p className="text-xs text-gray-500 font-semibold uppercase tracking-wide mt-0.5">Avg Hrs / Employee</p>
                </div>
                <div className="bg-white rounded-xl border border-gray-100 px-4 py-3">
                  <p className="text-2xl font-bold text-amber-700">
                    {displayRows.length > 0
                      ? (displayRows.reduce((s, r) => s + r.presentDays, 0) / displayRows.length).toFixed(1)
                      : '0'}
                  </p>
                  <p className="text-xs text-gray-500 font-semibold uppercase tracking-wide mt-0.5">Avg Days Present</p>
                </div>
              </>
            ) : (
              <>
                <div className="bg-white rounded-xl border border-orange-100 px-4 py-3">
                  <p className="text-2xl font-bold text-orange-700">{totOTHours.toFixed(1)}</p>
                  <p className="text-xs text-gray-500 font-semibold uppercase tracking-wide mt-0.5">Total OT Hours</p>
                </div>
                <div className="bg-white rounded-xl border border-gray-100 px-4 py-3">
                  <p className="text-2xl font-bold text-blue-700">{displayRows.filter((r) => r.overtimeHours > 0).length}</p>
                  <p className="text-xs text-gray-500 font-semibold uppercase tracking-wide mt-0.5">Employees with OT</p>
                </div>
                <div className="bg-white rounded-xl border border-gray-100 px-4 py-3">
                  <p className="text-2xl font-bold text-gray-800">
                    {(() => {
                      const n = displayRows.filter((r) => r.overtimeHours > 0).length;
                      return n > 0 ? (totOTHours / n).toFixed(1) : '0';
                    })()}
                  </p>
                  <p className="text-xs text-gray-500 font-semibold uppercase tracking-wide mt-0.5">Avg OT Hrs / Employee</p>
                </div>
                <div className="bg-white rounded-xl border border-gray-100 px-4 py-3">
                  <p className="text-2xl font-bold text-amber-700">{displayRows.reduce((s, r) => s + r.otDays, 0)}</p>
                  <p className="text-xs text-gray-500 font-semibold uppercase tracking-wide mt-0.5">Total OT Days</p>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Table */}
        {loading ? (
          <div className="py-16 flex items-center justify-center">
            <RefreshCw className="w-7 h-7 animate-spin text-teal-400" />
          </div>
        ) : displayRows.length === 0 ? (
          <div className="py-14 text-center">
            <BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-600 font-medium">No data for selected period</p>
            <p className="text-gray-400 text-sm mt-1">Adjust filters or record attendance entries first.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-400 uppercase tracking-wide w-8">#</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">Code</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Employee</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Project</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Type</th>
                  {reportTab === 'normal' ? (
                    <>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-teal-600 uppercase tracking-wide whitespace-nowrap">Reg. Hours</th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">Days Present</th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">Avg Hrs/Day</th>
                    </>
                  ) : (
                    <>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-orange-600 uppercase tracking-wide whitespace-nowrap">OT Hours</th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">OT Days</th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">Avg OT/Day</th>
                    </>
                  )}
                </tr>
              </thead>
              <tbody>
                {displayRows.map((r, idx) => {
                  const isOT      = reportTab === 'overtime';
                  const mainHours = isOT ? r.overtimeHours : r.regularHours;
                  const days      = isOT ? r.otDays : r.presentDays;
                  const avg       = days > 0 ? (mainHours / days).toFixed(2) : '—';
                  const projName  = r.projectId ? (projects.find((p) => p.id === r.projectId)?.name ?? '—') : '—';
                  const meta      = EMP_TYPE_META[r.emp.employment_type];
                  return (
                    <tr key={r.emp.id} className="border-b border-gray-100 hover:bg-gray-50/50 transition-colors">
                      <td className="px-4 py-3 text-gray-400 text-xs">{idx + 1}</td>
                      <td className="px-4 py-3 font-mono text-xs font-semibold text-teal-700">{r.emp.employee_code}</td>
                      <td className="px-4 py-3">
                        <p className="font-semibold text-gray-800">{r.emp.name}</p>
                        {r.emp.designation && <p className="text-xs text-gray-400">{r.emp.designation}</p>}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">{projName}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-semibold ${meta.bg} ${meta.color}`}>
                          {meta.label}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <span className={`font-bold text-sm ${
                          isOT
                            ? mainHours > 0 ? 'text-orange-700' : 'text-gray-300'
                            : mainHours >= 160 ? 'text-teal-700' : mainHours >= 80 ? 'text-blue-700' : 'text-gray-800'
                        }`}>
                          {mainHours.toFixed(1)}h
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right font-medium text-gray-700">{days}</td>
                      <td className="px-4 py-3 text-right text-gray-500 text-xs">{avg !== '—' ? avg + 'h' : '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="bg-gray-50 border-t-2 border-gray-200">
                  <td colSpan={5} className="px-4 py-3 text-sm font-semibold text-gray-700">
                    Total ({displayRows.length} employees)
                  </td>
                  <td className="px-4 py-3 text-right">
                    <span className={`font-bold text-sm ${reportTab === 'overtime' ? 'text-orange-700' : 'text-teal-700'}`}>
                      {(reportTab === 'overtime' ? totOTHours : totRegHours).toFixed(1)}h
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right font-semibold text-gray-700">
                    {reportTab === 'overtime'
                      ? displayRows.reduce((s, r) => s + r.otDays, 0)
                      : displayRows.reduce((s, r) => s + r.presentDays, 0)}
                  </td>
                  <td className="px-4 py-3 text-right text-gray-500 text-xs">
                    {(() => {
                      const hrs  = reportTab === 'overtime' ? totOTHours : totRegHours;
                      const days = reportTab === 'overtime'
                        ? displayRows.reduce((s, r) => s + r.otDays, 0)
                        : displayRows.reduce((s, r) => s + r.presentDays, 0);
                      return days > 0 ? (hrs / days).toFixed(2) + 'h' : '—';
                    })()}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
        <div className="px-5 py-3 border-t border-gray-100">
          <p className="text-xs text-gray-400">
            {displayRows.length} employees · {fmtDate(dateFrom)} — {fmtDate(dateTo)}
          </p>
        </div>
      </div>
    </>
  );
}

// ── Main Timesheet Component ──────────────────────────────────

export function Timesheet({ initialTab = 'employees' }: { initialTab?: TimesheetTab }) {
  const [tab, setTab] = useState<TimesheetTab>(initialTab);

  useEffect(() => { setTab(initialTab); }, [initialTab]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 p-6 lg:p-8">
      <div className="max-w-screen-2xl mx-auto space-y-6">

        {/* Page header */}
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Timesheets</h1>
          <p className="text-gray-500 text-sm mt-0.5">Manage employee records and monthly attendance</p>
        </div>

        {/* Tab bar */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="flex border-b border-gray-100">
            {([
              { id: 'employees', label: 'Employee Master', icon: Users     },
              { id: 'reports',   label: 'Reports',         icon: BarChart3 },
            ] as { id: TimesheetTab; label: string; icon: React.ElementType }[]).map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => setTab(id)}
                className={`flex items-center gap-2 px-6 py-3.5 text-sm font-medium border-b-2 transition-colors ${
                  tab === id
                    ? 'border-teal-500 text-teal-700 bg-teal-50/40'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}>
                <Icon className="w-4 h-4" />
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Tab content */}
        {tab === 'employees' ? <EmployeeMaster /> : <TimesheetReports />}

      </div>
    </div>
  );
}
