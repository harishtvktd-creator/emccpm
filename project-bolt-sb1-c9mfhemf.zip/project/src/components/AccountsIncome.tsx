import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useExchangeRates } from '../hooks/useExchangeRates';
import {
  formatCurrency, convertCurrency, SUPPORTED_CURRENCIES, DEFAULT_CURRENCY,
} from '../lib/currency';
import {
  TrendingUp, Plus, X, Search, Loader2, FileText, CreditCard,
  BarChart3, ChevronDown, ChevronUp, Eye, Pencil, Trash2,
  CheckCircle, Clock, AlertTriangle, Ban, Send, Download,
  RefreshCw, DollarSign, Calendar, Building2,
} from 'lucide-react';

// ── Types ──────────────────────────────────────────────────────────────────────

type Project = { id: string; name: string; project_code?: string | null };
type BankAccount = { id: string; name: string; currency: string };

type InvoiceItem = {
  id?: string;
  description: string;
  quantity: number;
  unit_price: number;
};

type Invoice = {
  id: string;
  type: 'invoice' | 'credit_note';
  invoice_number: string;
  client_name: string | null;
  issue_date: string;
  due_date: string | null;
  currency: string;
  subtotal: number;
  tax_rate: number;
  tax_amount: number;
  total: number;
  paid_amount: number;
  status: 'draft' | 'sent' | 'partial' | 'paid' | 'overdue' | 'cancelled';
  notes: string | null;
  linked_invoice_id: string | null;
  project: Project | null;
  items?: InvoiceItem[];
};

type Payment = {
  id: string;
  payment_date: string;
  amount: number;
  currency: string;
  reference: string | null;
  notes: string | null;
  bank_account: BankAccount | null;
};

type Tab = 'invoices' | 'credit_notes' | 'report';

// ── Helpers ────────────────────────────────────────────────────────────────────

function fmtDate(d: string | null) {
  if (!d) return '—';
  const [y, m, day] = d.split('-');
  return `${day}/${m}/${y}`;
}

const STATUS_CONFIG: Record<Invoice['status'], { label: string; cls: string; Icon: React.ElementType }> = {
  draft:      { label: 'Draft',     cls: 'bg-gray-100 text-gray-600 border-gray-200',       Icon: FileText },
  sent:       { label: 'Sent',      cls: 'bg-blue-50 text-blue-700 border-blue-200',         Icon: Send },
  partial:    { label: 'Partial',   cls: 'bg-amber-50 text-amber-700 border-amber-200',      Icon: Clock },
  paid:       { label: 'Paid',      cls: 'bg-emerald-50 text-emerald-700 border-emerald-200',Icon: CheckCircle },
  overdue:    { label: 'Overdue',   cls: 'bg-red-50 text-red-700 border-red-200',            Icon: AlertTriangle },
  cancelled:  { label: 'Cancelled', cls: 'bg-gray-100 text-gray-400 border-gray-200',        Icon: Ban },
};

function StatusBadge({ status }: { status: Invoice['status'] }) {
  const { label, cls, Icon } = STATUS_CONFIG[status] ?? STATUS_CONFIG.draft;
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold border ${cls}`}>
      <Icon className="w-3 h-3" />{label}
    </span>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────

export function AccountsIncome() {
  const { user } = useAuth();
  const { rates, loading: ratesLoading, lastUpdated } = useExchangeRates();
  const [displayCurrency, setDisplayCurrency] = useState(DEFAULT_CURRENCY);
  const [tab, setTab] = useState<Tab>('invoices');

  const [projects, setProjects] = useState<Project[]>([]);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);

  const [search, setSearch] = useState('');
  const [filterProject, setFilterProject] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  const [showForm, setShowForm] = useState(false);
  const [editInvoice, setEditInvoice] = useState<Invoice | null>(null);
  const [viewInvoice, setViewInvoice] = useState<Invoice | null>(null);
  const [paymentInvoice, setPaymentInvoice] = useState<Invoice | null>(null);

  const activeType: 'invoice' | 'credit_note' = tab === 'credit_notes' ? 'credit_note' : 'invoice';

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [invRes, projRes, bankRes] = await Promise.all([
      supabase
        .from('accounts_invoices')
        .select('id,type,invoice_number,client_name,issue_date,due_date,currency,subtotal,tax_rate,tax_amount,total,paid_amount,status,notes,linked_invoice_id,project:projects(id,name,project_code)')
        .order('issue_date', { ascending: false }),
      supabase.from('projects').select('id,name,project_code').order('name'),
      supabase.from('bank_accounts').select('id,name,currency').order('name'),
    ]);
    setInvoices((invRes.data ?? []) as unknown as Invoice[]);
    setProjects((projRes.data ?? []) as Project[]);
    setBankAccounts((bankRes.data ?? []) as BankAccount[]);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const conv = useCallback((amount: number, from: string) =>
    convertCurrency(amount, from, displayCurrency, rates), [displayCurrency, rates]);

  const filtered = invoices.filter((inv) => {
    if (tab !== 'report' && inv.type !== activeType) return false;
    if (filterProject !== 'all' && inv.project?.id !== filterProject) return false;
    if (filterStatus !== 'all' && inv.status !== filterStatus) return false;
    if (search) {
      const q = search.toLowerCase();
      if (![inv.invoice_number, inv.client_name, inv.project?.name].some((f) => f?.toLowerCase().includes(q))) return false;
    }
    return true;
  });

  // Summary totals
  const activeInvs = invoices.filter((i) => i.type === activeType);
  const totalBilled   = activeInvs.reduce((s, i) => s + conv(i.total, i.currency), 0);
  const totalPaid     = activeInvs.reduce((s, i) => s + conv(i.paid_amount, i.currency), 0);
  const totalBalance  = totalBilled - totalPaid;
  const overdueCount  = activeInvs.filter((i) => i.status === 'overdue').length;

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this record? This cannot be undone.')) return;
    await supabase.from('accounts_invoices').delete().eq('id', id);
    fetchData();
  };

  const tabBtn = (t: Tab, label: string, Icon: React.ElementType) => (
    <button onClick={() => setTab(t)}
      className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium border transition-all ${tab === t ? 'bg-teal-600 text-white border-teal-600 shadow-sm' : 'bg-white text-gray-600 border-gray-200 hover:border-teal-300'}`}>
      <Icon className="w-4 h-4" />{label}
    </button>
  );

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-bold text-gray-900 text-lg">Income</h3>
          <p className="text-sm text-gray-500 mt-0.5">Invoices, credit notes, and project-wise income reporting</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          {/* Currency selector */}
          <div className="flex items-center gap-2">
            {!ratesLoading && lastUpdated && (
              <span className="text-xs text-gray-400 flex items-center gap-1">
                <RefreshCw className="w-3 h-3" />Live rates
              </span>
            )}
            <select value={displayCurrency} onChange={(e) => setDisplayCurrency(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-teal-400 bg-white">
              {SUPPORTED_CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          {tab !== 'report' && (
            <button onClick={() => { setEditInvoice(null); setShowForm(true); }}
              className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm shadow-sm hover:from-teal-600 hover:to-blue-700 transition-all">
              <Plus className="w-4 h-4" />New {tab === 'credit_notes' ? 'Credit Note' : 'Invoice'}
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 flex-wrap">
        {tabBtn('invoices', 'Invoices', FileText)}
        {tabBtn('credit_notes', 'Credit Notes', CreditCard)}
        {tabBtn('report', 'Project Report', BarChart3)}
      </div>

      {tab === 'report' ? (
        <ProjectReport invoices={invoices} projects={projects} conv={conv} displayCurrency={displayCurrency} />
      ) : (
        <>
          {/* KPI row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <KpiCard label="Total Billed" value={formatCurrency(totalBilled, displayCurrency)} color="emerald" />
            <KpiCard label="Total Received" value={formatCurrency(totalPaid, displayCurrency)} color="teal" />
            <KpiCard label="Outstanding" value={formatCurrency(totalBalance, displayCurrency)} color={totalBalance > 0 ? 'amber' : 'gray'} />
            <KpiCard label="Overdue" value={String(overdueCount)} suffix="records" color={overdueCount > 0 ? 'red' : 'gray'} />
          </div>

          {/* Filters */}
          <div className="bg-white border border-gray-200 rounded-2xl p-4">
            <div className="flex flex-wrap gap-3 items-end">
              <div className="relative flex-1 min-w-[180px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Invoice #, client, project…"
                  className="w-full pl-9 pr-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
                {search && <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2"><X className="w-4 h-4 text-gray-400 hover:text-gray-600" /></button>}
              </div>
              <div>
                <select value={filterProject} onChange={(e) => setFilterProject(e.target.value)}
                  className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400">
                  <option value="all">All Projects</option>
                  {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div>
                <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}
                  className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400">
                  <option value="all">All Statuses</option>
                  {Object.entries(STATUS_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                </select>
              </div>
            </div>
          </div>

          {/* Invoice table */}
          {loading ? (
            <div className="bg-white rounded-2xl border border-gray-100 p-12 flex items-center justify-center">
              <Loader2 className="w-6 h-6 animate-spin text-teal-500" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="bg-white rounded-2xl border border-gray-100 p-14 text-center">
              <TrendingUp className="w-12 h-12 text-gray-200 mx-auto mb-3" />
              <p className="font-semibold text-gray-500">No {tab === 'credit_notes' ? 'credit notes' : 'invoices'} found</p>
              <p className="text-sm text-gray-400 mt-1 mb-5">Create your first one to start tracking income.</p>
              <button onClick={() => { setEditInvoice(null); setShowForm(true); }}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white rounded-xl text-sm font-medium">
                <Plus className="w-4 h-4" />Create {tab === 'credit_notes' ? 'Credit Note' : 'Invoice'}
              </button>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100">
                      {['Number','Project','Client','Issue Date','Due Date','Total','Paid','Balance','Status',''].map((h) => (
                        <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {filtered.map((inv) => {
                      const balance = conv(inv.total - inv.paid_amount, inv.currency);
                      return (
                        <tr key={inv.id} className="hover:bg-gray-50/60 transition-colors">
                          <td className="px-4 py-3 font-mono text-xs font-semibold text-teal-700 whitespace-nowrap">{inv.invoice_number}</td>
                          <td className="px-4 py-3 text-xs text-gray-600 max-w-[140px] truncate">
                            {inv.project ? (
                              <span className="flex items-center gap-1">
                                <Building2 className="w-3 h-3 text-gray-400 flex-shrink-0" />
                                {inv.project.project_code ? `[${inv.project.project_code}] ` : ''}{inv.project.name}
                              </span>
                            ) : <span className="text-gray-300">—</span>}
                          </td>
                          <td className="px-4 py-3 text-gray-700 max-w-[130px] truncate">{inv.client_name ?? '—'}</td>
                          <td className="px-4 py-3 font-mono text-xs text-gray-500 whitespace-nowrap">{fmtDate(inv.issue_date)}</td>
                          <td className="px-4 py-3 font-mono text-xs whitespace-nowrap">
                            {inv.due_date ? (
                              <span className={new Date(inv.due_date) < new Date() && inv.status !== 'paid' ? 'text-red-600 font-semibold' : 'text-gray-500'}>
                                {fmtDate(inv.due_date)}
                              </span>
                            ) : '—'}
                          </td>
                          <td className="px-4 py-3 font-semibold text-gray-800 whitespace-nowrap text-right">
                            {formatCurrency(conv(inv.total, inv.currency), displayCurrency)}
                          </td>
                          <td className="px-4 py-3 text-emerald-600 font-medium whitespace-nowrap text-right">
                            {inv.paid_amount > 0 ? formatCurrency(conv(inv.paid_amount, inv.currency), displayCurrency) : '—'}
                          </td>
                          <td className={`px-4 py-3 font-semibold whitespace-nowrap text-right ${balance > 0 ? 'text-amber-600' : 'text-gray-400'}`}>
                            {balance > 0.005 ? formatCurrency(balance, displayCurrency) : '—'}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap"><StatusBadge status={inv.status} /></td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="flex items-center gap-1">
                              <button onClick={() => setViewInvoice(inv)} title="View" className="p-1.5 rounded-lg text-gray-400 hover:text-teal-600 hover:bg-teal-50 transition-colors"><Eye className="w-3.5 h-3.5" /></button>
                              <button onClick={() => { setEditInvoice(inv); setShowForm(true); }} title="Edit" className="p-1.5 rounded-lg text-gray-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"><Pencil className="w-3.5 h-3.5" /></button>
                              {inv.type === 'invoice' && inv.status !== 'paid' && inv.status !== 'cancelled' && (
                                <button onClick={() => setPaymentInvoice(inv)} title="Record Payment" className="p-1.5 rounded-lg text-gray-400 hover:text-emerald-600 hover:bg-emerald-50 transition-colors"><DollarSign className="w-3.5 h-3.5" /></button>
                              )}
                              <button onClick={() => handleDelete(inv.id)} title="Delete" className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}

      {/* Invoice Form Modal */}
      {showForm && (
        <InvoiceFormModal
          type={activeType}
          invoice={editInvoice}
          projects={projects}
          invoices={invoices.filter((i) => i.type === 'invoice')}
          userId={user!.id}
          onClose={() => { setShowForm(false); setEditInvoice(null); }}
          onSaved={fetchData}
        />
      )}

      {/* View Invoice Modal */}
      {viewInvoice && (
        <InvoiceViewModal
          invoice={viewInvoice}
          displayCurrency={displayCurrency}
          rates={rates}
          bankAccounts={bankAccounts}
          onClose={() => setViewInvoice(null)}
          onRefresh={fetchData}
        />
      )}

      {/* Record Payment Modal */}
      {paymentInvoice && (
        <RecordPaymentModal
          invoice={paymentInvoice}
          bankAccounts={bankAccounts}
          userId={user!.id}
          displayCurrency={displayCurrency}
          rates={rates}
          onClose={() => setPaymentInvoice(null)}
          onSaved={() => { setPaymentInvoice(null); fetchData(); }}
        />
      )}
    </div>
  );
}

// ── KPI Card ───────────────────────────────────────────────────────────────────

function KpiCard({ label, value, suffix, color }: { label: string; value: string; suffix?: string; color: string }) {
  const colors: Record<string, string> = {
    emerald: 'border-emerald-100 text-emerald-600',
    teal: 'border-teal-100 text-teal-600',
    amber: 'border-amber-100 text-amber-600',
    red: 'border-red-100 text-red-600',
    gray: 'border-gray-100 text-gray-400',
  };
  return (
    <div className={`bg-white rounded-2xl border shadow-sm p-5 ${colors[color] ?? colors.gray}`}>
      <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">{label}</p>
      <p className={`text-xl font-bold ${colors[color]?.split(' ')[1]}`}>{value}</p>
      {suffix && <p className="text-xs text-gray-400 mt-0.5">{suffix}</p>}
    </div>
  );
}

// ── Project Report ─────────────────────────────────────────────────────────────

function ProjectReport({
  invoices, projects, conv, displayCurrency,
}: {
  invoices: Invoice[];
  projects: Project[];
  conv: (a: number, from: string) => number;
  displayCurrency: string;
}) {
  const rows = projects.map((p) => {
    const pInvs = invoices.filter((i) => i.project?.id === p.id && i.type === 'invoice');
    const pCNs  = invoices.filter((i) => i.project?.id === p.id && i.type === 'credit_note');
    const billed   = pInvs.reduce((s, i) => s + conv(i.total, i.currency), 0);
    const credits  = pCNs.reduce((s, i) => s + conv(i.total, i.currency), 0);
    const received = pInvs.reduce((s, i) => s + conv(i.paid_amount, i.currency), 0);
    const balance  = billed - received - credits;
    return { project: p, billed, received, credits, balance, count: pInvs.length };
  }).filter((r) => r.billed > 0 || r.count > 0);

  const unlinked = invoices.filter((i) => !i.project && i.type === 'invoice');
  const ulBilled   = unlinked.reduce((s, i) => s + conv(i.total, i.currency), 0);
  const ulReceived = unlinked.reduce((s, i) => s + conv(i.paid_amount, i.currency), 0);

  const grandBilled   = rows.reduce((s, r) => s + r.billed, 0) + ulBilled;
  const grandReceived = rows.reduce((s, r) => s + r.received, 0) + ulReceived;
  const grandBalance  = rows.reduce((s, r) => s + r.balance, 0) + (ulBilled - ulReceived);

  if (rows.length === 0 && unlinked.length === 0) {
    return (
      <div className="bg-white rounded-2xl border border-gray-100 p-14 text-center">
        <BarChart3 className="w-12 h-12 text-gray-200 mx-auto mb-3" />
        <p className="font-semibold text-gray-500">No project data yet</p>
        <p className="text-sm text-gray-400 mt-1">Create invoices linked to projects to see reports here.</p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KpiCard label="Total Invoiced" value={formatCurrency(grandBilled, displayCurrency)} color="emerald" />
        <KpiCard label="Total Received" value={formatCurrency(grandReceived, displayCurrency)} color="teal" />
        <KpiCard label="Net Outstanding" value={formatCurrency(grandBalance, displayCurrency)} color={grandBalance > 0 ? 'amber' : 'gray'} />
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="px-5 py-4 bg-gray-50 border-b border-gray-100 flex items-center gap-2">
          <Building2 className="w-4 h-4 text-teal-500" />
          <h4 className="font-bold text-gray-800 text-sm">Project-Wise Income Summary</h4>
          <span className="ml-auto text-xs text-gray-400">All amounts in {displayCurrency}</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100">
                {['Project', 'Invoices', 'Total Billed', 'Credit Notes', 'Received', 'Outstanding', '% Collected'].map((h) => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {rows.map((r) => {
                const pct = r.billed > 0 ? ((r.received / r.billed) * 100) : 0;
                return (
                  <tr key={r.project.id} className="hover:bg-gray-50/60 transition-colors">
                    <td className="px-4 py-3 font-medium text-gray-900">
                      <div>{r.project.project_code && <span className="text-xs text-gray-400 mr-1">[{r.project.project_code}]</span>}{r.project.name}</div>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-teal-100 text-teal-700 text-xs font-bold">{r.count}</span>
                    </td>
                    <td className="px-4 py-3 font-semibold text-gray-800 text-right whitespace-nowrap">{formatCurrency(r.billed, displayCurrency)}</td>
                    <td className="px-4 py-3 text-blue-600 text-right whitespace-nowrap">{r.credits > 0 ? formatCurrency(r.credits, displayCurrency) : '—'}</td>
                    <td className="px-4 py-3 text-emerald-600 font-medium text-right whitespace-nowrap">{formatCurrency(r.received, displayCurrency)}</td>
                    <td className={`px-4 py-3 font-semibold text-right whitespace-nowrap ${r.balance > 0.01 ? 'text-amber-600' : 'text-gray-400'}`}>
                      {r.balance > 0.01 ? formatCurrency(r.balance, displayCurrency) : '—'}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-100 rounded-full h-1.5 min-w-[60px]">
                          <div className="h-1.5 rounded-full bg-emerald-500 transition-all" style={{ width: `${Math.min(pct, 100)}%` }} />
                        </div>
                        <span className="text-xs text-gray-500 w-10 text-right">{pct.toFixed(0)}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {unlinked.length > 0 && (
                <tr className="hover:bg-gray-50/60 transition-colors opacity-60">
                  <td className="px-4 py-3 text-gray-500 italic">Unlinked invoices</td>
                  <td className="px-4 py-3 text-center"><span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-gray-100 text-gray-500 text-xs font-bold">{unlinked.length}</span></td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">{formatCurrency(ulBilled, displayCurrency)}</td>
                  <td className="px-4 py-3 text-right">—</td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">{formatCurrency(ulReceived, displayCurrency)}</td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">{formatCurrency(ulBilled - ulReceived, displayCurrency)}</td>
                  <td className="px-4 py-3">—</td>
                </tr>
              )}
            </tbody>
            <tfoot>
              <tr className="bg-gray-50 border-t-2 border-gray-200 font-bold">
                <td className="px-4 py-3 text-gray-700">Total</td>
                <td />
                <td className="px-4 py-3 text-right text-gray-800">{formatCurrency(grandBilled, displayCurrency)}</td>
                <td />
                <td className="px-4 py-3 text-right text-emerald-700">{formatCurrency(grandReceived, displayCurrency)}</td>
                <td className={`px-4 py-3 text-right ${grandBalance > 0 ? 'text-amber-700' : 'text-gray-400'}`}>{formatCurrency(grandBalance, displayCurrency)}</td>
                <td className="px-4 py-3 text-right text-gray-600 text-sm">{grandBilled > 0 ? `${((grandReceived / grandBilled) * 100).toFixed(0)}%` : '—'}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── Invoice Form Modal ─────────────────────────────────────────────────────────

function InvoiceFormModal({
  type, invoice, projects, invoices, userId, onClose, onSaved,
}: {
  type: 'invoice' | 'credit_note';
  invoice: Invoice | null;
  projects: Project[];
  invoices: Invoice[];
  userId: string;
  onClose: () => void;
  onSaved: () => void;
}) {
  const isEdit = !!invoice;
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    project_id: invoice?.project?.id ?? '',
    client_name: invoice?.client_name ?? '',
    issue_date: invoice?.issue_date ?? new Date().toISOString().split('T')[0],
    due_date: invoice?.due_date ?? '',
    currency: invoice?.currency ?? DEFAULT_CURRENCY,
    tax_rate: invoice?.tax_rate ?? 5,
    notes: invoice?.notes ?? '',
    linked_invoice_id: invoice?.linked_invoice_id ?? '',
    status: invoice?.status ?? 'draft',
  });
  const [items, setItems] = useState<InvoiceItem[]>(
    invoice?.items && invoice.items.length > 0
      ? invoice.items
      : [{ description: '', quantity: 1, unit_price: 0 }]
  );
  const [invoiceNumber, setInvoiceNumber] = useState(invoice?.invoice_number ?? '');
  const [loadingNumber, setLoadingNumber] = useState(!isEdit);

  useEffect(() => {
    if (!isEdit) {
      supabase.rpc('next_invoice_number', { p_type: type, p_user_id: userId }).then(({ data }) => {
        if (data) setInvoiceNumber(data);
        setLoadingNumber(false);
      });
    } else if (invoice?.items === undefined) {
      supabase.from('accounts_invoice_items')
        .select('id,description,quantity,unit_price,sort_order')
        .eq('invoice_id', invoice.id)
        .order('sort_order')
        .then(({ data }) => {
          if (data?.length) setItems(data);
        });
    }
  }, []);

  const subtotal = items.reduce((s, i) => s + i.quantity * i.unit_price, 0);
  const taxAmt   = subtotal * (form.tax_rate / 100);
  const total    = subtotal + taxAmt;

  const updateItem = (idx: number, field: keyof InvoiceItem, val: string | number) => {
    setItems((prev) => prev.map((it, i) => i === idx ? { ...it, [field]: val } : it));
  };

  const handleSave = async () => {
    if (!invoiceNumber.trim()) return;
    setSaving(true);
    const payload = {
      user_id: userId,
      type,
      invoice_number: invoiceNumber,
      project_id: form.project_id || null,
      client_name: form.client_name || null,
      issue_date: form.issue_date,
      due_date: form.due_date || null,
      currency: form.currency,
      subtotal,
      tax_rate: form.tax_rate,
      tax_amount: taxAmt,
      total,
      notes: form.notes || null,
      linked_invoice_id: form.linked_invoice_id || null,
      status: form.status,
      updated_at: new Date().toISOString(),
    };

    let invId = invoice?.id;
    if (isEdit) {
      await supabase.from('accounts_invoices').update(payload).eq('id', invId!);
      await supabase.from('accounts_invoice_items').delete().eq('invoice_id', invId!);
    } else {
      const { data } = await supabase.from('accounts_invoices').insert(payload).select('id').single();
      invId = data?.id;
    }

    if (invId) {
      await supabase.from('accounts_invoice_items').insert(
        items.filter((i) => i.description.trim()).map((it, idx) => ({
          invoice_id: invId,
          description: it.description,
          quantity: it.quantity,
          unit_price: it.unit_price,
          sort_order: idx,
        }))
      );
    }
    setSaving(false);
    onSaved();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[95vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-gray-100 flex-shrink-0">
          <div>
            <h3 className="font-bold text-gray-900">{isEdit ? 'Edit' : 'New'} {type === 'credit_note' ? 'Credit Note' : 'Invoice'}</h3>
            <p className="text-xs text-gray-500 mt-0.5">{type === 'credit_note' ? 'Create credit note against an invoice' : 'Create invoice for project billing'}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100"><X className="w-5 h-5 text-gray-500" /></button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Top fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
                {type === 'credit_note' ? 'Credit Note #' : 'Invoice #'} *
              </label>
              <input value={invoiceNumber} onChange={(e) => setInvoiceNumber(e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 font-mono"
                disabled={loadingNumber} placeholder={loadingNumber ? 'Generating…' : ''} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Project</label>
              <select value={form.project_id} onChange={(e) => setForm({ ...form, project_id: e.target.value })}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400">
                <option value="">— No Project —</option>
                {projects.map((p) => <option key={p.id} value={p.id}>{p.project_code ? `[${p.project_code}] ` : ''}{p.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Client Name</label>
              <input value={form.client_name} onChange={(e) => setForm({ ...form, client_name: e.target.value })}
                placeholder="Client / Company" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Issue Date *</label>
              <input type="date" value={form.issue_date} onChange={(e) => setForm({ ...form, issue_date: e.target.value })}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Due Date</label>
              <input type="date" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Currency</label>
              <select value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400">
                {SUPPORTED_CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            {type === 'credit_note' && (
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Linked Invoice</label>
                <select value={form.linked_invoice_id} onChange={(e) => setForm({ ...form, linked_invoice_id: e.target.value })}
                  className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400">
                  <option value="">— None —</option>
                  {invoices.map((i) => <option key={i.id} value={i.id}>{i.invoice_number} – {i.client_name ?? 'No client'}</option>)}
                </select>
              </div>
            )}
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Status</label>
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as Invoice['status'] })}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400">
                {Object.entries(STATUS_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
            </div>
          </div>

          {/* Line items */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Line Items</label>
              <button onClick={() => setItems((p) => [...p, { description: '', quantity: 1, unit_price: 0 }])}
                className="text-xs text-teal-600 hover:text-teal-700 font-medium flex items-center gap-1">
                <Plus className="w-3.5 h-3.5" />Add Line
              </button>
            </div>
            <div className="border border-gray-200 rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase">Description</th>
                    <th className="px-3 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase w-20">Qty</th>
                    <th className="px-3 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase w-32">Unit Price</th>
                    <th className="px-3 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase w-32">Amount</th>
                    <th className="w-8" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {items.map((item, idx) => (
                    <tr key={idx}>
                      <td className="px-3 py-2">
                        <input value={item.description} onChange={(e) => updateItem(idx, 'description', e.target.value)}
                          placeholder="Description…" className="w-full text-sm border-none outline-none bg-transparent" />
                      </td>
                      <td className="px-3 py-2">
                        <input type="number" value={item.quantity} min={0} step="any"
                          onChange={(e) => updateItem(idx, 'quantity', parseFloat(e.target.value) || 0)}
                          className="w-full text-sm text-right border-none outline-none bg-transparent" />
                      </td>
                      <td className="px-3 py-2">
                        <input type="number" value={item.unit_price} min={0} step="any"
                          onChange={(e) => updateItem(idx, 'unit_price', parseFloat(e.target.value) || 0)}
                          className="w-full text-sm text-right border-none outline-none bg-transparent" />
                      </td>
                      <td className="px-3 py-2 text-right text-sm font-medium text-gray-700">
                        {formatCurrency(item.quantity * item.unit_price, form.currency)}
                      </td>
                      <td className="px-2 py-2">
                        <button onClick={() => setItems((p) => p.filter((_, i) => i !== idx))} disabled={items.length === 1}
                          className="p-1 rounded text-gray-300 hover:text-red-500 disabled:opacity-30 transition-colors">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {/* Totals */}
              <div className="bg-gray-50 border-t border-gray-200 px-4 py-3 space-y-1.5">
                <div className="flex justify-between text-sm text-gray-600">
                  <span>Subtotal</span><span className="font-medium">{formatCurrency(subtotal, form.currency)}</span>
                </div>
                <div className="flex justify-between items-center text-sm text-gray-600">
                  <span className="flex items-center gap-2">
                    VAT
                    <input type="number" value={form.tax_rate} min={0} max={100} step="0.1"
                      onChange={(e) => setForm({ ...form, tax_rate: parseFloat(e.target.value) || 0 })}
                      className="w-14 px-2 py-0.5 border border-gray-200 rounded text-xs text-right focus:outline-none focus:ring-1 focus:ring-teal-400" />
                    %
                  </span>
                  <span className="font-medium">{formatCurrency(taxAmt, form.currency)}</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-gray-900 pt-1 border-t border-gray-200">
                  <span>Total</span><span className="text-teal-700 text-base">{formatCurrency(total, form.currency)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Notes</label>
            <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2}
              placeholder="Payment terms, bank details, remarks…"
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 resize-none" />
          </div>
        </div>

        <div className="flex-shrink-0 flex gap-3 p-5 border-t border-gray-100">
          <button onClick={onClose} className="flex-1 px-4 py-2.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors">Cancel</button>
          <button onClick={handleSave} disabled={saving || !invoiceNumber.trim()} className="flex-1 px-4 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white rounded-xl text-sm font-semibold hover:from-teal-600 hover:to-blue-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2">
            {saving && <Loader2 className="w-4 h-4 animate-spin" />}
            {isEdit ? 'Save Changes' : `Create ${type === 'credit_note' ? 'Credit Note' : 'Invoice'}`}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Invoice View Modal ─────────────────────────────────────────────────────────

function InvoiceViewModal({
  invoice, displayCurrency, rates, bankAccounts, onClose, onRefresh,
}: {
  invoice: Invoice;
  displayCurrency: string;
  rates: Record<string, number>;
  bankAccounts: BankAccount[];
  onClose: () => void;
  onRefresh: () => void;
}) {
  const [items, setItems] = useState<InvoiceItem[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);

  const conv = (a: number, from: string) => convertCurrency(a, from, displayCurrency, rates);

  useEffect(() => {
    Promise.all([
      supabase.from('accounts_invoice_items').select('id,description,quantity,unit_price').eq('invoice_id', invoice.id).order('sort_order'),
      supabase.from('accounts_payments').select('id,payment_date,amount,currency,reference,notes,bank_account:bank_accounts(id,name,currency)').eq('invoice_id', invoice.id).order('payment_date'),
    ]).then(([iRes, pRes]) => {
      setItems((iRes.data ?? []) as InvoiceItem[]);
      setPayments((pRes.data ?? []) as unknown as Payment[]);
      setLoading(false);
    });
  }, [invoice.id]);

  const handleDeletePayment = async (id: string) => {
    await supabase.from('accounts_payments').delete().eq('id', id);
    onRefresh();
    const { data } = await supabase.from('accounts_payments').select('id,payment_date,amount,currency,reference,notes,bank_account:bank_accounts(id,name,currency)').eq('invoice_id', invoice.id).order('payment_date');
    setPayments((data ?? []) as unknown as Payment[]);
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[95vh] flex flex-col">
        <div className="flex items-center justify-between p-5 border-b border-gray-100 flex-shrink-0">
          <div>
            <div className="flex items-center gap-3">
              <h3 className="font-bold text-gray-900 font-mono">{invoice.invoice_number}</h3>
              <StatusBadge status={invoice.status} />
            </div>
            <p className="text-xs text-gray-500 mt-0.5">{invoice.client_name ?? ''} {invoice.project ? `· ${invoice.project.name}` : ''}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100"><X className="w-5 h-5 text-gray-500" /></button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {loading ? (
            <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-teal-500" /></div>
          ) : (
            <>
              {/* Meta */}
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div><p className="text-xs text-gray-400 uppercase font-semibold mb-0.5">Issue Date</p><p className="font-medium text-gray-700">{fmtDate(invoice.issue_date)}</p></div>
                <div><p className="text-xs text-gray-400 uppercase font-semibold mb-0.5">Due Date</p><p className="font-medium text-gray-700">{fmtDate(invoice.due_date)}</p></div>
                <div><p className="text-xs text-gray-400 uppercase font-semibold mb-0.5">Currency</p><p className="font-semibold text-teal-600">{invoice.currency}</p></div>
              </div>

              {/* Line items */}
              {items.length > 0 && (
                <div className="rounded-xl border border-gray-100 overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50 border-b border-gray-100">
                      <tr>
                        <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase">Description</th>
                        <th className="px-4 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase w-16">Qty</th>
                        <th className="px-4 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase w-28">Unit Price</th>
                        <th className="px-4 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase w-28">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {items.map((item, i) => (
                        <tr key={i}>
                          <td className="px-4 py-2.5 text-gray-700">{item.description}</td>
                          <td className="px-4 py-2.5 text-right text-gray-600">{item.quantity}</td>
                          <td className="px-4 py-2.5 text-right text-gray-600">{formatCurrency(item.unit_price, invoice.currency)}</td>
                          <td className="px-4 py-2.5 text-right font-medium text-gray-800">{formatCurrency(item.quantity * item.unit_price, invoice.currency)}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-gray-50 border-t border-gray-100">
                      <tr><td colSpan={3} className="px-4 py-2 text-right text-xs text-gray-500">Subtotal</td><td className="px-4 py-2 text-right font-medium">{formatCurrency(invoice.subtotal, invoice.currency)}</td></tr>
                      <tr><td colSpan={3} className="px-4 py-2 text-right text-xs text-gray-500">VAT ({invoice.tax_rate}%)</td><td className="px-4 py-2 text-right font-medium">{formatCurrency(invoice.tax_amount, invoice.currency)}</td></tr>
                      <tr className="font-bold text-gray-900"><td colSpan={3} className="px-4 py-2.5 text-right text-sm">Total</td><td className="px-4 py-2.5 text-right text-teal-700">{formatCurrency(invoice.total, invoice.currency)}</td></tr>
                    </tfoot>
                  </table>
                </div>
              )}

              {/* Balance summary */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-gray-50 rounded-xl p-3 text-center">
                  <p className="text-xs text-gray-400 uppercase font-semibold mb-0.5">Total</p>
                  <p className="font-bold text-gray-800">{formatCurrency(conv(invoice.total, invoice.currency), displayCurrency)}</p>
                </div>
                <div className="bg-emerald-50 rounded-xl p-3 text-center">
                  <p className="text-xs text-gray-400 uppercase font-semibold mb-0.5">Paid</p>
                  <p className="font-bold text-emerald-600">{formatCurrency(conv(invoice.paid_amount, invoice.currency), displayCurrency)}</p>
                </div>
                <div className={`rounded-xl p-3 text-center ${invoice.total - invoice.paid_amount > 0.01 ? 'bg-amber-50' : 'bg-gray-50'}`}>
                  <p className="text-xs text-gray-400 uppercase font-semibold mb-0.5">Balance</p>
                  <p className={`font-bold ${invoice.total - invoice.paid_amount > 0.01 ? 'text-amber-600' : 'text-gray-400'}`}>
                    {formatCurrency(conv(invoice.total - invoice.paid_amount, invoice.currency), displayCurrency)}
                  </p>
                </div>
              </div>

              {/* Payments */}
              {payments.length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Payment History</p>
                  <div className="space-y-2">
                    {payments.map((p) => (
                      <div key={p.id} className="flex items-center gap-3 p-3 bg-emerald-50/60 border border-emerald-100 rounded-xl">
                        <CheckCircle className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-800">{formatCurrency(p.amount, p.currency)}</p>
                          <p className="text-xs text-gray-500">{fmtDate(p.payment_date)} {p.bank_account ? `· ${p.bank_account.name}` : ''} {p.reference ? `· Ref: ${p.reference}` : ''}</p>
                        </div>
                        <button onClick={() => handleDeletePayment(p.id)} className="p-1 rounded text-gray-300 hover:text-red-500 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Notes */}
              {invoice.notes && (
                <div className="p-3 bg-gray-50 rounded-xl">
                  <p className="text-xs text-gray-400 uppercase font-semibold mb-1">Notes</p>
                  <p className="text-sm text-gray-600">{invoice.notes}</p>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Record Payment Modal ───────────────────────────────────────────────────────

function RecordPaymentModal({
  invoice, bankAccounts, userId, displayCurrency, rates, onClose, onSaved,
}: {
  invoice: Invoice;
  bankAccounts: BankAccount[];
  userId: string;
  displayCurrency: string;
  rates: Record<string, number>;
  onClose: () => void;
  onSaved: () => void;
}) {
  const balance = invoice.total - invoice.paid_amount;
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    payment_date: new Date().toISOString().split('T')[0],
    amount: balance.toFixed(2),
    currency: invoice.currency,
    bank_account_id: bankAccounts[0]?.id ?? '',
    reference: '',
    notes: '',
  });

  const conv = (a: number, from: string) => convertCurrency(a, from, displayCurrency, rates);

  const handleSave = async () => {
    setSaving(true);
    await supabase.from('accounts_payments').insert({
      invoice_id: invoice.id,
      user_id: userId,
      payment_date: form.payment_date,
      amount: parseFloat(form.amount) || 0,
      currency: form.currency,
      bank_account_id: form.bank_account_id || null,
      reference: form.reference || null,
      notes: form.notes || null,
    });
    setSaving(false);
    onSaved();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div>
            <h3 className="font-bold text-gray-900">Record Payment</h3>
            <p className="text-xs text-gray-500 mt-0.5">{invoice.invoice_number} · Balance: {formatCurrency(conv(balance, invoice.currency), displayCurrency)}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100"><X className="w-5 h-5 text-gray-500" /></button>
        </div>
        <div className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Payment Date *</label>
              <input type="date" value={form.payment_date} onChange={(e) => setForm({ ...form, payment_date: e.target.value })}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Currency</label>
              <select value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400">
                {SUPPORTED_CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Amount *</label>
            <input type="number" value={form.amount} min={0} step="any"
              onChange={(e) => setForm({ ...form, amount: e.target.value })}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400" />
          </div>
          {bankAccounts.length > 0 && (
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Bank Account</label>
              <select value={form.bank_account_id} onChange={(e) => setForm({ ...form, bank_account_id: e.target.value })}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400">
                <option value="">— Not specified —</option>
                {bankAccounts.map((a) => <option key={a.id} value={a.id}>{a.name} ({a.currency})</option>)}
              </select>
            </div>
          )}
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Reference</label>
            <input value={form.reference} onChange={(e) => setForm({ ...form, reference: e.target.value })}
              placeholder="Cheque #, transfer ref…"
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Notes</label>
            <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400 resize-none" />
          </div>
        </div>
        <div className="flex gap-3 p-5 border-t border-gray-100">
          <button onClick={onClose} className="flex-1 px-4 py-2.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors">Cancel</button>
          <button onClick={handleSave} disabled={saving || !form.amount || parseFloat(form.amount) <= 0}
            className="flex-1 px-4 py-2.5 bg-emerald-600 text-white rounded-xl text-sm font-semibold hover:bg-emerald-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
            {saving && <Loader2 className="w-4 h-4 animate-spin" />}
            Record Payment
          </button>
        </div>
      </div>
    </div>
  );
}
