import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { logAudit } from './WorkforceEmployees';
import type { WFEmployee } from './WorkforceEmployees';
import {
  Clock, Plus, X, Search, Loader2, AlertCircle, CheckCircle2,
  RefreshCw, Info, Users, Download, Edit2, Save, Lock, Unlock, Send,
  Plane, Stethoscope, Star, Briefcase, RotateCcw, ChevronDown, ChevronUp, Trash2,
} from 'lucide-react';

type Project = { id: string; name: string };
type PostedRecord = { id: string; posted_at: string; posted_by_name: string | null; notes: string | null };
type AllProjEntry = { project: Project; rows: AllocationRow[]; posted: PostedRecord | null };

type WorkScheduleDay = { day_of_week: number; normal_hours: number; is_working_day: boolean };
type ProjectWeeklyRow = { project_id: string; day_of_week: number; normal_hours: number; is_working_day: boolean };
type DateOverride = { date_from: string; date_to: string; normal_hours: number; project_id: string | null };

type AttendanceStatus = 'present' | 'leave' | 'sick_leave' | 'public_holiday' | 'annual_leave' | 'compensation_leave';

const ATTENDANCE_META: Record<AttendanceStatus, { label: string; short: string; color: string; bg: string; icon: React.ElementType }> = {
  present:            { label: 'Present',             short: 'P',   color: 'text-teal-700',   bg: 'bg-teal-50 border-teal-200',    icon: CheckCircle2 },
  leave:              { label: 'Leave',                short: 'L',   color: 'text-gray-600',   bg: 'bg-gray-100 border-gray-200',   icon: X },
  sick_leave:         { label: 'Sick Leave',           short: 'SL',  color: 'text-red-700',    bg: 'bg-red-50 border-red-200',      icon: Stethoscope },
  public_holiday:     { label: 'Public Holiday',       short: 'PH',  color: 'text-blue-700',   bg: 'bg-blue-50 border-blue-200',    icon: Star },
  annual_leave:       { label: 'Annual Leave',         short: 'AL',  color: 'text-amber-700',  bg: 'bg-amber-50 border-amber-200',  icon: Plane },
  compensation_leave: { label: 'Compensation Leave',   short: 'CL',  color: 'text-purple-700', bg: 'bg-purple-50 border-purple-200',icon: RotateCcw },
};

type AllocationRow = {
  id: string | null;
  employee_id: string;
  employee_code: string;
  employee_name: string;
  designation: string | null;
  trade: string | null;
  attendance_status: AttendanceStatus;
  start_time: string;
  end_time: string;
  break_minutes: number;
  notes: string;
  saving: boolean;
  saved: boolean;
  error: string | null;
};

function calcWorkingHours(start: string, end: string, breakMins: number): number | null {
  if (!start || !end) return null;
  const parts = (s: string) => s.split(':').map(Number);
  const [sh, sm] = parts(start);
  const [eh, em] = parts(end);
  if ([sh, sm, eh, em].some(isNaN)) return null;
  const totalMins = (eh * 60 + em) - (sh * 60 + sm) - Math.max(0, breakMins || 0);
  return totalMins > 0 ? Math.round(totalMins * 100 / 60) / 100 : 0;
}

function splitHours(totalHours: number | null, normalHours: number): { regular: number; ot: number } {
  if (totalHours === null || totalHours <= 0) return { regular: 0, ot: 0 };
  const regular = Math.min(totalHours, normalHours);
  const ot = Math.max(0, totalHours - normalHours);
  return {
    regular: Math.round(regular * 100) / 100,
    ot: Math.round(ot * 100) / 100,
  };
}

// OT attribution for a single project when the employee also works at other projects.
// Cross-project hours are treated as consuming regular-time capacity first, so only
// the remaining capacity before the daily threshold applies to this project's hours.
function splitHoursForProject(projectHrs: number | null, crossHrs: number, normalHours: number): { regular: number; ot: number } {
  if (projectHrs === null || projectHrs <= 0) return { regular: 0, ot: 0 };
  const remainingNormal = Math.max(0, normalHours - Math.min(crossHrs, normalHours));
  return {
    regular: Math.round(Math.min(projectHrs, remainingNormal) * 100) / 100,
    ot:      Math.round(Math.max(0, projectHrs - remainingNormal) * 100) / 100,
  };
}

function fmtDate(d: string) {
  const [y, m, day] = d.split('-');
  return `${day}/${m}/${y}`;
}

function exportDayCSV(project: Project, date: string, rows: AllocationRow[]) {
  const header = ['#', 'Code', 'Employee', 'Designation', 'Trade', 'Status', 'Start', 'End', 'Break (min)', 'Working Hours', 'Notes'];
  const data = rows.map((r, i) => {
    const hrs = calcWorkingHours(r.start_time, r.end_time, r.break_minutes);
    return [
      i + 1, r.employee_code,
      `"${r.employee_name.replace(/"/g, '""')}"`,
      r.designation ?? '', r.trade ?? '',
      ATTENDANCE_META[r.attendance_status]?.label ?? r.attendance_status,
      r.start_time || '', r.end_time || '',
      r.break_minutes,
      hrs !== null ? hrs.toFixed(2) : '',
      `"${(r.notes || '').replace(/"/g, '""')}"`,
    ];
  });
  const total = rows.filter((r) => r.attendance_status === 'present').reduce((s, r) => s + (calcWorkingHours(r.start_time, r.end_time, r.break_minutes) ?? 0), 0);
  data.push(['', '', '', '', '', '', '', 'TOTAL', '', total.toFixed(2), '']);

  const blob = new Blob([[header, ...data].map((r) => r.join(',')).join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `workforce-${project.name.replace(/\s+/g, '-')}-${date}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export function WorkforceDailyAllocation() {
  const { teamMember, isAdmin, isTimeKeeper } = useAuth();
  const today = new Date().toISOString().split('T')[0];

  const [projects, setProjects]               = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [selectedDate, setSelectedDate]       = useState(today);
  const [rows, setRows]                       = useState<AllocationRow[]>([]);
  const [loading, setLoading]                 = useState(false);
  const [showAddModal, setShowAddModal]       = useState(false);
  const [showBulkModal, setShowBulkModal]     = useState(false);
  const [showPostModal, setShowPostModal]     = useState(false);
  const [projectsLoading, setProjectsLoading] = useState(true);
  const [workSchedule, setWorkSchedule]       = useState<WorkScheduleDay[]>([]);
  const [projectWeekly, setProjectWeekly]     = useState<ProjectWeeklyRow[]>([]);
  const [dateOverrides, setDateOverrides]     = useState<DateOverride[]>([]);
  const [postedRecord, setPostedRecord]       = useState<PostedRecord | null>(null);
  const [posting, setPosting]                 = useState(false);
  const [crossProjectHours, setCrossProjectHours] = useState<Map<string, number>>(new Map());

  // Bulk selection (admin only)
  const [selectedRowIds, setSelectedRowIds] = useState<Set<string>>(new Set());
  const [bulkDeleting, setBulkDeleting]     = useState(false);

  // All-projects mode (admin only)
  const [allProjectsData, setAllProjectsData]       = useState<AllProjEntry[]>([]);
  const [allProjectsLoading, setAllProjectsLoading] = useState(false);
  const [expandedProjectIds, setExpandedProjectIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!teamMember) return;
    const fetchProjects = async () => {
      setProjectsLoading(true);
      if (isAdmin) {
        const { data } = await supabase.from('projects').select('id,name').order('name');
        const list = (data ?? []) as Project[];
        setProjects(list);
        if (list[0]) setSelectedProject(list[0]);
      } else {
        const { data } = await supabase
          .from('project_members')
          .select('projects(id,name)')
          .eq('team_member_id', teamMember.id);
        const list = ((data ?? []).map((d: any) => d.projects).filter(Boolean)) as Project[];
        setProjects(list);
        if (list[0]) setSelectedProject(list[0]);
      }
      setProjectsLoading(false);
    };
    fetchProjects();
    // Fetch work schedule + overrides
    Promise.all([
      supabase.from('work_schedule').select('day_of_week,normal_hours,is_working_day').order('day_of_week'),
      supabase.from('work_schedule_project_weekly').select('project_id,day_of_week,normal_hours,is_working_day'),
      supabase.from('work_schedule_date_overrides').select('date_from,date_to,normal_hours,project_id'),
    ]).then(([ws, pw, do_]) => {
      if (ws.data) setWorkSchedule(ws.data as WorkScheduleDay[]);
      if (pw.data) setProjectWeekly(pw.data as ProjectWeeklyRow[]);
      if (do_.data) setDateOverrides(do_.data as DateOverride[]);
    });
  }, [teamMember, isAdmin]);

  const fetchAllAllocations = useCallback(async () => {
    if (!isAdmin) return;
    setAllProjectsLoading(true);

    const [allocResult, postedResult] = await Promise.all([
      supabase
        .from('workforce_daily_allocations')
        .select('*, employee:workforce_employees(id,employee_code,name,designation,trade)')
        .eq('entry_date', selectedDate)
        .order('created_at'),
      supabase
        .from('posted_allocations')
        .select('id,project_id,posted_at,posted_by_name,notes')
        .eq('entry_date', selectedDate),
    ]);

    const byProject = new Map<string, AllocationRow[]>();
    for (const d of (allocResult.data ?? []) as any[]) {
      const pid: string = d.project_id;
      if (!byProject.has(pid)) byProject.set(pid, []);
      byProject.get(pid)!.push({
        id: d.id,
        employee_id: d.employee_id,
        employee_code: d.employee?.employee_code ?? '',
        employee_name: d.employee?.name ?? '',
        designation: d.employee?.designation ?? null,
        trade: d.employee?.trade ?? null,
        attendance_status: (d.attendance_status as AttendanceStatus) ?? 'present',
        start_time: d.start_time ? d.start_time.slice(0, 5) : '',
        end_time: d.end_time ? d.end_time.slice(0, 5) : '',
        break_minutes: d.break_minutes ?? 0,
        notes: d.notes ?? '',
        saving: false, saved: true, error: null,
      });
    }

    const postedByProject = new Map<string, PostedRecord>(
      ((postedResult.data ?? []) as any[]).map((p) => [p.project_id, p as PostedRecord])
    );

    const projectMap = new Map(projects.map((p) => [p.id, p]));
    const entries: AllProjEntry[] = [];
    for (const [pid, rows] of byProject) {
      const project = projectMap.get(pid);
      if (!project) continue;
      entries.push({ project, rows, posted: postedByProject.get(pid) ?? null });
    }
    entries.sort((a, b) => a.project.name.localeCompare(b.project.name));

    setAllProjectsData(entries);
    setAllProjectsLoading(false);
  }, [isAdmin, selectedDate, projects]);

  const fetchAllocations = useCallback(async () => {
    if (!selectedProject) return;
    setLoading(true);

    // Fetch existing allocation records for this project+date
    const [allocResult, postedResult] = await Promise.all([
      supabase
        .from('workforce_daily_allocations')
        .select('*, employee:workforce_employees(id,employee_code,name,designation,trade)')
        .eq('project_id', selectedProject.id)
        .eq('entry_date', selectedDate)
        .order('created_at'),
      supabase
        .from('posted_allocations')
        .select('id,posted_at,posted_by_name,notes')
        .eq('project_id', selectedProject.id)
        .eq('entry_date', selectedDate)
        .maybeSingle(),
    ]);

    setPostedRecord(postedResult.data as PostedRecord | null);

    const existing: AllocationRow[] = (allocResult.data ?? []).map((d: any) => ({
      id: d.id,
      employee_id: d.employee_id,
      employee_code: d.employee?.employee_code ?? '',
      employee_name: d.employee?.name ?? '',
      designation: d.employee?.designation ?? null,
      trade: d.employee?.trade ?? null,
      attendance_status: (d.attendance_status as AttendanceStatus) ?? 'present',
      start_time: d.start_time ? d.start_time.slice(0, 5) : '',
      end_time: d.end_time ? d.end_time.slice(0, 5) : '',
      break_minutes: d.break_minutes ?? 0,
      notes: d.notes ?? '',
      saving: false, saved: true, error: null,
    }));

    // Auto-populate assigned employees who don't yet have an entry for this date.
    // Only applies to team-member / time-keeper submissions, not admin review.
    let autoRows: AllocationRow[] = [];
    if (!isAdmin) {
      const { data: assignments } = await supabase
        .from('workforce_project_employees')
        .select('employee:workforce_employees(id,employee_code,name,designation,trade)')
        .eq('project_id', selectedProject.id);

      const assignedEmployees = ((assignments ?? [])
        .map((a: any) => a.employee)
        .filter(Boolean)) as WFEmployee[];

      const existingIds = new Set(existing.map((r) => r.employee_id));
      autoRows = assignedEmployees
        .filter((e) => !existingIds.has(e.id))
        .map((e) => ({
          id: null,
          employee_id: e.id,
          employee_code: e.employee_code,
          employee_name: e.name,
          designation: e.designation ?? null,
          trade: e.trade ?? null,
          attendance_status: 'present' as AttendanceStatus,
          start_time: '', end_time: '', break_minutes: 0, notes: '',
          saving: false, saved: false, error: null,
        }));
    }

    setRows([...existing, ...autoRows]);

    // Fetch hours the same employees logged at OTHER projects today, so OT is
    // calculated on the full daily total rather than per-project hours alone.
    const allEmpIds = [...new Set([...existing.map((r) => r.employee_id), ...autoRows.map((r) => r.employee_id)])];
    if (allEmpIds.length > 0) {
      const { data: crossData } = await supabase
        .from('workforce_daily_allocations')
        .select('employee_id, start_time, end_time, break_minutes')
        .eq('entry_date', selectedDate)
        .eq('attendance_status', 'present')
        .neq('project_id', selectedProject!.id)
        .in('employee_id', allEmpIds);
      const crossMap = new Map<string, number>();
      for (const c of (crossData ?? []) as any[]) {
        if (!c.start_time || !c.end_time) continue;
        const h = calcWorkingHours(c.start_time.slice(0, 5), c.end_time.slice(0, 5), c.break_minutes ?? 0) ?? 0;
        crossMap.set(c.employee_id, Math.round(((crossMap.get(c.employee_id) ?? 0) + h) * 100) / 100);
      }
      setCrossProjectHours(crossMap);
    } else {
      setCrossProjectHours(new Map());
    }

    setLoading(false);
  }, [selectedProject, selectedDate, isAdmin]);

  useEffect(() => {
    if (!projectsLoading && selectedProject) fetchAllocations();
  }, [projectsLoading, selectedProject, selectedDate, fetchAllocations]);

  const allProjectsMode = isAdmin && selectedProject === null;

  useEffect(() => {
    if (allProjectsMode && !projectsLoading) fetchAllAllocations();
  }, [allProjectsMode, selectedDate, projectsLoading, fetchAllAllocations]);

  const toggleExpandedProject = (id: string) =>
    setExpandedProjectIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  const isToday = selectedDate === today;
  const isPosted = !!postedRecord;
  const canEdit   = !isTimeKeeper && !isPosted && (isAdmin || isToday);
  const canRemove = !isPosted || isAdmin;

  const updateRow = (idx: number, fields: Partial<AllocationRow>) =>
    setRows((prev) => prev.map((r, i) => i === idx ? { ...r, ...fields, saved: false } : r));

  const saveRow = async (idx: number) => {
    const row = rows[idx];
    if (!row || row.saving || (row.saved && row.id !== null)) return;
    updateRow(idx, { saving: true, error: null });

    const payload = {
      project_id: selectedProject!.id,
      employee_id: row.employee_id,
      entry_date: selectedDate,
      attendance_status: row.attendance_status,
      start_time: row.attendance_status === 'present' ? (row.start_time || null) : null,
      end_time: row.attendance_status === 'present' ? (row.end_time || null) : null,
      break_minutes: row.attendance_status === 'present' ? row.break_minutes : 0,
      notes: row.notes || null,
      updated_by: teamMember?.id ?? null,
    };

    if (row.id) {
      const { error } = await supabase
        .from('workforce_daily_allocations').update(payload).eq('id', row.id);
      if (error) { updateRow(idx, { saving: false, error: error.message }); return; }
      logAudit('UPDATE', 'workforce_daily_allocations', row.id,
        `${row.employee_name} @ ${selectedProject!.name} ${fmtDate(selectedDate)}`,
        teamMember?.id, teamMember?.name, undefined, payload);
    } else {
      const { data, error } = await supabase
        .from('workforce_daily_allocations')
        .insert({ ...payload, created_by: teamMember?.id ?? null })
        .select('id').single();
      if (error) { updateRow(idx, { saving: false, error: error.message }); return; }
      logAudit('INSERT', 'workforce_daily_allocations', data.id,
        `${row.employee_name} @ ${selectedProject!.name} ${fmtDate(selectedDate)}`,
        teamMember?.id, teamMember?.name, undefined, payload);
      setRows((prev) => prev.map((r, i) => i === idx ? { ...r, id: data.id } : r));
    }
    setRows((prev) => prev.map((r, i) => i === idx ? { ...r, saving: false, saved: true } : r));
  };

  const handleFieldBlur = (idx: number) => {
    const row = rows[idx];
    if (row && !row.saved) saveRow(idx);
  };

  const removeRow = async (idx: number) => {
    const row = rows[idx];
    if (isPosted && isAdmin) {
      if (!confirm(`Delete ${row.employee_name}'s entry from this posted day? This action cannot be undone.`)) return;
    }
    if (row.id) {
      await supabase.from('workforce_daily_allocations').delete().eq('id', row.id);
      logAudit('DELETE', 'workforce_daily_allocations', row.id,
        `${row.employee_name} @ ${selectedProject!.name} ${fmtDate(selectedDate)}`,
        teamMember?.id, teamMember?.name);
    }
    setRows((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleEmployeeAdded = (emp: WFEmployee) => {
    if (rows.some((r) => r.employee_id === emp.id)) return;
    setRows((prev) => [...prev, {
      id: null,
      employee_id: emp.id,
      employee_code: emp.employee_code,
      employee_name: emp.name,
      designation: emp.designation,
      trade: emp.trade,
      attendance_status: 'present' as AttendanceStatus,
      start_time: '', end_time: '', break_minutes: 0, notes: '',
      saving: false, saved: false, error: null,
    }]);
  };

  const handleBulkApply = async (start: string, end: string, breakMins: number) => {
    setShowBulkModal(false);
    // Apply times to all rows and save each to DB
    const updated = rows.map((r) => ({ ...r, start_time: start, end_time: end, break_minutes: breakMins, saved: false, saving: true }));
    setRows(updated);

    const saves = updated.map(async (row, idx) => {
      const payload = {
        project_id: selectedProject!.id,
        employee_id: row.employee_id,
        entry_date: selectedDate,
        attendance_status: row.attendance_status,
        start_time: start || null,
        end_time: end || null,
        break_minutes: breakMins,
        notes: row.notes || null,
        updated_by: teamMember?.id ?? null,
      };
      let newId = row.id;
      if (row.id) {
        await supabase.from('workforce_daily_allocations').update(payload).eq('id', row.id);
        logAudit('UPDATE', 'workforce_daily_allocations', row.id,
          `Bulk: ${row.employee_name} @ ${selectedProject!.name} ${fmtDate(selectedDate)}`,
          teamMember?.id, teamMember?.name, undefined, payload);
      } else {
        const { data } = await supabase
          .from('workforce_daily_allocations')
          .insert({ ...payload, created_by: teamMember?.id ?? null })
          .select('id').single();
        if (data) {
          newId = data.id;
          logAudit('INSERT', 'workforce_daily_allocations', data.id,
            `Bulk: ${row.employee_name} @ ${selectedProject!.name} ${fmtDate(selectedDate)}`,
            teamMember?.id, teamMember?.name, undefined, payload);
        }
      }
      return { idx, newId };
    });

    const results = await Promise.all(saves);
    setRows((prev) => prev.map((r, i) => {
      const res = results.find((x) => x.idx === i);
      return res ? { ...r, id: res.newId, saving: false, saved: true } : r;
    }));
  };

  const handlePost = async (notes: string) => {
    if (!selectedProject || posting) return;
    setPosting(true);
    // First save all unsaved rows
    const unsaved = rows.filter((r) => !r.saved || r.id === null);
    if (unsaved.length > 0) {
      await Promise.all(rows.map((_, idx) => {
        const r = rows[idx];
        if (!r.saved || r.id === null) return saveRow(idx);
        return Promise.resolve();
      }));
    }
    const { data, error } = await supabase
      .from('posted_allocations')
      .insert({
        project_id: selectedProject.id,
        entry_date: selectedDate,
        posted_by: teamMember?.id ?? null,
        posted_by_name: teamMember?.name ?? null,
        notes: notes || null,
      })
      .select('id,posted_at,posted_by_name,notes')
      .single();
    if (!error && data) {
      setPostedRecord(data as PostedRecord);
      logAudit('INSERT', 'posted_allocations', data.id,
        `Posted: ${selectedProject.name} ${fmtDate(selectedDate)}`,
        teamMember?.id, teamMember?.name, undefined, { notes });
    }
    setPosting(false);
    setShowPostModal(false);
  };

  const handleUnpost = async () => {
    if (!selectedProject || !postedRecord) return;
    setPosting(true);
    await supabase.from('posted_allocations').delete().eq('id', postedRecord.id);
    logAudit('DELETE', 'posted_allocations', postedRecord.id,
      `Unposted: ${selectedProject.name} ${fmtDate(selectedDate)}`,
      teamMember?.id, teamMember?.name);
    setPostedRecord(null);
    setPosting(false);
  };

  const handleBulkDelete = async () => {
    if (!isAdmin || selectedRowIds.size === 0) return;
    const count = selectedRowIds.size;
    if (!confirm(`Delete ${count} selected record${count > 1 ? 's' : ''} from this allocation? This cannot be undone.`)) return;
    setBulkDeleting(true);
    const ids = Array.from(selectedRowIds);
    await supabase.from('workforce_daily_allocations').delete().in('id', ids);
    logAudit('DELETE', 'workforce_daily_allocations', ids[0],
      `Bulk delete: ${count} records @ ${selectedProject?.name ?? ''} ${fmtDate(selectedDate)}`,
      teamMember?.id, teamMember?.name);
    setRows((prev) => prev.filter((r) => !r.id || !selectedRowIds.has(r.id)));
    setSelectedRowIds(new Set());
    setBulkDeleting(false);
  };

  // Clear selection when project or date changes
  useEffect(() => { setSelectedRowIds(new Set()); }, [selectedProject, selectedDate]);

  const totalHours = rows.filter((r) => r.attendance_status === 'present').reduce((sum, r) => sum + (calcWorkingHours(r.start_time, r.end_time, r.break_minutes) ?? 0), 0);
  const unsavedCount = rows.filter((r) => !r.saved && !r.saving).length;
  const presentCount = rows.filter((r) => r.attendance_status === 'present').length;
  const absentCount  = rows.filter((r) => r.attendance_status !== 'present').length;

  // Priority-based normal hours: date override (project) > date override (global) > project override > day-of-week default
  function getNormalHours(dateStr: string, projectId: string | null): number {
    const dow = new Date(dateStr + 'T00:00:00').getDay();
    const dateMatch = (ov: DateOverride) => dateStr >= ov.date_from && dateStr <= ov.date_to;
    // 1. Project-specific date override
    const pdOv = dateOverrides.find((ov) => dateMatch(ov) && ov.project_id === projectId);
    if (pdOv) return pdOv.normal_hours;
    // 2. Global date override
    const gdOv = dateOverrides.find((ov) => dateMatch(ov) && !ov.project_id);
    if (gdOv) return gdOv.normal_hours;
    // 3. Project weekly schedule
    if (projectId) {
      const pw = projectWeekly.find((r) => r.project_id === projectId && r.day_of_week === dow);
      if (pw) return pw.normal_hours;
    }
    // 4. Global day-of-week default
    return workSchedule.find((s) => s.day_of_week === dow)?.normal_hours ?? 0;
  }

  const normalHoursForDay = getNormalHours(selectedDate, selectedProject?.id ?? null);
  const scheduleDay = workSchedule.find((s) => s.day_of_week === new Date(selectedDate + 'T00:00:00').getDay());

  const { totalRegHours, totalOTHours } = rows
    .filter((r) => r.attendance_status === 'present')
    .reduce((acc, r) => {
      const hrs = calcWorkingHours(r.start_time, r.end_time, r.break_minutes) ?? 0;
      const crossHrs = crossProjectHours.get(r.employee_id) ?? 0;
      const { regular, ot } = splitHoursForProject(hrs, crossHrs, normalHoursForDay);
      return { totalRegHours: acc.totalRegHours + regular, totalOTHours: acc.totalOTHours + ot };
    }, { totalRegHours: 0, totalOTHours: 0 });

  if (projectsLoading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-7 h-7 animate-spin text-teal-500" />
    </div>
  );

  if (projects.length === 0) return (
    <div className="bg-white rounded-2xl border border-gray-100 p-14 text-center">
      <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
      <p className="font-semibold text-gray-600">No projects assigned</p>
      <p className="text-sm text-gray-400 mt-1">Contact your admin to be assigned to a project.</p>
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-bold text-gray-900 text-lg">Daily Workforce Allocation</h3>
          <p className="text-sm text-gray-500 mt-0.5">
            {allProjectsMode
              ? `${allProjectsData.length} project${allProjectsData.length !== 1 ? 's' : ''} · ${allProjectsData.reduce((s, e) => s + e.rows.filter((r) => r.attendance_status === 'present').length, 0)} present`
              : (<>{presentCount} present{absentCount > 0 && <span className="text-amber-600"> · {absentCount} on leave</span>} ·{' '}
                <span className="text-teal-600 font-medium">{totalRegHours.toFixed(2)}h reg</span>
                {totalOTHours > 0 && <span className="text-orange-600 font-medium"> + {totalOTHours.toFixed(2)}h OT</span>}
                {scheduleDay && (
                  <span className="text-gray-400 ml-1">
                    ({scheduleDay.is_working_day ? `${normalHoursForDay}h normal` : 'Rest day — all hours OT'})
                  </span>
                )}</>)
            }
          </p>
        </div>
        <div className="flex items-center gap-2">
          {isAdmin && selectedRowIds.size > 0 && (
            <button
              onClick={handleBulkDelete}
              disabled={bulkDeleting}
              className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white font-semibold rounded-xl text-sm shadow-sm hover:bg-red-600 disabled:opacity-60 transition-all"
            >
              {bulkDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              Delete {selectedRowIds.size} Selected
            </button>
          )}
          {rows.length > 0 && selectedProject && (
            <button
              onClick={() => exportDayCSV(selectedProject, selectedDate, rows)}
              className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 text-gray-600 font-medium rounded-xl text-sm hover:border-teal-300 hover:text-teal-600 transition-all"
            >
              <Download className="w-4 h-4" />Export
            </button>
          )}
          {canEdit && rows.length > 0 && (
            <button
              onClick={() => setShowBulkModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-white border-2 border-teal-400 text-teal-700 font-medium rounded-xl text-sm hover:bg-teal-50 transition-all"
            >
              <Edit2 className="w-4 h-4" />Set Time for All
            </button>
          )}
          {canEdit && (
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm shadow-sm hover:from-teal-600 hover:to-blue-700 transition-all"
            >
              <Plus className="w-4 h-4" />Add Employee
            </button>
          )}
          {canEdit && rows.length > 0 && (
            <button
              onClick={() => setShowPostModal(true)}
              disabled={posting}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-semibold rounded-xl text-sm shadow-sm hover:from-emerald-600 hover:to-teal-700 disabled:opacity-60 transition-all"
            >
              {posting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              Save &amp; Post
            </button>
          )}
          {isAdmin && isPosted && (
            <button
              onClick={handleUnpost}
              disabled={posting}
              className="flex items-center gap-2 px-4 py-2 bg-white border-2 border-amber-400 text-amber-700 font-semibold rounded-xl text-sm hover:bg-amber-50 disabled:opacity-60 transition-all"
            >
              {posting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Unlock className="w-4 h-4" />}
              Unpost
            </button>
          )}
        </div>
      </div>

      {/* Posted banner — single project only */}
      {!allProjectsMode && isPosted && postedRecord && (
        <div className="flex items-center gap-3 px-4 py-3 bg-emerald-50 border border-emerald-200 rounded-xl text-sm text-emerald-800">
          <Lock className="w-4 h-4 flex-shrink-0 text-emerald-600" />
          <div className="flex-1">
            <span className="font-semibold">Posted</span>
            {' — '}posted by <span className="font-medium">{postedRecord.posted_by_name ?? 'Admin'}</span>
            {' on '}
            <span className="font-medium">{new Date(postedRecord.posted_at).toLocaleString()}</span>
            {postedRecord.notes && <span className="text-emerald-700 ml-2">· {postedRecord.notes}</span>}
          </div>
          {isAdmin && (
            <span className="text-xs text-emerald-600 font-medium">Editing locked · Delete individual rows or Unpost to make full changes</span>
          )}
        </div>
      )}

      {/* Controls bar */}
      <div className="bg-white border border-gray-200 rounded-2xl p-4">
        <div className="flex flex-wrap gap-4 items-end">
          <div className="flex-1 min-w-[200px]">
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Project</label>
            <select
              value={selectedProject?.id ?? ''}
              onChange={(e) => {
                const val = e.target.value;
                setSelectedProject(val === '' ? null : (projects.find((p) => p.id === val) ?? null));
              }}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400"
            >
              {isAdmin && <option value="">All Projects</option>}
              {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
              Date{!isAdmin && <span className="text-amber-500 font-normal normal-case ml-1">(today only)</span>}
            </label>
            <input
              type="date"
              value={selectedDate}
              disabled={!isAdmin}
              onChange={(e) => setSelectedDate(e.target.value)}
              className={`px-3 py-2.5 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 ${!isAdmin ? 'border-gray-200 bg-gray-50 text-gray-500 cursor-not-allowed' : 'border-gray-200'}`}
            />
          </div>
          <button
            onClick={allProjectsMode ? fetchAllAllocations : fetchAllocations}
            className="flex items-center gap-1.5 px-3 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:border-teal-300 hover:text-teal-600 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />Refresh
          </button>
        </div>

        {!isAdmin && !isToday && (
          <div className="mt-3 flex items-start gap-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
            <Info className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
            You can only add or edit allocations for today. Past records are view-only.
          </div>
        )}
      </div>

      {/* Unsaved indicator — single project only */}
      {!allProjectsMode && unsavedCount > 0 && (
        <div className="flex items-center gap-3 px-4 py-2.5 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800">
          <Info className="w-4 h-4 flex-shrink-0" />
          {unsavedCount} unsaved row{unsavedCount > 1 ? 's' : ''} — changes save automatically when you leave a field.
        </div>
      )}

      {/* All Projects view */}
      {allProjectsMode && (
        allProjectsLoading ? (
          <div className="bg-white rounded-2xl border border-gray-100 p-12 flex items-center justify-center">
            <Loader2 className="w-6 h-6 animate-spin text-teal-500" />
          </div>
        ) : allProjectsData.length === 0 ? (
          <div className="bg-white rounded-2xl border border-gray-100 p-14 text-center">
            <Clock className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="font-semibold text-gray-600">No allocations found</p>
            <p className="text-sm text-gray-400 mt-1">No workforce data has been submitted for this date across any project.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {/* Summary strip */}
            <div className="flex flex-wrap gap-4 px-1 text-sm text-gray-500">
              <span><span className="font-semibold text-gray-800">{allProjectsData.length}</span> projects</span>
              <span>
                <span className="font-semibold text-teal-700">
                  {allProjectsData.reduce((s, e) => s + e.rows.filter((r) => r.attendance_status === 'present').length, 0)}
                </span> present
              </span>
              <span>
                <span className="font-semibold text-teal-700">
                  {allProjectsData.reduce((s, e) => s + e.rows.reduce((rs, r) => {
                    if (r.attendance_status !== 'present') return rs;
                    return rs + (calcWorkingHours(r.start_time, r.end_time, r.break_minutes) ?? 0);
                  }, 0), 0).toFixed(1)}h
                </span> total
              </span>
              {allProjectsData.filter((e) => !e.posted).length > 0 && (
                <span>
                  <span className="font-semibold text-amber-600">{allProjectsData.filter((e) => !e.posted).length}</span> not yet posted
                </span>
              )}
            </div>

            {/* Per-project collapsible cards */}
            {allProjectsData.map((entry) => {
              const isExpanded = expandedProjectIds.has(entry.project.id);
              const presentRows = entry.rows.filter((r) => r.attendance_status === 'present');
              const totalHrs = presentRows.reduce((s, r) => s + (calcWorkingHours(r.start_time, r.end_time, r.break_minutes) ?? 0), 0);
              return (
                <div key={entry.project.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                  <div
                    onClick={() => toggleExpandedProject(entry.project.id)}
                    className="flex items-center gap-4 px-5 py-4 cursor-pointer hover:bg-gray-50/60 transition-colors select-none"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-gray-900">{entry.project.name}</span>
                        {entry.posted ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-full text-xs font-semibold">
                            <Lock className="w-3 h-3" />Posted
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-100 text-amber-700 rounded-full text-xs font-semibold">
                            <Unlock className="w-3 h-3" />Not Posted
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {entry.rows.length} employees · <span className="text-teal-600 font-medium">{presentRows.length} present</span>
                        {totalHrs > 0 && <span className="text-gray-500"> · {totalHrs.toFixed(1)}h total</span>}
                        {entry.posted && (
                          <span className="ml-2">· Posted by {entry.posted.posted_by_name ?? 'Admin'} on {new Date(entry.posted.posted_at).toLocaleString()}</span>
                        )}
                      </p>
                    </div>
                    <div className="flex-shrink-0">
                      {isExpanded
                        ? <ChevronUp className="w-5 h-5 text-teal-500" />
                        : <ChevronDown className="w-5 h-5 text-gray-400" />}
                    </div>
                  </div>

                  {isExpanded && (
                    <div className="border-t border-gray-100 overflow-x-auto">
                      <table className="w-full text-sm min-w-[680px]">
                        <thead>
                          <tr className="bg-gray-50 border-b border-gray-100">
                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-400 uppercase tracking-wide w-8">#</th>
                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Employee</th>
                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide w-36">Status</th>
                            <th className="px-4 py-2.5 text-center text-xs font-semibold text-gray-500 uppercase tracking-wide w-20">Start</th>
                            <th className="px-4 py-2.5 text-center text-xs font-semibold text-gray-500 uppercase tracking-wide w-20">End</th>
                            <th className="px-4 py-2.5 text-center text-xs font-semibold text-teal-600 uppercase tracking-wide w-24">Hours</th>
                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Notes</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                          {entry.rows.map((row, idx) => {
                            const isPresent = row.attendance_status === 'present';
                            const hrs = isPresent ? (calcWorkingHours(row.start_time, row.end_time, row.break_minutes) ?? 0) : null;
                            const meta = ATTENDANCE_META[row.attendance_status];
                            return (
                              <tr key={row.id ?? idx} className={`hover:bg-gray-50/40 ${!isPresent ? 'opacity-60' : ''}`}>
                                <td className="px-4 py-2.5 text-xs text-gray-400">{idx + 1}</td>
                                <td className="px-4 py-2.5">
                                  <p className="font-semibold text-gray-900">{row.employee_name}</p>
                                  <p className="text-xs text-gray-400">{row.employee_code}{row.designation ? ` · ${row.designation}` : ''}</p>
                                </td>
                                <td className="px-4 py-2.5">
                                  <span className={`inline-flex items-center gap-1 px-2 py-0.5 border rounded-full text-xs font-semibold ${meta.bg} ${meta.color}`}>
                                    <meta.icon className="w-3 h-3" />{meta.short}
                                  </span>
                                </td>
                                <td className="px-4 py-2.5 text-center text-sm text-gray-600">{row.start_time || '—'}</td>
                                <td className="px-4 py-2.5 text-center text-sm text-gray-600">{row.end_time || '—'}</td>
                                <td className="px-4 py-2.5 text-center">
                                  {hrs !== null
                                    ? <span className="font-bold text-teal-700">{hrs.toFixed(2)}h</span>
                                    : <span className="text-gray-300">—</span>}
                                </td>
                                <td className="px-4 py-2.5 text-sm text-gray-500">{row.notes || '—'}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                        <tfoot>
                          <tr className="bg-teal-50/50 border-t border-teal-100">
                            <td colSpan={5} className="px-4 py-2 text-xs font-semibold text-teal-700 text-right">
                              Total — {presentRows.length} present
                            </td>
                            <td className="px-4 py-2 text-center font-bold text-teal-800">{totalHrs.toFixed(2)}h</td>
                            <td />
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )
      )}

      {/* Allocation table — single project */}
      {!allProjectsMode && loading ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-12 flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-teal-500" />
        </div>
      ) : rows.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-14 text-center">
          <Clock className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="font-semibold text-gray-600">
            {isAdmin ? 'No timesheet submitted' : 'No employees allocated'}
          </p>
          <p className="text-sm text-gray-400 mt-1">
            {isAdmin
              ? 'No timesheet has been posted for this project and date.'
              : canEdit ? 'Click "Add Employee" to begin the daily roster.' : 'No allocation was recorded for this date.'}
          </p>
          {canEdit && (
            <button
              onClick={() => setShowAddModal(true)}
              className="mt-4 inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white rounded-xl text-sm font-medium"
            >
              <Plus className="w-4 h-4" />Add Employee
            </button>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[960px]">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  {isAdmin && (
                    <th className="px-3 py-3 w-10">
                      <input
                        type="checkbox"
                        className="w-4 h-4 rounded border-gray-300 text-teal-600 focus:ring-teal-400 cursor-pointer"
                        checked={selectedRowIds.size > 0 && rows.filter((r) => r.id).every((r) => selectedRowIds.has(r.id!))}
                        ref={(el) => {
                          if (el) el.indeterminate = selectedRowIds.size > 0 && !rows.filter((r) => r.id).every((r) => selectedRowIds.has(r.id!));
                        }}
                        onChange={(e) => {
                          const selectableIds = rows.filter((r) => r.id).map((r) => r.id!);
                          setSelectedRowIds(e.target.checked ? new Set(selectableIds) : new Set());
                        }}
                        title="Select all"
                      />
                    </th>
                  )}
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide w-8">#</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Employee</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide w-40">Status</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide w-28">Start Time</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide w-28">End Time</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide w-24">Break (min)</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-teal-600 uppercase tracking-wide w-20">Reg Hrs</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-orange-500 uppercase tracking-wide w-20">OT Hrs</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Notes</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-500 uppercase tracking-wide w-16"></th>
                  {canRemove && <th className="px-4 py-3 w-12" />}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {rows.map((row, idx) => {
                  const isPresent = row.attendance_status === 'present';
                  const hrs = isPresent ? calcWorkingHours(row.start_time, row.end_time, row.break_minutes) : null;
                  const crossHrs = crossProjectHours.get(row.employee_id) ?? 0;
                  const { regular, ot } = splitHoursForProject(hrs, crossHrs, normalHoursForDay);
                  const meta = ATTENDANCE_META[row.attendance_status];
                  const isSelected = !!row.id && selectedRowIds.has(row.id);
                  return (
                    <tr key={row.employee_id} className={`${isSelected ? 'bg-red-50/40' : (!row.saved ? 'bg-amber-50/20' : '')} ${!isPresent ? 'opacity-75' : ''} hover:bg-gray-50/50 transition-colors`}>
                      {isAdmin && (
                        <td className="px-3 py-3 text-center">
                          {row.id ? (
                            <input
                              type="checkbox"
                              className="w-4 h-4 rounded border-gray-300 text-teal-600 focus:ring-teal-400 cursor-pointer"
                              checked={isSelected}
                              onChange={(e) => {
                                setSelectedRowIds((prev) => {
                                  const next = new Set(prev);
                                  e.target.checked ? next.add(row.id!) : next.delete(row.id!);
                                  return next;
                                });
                              }}
                            />
                          ) : <span className="w-4 h-4 inline-block" />}
                        </td>
                      )}
                      <td className="px-4 py-3 text-gray-400 text-xs font-medium">{idx + 1}</td>
                      <td className="px-4 py-3">
                        <p className="font-semibold text-gray-900">{row.employee_name}</p>
                        <p className="text-xs text-gray-400">
                          {row.employee_code}{row.designation ? ` · ${row.designation}` : ''}{row.trade ? ` · ${row.trade}` : ''}
                        </p>
                      </td>
                      <td className="px-2 py-2.5">
                        {canEdit ? (
                          <select
                            value={row.attendance_status}
                            onChange={(e) => {
                              updateRow(idx, { attendance_status: e.target.value as AttendanceStatus });
                              setTimeout(() => handleFieldBlur(idx), 0);
                            }}
                            className={`w-full px-2 py-1.5 border rounded-lg text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-teal-400 ${meta.bg} ${meta.color}`}
                          >
                            {(Object.entries(ATTENDANCE_META) as [AttendanceStatus, typeof ATTENDANCE_META[AttendanceStatus]][]).map(([k, v]) => (
                              <option key={k} value={k}>{v.label}</option>
                            ))}
                          </select>
                        ) : (
                          <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-semibold border ${meta.bg} ${meta.color}`}>
                            <meta.icon className="w-3 h-3" />{meta.label}
                          </span>
                        )}
                      </td>
                      <td className="px-2 py-2.5">
                        <input
                          type="time"
                          value={row.start_time}
                          disabled={!canEdit || !isPresent}
                          onChange={(e) => updateRow(idx, { start_time: e.target.value })}
                          onBlur={() => handleFieldBlur(idx)}
                          className="w-full px-2 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-teal-400 disabled:bg-gray-50 disabled:text-gray-300 disabled:cursor-not-allowed"
                        />
                      </td>
                      <td className="px-2 py-2.5">
                        <input
                          type="time"
                          value={row.end_time}
                          disabled={!canEdit || !isPresent}
                          onChange={(e) => updateRow(idx, { end_time: e.target.value })}
                          onBlur={() => handleFieldBlur(idx)}
                          className="w-full px-2 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-teal-400 disabled:bg-gray-50 disabled:text-gray-300 disabled:cursor-not-allowed"
                        />
                      </td>
                      <td className="px-2 py-2.5">
                        <input
                          type="number"
                          min="0"
                          value={row.break_minutes === 0 ? '' : row.break_minutes}
                          disabled={!canEdit || !isPresent}
                          onChange={(e) => updateRow(idx, { break_minutes: Math.max(0, parseInt(e.target.value) || 0) })}
                          onBlur={(e) => { updateRow(idx, { break_minutes: Math.max(0, parseInt(e.target.value) || 0) }); handleFieldBlur(idx); }}
                          placeholder="0"
                          className="w-full px-2 py-1.5 border border-gray-200 rounded-lg text-sm text-center focus:outline-none focus:ring-1 focus:ring-teal-400 disabled:bg-gray-50 disabled:text-gray-300 disabled:cursor-not-allowed"
                        />
                      </td>
                      <td className="px-4 py-3 text-center">
                        {!isPresent ? (
                          <span className="text-gray-300 text-sm">—</span>
                        ) : hrs !== null ? (
                          <span className="font-bold text-sm text-teal-700">{regular.toFixed(2)}</span>
                        ) : (
                          <span className="text-gray-300 text-sm">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-center">
                        {!isPresent ? (
                          <span className="text-gray-300 text-sm">—</span>
                        ) : hrs !== null ? (
                          ot > 0
                            ? <span className="font-bold text-sm text-orange-600">{ot.toFixed(2)}</span>
                            : <span className="text-gray-300 text-sm">—</span>
                        ) : (
                          <span className="text-gray-300 text-sm">—</span>
                        )}
                      </td>
                      <td className="px-2 py-2.5">
                        <input
                          type="text"
                          value={row.notes}
                          disabled={!canEdit}
                          onChange={(e) => updateRow(idx, { notes: e.target.value })}
                          onBlur={() => handleFieldBlur(idx)}
                          placeholder="Optional notes…"
                          className="w-full px-2 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-teal-400 disabled:bg-gray-50 disabled:text-gray-400 disabled:cursor-not-allowed"
                        />
                      </td>
                      <td className="px-4 py-3 text-center">
                        {row.saving ? (
                          <Loader2 className="w-4 h-4 animate-spin text-teal-500 mx-auto" />
                        ) : row.error ? (
                          <span title={row.error}>
                            <AlertCircle className="w-4 h-4 text-red-500 mx-auto cursor-help" />
                          </span>
                        ) : row.saved && row.id ? (
                          <CheckCircle2 className="w-4 h-4 text-green-500 mx-auto" />
                        ) : (
                          <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" title="Unsaved" />
                        )}
                      </td>
                      {canRemove && (
                        <td className="px-3 py-3 text-center">
                          <button
                            onClick={() => removeRow(idx)}
                            className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                            title="Remove"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
              {rows.length > 0 && (
                <tfoot>
                  <tr className="bg-gradient-to-r from-teal-50 to-blue-50 border-t-2 border-teal-100">
                    <td colSpan={isAdmin ? 7 : 6} className="px-4 py-3 text-right text-xs font-bold text-teal-700 uppercase tracking-wide">
                      Totals — {presentCount} present{absentCount > 0 ? `, ${absentCount} on leave` : ''}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className="font-bold text-base text-teal-800">{totalRegHours.toFixed(2)}</span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      {totalOTHours > 0
                        ? <span className="font-bold text-base text-orange-700">{totalOTHours.toFixed(2)}</span>
                        : <span className="text-gray-300">—</span>}
                    </td>
                    <td colSpan={canRemove ? 3 : 2} />                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>
      )}

      {showAddModal && selectedProject && (
        <AddEmployeeModal
          projectId={selectedProject.id}
          isAdmin={isAdmin}
          excludeIds={rows.map((r) => r.employee_id)}
          onClose={() => setShowAddModal(false)}
          onAdd={(emp) => { handleEmployeeAdded(emp); setShowAddModal(false); }}
        />
      )}

      {showBulkModal && selectedProject && (
        <BulkTimeEntryModal
          projectName={selectedProject.name}
          employeeCount={rows.length}
          currentStart={rows[0]?.start_time ?? ''}
          currentEnd={rows[0]?.end_time ?? ''}
          currentBreak={rows[0]?.break_minutes ?? 0}
          onClose={() => setShowBulkModal(false)}
          onApply={handleBulkApply}
        />
      )}

      {showPostModal && selectedProject && (
        <PostAllocationModal
          projectName={selectedProject.name}
          date={selectedDate}
          presentCount={presentCount}
          absentCount={absentCount}
          totalRegHours={totalRegHours}
          totalOTHours={totalOTHours}
          unsavedCount={unsavedCount}
          posting={posting}
          onClose={() => setShowPostModal(false)}
          onPost={handlePost}
        />
      )}
    </div>
  );
}

/* ── Bulk Time Entry Modal ───────────────────────────────────── */
function BulkTimeEntryModal({
  projectName, employeeCount, currentStart, currentEnd, currentBreak, onClose, onApply,
}: {
  projectName: string;
  employeeCount: number;
  currentStart: string;
  currentEnd: string;
  currentBreak: number;
  onClose: () => void;
  onApply: (start: string, end: string, breakMins: number) => void;
}) {
  const [start,  setStart]  = useState(currentStart);
  const [end,    setEnd]    = useState(currentEnd);
  const [brk,    setBrk]    = useState(String(currentBreak));

  const hrs = calcWorkingHours(start, end, parseInt(brk) || 0);

  const inp = 'w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400';
  const lbl = 'block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5';

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-teal-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
              <Edit2 className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Set Time for All Employees</h3>
              <p className="text-xs text-gray-500 mt-0.5">
                {projectName} · {employeeCount} employee{employeeCount !== 1 ? 's' : ''}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 flex items-start gap-2">
            <Info className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
            This will overwrite the start time, end time, and break for all {employeeCount} employee{employeeCount !== 1 ? 's' : ''} in today's roster.
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={lbl}>Start Time</label>
              <input type="time" value={start} onChange={(e) => setStart(e.target.value)} className={inp} />
            </div>
            <div>
              <label className={lbl}>End Time</label>
              <input type="time" value={end} onChange={(e) => setEnd(e.target.value)} className={inp} />
            </div>
          </div>

          <div>
            <label className={lbl}>Break (minutes)</label>
            <input
              type="number" min="0" step="5"
              value={brk} onChange={(e) => setBrk(e.target.value)}
              className={inp}
            />
          </div>

          {hrs !== null && (
            <div className="flex items-center justify-between px-4 py-3 bg-teal-50 border border-teal-200 rounded-xl">
              <span className="text-sm text-teal-700 font-medium">Working hours per employee</span>
              <span className={`text-lg font-bold ${hrs >= 8 ? 'text-teal-700' : hrs >= 4 ? 'text-blue-700' : 'text-amber-700'}`}>
                {hrs.toFixed(2)}h
              </span>
            </div>
          )}

          <div className="flex items-center gap-3 pt-1">
            <button
              onClick={() => onApply(start, end, parseInt(brk) || 0)}
              disabled={!start || !end}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm disabled:opacity-50 hover:from-teal-600 hover:to-blue-700 transition-all"
            >
              <Save className="w-4 h-4" />Apply to All {employeeCount} Employees
            </button>
            <button onClick={onClose} className="px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Post Allocation Modal ───────────────────────────────────── */
function PostAllocationModal({
  projectName, date, presentCount, absentCount,
  totalRegHours, totalOTHours, unsavedCount, posting, onClose, onPost,
}: {
  projectName: string;
  date: string;
  presentCount: number;
  absentCount: number;
  totalRegHours: number;
  totalOTHours: number;
  unsavedCount: number;
  posting: boolean;
  onClose: () => void;
  onPost: (notes: string) => void;
}) {
  const [notes, setNotes] = useState('');

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center flex-shrink-0">
              <Send className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Save &amp; Post Allocation</h3>
              <p className="text-xs text-gray-500 mt-0.5">{projectName} · {fmtDate(date)}</p>
            </div>
          </div>
          <button onClick={onClose} disabled={posting} className="p-2 rounded-lg hover:bg-gray-100 disabled:opacity-50">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Summary */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-teal-50 border border-teal-100 rounded-xl px-4 py-3">
              <p className="text-xs text-teal-600 font-medium uppercase tracking-wide">Present</p>
              <p className="text-2xl font-bold text-teal-800 mt-0.5">{presentCount}</p>
            </div>
            <div className="bg-gray-50 border border-gray-100 rounded-xl px-4 py-3">
              <p className="text-xs text-gray-500 font-medium uppercase tracking-wide">On Leave</p>
              <p className="text-2xl font-bold text-gray-700 mt-0.5">{absentCount}</p>
            </div>
            <div className="bg-blue-50 border border-blue-100 rounded-xl px-4 py-3">
              <p className="text-xs text-blue-600 font-medium uppercase tracking-wide">Regular Hours</p>
              <p className="text-2xl font-bold text-blue-800 mt-0.5">{totalRegHours.toFixed(2)}<span className="text-sm font-normal ml-1">h</span></p>
            </div>
            <div className="bg-orange-50 border border-orange-100 rounded-xl px-4 py-3">
              <p className="text-xs text-orange-600 font-medium uppercase tracking-wide">Overtime Hours</p>
              <p className="text-2xl font-bold text-orange-800 mt-0.5">{totalOTHours.toFixed(2)}<span className="text-sm font-normal ml-1">h</span></p>
            </div>
          </div>

          {unsavedCount > 0 && (
            <div className="flex items-start gap-2 text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2.5">
              <Info className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
              {unsavedCount} unsaved row{unsavedCount > 1 ? 's' : ''} will be saved automatically before posting.
            </div>
          )}

          <div className="flex items-start gap-2 text-xs text-blue-800 bg-blue-50 border border-blue-200 rounded-xl px-3 py-2.5">
            <Lock className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
            Posting locks this day's allocation. Editing will be disabled until an admin unposted it.
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
              Post Notes <span className="text-gray-300 font-normal normal-case">(optional)</span>
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Any remarks for this posting…"
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400 resize-none"
            />
          </div>

          <div className="flex items-center gap-3 pt-1">
            <button
              onClick={() => onPost(notes)}
              disabled={posting}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-semibold rounded-xl text-sm disabled:opacity-50 hover:from-emerald-600 hover:to-teal-700 transition-all"
            >
              {posting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              Confirm &amp; Post
            </button>
            <button onClick={onClose} disabled={posting} className="px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-100 rounded-xl transition-colors disabled:opacity-50">
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
function AddEmployeeModal({
  projectId, isAdmin, excludeIds, onClose, onAdd,
}: {
  projectId: string;
  isAdmin: boolean;
  excludeIds: string[];
  onClose: () => void;
  onAdd: (emp: WFEmployee) => void;
}) {
  const [employees, setEmployees] = useState<WFEmployee[]>([]);
  const [search, setSearch]       = useState('');
  const [loading, setLoading]     = useState(true);

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from('workforce_employees')
        .select('id,employee_code,name,designation,trade,employment_type,nationality,department,contact_phone,is_active,created_at')
        .eq('is_active', true)
        .order('name');
      setEmployees(((data as WFEmployee[]) ?? []).filter((e) => !excludeIds.includes(e.id)));
      setLoading(false);
    };
    load();
  }, [projectId, isAdmin]);

  const filtered = employees.filter((e) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return [e.name, e.employee_code, e.designation, e.trade]
      .some((f) => f?.toLowerCase().includes(q));
  });

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[80vh] flex flex-col">
        <div className="flex items-center justify-between p-5 border-b border-gray-100 flex-shrink-0">
          <div>
            <h3 className="font-bold text-gray-900">Add Employee to Allocation</h3>
            <p className="text-xs text-gray-500 mt-0.5">Select from the employee master</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>
        <div className="p-4 border-b border-gray-100 flex-shrink-0">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text" value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, code, trade…" autoFocus
              className="w-full pl-9 pr-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
            />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {loading ? (
            <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-teal-500" /></div>
          ) : filtered.length === 0 ? (
            <div className="py-8 text-center text-sm text-gray-400">
              {employees.length === 0 ? 'All employees have already been added.' : 'No employees match your search.'}
            </div>
          ) : (
            <div className="space-y-1">
              {filtered.map((emp) => (
                <button
                  key={emp.id}
                  onClick={() => onAdd(emp)}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-teal-50 text-left transition-colors group"
                >
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-teal-100 to-blue-100 flex items-center justify-center flex-shrink-0 text-xs font-bold text-teal-700">
                    {emp.name.split(' ').map((w) => w[0]).join('').slice(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm">{emp.name}</p>
                    <p className="text-xs text-gray-400">
                      {emp.employee_code}{emp.designation ? ` · ${emp.designation}` : ''}{emp.trade ? ` · ${emp.trade}` : ''}
                    </p>
                  </div>
                  <Plus className="w-4 h-4 text-teal-500 opacity-0 group-hover:opacity-100 flex-shrink-0 transition-opacity" />
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
