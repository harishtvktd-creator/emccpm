import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { MRItem } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import {
  Plus, X, ShoppingCart, CheckCircle2, AlertCircle, ChevronDown, ChevronUp,
  Trash2, Send, Loader2, PackageSearch, FileText, Info, ChevronRight, Edit3,
  Search, Download, Printer, Filter, ArrowUpDown, SortAsc, SortDesc, Paperclip, Upload,
  Save, RotateCcw,
} from 'lucide-react';

/* ── Types ───────────────────────────────────────────── */

type MRStatus = 'draft' | 'created' | 'assigned' | 'in_progress' | 'po_released' | 'closed';
type SortKey  = 'created_at' | 'requisition_number' | 'project' | 'status';

type MRAttachment = { name: string; url: string; size: number };

type MR = {
  id: string;
  requisition_number: string | null;
  title: string;
  purpose: string | null;
  preferred_supplier: string | null;
  required_delivery_date: string | null;
  transit_remarks: string | null;
  attachments: MRAttachment[];
  items: MRItem[];
  status: MRStatus;
  project_id: string | null;
  assigned_to: string | null;
  task_id: string | null;
  notes: string | null;
  po_number: string | null;
  po_vendor: string | null;
  po_date: string | null;
  po_amount: number | null;
  po_vendor_contact_name: string | null;
  po_vendor_contact_number: string | null;
  po_vendor_location: string | null;
  delivery_status: 'assigned' | 'in_transit' | 'delivered' | null;
  material_coordinator_id: string | null;
  delivery_date: string | null;
  delivery_remarks: string | null;
  created_by?: string | null;
  created_at: string;
  projects?: { name: string } | null;
  creator?: { name: string } | null;
  coordinator?: { name: string } | null;
};

/* ── Constants ───────────────────────────────────────── */

const STATUS_STEPS: { key: MRStatus; label: string }[] = [
  { key: 'created',     label: 'Created' },
  { key: 'assigned',    label: 'RFQ Stage' },
  { key: 'in_progress', label: 'PM Approval' },
  { key: 'po_released', label: 'PO Released' },
  { key: 'closed',      label: 'Closed' },
];

const STATUS_META: Record<MRStatus, { label: string; color: string; bg: string }> = {
  draft:       { label: 'Draft',       color: 'text-gray-500',  bg: 'bg-gray-50 border-gray-200' },
  created:     { label: 'Created',     color: 'text-gray-700',  bg: 'bg-gray-100 border-gray-200' },
  assigned:    { label: 'RFQ Stage',   color: 'text-blue-700',  bg: 'bg-blue-100 border-blue-200' },
  in_progress: { label: 'PM Approval', color: 'text-amber-700', bg: 'bg-amber-100 border-amber-200' },
  po_released: { label: 'PO Released', color: 'text-teal-700',  bg: 'bg-teal-100 border-teal-200' },
  closed:      { label: 'Closed',      color: 'text-green-700', bg: 'bg-green-100 border-green-200' },
};

const STATUS_ORDER: Record<MRStatus, number> = {
  draft: -1, created: 0, assigned: 1, in_progress: 2, po_released: 3, closed: 4,
};

const STEP_IDX: Record<MRStatus, number> = {
  draft: -1, created: 0, assigned: 1, in_progress: 2, po_released: 3, closed: 4,
};

const NEXT_STATUS: Record<MRStatus, MRStatus | null> = {
  draft: null, created: 'assigned', assigned: 'in_progress', in_progress: 'po_released', po_released: 'closed', closed: null,
};

const NEXT_ACTION_LABEL: Record<MRStatus, string> = {
  draft: '', created: 'Mark RFQ Stage', assigned: 'Mark PM Approval', in_progress: 'Enter PO & Release', po_released: 'Close MR', closed: '',
};

const EMPTY_ITEM: MRItem = { description: '', specification: '', proposed_make: '', country_of_origin: '', quantity: 1, unit: 'pcs' };

/* ── Helpers ─────────────────────────────────────────── */

function fmtDate(d: string) {
  const [y, m, day] = d.split('T')[0].split('-');
  return `${day}/${m}/${y}`;
}

async function generateMRNumber(): Promise<string> {
  const now    = new Date();
  const prefix = `MR-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}-`;
  const { data } = await supabase
    .from('material_requisitions')
    .select('requisition_number')
    .like('requisition_number', `${prefix}%`);
  const used = new Set((data ?? []).filter((r) => r.requisition_number).map((r) => parseInt(r.requisition_number!.replace(prefix, ''), 10)));
  let seq = 1;
  while (used.has(seq)) seq++;
  return `${prefix}${String(seq).padStart(4, '0')}`;
}

/* ── Export helpers ──────────────────────────────────── */

function exportMRCSV(mr: MR) {
  const proj    = (mr.projects as { name: string } | null)?.name ?? '';
  const creator = (mr.creator  as { name: string } | null)?.name ?? '';
  const lines: string[][] = [
    ['MATERIAL REQUISITION'],
    ['MR Number', mr.requisition_number ?? 'Draft'],
    ['Date', fmtDate(mr.created_at)],
    ['Required Delivery Date', mr.required_delivery_date ? fmtDate(mr.required_delivery_date) : ''],
    ['Project', proj],
    ['Submitted By', creator],
    ['Preferred Supplier', mr.preferred_supplier ?? ''],
    ['Status', STATUS_META[mr.status].label],
    ['Additional Remarks', mr.purpose ?? ''],
    [],
    ['#', 'Material Description', 'Specification / Rating', 'Proposed Make / Manufacturer', 'Country of Origin', 'Qty', 'Unit'],
    ...mr.items.map((item, i) => [
      String(i + 1),
      `"${(item.description ?? '').replace(/"/g, '""')}"`,
      `"${(item.specification ?? '').replace(/"/g, '""')}"`,
      `"${(item.proposed_make ?? '').replace(/"/g, '""')}"`,
      `"${(item.country_of_origin ?? '').replace(/"/g, '""')}"`,
      String(item.quantity),
      item.unit,
    ]),
  ];
  if (mr.po_number) {
    lines.push([], ['PURCHASE ORDER DETAILS']);
    lines.push(['PO Number', mr.po_number], ['Vendor', mr.po_vendor ?? ''],
               ['PO Date', mr.po_date ? fmtDate(mr.po_date) : ''],
               ['PO Amount (AED)', mr.po_amount != null ? mr.po_amount.toFixed(2) : '']);
  }
  const blob = new Blob([lines.map((r) => r.join(',')).join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = `${mr.requisition_number ?? 'Draft'}.csv`; a.click();
  URL.revokeObjectURL(url);
}

function buildMRHTML(mr: MR): string {
  const proj    = (mr.projects as { name: string } | null)?.name ?? '—';
  const creator = (mr.creator  as { name: string } | null)?.name ?? '—';
  const itemRows = mr.items.map((item, i) => `
    <tr>
      <td>${i + 1}</td><td>${item.description ?? ''}</td><td>${item.specification ?? ''}</td>
      <td>${item.proposed_make ?? ''}</td><td>${item.country_of_origin ?? ''}</td>
      <td class="center">${item.quantity}</td><td>${item.unit}</td>
    </tr>`).join('');
  const poSection = mr.po_number ? `
    <div class="section"><div class="section-title">Purchase Order Details</div>
      <table class="info-table">
        <tr><td class="label">PO Number</td><td>${mr.po_number}</td><td class="label">Vendor</td><td>${mr.po_vendor ?? '—'}</td></tr>
        <tr><td class="label">PO Date</td><td>${mr.po_date ? fmtDate(mr.po_date) : '—'}</td><td class="label">PO Amount</td>
            <td>${mr.po_amount != null ? `AED ${mr.po_amount.toLocaleString('en-AE', { minimumFractionDigits: 2 })}` : '—'}</td></tr>
      </table></div>` : '';
  const attachSection = mr.attachments?.length > 0 ? `
    <div class="section"><div class="section-title">Attachments</div>
      <ul style="margin:0;padding:0 0 0 16px;font-size:10pt;line-height:1.8">
        ${mr.attachments.map((a) => `<li><a href="${a.url}" style="color:#0d9488">${a.name}</a> <span style="color:#9ca3af">(${(a.size / 1024).toFixed(0)} KB)</span></li>`).join('')}
      </ul></div>` : '';
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${mr.requisition_number ?? 'Draft'}</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}body{font-family:Arial,sans-serif;font-size:11pt;color:#1a1a1a;padding:20mm}
  .header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #0d9488;padding-bottom:12px;margin-bottom:16px}
  .company{font-size:14pt;font-weight:bold;color:#0d9488}.mr-title{font-size:18pt;font-weight:bold;text-align:right}
  .mr-number{font-size:12pt;color:#6b7280;text-align:right}
  .info-table{width:100%;border-collapse:collapse;margin-bottom:12px}
  .info-table td{padding:5px 8px;border:1px solid #e5e7eb;font-size:10pt}
  .info-table td.label{background:#f9fafb;font-weight:bold;width:20%;color:#374151}
  .section{margin-bottom:16px}.section-title{font-weight:bold;font-size:11pt;color:#0d9488;border-bottom:1px solid #d1fae5;padding-bottom:4px;margin-bottom:8px;text-transform:uppercase;letter-spacing:.05em}
  .items-table{width:100%;border-collapse:collapse;font-size:9.5pt}
  .items-table th{background:#f0fdfa;border:1px solid #a7f3d0;padding:6px 8px;text-align:left;font-weight:bold;color:#065f46}
  .items-table td{border:1px solid #e5e7eb;padding:6px 8px;vertical-align:top}
  .items-table td.center{text-align:center}.items-table tr:nth-child(even) td{background:#f9fafb}
  .remarks{background:#fffbeb;border:1px solid #fde68a;border-radius:4px;padding:8px 12px;font-size:10pt}
  .status-badge{display:inline-block;padding:3px 10px;border-radius:999px;font-size:9pt;font-weight:bold;background:#d1fae5;color:#065f46}
  .sig-block{margin-top:32px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:24px}
  .sig-box{border-top:1px solid #374151;padding-top:6px;font-size:9pt;color:#374151}
  .footer{margin-top:24px;border-top:1px solid #e5e7eb;padding-top:12px;display:flex;justify-content:space-between;font-size:9pt;color:#9ca3af}
  @media print{body{padding:15mm}}
</style></head><body>
<div class="header">
  <div><div class="company">EMCC Projects Division</div><div style="font-size:9pt;color:#6b7280;margin-top:2px">Material Requisition</div></div>
  <div><div class="mr-title">${mr.requisition_number ?? 'Draft'}</div><div class="mr-number">Date: ${fmtDate(mr.created_at)}</div>
       <div style="margin-top:4px"><span class="status-badge">${STATUS_META[mr.status].label}</span></div></div>
</div>
<div class="section"><table class="info-table">
  <tr><td class="label">Project</td><td>${proj}</td><td class="label">Submitted By</td><td>${creator}</td></tr>
  <tr><td class="label">Subject / Title</td><td colspan="3">${mr.title}</td></tr>
  <tr><td class="label">Required Delivery Date</td><td>${mr.required_delivery_date ? fmtDate(mr.required_delivery_date) : '—'}</td><td class="label">Preferred Supplier</td><td>${mr.preferred_supplier ?? '—'}</td></tr>
</table></div>
<div class="section"><div class="section-title">Material Items</div>
  <table class="items-table"><thead><tr>
    <th style="width:4%">#</th><th style="width:22%">Material Description</th>
    <th style="width:18%">Specification / Rating</th><th style="width:18%">Proposed Make / Mfr.</th>
    <th style="width:16%">Country of Origin</th><th style="width:8%">Qty</th><th style="width:8%">Unit</th>
  </tr></thead><tbody>${itemRows}</tbody></table>
</div>
${mr.purpose ? `<div class="section"><div class="section-title">Additional Remarks</div><div class="remarks">${mr.purpose}</div></div>` : ''}
${poSection}
${attachSection}
<div class="sig-block">
  <div class="sig-box">Prepared by<br><br>Name: _______________<br>Date: _______________</div>
  <div class="sig-box">Reviewed by<br><br>Name: _______________<br>Date: _______________</div>
  <div class="sig-box">Approved by<br><br>Name: _______________<br>Date: _______________</div>
</div>
<div class="footer"><span>EMCC Project Management System</span><span>${new Date().toLocaleString()}</span></div>
</body></html>`;
}

function exportMRHTML(mr: MR) {
  const html = buildMRHTML(mr);
  const blob = new Blob([html], { type: 'text/html;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = `${mr.requisition_number ?? 'Draft'}.html`; a.click();
  URL.revokeObjectURL(url);
}

function exportMRPrint(mr: MR) {
  const html = buildMRHTML(mr);
  const win = window.open('', '_blank');
  if (win) { win.document.write(html); win.document.close(); setTimeout(() => win.print(), 500); }
}

/* ── Bulk export ─────────────────────────────────────── */

function exportFilteredCSV(mrs: MR[]) {
  const header = [
    'MR Number', 'Date', 'Project', 'Submitted By', 'Title',
    'Required Delivery Date', 'Status', 'Preferred Supplier',
    'PO Number', 'Vendor', 'PO Date', 'PO Amount (AED)',
    'Items Count', 'Remarks',
  ];
  const rows = mrs.map((mr) => [
    mr.requisition_number ?? 'Draft',
    fmtDate(mr.created_at),
    `"${((mr.projects as { name: string } | null)?.name ?? '').replace(/"/g, '""')}"`,
    `"${((mr.creator  as { name: string } | null)?.name ?? '').replace(/"/g, '""')}"`,
    `"${mr.title.replace(/"/g, '""')}"`,
    mr.required_delivery_date ? fmtDate(mr.required_delivery_date) : '',
    STATUS_META[mr.status].label,
    `"${(mr.preferred_supplier ?? '').replace(/"/g, '""')}"`,
    mr.po_number ?? '',
    `"${(mr.po_vendor ?? '').replace(/"/g, '""')}"`,
    mr.po_date ? fmtDate(mr.po_date) : '',
    mr.po_amount != null ? mr.po_amount.toFixed(2) : '',
    String(mr.items.length),
    `"${(mr.purpose ?? '').replace(/"/g, '""')}"`,
  ]);
  const csv = [header, ...rows].map((r) => r.join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url;
  a.download = `MR-Export-${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

/* ── StatusStepper ───────────────────────────────────── */
function StatusStepper({ status }: { status: MRStatus }) {
  const current = STEP_IDX[status];
  return (
    <div className="flex items-center overflow-x-auto py-1">
      {STATUS_STEPS.map((step, i) => {
        const done = i < current; const active = i === current;
        return (
          <div key={step.key} className="flex items-center">
            <div className={`flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium whitespace-nowrap ${active ? 'bg-teal-600 text-white' : done ? 'bg-teal-100 text-teal-700' : 'bg-gray-100 text-gray-400'}`}>
              {done ? <CheckCircle2 className="w-3 h-3" /> : <span className="w-3 h-3 rounded-full border-2 border-current inline-block" />}
              {step.label}
            </div>
            {i < STATUS_STEPS.length - 1 && <ChevronRight className={`w-3.5 h-3.5 flex-shrink-0 ${i < current ? 'text-teal-400' : 'text-gray-300'}`} />}
          </div>
        );
      })}
    </div>
  );
}

/* ── ExportMenu ──────────────────────────────────────── */
function ExportMenu({ mr }: { mr: MR }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={() => setOpen((o) => !o)} className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-200 hover:border-teal-300 text-gray-600 hover:text-teal-700 text-xs font-semibold rounded-lg transition-colors">
        <Download className="w-3.5 h-3.5" />Export<ChevronDown className="w-3 h-3" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-1 z-20 bg-white border border-gray-200 rounded-xl shadow-lg py-1 min-w-[150px]">
            <button onClick={() => { exportMRCSV(mr); setOpen(false); }} className="flex items-center gap-2 w-full px-3 py-2 text-sm text-gray-700 hover:bg-gray-50">
              <Download className="w-4 h-4 text-green-600" />Excel / CSV
            </button>
            <button onClick={() => { exportMRHTML(mr); setOpen(false); }} className="flex items-center gap-2 w-full px-3 py-2 text-sm text-gray-700 hover:bg-gray-50">
              <FileText className="w-4 h-4 text-orange-500" />Download HTML
            </button>
            <button onClick={() => { exportMRPrint(mr); setOpen(false); }} className="flex items-center gap-2 w-full px-3 py-2 text-sm text-gray-700 hover:bg-gray-50">
              <Printer className="w-4 h-4 text-blue-600" />Print / PDF
            </button>
          </div>
        </>
      )}
    </div>
  );
}

/* ── AttachmentSection ───────────────────────────────── */
function AttachmentSection({ mr, canEdit, onUpdate }: {
  mr: MR;
  canEdit: boolean;
  onUpdate: (updated: MRAttachment[]) => void;
}) {
  const [uploading, setUploading] = useState(false);
  const [uploadErr, setUploadErr] = useState<string | null>(null);

  const handleFilesAdded = async (files: File[]) => {
    setUploading(true);
    setUploadErr(null);
    const existing = mr.attachments ?? [];
    const newUploaded: MRAttachment[] = [];
    for (const file of files) {
      const path = `${mr.id}/${Date.now()}-${file.name}`;
      const { error: upErr } = await supabase.storage.from('mr-attachments').upload(path, file);
      if (upErr) { setUploadErr(`Failed to upload "${file.name}": ${upErr.message}`); continue; }
      const { data: urlData } = supabase.storage.from('mr-attachments').getPublicUrl(path);
      newUploaded.push({ name: file.name, url: urlData.publicUrl, size: file.size });
    }
    if (newUploaded.length > 0) {
      const merged = [...existing, ...newUploaded];
      const { error } = await supabase.from('material_requisitions').update({ attachments: merged }).eq('id', mr.id);
      if (!error) onUpdate(merged);
    }
    setUploading(false);
  };

  const handleDelete = async (idx: number) => {
    const att = (mr.attachments ?? [])[idx];
    const updated = (mr.attachments ?? []).filter((_, i) => i !== idx);
    // Best-effort: remove from storage by extracting path after bucket name
    const marker = '/mr-attachments/';
    const markerIdx = att.url.indexOf(marker);
    if (markerIdx !== -1) {
      const storagePath = decodeURIComponent(att.url.slice(markerIdx + marker.length));
      await supabase.storage.from('mr-attachments').remove([storagePath]);
    }
    await supabase.from('material_requisitions').update({ attachments: updated }).eq('id', mr.id);
    onUpdate(updated);
  };

  const attachments = mr.attachments ?? [];

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
          Attachments{attachments.length > 0 ? ` (${attachments.length})` : ''}
        </p>
        {canEdit && (
          <label className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${uploading ? 'bg-gray-50 border-gray-200 text-gray-400' : 'bg-teal-50 border-teal-200 text-teal-700 hover:bg-teal-100'}`}>
            {uploading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Upload className="w-3 h-3" />}
            {uploading ? 'Uploading…' : 'Attach Files'}
            <input type="file" multiple className="sr-only" disabled={uploading} onChange={(e) => {
              const files = Array.from(e.target.files ?? []);
              if (files.length) handleFilesAdded(files);
              e.target.value = '';
            }} />
          </label>
        )}
      </div>
      {uploadErr && (
        <p className="flex items-center gap-1.5 text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-1.5 mb-2">
          <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />{uploadErr}
        </p>
      )}
      {attachments.length === 0 ? (
        <p className="text-xs text-gray-400 italic">
          {canEdit ? 'No attachments yet — click "Attach Files" to add drawings, specs, or photos.' : 'No attachments.'}
        </p>
      ) : (
        <div className="flex flex-wrap gap-2">
          {attachments.map((att, i) => (
            <div key={i} className="group flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-lg text-xs font-medium text-blue-700 hover:bg-blue-100 hover:border-blue-300 transition-colors">
              <Paperclip className="w-3 h-3 flex-shrink-0" />
              <a href={att.url} target="_blank" rel="noopener noreferrer" className="hover:underline max-w-[200px] truncate">
                {att.name}
              </a>
              <span className="text-blue-400 flex-shrink-0">({(att.size / 1024).toFixed(0)} KB)</span>
              {canEdit && (
                <button
                  onClick={() => handleDelete(i)}
                  className="ml-0.5 text-blue-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                  title="Remove attachment"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ── Main component ──────────────────────────────────── */
export function MaterialRequisitions() {
  const { teamMember } = useAuth();
  const isProcurementLead = !!teamMember?.is_procurement_lead;

  const [mrs, setMrs]               = useState<MR[]>([]);
  const [projects, setProjects]     = useState<{ id: string; name: string }[]>([]);
  const [loading, setLoading]       = useState(true);
  const [showForm, setShowForm]     = useState(false);
  const [resumeDraft, setResumeDraft] = useState<MR | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [poMR, setPoMR]             = useState<MR | null>(null);
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  /* Filters */
  const [search, setSearch]             = useState('');
  const [filterStatus, setFilterStatus] = useState<MRStatus | 'open' | 'all'>('all');
  const [filterProject, setFilterProject] = useState('all');
  const [filterFrom, setFilterFrom]     = useState('');
  const [filterTo, setFilterTo]         = useState('');
  const [sortKey, setSortKey]           = useState<SortKey>('created_at');
  const [sortAsc, setSortAsc]           = useState(false);

  const fetchMRs = useCallback(async () => {
    if (!teamMember) return;
    setLoading(true);
    let q = supabase
      .from('material_requisitions')
      .select('*, projects(name), creator:team_members!created_by(name), coordinator:team_members!material_coordinator_id(name)')
      .order('created_at', { ascending: false });
    if (!isProcurementLead) q = q.eq('created_by', teamMember.id);
    const { data } = await q;
    setMrs((data as MR[]) ?? []);
    setLoading(false);
  }, [teamMember, isProcurementLead]);

  useEffect(() => {
    fetchMRs();
    supabase.from('projects').select('id,name').order('name').then(({ data }) => setProjects(data ?? []));
  }, [fetchMRs]);

  const handleAdvanceStatus = async (mr: MR) => {
    if (!NEXT_STATUS[mr.status]) return;
    if (mr.status === 'in_progress') { setPoMR(mr); return; }
    setUpdatingId(mr.id);
    const nextStatus = NEXT_STATUS[mr.status]!;
    await supabase.from('material_requisitions').update({ status: nextStatus }).eq('id', mr.id);
    if (mr.task_id && nextStatus === 'closed')
      await supabase.from('tasks').update({ status: 'completed' }).eq('id', mr.task_id);
    await fetchMRs();
    setUpdatingId(null);
  };

  /* Filtering + sorting */
  const filtered = mrs
    .filter((m) => {
      if (filterStatus === 'all') return true;
      if (filterStatus === 'open') return m.status === 'created' || m.status === 'assigned';
      return m.status === filterStatus;
    })
    .filter((m) => filterProject === 'all' || (m.projects as { name: string } | null)?.name === filterProject)
    .filter((m) => !filterFrom || m.created_at.split('T')[0] >= filterFrom)
    .filter((m) => !filterTo   || m.created_at.split('T')[0] <= filterTo)
    .filter((m) => {
      if (!search) return true;
      const q = search.toLowerCase();
      return (
        (m.requisition_number ?? '').toLowerCase().includes(q) ||
        m.title.toLowerCase().includes(q) ||
        (m.preferred_supplier ?? '').toLowerCase().includes(q) ||
        (m.po_number ?? '').toLowerCase().includes(q) ||
        ((m.projects as { name: string } | null)?.name ?? '').toLowerCase().includes(q) ||
        ((m.creator  as { name: string } | null)?.name ?? '').toLowerCase().includes(q)
      );
    })
    .sort((a, b) => {
      let cmp = 0;
      if (sortKey === 'created_at')        cmp = a.created_at.localeCompare(b.created_at);
      else if (sortKey === 'requisition_number') cmp = (a.requisition_number ?? '').localeCompare(b.requisition_number ?? '');
      else if (sortKey === 'project')      cmp = ((a.projects as { name: string } | null)?.name ?? '').localeCompare((b.projects as { name: string } | null)?.name ?? '');
      else if (sortKey === 'status')       cmp = STATUS_ORDER[a.status] - STATUS_ORDER[b.status];
      return sortAsc ? cmp : -cmp;
    });

  const counts = (['all', 'open', 'draft', ...STATUS_STEPS.map((s) => s.key)] as const).reduce((acc, k) => {
    if (k === 'all') acc['all'] = mrs.length;
    else if (k === 'open') acc['open'] = mrs.filter((m) => m.status === 'created' || m.status === 'assigned').length;
    else acc[k as string] = mrs.filter((m) => m.status === k).length;
    return acc;
  }, {} as Record<string, number>);

  const activeFilters = [filterStatus !== 'all', filterProject !== 'all', !!filterFrom, !!filterTo].filter(Boolean).length;

  const clearFilters = () => { setFilterStatus('all'); setFilterProject('all'); setFilterFrom(''); setFilterTo(''); };

  const toggleSort = (k: SortKey) => { if (sortKey === k) setSortAsc((a) => !a); else { setSortKey(k); setSortAsc(false); } };

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-7 h-7 animate-spin text-teal-500" />
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Header row */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-bold text-gray-900 text-lg">
            {isProcurementLead ? 'All Material Requisitions' : 'My Requisitions'}
          </h3>
          <p className="text-sm text-gray-500 mt-0.5">{filtered.length} of {mrs.length}</p>
        </div>
        <div className="flex items-center gap-2">
          {isProcurementLead && filtered.length > 0 && (
            <button
              onClick={() => exportFilteredCSV(filtered)}
              className="flex items-center gap-2 px-4 py-2.5 bg-white border border-gray-200 text-gray-700 font-medium rounded-xl text-sm hover:border-teal-300 hover:text-teal-600 transition-all"
              title="Export filtered results as CSV"
            >
              <Download className="w-4 h-4" />
              Export ({filtered.length})
            </button>
          )}
          <button onClick={() => setShowForm(true)} className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm shadow-sm hover:from-teal-600 hover:to-blue-700 transition-all">
            <Plus className="w-4 h-4" />New Requisition
          </button>
        </div>
      </div>

      {/* Search + filter toolbar */}
      <div className="space-y-2">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text" value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search MR number, title, supplier, PO number, project…"
              className="w-full pl-9 pr-8 py-2.5 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400"
            />
            {search && <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>}
          </div>
          <button
            onClick={() => setShowFilters((f) => !f)}
            className={`flex items-center gap-1.5 px-3 py-2.5 rounded-xl text-sm font-medium border transition-all ${showFilters || activeFilters > 0 ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-gray-600 border-gray-200 hover:border-teal-300'}`}
          >
            <Filter className="w-4 h-4" />
            Filters
            {activeFilters > 0 && <span className="bg-white text-teal-700 text-xs rounded-full w-4 h-4 flex items-center justify-center font-bold">{activeFilters}</span>}
          </button>
          {activeFilters > 0 && (
            <button onClick={clearFilters} className="flex items-center gap-1 px-3 py-2.5 rounded-xl text-sm text-red-500 hover:bg-red-50 border border-red-200 transition-colors">
              <X className="w-3.5 h-3.5" />Clear
            </button>
          )}
        </div>

        {/* Expanded filter panel */}
        {showFilters && (
          <div className="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Status */}
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Status</label>
                <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value as typeof filterStatus)} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400">
                  <option value="all">All Statuses</option>
                  <option value="draft">Drafts</option>
                  <option value="open">Open (Created + RFQ Stage)</option>
                  <option value="in_progress">PM Approval</option>
                  <option value="po_released">PO Released</option>
                  <option value="closed">Closed</option>
                </select>
              </div>
              {/* Project */}
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Project</label>
                <select value={filterProject} onChange={(e) => setFilterProject(e.target.value)} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400">
                  <option value="all">All Projects</option>
                  {Array.from(new Set(mrs.filter((m) => m.projects).map((m) => (m.projects as { name: string }).name))).map((p) => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>
              </div>
              {/* Date from */}
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Date From</label>
                <input type="date" value={filterFrom} onChange={(e) => setFilterFrom(e.target.value)} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400" />
              </div>
              {/* Date to */}
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Date To</label>
                <input type="date" value={filterTo} onChange={(e) => setFilterTo(e.target.value)} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400" />
              </div>
            </div>
            {/* Sort row */}
            <div className="pt-3 border-t border-gray-100">
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Sort By</label>
              <div className="flex flex-wrap gap-2">
                {([
                  { key: 'created_at',        label: 'Date' },
                  { key: 'requisition_number', label: 'MR Number' },
                  { key: 'project',           label: 'Project' },
                  { key: 'status',            label: 'Status' },
                ] as { key: SortKey; label: string }[]).map(({ key, label }) => (
                  <button key={key} onClick={() => toggleSort(key)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${sortKey === key ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-gray-600 border-gray-200 hover:border-teal-300'}`}>
                    {label}
                    {sortKey === key
                      ? (sortAsc ? <SortAsc className="w-3.5 h-3.5" /> : <SortDesc className="w-3.5 h-3.5" />)
                      : <ArrowUpDown className="w-3.5 h-3.5 opacity-40" />}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Active filter chips */}
        {activeFilters > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {filterStatus !== 'all' && (
              <span className="flex items-center gap-1 px-2 py-0.5 bg-teal-100 text-teal-700 rounded-full text-xs font-medium">
                Status: {filterStatus === 'open' ? 'Open' : STATUS_META[filterStatus as MRStatus]?.label}
                <button onClick={() => setFilterStatus('all')}><X className="w-3 h-3" /></button>
              </span>
            )}
            {filterProject !== 'all' && (
              <span className="flex items-center gap-1 px-2 py-0.5 bg-teal-100 text-teal-700 rounded-full text-xs font-medium">
                Project: {filterProject}<button onClick={() => setFilterProject('all')}><X className="w-3 h-3 ml-0.5" /></button>
              </span>
            )}
            {filterFrom && (
              <span className="flex items-center gap-1 px-2 py-0.5 bg-teal-100 text-teal-700 rounded-full text-xs font-medium">
                From: {fmtDate(filterFrom)}<button onClick={() => setFilterFrom('')}><X className="w-3 h-3 ml-0.5" /></button>
              </span>
            )}
            {filterTo && (
              <span className="flex items-center gap-1 px-2 py-0.5 bg-teal-100 text-teal-700 rounded-full text-xs font-medium">
                To: {fmtDate(filterTo)}<button onClick={() => setFilterTo('')}><X className="w-3 h-3 ml-0.5" /></button>
              </span>
            )}
          </div>
        )}

        {/* Quick status pills */}
        <div className="flex flex-wrap gap-2">
          {([
            { key: 'all',      label: `All (${counts.all ?? 0})` },
            { key: 'draft',    label: `Drafts (${counts.draft ?? 0})` },
            { key: 'open',     label: `Open (${counts.open ?? 0})` },
            { key: 'in_progress', label: `PM Approval (${counts.in_progress ?? 0})` },
            { key: 'po_released', label: `PO Released (${counts.po_released ?? 0})` },
            { key: 'closed',   label: `Closed (${counts.closed ?? 0})` },
          ] as { key: string; label: string }[]).map(({ key, label }) => (
            <button key={key} onClick={() => setFilterStatus(key as typeof filterStatus)} className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${filterStatus === key ? 'bg-gray-800 text-white border-gray-800' : 'bg-white text-gray-600 border-gray-200 hover:border-gray-400'}`}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* MR list */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-14 text-center">
          <PackageSearch className="w-14 h-14 text-gray-300 mx-auto mb-4" />
          <p className="font-semibold text-gray-700">{mrs.length === 0 ? 'No requisitions yet' : 'No requisitions match'}</p>
          {activeFilters > 0 && <button onClick={clearFilters} className="text-teal-600 text-sm hover:underline mt-2">Clear filters</button>}
          {mrs.length === 0 && (
            <button onClick={() => setShowForm(true)} className="mt-4 inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white rounded-xl text-sm font-medium">
              <Plus className="w-4 h-4" />Create First Requisition
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((mr) => {
            const meta      = STATUS_META[mr.status];
            const expanded  = expandedId === mr.id;
            const nextAction = NEXT_STATUS[mr.status];
            const isUpdating = updatingId === mr.id;
            const isDraft = mr.status === 'draft';
            return (
              <div key={mr.id} className={`bg-white rounded-2xl border shadow-sm overflow-hidden ${isDraft ? 'border-dashed border-gray-300' : 'border-gray-100'}`}>
                <div className="flex items-start gap-3 p-4">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5 ${isDraft ? 'bg-gray-100' : 'bg-gradient-to-br from-teal-500 to-blue-600'}`}>
                    {isDraft ? <FileText className="w-5 h-5 text-gray-400" /> : <ShoppingCart className="w-5 h-5 text-white" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-0.5">
                      <span className="font-bold text-gray-900">{mr.requisition_number ?? 'Draft'}</span>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${meta.bg} ${meta.color}`}>{meta.label}</span>
                    </div>
                    <p className="text-sm text-gray-700 truncate">{mr.title || <span className="text-gray-400 italic">Untitled draft</span>}</p>
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 mt-1 text-xs text-gray-400">
                      <span>{fmtDate(mr.created_at)}</span>
                      {mr.projects && <span>· {(mr.projects as { name: string }).name}</span>}
                      {isProcurementLead && mr.creator && <span>· {(mr.creator as { name: string }).name}</span>}
                      {mr.preferred_supplier && <span>· {mr.preferred_supplier}</span>}
                      {mr.po_number && <span className="text-teal-600 font-medium">· PO: {mr.po_number}</span>}
                      {mr.delivery_status && !isDraft && (
                        <span className={`font-semibold ${mr.delivery_status === 'delivered' ? 'text-green-600' : mr.delivery_status === 'in_transit' ? 'text-amber-600' : 'text-blue-600'}`}>
                          · {mr.delivery_status === 'delivered' ? 'Delivered' : mr.delivery_status === 'in_transit' ? 'In Transit' : `Assigned to ${(mr.coordinator as { name: string } | null)?.name ?? 'Coordinator'}`}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {isDraft ? (
                      <>
                        <button
                          onClick={() => { setResumeDraft(mr); setShowForm(true); }}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-700 hover:bg-gray-900 text-white text-xs font-semibold rounded-lg transition-colors"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />Resume Draft
                        </button>
                        <button
                          onClick={async () => {
                            if (!confirm('Delete this draft?')) return;
                            await supabase.from('material_requisitions').delete().eq('id', mr.id);
                            fetchMRs();
                          }}
                          className="p-1.5 rounded-lg hover:bg-red-50 text-gray-300 hover:text-red-500 transition-colors"
                          title="Delete draft"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </>
                    ) : (
                      <>
                        {isProcurementLead && <ExportMenu mr={mr} />}
                        {isProcurementLead && nextAction && (
                          <button onClick={() => handleAdvanceStatus(mr)} disabled={isUpdating} className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg transition-colors disabled:opacity-60">
                            {isUpdating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Edit3 className="w-3.5 h-3.5" />}
                            {NEXT_ACTION_LABEL[mr.status]}
                          </button>
                        )}
                      </>
                    )}
                    <button onClick={() => setExpandedId(expanded ? null : mr.id)} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors">
                      {expanded ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
                    </button>
                  </div>
                </div>

                {!isDraft && <div className="px-4 pb-3"><StatusStepper status={mr.status} /></div>}

                {expanded && (
                  <div className="border-t border-gray-100 px-4 py-4 space-y-4">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-sm">
                      {mr.required_delivery_date && (
                        <div>
                          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-0.5">Required Delivery Date</p>
                          <p className="font-semibold text-amber-700">{fmtDate(mr.required_delivery_date)}</p>
                        </div>
                      )}
                      {mr.preferred_supplier && (
                        <div><p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-0.5">Preferred Supplier</p><p className="text-gray-800">{mr.preferred_supplier}</p></div>
                      )}
                      {mr.purpose && (
                        <div className="col-span-2"><p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-0.5">Additional Remarks</p><p className="text-gray-800">{mr.purpose}</p></div>
                      )}
                    </div>

                    {mr.items.length > 0 && (
                      <div>
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Material Items</p>
                        <div className="overflow-x-auto rounded-xl border border-gray-100">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="bg-gray-50">
                                {['#', 'Material Description', 'Specification / Rating', 'Proposed Make / Mfr.', 'Country of Origin', 'Qty', 'Unit'].map((h) => (
                                  <th key={h} className="text-left px-3 py-2 text-xs font-semibold text-gray-500 whitespace-nowrap">{h}</th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {mr.items.map((item, i) => (
                                <tr key={i} className="border-t border-gray-100">
                                  <td className="px-3 py-2 text-gray-400 text-xs">{i + 1}</td>
                                  <td className="px-3 py-2 text-gray-800">{item.description}</td>
                                  <td className="px-3 py-2 text-gray-600">{item.specification ?? '—'}</td>
                                  <td className="px-3 py-2 text-gray-600">{item.proposed_make ?? '—'}</td>
                                  <td className="px-3 py-2 text-gray-600">{item.country_of_origin ?? '—'}</td>
                                  <td className="px-3 py-2 text-right text-gray-700">{item.quantity}</td>
                                  <td className="px-3 py-2 text-gray-500">{item.unit}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}

                    {mr.po_number && (
                      <div className="bg-teal-50 border border-teal-100 rounded-xl px-4 py-3 space-y-3">
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                          {[
                            { label: 'PO Number', value: mr.po_number },
                            { label: 'Vendor',    value: mr.po_vendor ?? '—' },
                            { label: 'PO Date',   value: mr.po_date ? fmtDate(mr.po_date) : '—' },
                            { label: 'PO Amount', value: mr.po_amount != null ? `AED ${mr.po_amount.toLocaleString('en-AE', { minimumFractionDigits: 2 })}` : '—' },
                          ].map((f) => (
                            <div key={f.label}>
                              <p className="text-xs font-semibold text-teal-600 uppercase tracking-wide mb-0.5">{f.label}</p>
                              <p className="text-sm font-bold text-teal-900">{f.value}</p>
                            </div>
                          ))}
                        </div>
                        {(mr.po_vendor_contact_name || mr.po_vendor_contact_number || mr.po_vendor_location) && (
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-teal-100">
                            {mr.po_vendor_contact_name && (
                              <div>
                                <p className="text-xs font-semibold text-teal-600 uppercase tracking-wide mb-0.5">Contact Name</p>
                                <p className="text-sm font-medium text-teal-900">{mr.po_vendor_contact_name}</p>
                              </div>
                            )}
                            {mr.po_vendor_contact_number && (
                              <div>
                                <p className="text-xs font-semibold text-teal-600 uppercase tracking-wide mb-0.5">Contact Number</p>
                                <p className="text-sm font-medium text-teal-900">{mr.po_vendor_contact_number}</p>
                              </div>
                            )}
                            {mr.po_vendor_location && (
                              <div>
                                <p className="text-xs font-semibold text-teal-600 uppercase tracking-wide mb-0.5">Location</p>
                                <p className="text-sm font-medium text-teal-900">{mr.po_vendor_location}</p>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    )}

                    {mr.delivery_status && (
                      <div className={`rounded-xl border px-4 py-3 ${mr.delivery_status === 'delivered' ? 'bg-green-50 border-green-100' : 'bg-blue-50 border-blue-100'}`}>
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Delivery Tracking</p>
                        <div className="flex flex-wrap items-center gap-3">
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
                            mr.delivery_status === 'delivered' ? 'bg-green-100 text-green-700' :
                            mr.delivery_status === 'in_transit' ? 'bg-amber-100 text-amber-700' :
                            'bg-blue-100 text-blue-700'
                          }`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${
                              mr.delivery_status === 'delivered' ? 'bg-green-500' :
                              mr.delivery_status === 'in_transit' ? 'bg-amber-500' : 'bg-blue-500'
                            }`} />
                            {mr.delivery_status === 'delivered' ? 'Delivered' : mr.delivery_status === 'in_transit' ? 'In Transit' : 'Assigned'}
                          </span>
                          {(mr.coordinator as { name: string } | null)?.name && (
                            <span className="text-sm text-gray-600">Coordinator: <span className="font-semibold">{(mr.coordinator as { name: string }).name}</span></span>
                          )}
                          {mr.delivery_date && (
                            <span className="text-sm font-semibold text-green-700">Delivered: {fmtDate(mr.delivery_date)}</span>
                          )}
                        </div>
                        {mr.delivery_remarks && <p className="text-sm text-gray-600 mt-1.5">{mr.delivery_remarks}</p>}
                        {mr.transit_remarks && mr.delivery_status !== 'delivered' && (
                          <p className="text-sm text-amber-700 mt-1.5"><span className="font-semibold">Transit note: </span>{mr.transit_remarks}</p>
                        )}
                      </div>
                    )}
                    <AttachmentSection
                      mr={mr}
                      canEdit={isProcurementLead || mr.created_by === teamMember?.id}
                      onUpdate={(updated) =>
                        setMrs((prev) => prev.map((m) => m.id === mr.id ? { ...m, attachments: updated } : m))
                      }
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {showForm && (
        <NewMRForm
          teamMemberId={teamMember!.id}
          projects={projects}
          draft={resumeDraft}
          onClose={() => { setShowForm(false); setResumeDraft(null); }}
          onCreated={() => { setShowForm(false); setResumeDraft(null); fetchMRs(); }}
        />
      )}
      {poMR && (
        <POEntryModal
          mr={poMR}
          onClose={() => setPoMR(null)}
          onSaved={() => { setPoMR(null); fetchMRs(); }}
        />
      )}
    </div>
  );
}

/* ── PO Entry Modal ──────────────────────────────────── */
function POEntryModal({ mr, onClose, onSaved }: {
  mr: MR; onClose: () => void; onSaved: () => void;
}) {
  const [poNumber,       setPoNumber]       = useState(mr.po_number ?? '');
  const [poVendor,       setPoVendor]       = useState(mr.po_vendor ?? '');
  const [poDate,         setPoDate]         = useState(mr.po_date ?? new Date().toISOString().split('T')[0]);
  const [poAmount,       setPoAmount]       = useState(mr.po_amount != null ? String(mr.po_amount) : '');
  const [contactName,    setContactName]    = useState(mr.po_vendor_contact_name ?? '');
  const [contactNumber,  setContactNumber]  = useState(mr.po_vendor_contact_number ?? '');
  const [vendorLocation, setVendorLocation] = useState(mr.po_vendor_location ?? '');
  const [saving, setSaving] = useState(false);
  const [error,  setError]  = useState<string | null>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!poNumber.trim()) { setError('PO Number is required.'); return; }
    setSaving(true);

    await supabase.from('material_requisitions').update({
      po_number:               poNumber.trim(),
      po_vendor:               poVendor.trim() || null,
      po_date:                 poDate || null,
      po_amount:               poAmount ? parseFloat(poAmount) : null,
      po_vendor_contact_name:   contactName.trim() || null,
      po_vendor_contact_number: contactNumber.trim() || null,
      po_vendor_location:       vendorLocation.trim() || null,
      status: 'po_released',
    }).eq('id', mr.id);

    if (mr.task_id) await supabase.from('tasks').update({ status: 'review' }).eq('id', mr.task_id);

    // Auto-assign to Material Coordinator immediately when PO is released
    const { data: mcList } = await supabase
      .from('team_members')
      .select('id, name')
      .eq('is_material_coordinator', true)
      .eq('is_active', true)
      .limit(1);
    const mc = mcList?.[0] ?? null;
    if (mc) {
      await supabase.from('material_requisitions').update({
        material_coordinator_id: mc.id,
        delivery_status: 'assigned',
        delivery_updated_at: new Date().toISOString(),
      }).eq('id', mr.id);
    }

    setSaving(false);
    onSaved();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div>
            <h3 className="font-bold text-gray-900">Enter Purchase Order Details</h3>
            <p className="text-xs text-gray-500 mt-0.5">{mr.requisition_number ?? 'Draft'} · {mr.title}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100"><X className="w-5 h-5 text-gray-500" /></button>
        </div>
        <form onSubmit={handleSave} className="p-5 space-y-4">
          {/* PO core fields */}
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">PO Number <span className="text-red-400">*</span></label>
            <input type="text" value={poNumber} onChange={(e) => setPoNumber(e.target.value)} placeholder="e.g. PO-2026-0042" required className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Vendor / Supplier</label>
            <input type="text" value={poVendor} onChange={(e) => setPoVendor(e.target.value)} placeholder="Vendor company name" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">PO Date</label>
              <input type="date" value={poDate} onChange={(e) => setPoDate(e.target.value)} className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">PO Amount (AED)</label>
              <input type="number" min="0" step="0.01" value={poAmount} onChange={(e) => setPoAmount(e.target.value)} placeholder="0.00" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
            </div>
          </div>

          {/* Vendor contact details */}
          <div className="pt-1">
            <p className="text-xs font-bold text-gray-700 uppercase tracking-wide mb-3 flex items-center gap-2">
              <span className="w-4 h-px bg-gray-300 inline-block" />
              Vendor Contact Details
              <span className="flex-1 h-px bg-gray-300 inline-block" />
            </p>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Contact Name</label>
                <input type="text" value={contactName} onChange={(e) => setContactName(e.target.value)} placeholder="e.g. Ahmed Al-Rashidi" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Contact Number</label>
                  <input type="tel" value={contactNumber} onChange={(e) => setContactNumber(e.target.value)} placeholder="e.g. +971 50 123 4567" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Location</label>
                  <input type="text" value={vendorLocation} onChange={(e) => setVendorLocation(e.target.value)} placeholder="e.g. Dubai, UAE" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
                </div>
              </div>
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl px-3 py-2.5">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />{error}
            </div>
          )}
          <div className="flex items-center gap-3 pt-1">
            <button type="submit" disabled={saving} className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm disabled:opacity-60 hover:from-teal-600 hover:to-blue-700 transition-all">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              {saving ? 'Saving…' : 'Release PO'}
            </button>
            <button type="button" onClick={onClose} className="px-4 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* ── New MR Form ─────────────────────────────────────── */
export function NewMRForm({
  teamMemberId, projects, draft, onClose, onCreated,
}: {
  teamMemberId: string;
  projects: { id: string; name: string }[];
  draft?: MR | null;
  onClose: () => void;
  onCreated: () => void;
}) {
  const [title, setTitle]                           = useState(draft?.title ?? '');
  const [projectId, setProjectId]                   = useState(draft?.project_id ?? '');
  const [supplier, setSupplier]                     = useState(draft?.preferred_supplier ?? '');
  const [requiredDeliveryDate, setRequiredDeliveryDate] = useState(draft?.required_delivery_date ?? '');
  const [remarks, setRemarks]                       = useState(draft?.purpose ?? '');
  const [items, setItems]                           = useState<MRItem[]>(draft?.items?.length ? draft.items : [{ ...EMPTY_ITEM }]);
  const [submitting, setSubmitting]                 = useState(false);
  const [error, setError]                           = useState<string | null>(null);
  const [noLeadWarning, setNoLeadWarning]           = useState(false);
  const [attachmentFiles, setAttachmentFiles]       = useState<File[]>([]);
  const [uploadStatus, setUploadStatus]             = useState<string | null>(null);

  const [draftId, setDraftId]       = useState<string | null>(draft?.id ?? null);
  const [savingDraft, setSavingDraft] = useState(false);
  const [draftSaved, setDraftSaved]   = useState(false);

  const updateItem = (i: number, field: keyof MRItem, value: string | number) =>
    setItems((prev) => prev.map((item, idx) => idx === i ? { ...item, [field]: value } : item));
  const addItem    = () => setItems((prev) => [...prev, { ...EMPTY_ITEM }]);
  const removeItem = (i: number) => setItems((prev) => prev.filter((_, idx) => idx !== i));
  const handleFileAdd = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    setAttachmentFiles((prev) => [...prev, ...files]);
    e.target.value = '';
  };
  const removeAttachment = (i: number) => setAttachmentFiles((prev) => prev.filter((_, idx) => idx !== i));

  const handleSaveDraft = async () => {
    setSavingDraft(true);
    const payload = {
      created_by: teamMemberId,
      project_id: projectId || null,
      title: title.trim() || 'Untitled Draft',
      purpose: remarks.trim() || null,
      preferred_supplier: supplier.trim() || null,
      required_delivery_date: requiredDeliveryDate || null,
      items,
      status: 'draft' as MRStatus,
    };
    let savedId = draftId;
    if (draftId) {
      await supabase.from('material_requisitions').update(payload).eq('id', draftId);
    } else {
      const { data } = await supabase.from('material_requisitions').insert({
        ...payload,
        requisition_number: null,
      }).select('id').single();
      if (data) { savedId = data.id; setDraftId(data.id); }
    }
    setSavingDraft(false);
    if (savedId) {
      setDraftSaved(true);
      setTimeout(() => setDraftSaved(false), 3000);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) { setError('Please enter a subject / title.'); return; }
    if (!requiredDeliveryDate) { setError('Required delivery date is mandatory.'); return; }
    if (items.some((item) => !item.description.trim())) { setError('Each item must have a material description.'); return; }
    setSubmitting(true); setError(null);

    const reqNum = await generateMRNumber();

    const { data: lead } = await supabase.from('team_members').select('id').eq('is_procurement_lead', true).eq('is_active', true).maybeSingle();
    const leadId = lead?.id ?? null;
    if (!leadId) setNoLeadWarning(true);

    let mrId: string;

    if (draftId) {
      // Promote existing draft to created
      const { data: mr, error: mrErr } = await supabase.from('material_requisitions').update({
        requisition_number: reqNum,
        project_id: projectId || null,
        title: title.trim(),
        purpose: remarks.trim() || null,
        preferred_supplier: supplier.trim() || null,
        required_delivery_date: requiredDeliveryDate || null,
        items,
        assigned_to: leadId,
        status: 'created',
      }).eq('id', draftId).select('id').single();
      if (mrErr || !mr) { setError(mrErr?.message ?? 'Failed to submit.'); setSubmitting(false); return; }
      mrId = mr.id;
    } else {
      const { data: mr, error: mrErr } = await supabase.from('material_requisitions').insert({
        requisition_number: reqNum, created_by: teamMemberId,
        project_id: projectId || null, title: title.trim(),
        purpose: remarks.trim() || null,
        preferred_supplier: supplier.trim() || null,
        required_delivery_date: requiredDeliveryDate || null,
        items, assigned_to: leadId, status: 'created',
      }).select('id').single();
      if (mrErr || !mr) { setError(mrErr?.message ?? 'Failed to submit.'); setSubmitting(false); return; }
      mrId = mr.id;
    }

    if (leadId) {
      const due = new Date(); due.setDate(due.getDate() + 3);
      const { data: task } = await supabase.from('tasks').insert({
        project_id: projectId || null, assigned_to: leadId,
        title: `Review ${reqNum}: ${title.trim()}`,
        description: 'Material Requisition submitted. Please review and process.',
        task_type: 'procurement', priority: 'high',
        due_date: due.toISOString().split('T')[0],
        created_by: teamMemberId, notes: remarks.trim() || null,
      }).select('id').single();
      if (task) await supabase.from('material_requisitions').update({ task_id: task.id, status: 'assigned' }).eq('id', mrId);
    }
    setSubmitting(false);
    if (attachmentFiles.length > 0) {
      setUploadStatus(`Uploading ${attachmentFiles.length} file(s)…`);
      const uploaded: MRAttachment[] = [];
      for (const file of attachmentFiles) {
        const path = `${mrId}/${Date.now()}-${file.name}`;
        const { error: upErr } = await supabase.storage.from('mr-attachments').upload(path, file);
        if (!upErr) {
          const { data: urlData } = supabase.storage.from('mr-attachments').getPublicUrl(path);
          uploaded.push({ name: file.name, url: urlData.publicUrl, size: file.size });
        }
      }
      if (uploaded.length > 0) {
        await supabase.from('material_requisitions').update({ attachments: uploaded }).eq('id', mrId);
      }
      setUploadStatus(null);
    }
    onCreated();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center overflow-y-auto py-8 px-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl my-auto">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-teal-500 to-blue-600 rounded-xl flex items-center justify-center">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">{draft ? 'Resume Draft Requisition' : 'New Material Requisition'}</h3>
              <p className="text-xs text-gray-500">{draft ? 'Continue editing your saved draft' : 'MR number assigned automatically on submit'}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100"><X className="w-5 h-5 text-gray-500" /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-6">
          {noLeadWarning && (
            <div className="flex items-start gap-2 p-3 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800">
              <Info className="w-4 h-4 flex-shrink-0 mt-0.5" />
              No Procurement Lead assigned. MR will be saved but no task will be auto-created.
            </div>
          )}

          {/* Section 1 — Header */}
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Requisition Details</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Subject / Title <span className="text-red-400">*</span></label>
                <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Electrical Materials – Block B Fit-out" required className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Project</label>
                <select value={projectId} onChange={(e) => setProjectId(e.target.value)} className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400">
                  <option value="">— No specific project —</option>
                  {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
                  Required Delivery Date <span className="text-red-400">*</span>
                </label>
                <input
                  type="date"
                  value={requiredDeliveryDate}
                  onChange={(e) => setRequiredDeliveryDate(e.target.value)}
                  required
                  min={new Date().toISOString().split('T')[0]}
                  className="w-full px-3 py-2.5 border border-amber-300 bg-amber-50 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-amber-400"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Preferred Supplier</label>
                <input type="text" value={supplier} onChange={(e) => setSupplier(e.target.value)} placeholder="Preferred vendor / supplier name" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
              </div>
            </div>
          </div>

          {/* Section 2 — Items */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Material Items <span className="text-red-400">*</span></p>
              <button type="button" onClick={addItem} className="flex items-center gap-1 text-xs font-medium text-teal-600 hover:text-teal-700 px-2 py-1 rounded-lg hover:bg-teal-50 transition-colors">
                <Plus className="w-3.5 h-3.5" />Add Item
              </button>
            </div>
            <div className="border border-gray-200 rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[700px]">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-200">
                      {['#', 'Material Description *', 'Specification / Rating', 'Proposed Make / Mfr.', 'Country of Origin', 'Qty', 'Unit', ''].map((h, i) => (
                        <th key={i} className={`px-3 py-2.5 text-xs font-semibold text-gray-500 text-left ${i === 0 ? 'w-8' : ''} ${i === 5 ? 'w-20' : ''} ${i === 6 ? 'w-20' : ''} ${i === 7 ? 'w-8' : ''}`}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {items.map((item, i) => (
                      <tr key={i}>
                        <td className="px-3 py-2 text-xs text-gray-400 text-center">{i + 1}</td>
                        <td className="px-2 py-2 min-w-[180px]">
                          <input type="text" value={item.description} onChange={(e) => updateItem(i, 'description', e.target.value)} placeholder="Material description" required className="w-full px-2 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-teal-400" />
                        </td>
                        <td className="px-2 py-2 min-w-[150px]">
                          <input type="text" value={item.specification ?? ''} onChange={(e) => updateItem(i, 'specification', e.target.value)} placeholder="e.g. 1.5mm², 230V" className="w-full px-2 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-teal-400" />
                        </td>
                        <td className="px-2 py-2 min-w-[150px]">
                          <input type="text" value={item.proposed_make ?? ''} onChange={(e) => updateItem(i, 'proposed_make', e.target.value)} placeholder="e.g. Schneider" className="w-full px-2 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-teal-400" />
                        </td>
                        <td className="px-2 py-2 min-w-[130px]">
                          <input type="text" value={item.country_of_origin ?? ''} onChange={(e) => updateItem(i, 'country_of_origin', e.target.value)} placeholder="e.g. Germany" className="w-full px-2 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-teal-400" />
                        </td>
                        <td className="px-2 py-2">
                          <input type="number" min="0" step="any" value={item.quantity} onChange={(e) => updateItem(i, 'quantity', parseFloat(e.target.value) || 0)} className="w-full px-2 py-1.5 border border-gray-200 rounded-lg text-sm text-right focus:outline-none focus:ring-1 focus:ring-teal-400" />
                        </td>
                        <td className="px-2 py-2">
                          <input type="text" value={item.unit} onChange={(e) => updateItem(i, 'unit', e.target.value)} placeholder="pcs" className="w-full px-2 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-teal-400" />
                        </td>
                        <td className="px-2 py-2">
                          <button type="button" onClick={() => removeItem(i)} disabled={items.length === 1} className="p-1 text-gray-300 hover:text-red-500 disabled:opacity-20 transition-colors">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Section 3 — Remarks */}
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Additional Remarks</p>
            <textarea value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Any additional notes, urgency, or special instructions…" rows={3} className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 resize-none" />
          </div>

          {/* Section 4 — Attachments */}
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">
              Attachments <span className="text-gray-300 font-normal normal-case">(optional — drawings, specs, photos)</span>
            </p>
            {attachmentFiles.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-3">
                {attachmentFiles.map((file, i) => (
                  <span key={i} className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-lg text-xs font-medium text-blue-800">
                    <Paperclip className="w-3 h-3 flex-shrink-0" />
                    <span className="max-w-[200px] truncate">{file.name}</span>
                    <span className="text-blue-400 flex-shrink-0">({(file.size / 1024).toFixed(0)} KB)</span>
                    <button type="button" onClick={() => removeAttachment(i)} className="text-blue-400 hover:text-red-500 transition-colors flex-shrink-0">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}
            <label className="flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed border-gray-200 rounded-xl cursor-pointer hover:border-teal-400 hover:bg-teal-50/30 transition-all group">
              <Upload className="w-4 h-4 text-gray-400 group-hover:text-teal-500 transition-colors" />
              <span className="text-sm text-gray-500 group-hover:text-teal-600 transition-colors">
                {attachmentFiles.length > 0 ? 'Attach more files' : 'Click to attach files'}
              </span>
              <input type="file" multiple onChange={handleFileAdd} className="sr-only" />
            </label>
            {uploadStatus && (
              <p className="text-xs text-teal-600 mt-1.5 flex items-center gap-1.5">
                <Loader2 className="w-3 h-3 animate-spin" />{uploadStatus}
              </p>
            )}
          </div>

          {error && (
            <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-xl text-sm text-red-700">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />{error}
            </div>
          )}

          <div className="flex items-center gap-3 pt-1 border-t border-gray-100 flex-wrap">
            <button type="submit" disabled={submitting} className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm disabled:opacity-60 hover:from-teal-600 hover:to-blue-700 transition-all shadow-sm">
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              {submitting ? 'Submitting…' : 'Submit Requisition'}
            </button>
            <button
              type="button"
              onClick={handleSaveDraft}
              disabled={savingDraft || submitting}
              className="flex items-center gap-2 px-4 py-2.5 bg-white border border-gray-300 text-gray-700 font-medium rounded-xl text-sm hover:border-gray-400 hover:bg-gray-50 transition-all disabled:opacity-60"
            >
              {savingDraft ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              {savingDraft ? 'Saving…' : 'Save Draft'}
            </button>
            {draftSaved && (
              <span className="flex items-center gap-1.5 text-sm text-green-700 font-medium">
                <CheckCircle2 className="w-4 h-4" />Draft saved
              </span>
            )}
            <button type="button" onClick={onClose} className="ml-auto px-4 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
