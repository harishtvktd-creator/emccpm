import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../lib/supabase';
import {
  Settings as SettingsIcon,
  Tag,
  DollarSign,
  Plus,
  Trash2,
  Edit2,
  X,
  Save,
  Search,
  Palette,
  Bell,
  BellOff,
  Mail,
  Play,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Clock,
  Users,
  UserCheck,
  Download,
  KeyRound,
  Shield,
  ShoppingCart,
  Truck,
  Eye,
  EyeOff,
  CalendarClock,
  CalendarRange,
  MessageSquareDot,
  Info,
  AlertTriangle,
  ToggleLeft,
  ToggleRight,
} from 'lucide-react';
import type { Database } from '../lib/supabase';

type Category = Database['public']['Tables']['categories']['Row'];
type OpeningBalance = Database['public']['Tables']['opening_balances']['Row'];

const PRESET_COLORS = [
  '#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6',
  '#EC4899', '#06B6D4', '#84CC16', '#F97316', '#6366F1',
];

const PRESET_ICONS = [
  'Wallet', 'ShoppingCart', 'Home', 'Utensils', 'Car', 'Zap', 'Film',
  'Heart', 'GraduationCap', 'Plane', 'Gift', 'DollarSign', 'CreditCard',
  'Briefcase', 'Coffee', 'ShoppingBag', 'Smartphone', 'Wifi',
];

interface SettingsProps {
  onBack: () => void;
}

export function Settings({ onBack }: SettingsProps) {
  const { user } = useAuth();
  const [categories, setCategories] = useState<Category[]>([]);
  const [openingBalance, setOpeningBalance] = useState<OpeningBalance | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'categories' | 'balance' | 'reminders' | 'team-access' | 'work-schedule' | 'flash-message'>('categories');
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  const fetchData = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const [categoriesRes, balanceRes] = await Promise.all([
        supabase.from('categories').select('*').eq('user_id', user.id).order('created_at', { ascending: true }),
        supabase
          .from('opening_balances')
          .select('*')
          .eq('user_id', user.id)
          .order('date', { ascending: false })
          .maybeSingle(),
      ]);

      if (categoriesRes.data) setCategories(categoriesRes.data);
      if (balanceRes.data) setOpeningBalance(balanceRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleDeleteCategory = async (id: string) => {
    if (!confirm('Are you sure you want to delete this category? All transactions in this category will also be deleted.')) {
      return;
    }

    try {
      await supabase.from('categories').delete().eq('id', id);
      fetchData();
    } catch (error) {
      console.error('Error deleting category:', error);
    }
  };

  const handleCategorySaved = () => {
    setShowCategoryModal(false);
    setEditingCategory(null);
    fetchData();
  };

  const handleSetOpeningBalance = async (balance: number, date: string) => {
    try {
      if (openingBalance) {
        await supabase
          .from('opening_balances')
          .update({ balance, date })
          .eq('id', openingBalance.id);
      } else {
        await supabase.from('opening_balances').insert({
          user_id: user!.id,
          balance,
          date,
        });
      }
      fetchData();
    } catch (error) {
      console.error('Error setting opening balance:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50">
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="text-gray-600 hover:text-gray-900">
              <X className="w-6 h-6" />
            </button>
            <div className="flex items-center gap-2">
              <SettingsIcon className="w-6 h-6 text-gray-600" />
              <h1 className="text-xl font-bold text-gray-900">Settings</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-4 mb-6">
          <button
            onClick={() => setActiveTab('categories')}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'categories'
                ? 'bg-white shadow text-gray-900'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Tag className="w-4 h-4 inline mr-2" />
            Categories
          </button>
          <button
            onClick={() => setActiveTab('balance')}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'balance'
                ? 'bg-white shadow text-gray-900'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <DollarSign className="w-4 h-4 inline mr-2" />
            Opening Balance
          </button>
          <button
            onClick={() => setActiveTab('reminders')}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'reminders'
                ? 'bg-white shadow text-gray-900'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Bell className="w-4 h-4 inline mr-2" />
            Email Reminders
          </button>
          <button
            onClick={() => setActiveTab('team-access')}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'team-access'
                ? 'bg-white shadow text-gray-900'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <KeyRound className="w-4 h-4 inline mr-2" />
            Team Access
          </button>
          <button
            onClick={() => setActiveTab('work-schedule')}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'work-schedule'
                ? 'bg-white shadow text-gray-900'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <CalendarClock className="w-4 h-4 inline mr-2" />
            Work Schedule
          </button>
          <button
            onClick={() => setActiveTab('flash-message')}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'flash-message'
                ? 'bg-white shadow text-gray-900'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <MessageSquareDot className="w-4 h-4 inline mr-2" />
            Flash Message
          </button>
        </div>

        {activeTab === 'categories' && (
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Manage Categories</h2>
              <button
                onClick={() => {
                  setEditingCategory(null);
                  setShowCategoryModal(true);
                }}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg hover:from-teal-600 hover:to-blue-700 transition-all"
              >
                <Plus className="w-4 h-4" />
                Add Category
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {categories.filter((c) => c.type === 'income').length > 0 && (
                <div className="md:col-span-2">
                  <h3 className="text-sm font-medium text-gray-500 mb-2">Income Categories</h3>
                </div>
              )}
              {categories
                .filter((c) => c.type === 'income')
                .map((category) => (
                  <div
                    key={category.id}
                    className="flex items-center justify-between p-4 bg-emerald-50 rounded-xl border border-emerald-100"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: category.color }}
                      >
                        <div className="w-5 h-5 bg-white rounded opacity-80" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{category.name}</p>
                        <p className="text-sm text-gray-500">Income</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setEditingCategory(category);
                          setShowCategoryModal(true);
                        }}
                        className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteCategory(category.id)}
                        className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}

              {categories.filter((c) => c.type === 'expense').length > 0 && (
                <div className="md:col-span-2 mt-4">
                  <h3 className="text-sm font-medium text-gray-500 mb-2">Expense Categories</h3>
                </div>
              )}
              {categories
                .filter((c) => c.type === 'expense')
                .map((category) => (
                  <div
                    key={category.id}
                    className="flex items-center justify-between p-4 bg-red-50 rounded-xl border border-red-100"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: category.color }}
                      >
                        <div className="w-5 h-5 bg-white rounded opacity-80" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{category.name}</p>
                        <p className="text-sm text-gray-500">Expense</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setEditingCategory(category);
                          setShowCategoryModal(true);
                        }}
                        className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteCategory(category.id)}
                        className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
            </div>

            {categories.length === 0 && (
              <div className="text-center py-12">
                <Tag className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500 mb-2">No categories yet</p>
                <p className="text-sm text-gray-400">Create your first category to start tracking transactions</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'balance' && (
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <h2 className="text-lg font-semibold text-gray-900 mb-6">Opening Balance</h2>
            <OpeningBalanceForm
              openingBalance={openingBalance}
              onSave={handleSetOpeningBalance}
            />
          </div>
        )}
        {activeTab === 'reminders' && (
          <EmailReminderSettings />
        )}
        {activeTab === 'team-access' && (
          <TeamAccessExport />
        )}
        {activeTab === 'work-schedule' && (
          <WorkScheduleSettings />
        )}
        {activeTab === 'flash-message' && (
          <FlashMessageSettings />
        )}
      </main>

      {showCategoryModal && (
        <CategoryModal
          category={editingCategory}
          userId={user!.id}
          onClose={() => {
            setShowCategoryModal(false);
            setEditingCategory(null);
          }}
          onSave={handleCategorySaved}
        />
      )}
    </div>
  );
}

function OpeningBalanceForm({
  openingBalance,
  onSave,
}: {
  openingBalance: OpeningBalance | null;
  onSave: (balance: number, date: string) => void;
}) {
  const [balance, setBalance] = useState(openingBalance?.balance.toString() || '0');
  const [date, setDate] = useState(
    openingBalance?.date || new Date().toISOString().split('T')[0]
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(parseFloat(balance) || 0, date);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="p-6 bg-blue-50 rounded-xl border border-blue-200">
        <p className="text-sm text-blue-800 mb-4">
          The opening balance is your starting cash amount. All cash flow calculations are based on this amount plus your transactions.
        </p>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Opening Balance Amount
          </label>
          <div className="relative">
            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="number"
              step="0.01"
              value={balance}
              onChange={(e) => setBalance(e.target.value)}
              className="w-full pl-10 pr-4 py-3 text-2xl font-bold border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="0.00"
            />
          </div>
        </div>
        <div className="mt-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Effective From Date
          </label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <p className="text-xs text-gray-500 mt-3">
          Set this to the earliest date you want to track transactions from.
        </p>
      </div>
      <button
        type="submit"
        className="w-full py-3 px-4 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg hover:from-teal-600 hover:to-blue-700 transition-all flex items-center justify-center gap-2"
      >
        <Save className="w-5 h-5" />
        Save Opening Balance
      </button>
    </form>
  );
}

type TeamMemberBasic = { id: string; name: string; email: string; department: string | null; role: string | null };

// Preset time options (local UAE time)
const TIME_PRESETS = [
  '06:00', '06:30', '07:00', '07:30', '08:00', '08:30',
  '09:00', '09:30', '10:00', '10:30', '11:00', '12:00',
];

function fmt12h(t: string) {
  const [hStr, mStr] = t.split(':');
  let h = parseInt(hStr, 10);
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return `${h}:${mStr} ${ampm}`;
}

function EmailReminderSettings() {
  const [enabled, setEnabled] = useState(false);
  const [senderName, setSenderName] = useState('EMCC Projects Division');
  const [senderEmail, setSenderEmail] = useState('');
  const [replyTo, setReplyTo] = useState('');
  const [sendTime, setSendTime] = useState('08:30');
  const [includedIds, setIncludedIds] = useState<string[]>([]);
  const [allMembers, setAllMembers] = useState<TeamMemberBasic[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [saved, setSaved] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);
  const [memberSearch, setMemberSearch] = useState('');

  useEffect(() => {
    (async () => {
      const [settingsRes, membersRes] = await Promise.all([
        supabase.from('email_reminder_settings').select('*').maybeSingle(),
        supabase.from('team_members').select('id,name,email,department,role').eq('is_active', true).order('name'),
      ]);
      if (settingsRes.data) {
        setEnabled(settingsRes.data.enabled);
        setSenderName(settingsRes.data.sender_name ?? 'EMCC Projects Division');
        setSenderEmail(settingsRes.data.sender_email ?? '');
        setReplyTo(settingsRes.data.reply_to ?? '');
        setSendTime(settingsRes.data.send_time ?? '08:30');
        setIncludedIds((settingsRes.data.included_member_ids as string[]) ?? []);
      }
      if (membersRes.data) setAllMembers(membersRes.data as TeamMemberBasic[]);
      setLoading(false);
    })();
  }, []);

  const toggleMember = (id: string) => {
    setIncludedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const selectAll = () => setIncludedIds(allMembers.map((m) => m.id));
  const deselectAll = () => setIncludedIds([]);

  const filteredMembers = allMembers.filter(
    (m) =>
      !memberSearch ||
      m.name.toLowerCase().includes(memberSearch.toLowerCase()) ||
      (m.department ?? '').toLowerCase().includes(memberSearch.toLowerCase())
  );

  const selectedCount = includedIds.length;
  const allSelected = selectedCount === allMembers.length;
  const noneSelected = selectedCount === 0;

  const handleSave = async () => {
    setSaving(true);
    setSaved(false);
    const { data: existing } = await supabase
      .from('email_reminder_settings')
      .select('id')
      .maybeSingle();
    const payload = {
      enabled,
      sender_name: senderName,
      sender_email: senderEmail,
      reply_to: replyTo,
      send_time: sendTime,
      included_member_ids: includedIds,
    };
    if (existing) {
      await supabase.from('email_reminder_settings').update(payload).eq('id', existing.id);
    } else {
      await supabase.from('email_reminder_settings').insert(payload);
    }
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleTestSend = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-task-reminders`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: '{}',
      });
      const json = await res.json();
      if (res.ok && json.success) {
        const sent = json.results?.filter((r: { status: string }) => r.status === 'sent').length ?? 0;
        setTestResult({ ok: true, message: `Sent ${sent} reminder email${sent !== 1 ? 's' : ''} successfully.` });
      } else {
        setTestResult({ ok: false, message: json.message || json.error || 'Unknown error.' });
      }
    } catch (e) {
      setTestResult({ ok: false, message: String(e) });
    }
    setTesting(false);
  };

  if (loading) {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-12 border border-gray-100 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-teal-500" />
      </div>
    );
  }

  return (
    <div className="space-y-5">

      {/* ── Card 1: Master toggle ── */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className={`p-5 flex items-center justify-between gap-4 ${enabled ? 'bg-gradient-to-r from-teal-50 to-blue-50' : 'bg-gray-50'} transition-colors`}>
          <div className="flex items-center gap-4">
            <div className={`w-11 h-11 rounded-xl flex items-center justify-center shadow-sm flex-shrink-0 ${enabled ? 'bg-gradient-to-br from-teal-500 to-blue-600' : 'bg-gray-200'} transition-all`}>
              {enabled ? <Bell className="w-5 h-5 text-white" /> : <BellOff className="w-5 h-5 text-gray-400" />}
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Daily Email Reminders</h3>
              <p className="text-sm text-gray-500 mt-0.5">
                {enabled
                  ? <span className="text-teal-700 font-medium">Active — sends at <strong>{fmt12h(sendTime)}</strong> every day</span>
                  : 'Disabled — no emails will be sent'}
              </p>
            </div>
          </div>
          <button
            onClick={() => setEnabled(!enabled)}
            className={`relative inline-flex h-7 w-14 flex-shrink-0 items-center rounded-full transition-colors focus:outline-none ${enabled ? 'bg-teal-500' : 'bg-gray-300'}`}
          >
            <span className={`inline-block h-5 w-5 transform rounded-full bg-white shadow-md transition-transform ${enabled ? 'translate-x-8' : 'translate-x-1'}`} />
          </button>
        </div>
      </div>

      {/* ── Card 2: Time & sender config ── */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100 flex items-center gap-2">
          <Clock className="w-4 h-4 text-teal-600" />
          <h4 className="font-semibold text-gray-900 text-sm">Reminder Time & Sender</h4>
        </div>
        <div className="p-5 space-y-5">
          {/* Time picker */}
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">
              Send Time <span className="text-gray-400 font-normal normal-case">(UAE / GST — UTC+4)</span>
            </label>
            <div className="flex flex-wrap gap-2 mb-3">
              {TIME_PRESETS.map((t) => (
                <button
                  key={t}
                  onClick={() => setSendTime(t)}
                  className={`px-3 py-2 rounded-lg text-sm font-medium border transition-all ${
                    sendTime === t
                      ? 'bg-teal-600 text-white border-teal-600 shadow-sm'
                      : 'bg-white text-gray-600 border-gray-200 hover:border-teal-300 hover:text-teal-600'
                  }`}
                >
                  {fmt12h(t)}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs text-gray-400">Custom:</span>
              <input
                type="time"
                value={sendTime}
                onChange={(e) => setSendTime(e.target.value)}
                className="text-sm border border-gray-200 rounded-lg px-3 py-2 text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-teal-400"
              />
              <span className="text-sm text-gray-500 font-medium">{fmt12h(sendTime)} local time</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Sender Name</label>
              <input
                type="text"
                value={senderName}
                onChange={(e) => setSenderName(e.target.value)}
                placeholder="EMCC Projects Division"
                className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-teal-400"
              />
              <p className="text-xs text-gray-400 mt-1">"From" display name in email clients</p>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Reply-To Email</label>
              <input
                type="email"
                value={replyTo}
                onChange={(e) => setReplyTo(e.target.value)}
                placeholder="admin@yourcompany.com"
                className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-teal-400"
              />
              <p className="text-xs text-gray-400 mt-1">Optional — where team member replies go</p>
            </div>
          </div>

          {/* Custom sender domain */}
          <div className="border border-gray-200 rounded-xl overflow-hidden">
            <div className="bg-gray-50 px-4 py-3 border-b border-gray-200 flex items-center gap-2">
              <Mail className="w-4 h-4 text-teal-600" />
              <span className="text-sm font-semibold text-gray-700">Custom Sender Domain</span>
              <span className="ml-auto text-xs text-gray-400 bg-white border border-gray-200 px-2 py-0.5 rounded-full">
                Requires Resend domain verification
              </span>
            </div>
            <div className="p-4 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
                  From Email Address
                </label>
                <input
                  type="email"
                  value={senderEmail}
                  onChange={(e) => setSenderEmail(e.target.value)}
                  placeholder="reminders@yourdomain.com"
                  className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-teal-400"
                />
              </div>
              <div className="flex items-start gap-2 text-xs text-gray-500 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2.5">
                <AlertCircle className="w-3.5 h-3.5 text-amber-500 flex-shrink-0 mt-0.5" />
                <span>
                  The domain in this address must be verified in your{' '}
                  <strong>Resend account → Domains</strong> before emails can be sent from it.
                  Leave blank to use the default <code className="bg-amber-100 px-1 rounded">onboarding@resend.dev</code> address (Resend sandbox only).
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Card 3: Team member selection ── */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-teal-600" />
            <h4 className="font-semibold text-gray-900 text-sm">Recipient Team Members</h4>
            <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${noneSelected ? 'bg-blue-100 text-blue-700' : 'bg-teal-100 text-teal-700'}`}>
              {noneSelected ? 'All members' : `${selectedCount} selected`}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={selectAll}
              disabled={allSelected}
              className="text-xs font-medium text-teal-600 hover:text-teal-700 disabled:opacity-40 px-2 py-1 rounded hover:bg-teal-50 transition-colors"
            >
              Select All
            </button>
            <span className="text-gray-300">|</span>
            <button
              onClick={deselectAll}
              disabled={noneSelected}
              className="text-xs font-medium text-gray-500 hover:text-gray-700 disabled:opacity-40 px-2 py-1 rounded hover:bg-gray-50 transition-colors"
            >
              Clear All
            </button>
          </div>
        </div>

        <div className="p-4 border-b border-gray-100 bg-gray-50">
          <p className="text-xs text-gray-500 mb-3">
            {noneSelected
              ? 'No members ticked — reminders will be sent to all active members.'
              : `Only the ${selectedCount} ticked member${selectedCount !== 1 ? 's' : ''} will receive reminders.`}
          </p>
          <input
            type="text"
            value={memberSearch}
            onChange={(e) => setMemberSearch(e.target.value)}
            placeholder="Search by name or department…"
            className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-800 bg-white focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-teal-400"
          />
        </div>

        <div className="divide-y divide-gray-50 max-h-80 overflow-y-auto">
          {filteredMembers.length === 0 && (
            <p className="text-sm text-gray-400 text-center py-8">No members match your search</p>
          )}
          {filteredMembers.map((m) => {
            const checked = includedIds.includes(m.id);
            return (
              <label
                key={m.id}
                className={`flex items-center gap-4 px-5 py-3 cursor-pointer transition-colors ${checked ? 'bg-teal-50' : 'hover:bg-gray-50'}`}
              >
                {/* Checkbox */}
                <div className={`w-5 h-5 rounded flex-shrink-0 border-2 flex items-center justify-center transition-all ${
                  checked ? 'bg-teal-500 border-teal-500' : 'border-gray-300 bg-white'
                }`}>
                  {checked && <CheckCircle2 className="w-3.5 h-3.5 text-white" />}
                </div>
                {/* Avatar */}
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold ${
                  checked ? 'bg-teal-500 text-white' : 'bg-gray-200 text-gray-600'
                }`}>
                  {m.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                </div>
                {/* Info */}
                <div className="flex-1 min-w-0">
                  <p className={`text-sm font-medium truncate ${checked ? 'text-teal-900' : 'text-gray-800'}`}>{m.name}</p>
                  <p className="text-xs text-gray-400 truncate">{m.department ?? ''}{m.department && m.role ? ' · ' : ''}{m.role ?? ''}</p>
                </div>
                <div className="text-xs text-gray-400 truncate max-w-[160px] hidden sm:block">{m.email}</div>
                {checked && <UserCheck className="w-4 h-4 text-teal-500 flex-shrink-0" />}
                <input type="checkbox" className="sr-only" checked={checked} onChange={() => toggleMember(m.id)} />
              </label>
            );
          })}
        </div>
      </div>

      {/* ── Card 4: How it works ── */}
      <div className="bg-blue-50 border border-blue-100 rounded-2xl p-5 flex gap-3">
        <Mail className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-blue-700 space-y-1">
          <p className="font-semibold">How it works</p>
          <ul className="list-disc list-inside space-y-0.5 text-blue-600">
            <li>Emails are sent daily at the configured time (UAE local time)</li>
            <li>Each member gets their own personalised email with today's + overdue tasks</li>
            <li>Members with no due/overdue tasks are skipped automatically</li>
            <li>Emails are delivered via <strong>Resend</strong> — a <code className="bg-blue-100 px-1 rounded">RESEND_API_KEY</code> secret is required</li>
          </ul>
        </div>
      </div>

      {/* ── Action bar ── */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 px-5 py-4 flex flex-wrap items-center gap-3">
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg text-sm disabled:opacity-60 hover:from-teal-600 hover:to-blue-700 transition-all shadow-sm"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          {saving ? 'Saving…' : 'Save Settings'}
        </button>
        {saved && (
          <span className="flex items-center gap-1.5 text-sm text-green-600 font-medium">
            <CheckCircle2 className="w-4 h-4" />
            Settings saved
          </span>
        )}
        <div className="ml-auto flex items-center gap-3">
          <button
            onClick={handleTestSend}
            disabled={testing}
            className="flex items-center gap-2 px-4 py-2.5 bg-white border border-gray-200 text-gray-700 font-medium rounded-lg text-sm hover:border-teal-300 hover:text-teal-600 disabled:opacity-60 transition-all"
          >
            {testing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            {testing ? 'Sending…' : 'Send Test Now'}
          </button>
        </div>
      </div>

      {/* Test result */}
      {testResult && (
        <div className={`flex items-start gap-2.5 px-4 py-3 rounded-xl text-sm font-medium border ${
          testResult.ok ? 'bg-green-50 text-green-700 border-green-200' : 'bg-red-50 text-red-700 border-red-200'
        }`}>
          {testResult.ok
            ? <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5" />
            : <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />}
          {testResult.message}
        </div>
      )}
    </div>
  );
}

/* ── Team Access Export ─────────────────────────────────────── */
type TeamMemberFull = {
  id: string;
  name: string;
  email: string;
  department: string | null;
  role: string | null;
  is_active: boolean;
  is_admin: boolean;
  is_procurement_lead: boolean;
  is_material_coordinator: boolean;
  user_id: string | null;
  login_password_hint: string | null;
};

function TeamAccessExport() {
  const [members, setMembers] = useState<TeamMemberFull[]>([]);
  const [loading, setLoading] = useState(true);
  const [revealId, setRevealId] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('team_members')
        .select('id,name,email,department,role,is_active,is_admin,is_procurement_lead,is_material_coordinator,user_id,login_password_hint')
        .order('name', { ascending: true });
      setMembers((data as TeamMemberFull[]) ?? []);
      setLoading(false);
    })();
  }, []);

  const exportCSV = () => {
    const header = ['Name', 'Login Email', 'Department', 'Role', 'Admin', 'Procurement Lead', 'Material Coordinator', 'Login Set', 'Password'];
    const rows = members.map((m) => [
      `"${m.name.replace(/"/g, '""')}"`,
      m.email,
      `"${(m.department ?? '').replace(/"/g, '""')}"`,
      `"${(m.role ?? '').replace(/"/g, '""')}"`,
      m.is_admin ? 'Yes' : 'No',
      m.is_procurement_lead ? 'Yes' : 'No',
      m.is_material_coordinator ? 'Yes' : 'No',
      m.user_id ? 'Yes' : 'No',
      `"${(m.login_password_hint ?? '').replace(/"/g, '""')}"`,
    ]);
    const csv = [header, ...rows].map((r) => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `team-credentials-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-12 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-teal-500" />
      </div>
    );
  }

  const loginSet = members.filter((m) => m.user_id).length;

  return (
    <div className="space-y-5">
      {/* Header card */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-6 py-5 border-b border-gray-100 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-blue-600 rounded-xl flex items-center justify-center shadow-sm">
              <KeyRound className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Team Login Credentials</h3>
              <p className="text-xs text-gray-500 mt-0.5">{members.length} members · {loginSet} with login set</p>
            </div>
          </div>
          <button
            onClick={exportCSV}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg text-sm hover:from-teal-600 hover:to-blue-700 transition-all shadow-sm"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        </div>

        {/* Security notice */}
        <div className="px-6 py-3 bg-amber-50 border-b border-amber-100 flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700">
            Passwords shown here are the credentials set by admin via "Create Login" or "Reset". Store and share this file securely — it contains login credentials.
          </p>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Name</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Login Email</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Department / Role</th>
                <th className="text-center px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Roles</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Login</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Password</th>
              </tr>
            </thead>
            <tbody>
              {members.map((m) => {
                const revealed = revealId === m.id;
                const roles = [
                  m.is_admin && { label: 'Admin', color: 'bg-blue-100 text-blue-700', icon: Shield },
                  m.is_procurement_lead && { label: 'Procurement Lead', color: 'bg-orange-100 text-orange-700', icon: ShoppingCart },
                  m.is_material_coordinator && { label: 'Material Coordinator', color: 'bg-emerald-100 text-emerald-700', icon: Truck },
                ].filter(Boolean) as { label: string; color: string; icon: React.ElementType }[];

                return (
                  <tr key={m.id} className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${!m.is_active ? 'opacity-50' : ''}`}>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-teal-500 to-blue-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                          {m.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-gray-900 leading-tight">{m.name}</p>
                          {!m.is_active && <span className="text-xs text-gray-400">Inactive</span>}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">{m.email}</td>
                    <td className="px-4 py-3">
                      <p className="text-sm text-gray-700">{m.department ?? '—'}</p>
                      {m.role && <p className="text-xs text-gray-400">{m.role}</p>}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1 justify-center">
                        {roles.length === 0
                          ? <span className="text-xs text-gray-300">—</span>
                          : roles.map(({ label, color, icon: Icon }) => (
                              <span key={label} className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-xs font-medium ${color}`}>
                                <Icon className="w-3 h-3" />{label}
                              </span>
                            ))
                        }
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {m.user_id
                        ? <span className="inline-flex items-center gap-1 text-xs text-green-600 font-medium"><CheckCircle2 className="w-3.5 h-3.5" />Set</span>
                        : <span className="text-xs text-gray-400">Not set</span>
                      }
                    </td>
                    <td className="px-5 py-3">
                      {m.login_password_hint ? (
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-mono text-gray-800">
                            {revealed ? m.login_password_hint : '••••••••'}
                          </span>
                          <button
                            onClick={() => setRevealId(revealed ? null : m.id)}
                            className="p-1 text-gray-400 hover:text-gray-600 rounded transition-colors flex-shrink-0"
                            title={revealed ? 'Hide password' : 'Reveal password'}
                          >
                            {revealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs text-gray-300 italic">Not recorded</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {members.length === 0 && (
            <div className="py-16 text-center">
              <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500 font-medium">No team members yet</p>
            </div>
          )}
        </div>

        <div className="px-5 py-3 border-t border-gray-100">
          <p className="text-xs text-gray-400">
            Passwords are only recorded when set via "Create Login" or "Reset" in Team Members. Members created before this feature was added show "Not recorded".
          </p>
        </div>
      </div>
    </div>
  );
}

/* ── Work Schedule Settings ─────────────────────────────────── */

const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

type WorkScheduleRow = {
  day_of_week: number;
  normal_hours: number;
  is_working_day: boolean;
};

type DateOverride = {
  id: string;
  label: string;
  date_from: string;
  date_to: string;
  normal_hours: number;
  project_id: string | null;
  project_name?: string;
};

function WorkScheduleSettings() {
  const { isAdmin } = useAuth();
  const [subTab, setSubTab] = useState<'weekly' | 'by-date'>('weekly');

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-1.5 flex gap-1">
        {([
          { id: 'weekly', label: 'Weekly Schedule', icon: CalendarClock },
          { id: 'by-date', label: 'By Date', icon: CalendarRange },
        ] as const).map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setSubTab(id)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-sm font-semibold transition-all ${
              subTab === id
                ? 'bg-gradient-to-r from-teal-500 to-blue-600 text-white shadow-sm'
                : 'text-gray-500 hover:text-gray-800 hover:bg-gray-50'
            }`}
          >
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </div>

      {subTab === 'weekly' && <WeeklyScheduleTab isAdmin={isAdmin} />}
      {subTab === 'by-date' && <ByDateTab isAdmin={isAdmin} />}

      {!isAdmin && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl px-5 py-4 flex items-center gap-2 text-sm text-amber-700">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          Only admins can modify the work schedule.
        </div>
      )}
    </div>
  );
}

/* ── Weekly Schedule Tab (Global + per-Project) ─────────────── */
function WeeklyScheduleTab({ isAdmin }: { isAdmin: boolean }) {
  const [projects, setProjects]       = useState<{ id: string; name: string }[]>([]);
  const [selectedProject, setSelectedProject] = useState<string>('global');
  const [rows, setRows]               = useState<WorkScheduleRow[]>([]);
  const [loading, setLoading]         = useState(true);
  const [saving, setSaving]           = useState(false);
  const [saved, setSaved]             = useState(false);
  const [error, setError]             = useState<string | null>(null);
  const [hasProjectSchedule, setHasProjectSchedule] = useState(false);

  const defaultRows = (fri0 = true): WorkScheduleRow[] =>
    Array.from({ length: 7 }, (_, i) => ({
      day_of_week: i,
      normal_hours: i === 5 ? 0 : 9,
      is_working_day: !(i === 5 && fri0),
    }));

  useEffect(() => {
    supabase.from('projects').select('id,name').order('name').then(({ data }) => {
      setProjects((data ?? []) as { id: string; name: string }[]);
    });
  }, []);

  useEffect(() => {
    setLoading(true);
    setSaved(false);
    setError(null);
    if (selectedProject === 'global') {
      supabase
        .from('work_schedule')
        .select('day_of_week,normal_hours,is_working_day')
        .order('day_of_week')
        .then(({ data }) => {
          setRows(data && data.length === 7 ? (data as WorkScheduleRow[]) : defaultRows());
          setHasProjectSchedule(false);
          setLoading(false);
        });
    } else {
      supabase
        .from('work_schedule_project_weekly')
        .select('day_of_week,normal_hours,is_working_day')
        .eq('project_id', selectedProject)
        .order('day_of_week')
        .then(({ data }) => {
          if (data && data.length === 7) {
            setRows(data as WorkScheduleRow[]);
            setHasProjectSchedule(true);
          } else {
            // Show global schedule as a starting template, but not yet saved for this project
            supabase
              .from('work_schedule')
              .select('day_of_week,normal_hours,is_working_day')
              .order('day_of_week')
              .then(({ data: global }) => {
                setRows(global && global.length === 7 ? (global as WorkScheduleRow[]) : defaultRows());
                setHasProjectSchedule(false);
                setLoading(false);
              });
            return;
          }
          setLoading(false);
        });
    }
  }, [selectedProject]);

  const update = (idx: number, field: keyof WorkScheduleRow, value: number | boolean) => {
    setRows((prev) => prev.map((r, i) => {
      if (i !== idx) return r;
      const updated = { ...r, [field]: value };
      if (field === 'is_working_day' && !value) updated.normal_hours = 0;
      return updated;
    }));
    setSaved(false);
  };

  const handleSave = async () => {
    setSaving(true);
    setError(null);
    if (selectedProject === 'global') {
      for (const row of rows) {
        const { error: err } = await supabase
          .from('work_schedule')
          .update({ normal_hours: row.normal_hours, is_working_day: row.is_working_day })
          .eq('day_of_week', row.day_of_week);
        if (err) { setError(err.message); setSaving(false); return; }
      }
    } else {
      // Upsert all 7 rows for this project
      const upsertRows = rows.map((r) => ({
        project_id: selectedProject,
        day_of_week: r.day_of_week,
        normal_hours: r.normal_hours,
        is_working_day: r.is_working_day,
      }));
      const { error: err } = await supabase
        .from('work_schedule_project_weekly')
        .upsert(upsertRows, { onConflict: 'project_id,day_of_week' });
      if (err) { setError(err.message); setSaving(false); return; }
      setHasProjectSchedule(true);
    }
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleDeleteProjectSchedule = async () => {
    if (!confirm('Remove the custom schedule for this project? It will fall back to the global schedule.')) return;
    await supabase.from('work_schedule_project_weekly').delete().eq('project_id', selectedProject);
    setHasProjectSchedule(false);
    // Reload global as template
    const { data } = await supabase.from('work_schedule').select('day_of_week,normal_hours,is_working_day').order('day_of_week');
    setRows(data && data.length === 7 ? (data as WorkScheduleRow[]) : defaultRows());
  };

  if (loading) {
    return (
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-12 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-teal-500" />
      </div>
    );
  }

  const totalWeeklyHours = rows.reduce((s, r) => s + r.normal_hours, 0);
  const isProjectMode = selectedProject !== 'global';

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        {/* Header + project picker */}
        <div className="px-6 py-5 border-b border-gray-100">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-blue-600 rounded-xl flex items-center justify-center shadow-sm">
                <CalendarClock className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900">Normal Working Hours per Day</h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  {isProjectMode
                    ? hasProjectSchedule
                      ? 'Custom schedule for this project'
                      : 'No custom schedule yet — showing global template'
                    : 'Global default — applies to all projects without a custom schedule'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">Schedule for</label>
              <select
                value={selectedProject}
                onChange={(e) => setSelectedProject(e.target.value)}
                className="px-3 py-2 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400 min-w-[180px]"
              >
                <option value="global">Global (All Projects)</option>
                {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
              {isProjectMode && hasProjectSchedule && isAdmin && (
                <button
                  onClick={handleDeleteProjectSchedule}
                  className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  title="Remove custom schedule for this project"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Info banner */}
        <div className={`px-6 py-3 border-b flex items-start gap-2.5 ${isProjectMode && !hasProjectSchedule ? 'bg-amber-50 border-amber-100' : 'bg-blue-50 border-blue-100'}`}>
          <AlertCircle className={`w-4 h-4 flex-shrink-0 mt-0.5 ${isProjectMode && !hasProjectSchedule ? 'text-amber-500' : 'text-blue-500'}`} />
          <p className={`text-xs ${isProjectMode && !hasProjectSchedule ? 'text-amber-700' : 'text-blue-700'}`}>
            {isProjectMode && !hasProjectSchedule
              ? <><strong>No custom schedule saved yet.</strong> Edit the hours below and click Save to create a custom schedule for this project.</>
              : isProjectMode
                ? <><strong>Project schedule active.</strong> This overrides the global defaults for all employees on this project.</>
                : <><strong>Global schedule</strong> — applies when no project-specific schedule exists. Hours beyond the threshold = Overtime.</>
            }
          </p>
        </div>

        {/* Schedule grid */}
        <div className="p-6">
          <div className="space-y-3">
            {rows.map((row, idx) => (
              <div key={row.day_of_week} className={`flex items-center gap-4 p-4 rounded-xl border transition-all ${row.is_working_day ? 'bg-white border-gray-200' : 'bg-gray-50 border-dashed border-gray-200'}`}>
                <button
                  type="button"
                  disabled={!isAdmin}
                  onClick={() => update(idx, 'is_working_day', !row.is_working_day)}
                  className={`relative inline-flex h-6 w-11 flex-shrink-0 items-center rounded-full transition-colors focus:outline-none ${row.is_working_day ? 'bg-teal-500' : 'bg-gray-300'} ${!isAdmin ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'}`}
                >
                  <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${row.is_working_day ? 'translate-x-6' : 'translate-x-1'}`} />
                </button>
                <div className="w-24 flex-shrink-0">
                  <p className={`text-sm font-semibold ${row.is_working_day ? 'text-gray-900' : 'text-gray-400'}`}>{DAY_NAMES[row.day_of_week]}</p>
                  <p className="text-xs text-gray-400">{row.is_working_day ? 'Working day' : 'Rest day'}</p>
                </div>
                <div className="flex items-center gap-3 flex-1">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">Normal Hours</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number" min="0" max="24" step="0.5"
                      value={row.normal_hours}
                      disabled={!isAdmin}
                      onChange={(e) => update(idx, 'normal_hours', Math.min(24, Math.max(0, parseFloat(e.target.value) || 0)))}
                      className={`w-20 px-3 py-2 border rounded-lg text-sm text-center font-semibold focus:outline-none focus:ring-2 focus:ring-teal-400 ${
                        !isAdmin ? 'bg-gray-50 text-gray-400 cursor-not-allowed border-gray-100' :
                        row.is_working_day ? 'border-teal-200 bg-teal-50 text-teal-900' : 'border-gray-200 bg-gray-50 text-gray-400'
                      }`}
                    />
                    <span className="text-sm text-gray-500">hrs</span>
                  </div>
                  {row.is_working_day && row.normal_hours > 0 && (
                    <span className="text-xs text-gray-400">OT starts after {row.normal_hours}h</span>
                  )}
                  {(!row.is_working_day || row.normal_hours === 0) && (
                    <span className="text-xs text-amber-600 font-medium">All hours = OT</span>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-5 pt-4 border-t border-gray-100 flex items-center justify-between">
            <div className="flex items-center gap-3 text-sm">
              <Clock className="w-4 h-4 text-teal-600" />
              <span className="text-gray-600">Total normal hours per week:</span>
              <span className="font-bold text-teal-700 text-base">{totalWeeklyHours}h</span>
            </div>
            <div className="text-xs text-gray-400">{rows.filter((r) => r.is_working_day).length} working days / week</div>
          </div>
        </div>
      </div>

      {isAdmin && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 px-5 py-4 flex items-center gap-3">
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg text-sm disabled:opacity-60 hover:from-teal-600 hover:to-blue-700 transition-all shadow-sm"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {saving ? 'Saving…' : isProjectMode ? 'Save Project Schedule' : 'Save Global Schedule'}
          </button>
          {saved && (
            <span className="flex items-center gap-1.5 text-sm text-green-600 font-medium">
              <CheckCircle2 className="w-4 h-4" />Saved
            </span>
          )}
          {error && (
            <span className="flex items-center gap-1.5 text-sm text-red-600">
              <AlertCircle className="w-4 h-4" />{error}
            </span>
          )}
        </div>
      )}
    </div>
  );
}

/* ── By Date Tab ────────────────────────────────────────────── */
function ByDateTab({ isAdmin }: { isAdmin: boolean }) {
  const [overrides, setOverrides] = useState<DateOverride[]>([]);
  const [projects, setProjects]   = useState<{ id: string; name: string }[]>([]);
  const [loading, setLoading]     = useState(true);
  const [showAdd, setShowAdd]     = useState(false);
  const [saving, setSaving]       = useState(false);
  const [error, setError]         = useState<string | null>(null);

  const [newLabel, setNewLabel]   = useState('');
  const [newFrom, setNewFrom]     = useState('');
  const [newTo, setNewTo]         = useState('');
  const [newHours, setNewHours]   = useState('9');
  const [newProjectId, setNewProjectId] = useState('');

  const load = useCallback(async () => {
    const [projRes, ovRes] = await Promise.all([
      supabase.from('projects').select('id,name').order('name'),
      supabase
        .from('work_schedule_date_overrides')
        .select('id,label,date_from,date_to,normal_hours,project_id,projects(name)')
        .order('date_from', { ascending: false }),
    ]);
    setProjects((projRes.data ?? []) as { id: string; name: string }[]);
    const list: DateOverride[] = (ovRes.data ?? []).map((r: any) => ({
      id: r.id,
      label: r.label,
      date_from: r.date_from,
      date_to: r.date_to,
      normal_hours: r.normal_hours,
      project_id: r.project_id,
      project_name: r.projects?.name,
    }));
    setOverrides(list);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleAdd = async () => {
    if (!newLabel || !newFrom || !newTo) return;
    setSaving(true);
    setError(null);
    const { error: err } = await supabase.from('work_schedule_date_overrides').insert({
      label: newLabel,
      date_from: newFrom,
      date_to: newTo,
      normal_hours: parseFloat(newHours) || 9,
      project_id: newProjectId || null,
    });
    setSaving(false);
    if (err) { setError(err.message); return; }
    setShowAdd(false);
    setNewLabel(''); setNewFrom(''); setNewTo(''); setNewHours('9'); setNewProjectId('');
    load();
  };

  const handleDelete = async (id: string) => {
    await supabase.from('work_schedule_date_overrides').delete().eq('id', id);
    load();
  };

  function fmtD(d: string) {
    if (!d) return '';
    const [y, m, day] = d.split('-');
    return `${day}/${m}/${y}`;
  }

  if (loading) {
    return (
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-12 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-teal-500" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-6 py-5 border-b border-gray-100 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-blue-600 rounded-xl flex items-center justify-center shadow-sm">
              <CalendarRange className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Date-Specific Normal Hours</h3>
              <p className="text-xs text-gray-500 mt-0.5">
                Override hours for date ranges (e.g., Ramadan, public holidays). Highest priority.
              </p>
            </div>
          </div>
          {isAdmin && (
            <button
              onClick={() => setShowAdd(true)}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm shadow-sm hover:from-teal-600 hover:to-blue-700 transition-all"
            >
              <Plus className="w-4 h-4" />Add Override
            </button>
          )}
        </div>

        <div className="px-6 py-3 bg-orange-50 border-b border-orange-100 flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-orange-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-orange-800">
            <strong>Highest priority.</strong> Date overrides apply to all employees on matching dates.
            You can optionally restrict an override to a specific project — otherwise it applies globally.
          </p>
        </div>

        {overrides.length === 0 ? (
          <div className="py-14 text-center">
            <CalendarRange className="w-10 h-10 text-gray-300 mx-auto mb-3" />
            <p className="font-semibold text-gray-500">No date overrides configured</p>
            <p className="text-sm text-gray-400 mt-1">Add overrides for Ramadan, special periods, or public holidays.</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {overrides.map((ov) => (
              <div key={ov.id} className="flex items-center gap-4 px-6 py-4 hover:bg-gray-50/50 transition-colors">
                <div className="w-9 h-9 bg-gradient-to-br from-orange-100 to-amber-100 rounded-xl flex items-center justify-center flex-shrink-0">
                  <CalendarRange className="w-4 h-4 text-orange-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold text-gray-900 text-sm">{ov.label}</p>
                    {ov.project_name && (
                      <span className="px-2 py-0.5 bg-teal-100 text-teal-700 text-xs rounded-full font-medium">
                        {ov.project_name}
                      </span>
                    )}
                    {!ov.project_id && (
                      <span className="px-2 py-0.5 bg-gray-100 text-gray-500 text-xs rounded-full">Global</span>
                    )}
                  </div>
                  <p className="text-xs text-gray-400 mt-0.5">
                    {fmtD(ov.date_from)} — {fmtD(ov.date_to)}
                  </p>
                </div>
                <span className="text-lg font-bold text-orange-600 flex-shrink-0">{ov.normal_hours}h</span>
                {isAdmin && (
                  <button
                    onClick={() => handleDelete(ov.id)}
                    className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors flex-shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add form */}
      {showAdd && (
        <div className="bg-white rounded-2xl shadow-sm border border-orange-200 p-5 space-y-4">
          <h4 className="font-semibold text-gray-900 text-sm">Add Date Override</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Label / Description</label>
              <input
                type="text"
                value={newLabel}
                onChange={(e) => setNewLabel(e.target.value)}
                placeholder="e.g., Ramadan 2026, National Day Holiday…"
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">From Date</label>
              <input
                type="date" value={newFrom}
                onChange={(e) => setNewFrom(e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">To Date</label>
              <input
                type="date" value={newTo}
                onChange={(e) => setNewTo(e.target.value)}
                min={newFrom}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Normal Hours / Day</label>
              <div className="flex items-center gap-2">
                <input
                  type="number" min="0" max="24" step="0.5"
                  value={newHours}
                  onChange={(e) => setNewHours(e.target.value)}
                  className="flex-1 px-3 py-2.5 border border-gray-200 rounded-xl text-sm text-center font-semibold focus:outline-none focus:ring-2 focus:ring-teal-400"
                />
                <span className="text-sm text-gray-500">hrs</span>
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Project (optional)</label>
              <select
                value={newProjectId}
                onChange={(e) => setNewProjectId(e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400"
              >
                <option value="">All projects (global)</option>
                {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
          </div>
          {error && (
            <p className="text-xs text-red-600 flex items-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5" />{error}
            </p>
          )}
          <div className="flex gap-2">
            <button
              onClick={handleAdd}
              disabled={saving || !newLabel || !newFrom || !newTo}
              className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm disabled:opacity-50"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              Save Override
            </button>
            <button
              onClick={() => { setShowAdd(false); setError(null); }}
              className="px-4 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Flash Message Settings
/* ── Flash Message Settings ─────────────────────────────────── */

type FlashRow = {
  id: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error';
  is_active: boolean;
  created_at: string;
};

const FLASH_TYPE_CONFIG = {
  info:    { label: 'Info',    bg: 'bg-blue-50',   border: 'border-blue-300',  text: 'text-blue-800',  icon: Info },
  warning: { label: 'Warning', bg: 'bg-amber-50',  border: 'border-amber-300', text: 'text-amber-800', icon: AlertTriangle },
  success: { label: 'Success', bg: 'bg-green-50',  border: 'border-green-300', text: 'text-green-800', icon: CheckCircle2 },
  error:   { label: 'Alert',   bg: 'bg-red-50',    border: 'border-red-300',   text: 'text-red-800',   icon: AlertCircle },
} as const;

function FlashMessageSettings() {
  const [rows, setRows]         = useState<FlashRow[]>([]);
  const [loading, setLoading]   = useState(true);
  const [editing, setEditing]   = useState<FlashRow | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [msg, setMsg]           = useState('');
  const [type, setType]         = useState<FlashRow['type']>('info');
  const [saving, setSaving]     = useState(false);
  const [savErr, setSavErr]     = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data } = await supabase
      .from('flash_messages')
      .select('id,message,type,is_active,created_at')
      .order('created_at', { ascending: false });
    setRows((data as FlashRow[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const openNew = () => {
    setEditing(null);
    setMsg('');
    setType('info');
    setSavErr(null);
    setShowForm(true);
  };

  const openEdit = (row: FlashRow) => {
    setEditing(row);
    setMsg(row.message);
    setType(row.type);
    setSavErr(null);
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!msg.trim()) return;
    setSaving(true);
    setSavErr(null);
    let err;
    if (editing) {
      ({ error: err } = await supabase
        .from('flash_messages')
        .update({ message: msg.trim(), type, updated_at: new Date().toISOString() })
        .eq('id', editing.id));
    } else {
      ({ error: err } = await supabase
        .from('flash_messages')
        .insert({ message: msg.trim(), type, is_active: false }));
    }
    setSaving(false);
    if (err) { setSavErr(err.message); return; }
    setShowForm(false);
    load();
  };

  const toggleActive = async (row: FlashRow) => {
    const newActive = !row.is_active;
    if (newActive) {
      await supabase.from('flash_messages')
        .update({ is_active: false, updated_at: new Date().toISOString() })
        .neq('id', row.id);
    }
    await supabase.from('flash_messages')
      .update({ is_active: newActive, updated_at: new Date().toISOString() })
      .eq('id', row.id);
    load();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this flash message?')) return;
    await supabase.from('flash_messages').delete().eq('id', id);
    load();
  };

  if (loading) {
    return (
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-12 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-teal-500" />
      </div>
    );
  }

  const active = rows.find((r) => r.is_active);

  return (
    <div className="space-y-5">
      {/* Header card */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-6 py-5 border-b border-gray-100 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-blue-600 rounded-xl flex items-center justify-center shadow-sm">
              <MessageSquareDot className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Login Page Flash Message</h3>
              <p className="text-xs text-gray-500 mt-0.5">
                {active ? 'One message is currently live on the login page.' : 'No message is currently active on the login page.'}
              </p>
            </div>
          </div>
          <button
            onClick={openNew}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm shadow-sm hover:from-teal-600 hover:to-blue-700 transition-all"
          >
            <Plus className="w-4 h-4" />
            New Message
          </button>
        </div>

        {/* Live preview of active message */}
        {active && (() => {
          const cfg = FLASH_TYPE_CONFIG[active.type];
          const Icon = cfg.icon;
          return (
            <div className={`mx-6 my-4 flex items-start gap-3 px-4 py-3 rounded-xl border ${cfg.bg} ${cfg.border} ${cfg.text} text-sm`}>
              <Icon className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-xs font-semibold uppercase tracking-wide opacity-60 mb-0.5">Live Preview — login page</p>
                <p className="font-medium leading-snug whitespace-pre-wrap">{active.message}</p>
              </div>
            </div>
          );
        })()}

        {/* Messages list */}
        {rows.length === 0 ? (
          <div className="py-14 text-center">
            <MessageSquareDot className="w-10 h-10 text-gray-300 mx-auto mb-3" />
            <p className="font-semibold text-gray-500">No flash messages yet</p>
            <p className="text-sm text-gray-400 mt-1">Create a message to display on the login page.</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {rows.map((row) => {
              const cfg = FLASH_TYPE_CONFIG[row.type];
              const Icon = cfg.icon;
              return (
                <div key={row.id} className={`flex items-center gap-4 px-6 py-4 hover:bg-gray-50/50 transition-colors ${row.is_active ? 'bg-teal-50/30' : ''}`}>
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 border ${cfg.bg} ${cfg.border}`}>
                    <Icon className={`w-4 h-4 ${cfg.text}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-0.5">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${cfg.bg} ${cfg.text} ${cfg.border}`}>
                        {cfg.label}
                      </span>
                      {row.is_active && (
                        <span className="px-2 py-0.5 bg-teal-100 text-teal-700 text-xs rounded-full font-semibold border border-teal-200">
                          Live
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-800 font-medium leading-snug truncate">{row.message}</p>
                  </div>
                  <button
                    onClick={() => toggleActive(row)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border flex-shrink-0 ${
                      row.is_active
                        ? 'bg-teal-50 border-teal-200 text-teal-700 hover:bg-teal-100'
                        : 'bg-gray-50 border-gray-200 text-gray-500 hover:bg-gray-100'
                    }`}
                    title={row.is_active ? 'Deactivate' : 'Activate'}
                  >
                    {row.is_active
                      ? <ToggleRight className="w-4 h-4" />
                      : <ToggleLeft className="w-4 h-4" />}
                    {row.is_active ? 'Active' : 'Inactive'}
                  </button>
                  <button
                    onClick={() => openEdit(row)}
                    className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    title="Edit"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(row.id)}
                    className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Create / Edit form */}
      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-teal-200 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-semibold text-gray-900">{editing ? 'Edit Message' : 'New Flash Message'}</h4>
            <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-600 p-1 rounded">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Type selector */}
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Message Type</label>
            <div className="grid grid-cols-4 gap-2">
              {(Object.keys(FLASH_TYPE_CONFIG) as FlashRow['type'][]).map((t) => {
                const cfg = FLASH_TYPE_CONFIG[t];
                const Icon = cfg.icon;
                return (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setType(t)}
                    className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-xl border text-xs font-semibold transition-all ${
                      type === t
                        ? `${cfg.bg} ${cfg.border} ${cfg.text} shadow-sm`
                        : 'bg-gray-50 border-gray-200 text-gray-500 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {cfg.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Message text */}
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Message Text</label>
            <textarea
              value={msg}
              onChange={(e) => setMsg(e.target.value)}
              rows={3}
              placeholder="e.g., System maintenance scheduled for Saturday 10 PM – 12 AM."
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm resize-none focus:outline-none focus:ring-2 focus:ring-teal-400"
            />
          </div>

          {/* Live preview while composing */}
          {msg.trim() && (() => {
            const cfg = FLASH_TYPE_CONFIG[type];
            const Icon = cfg.icon;
            return (
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Preview</label>
                <div className={`flex items-start gap-3 px-4 py-3 rounded-xl border ${cfg.bg} ${cfg.border} ${cfg.text} text-sm`}>
                  <Icon className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  <p className="font-medium leading-snug whitespace-pre-wrap">{msg.trim()}</p>
                </div>
              </div>
            );
          })()}

          {savErr && (
            <p className="text-xs text-red-600 flex items-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5" />{savErr}
            </p>
          )}

          <div className="flex gap-2">
            <button
              onClick={handleSave}
              disabled={saving || !msg.trim()}
              className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm disabled:opacity-50 hover:from-teal-600 hover:to-blue-700 transition-all shadow-sm"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              {saving ? 'Saving…' : editing ? 'Update Message' : 'Save Message'}
            </button>
            <button
              onClick={() => { setShowForm(false); setSavErr(null); }}
              className="px-4 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      <div className="bg-blue-50 border border-blue-100 rounded-2xl px-5 py-4 flex items-start gap-2.5">
        <Info className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-blue-700">
          Only one message can be active at a time. Activating a message automatically deactivates any other.
          The banner appears on the login page for all visitors and can be dismissed by the user.
        </p>
      </div>
    </div>
  );
}

function CategoryModal({
  category,
  userId,
  onClose,
  onSave,
}: {
  category: Category | null;
  userId: string;
  onClose: () => void;
  onSave: () => void;
}) {
  const [name, setName] = useState(category?.name || '');
  const [type, setType] = useState<'income' | 'expense'>(category?.type || 'expense');
  const [color, setColor] = useState(category?.color || PRESET_COLORS[0]);
  const [customColor, setCustomColor] = useState(category?.color || '');
  const [icon] = useState(category?.icon || PRESET_ICONS[0]);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const finalColor = customColor || color;
      if (category) {
        await supabase
          .from('categories')
          .update({ name, type, color: finalColor, icon })
          .eq('id', category.id);
      } else {
        await supabase.from('categories').insert({
          user_id: userId,
          name,
          type,
          color: finalColor,
          icon,
        });
      }
      onSave();
    } catch (error) {
      console.error('Error saving category:', error);
    }
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-900">
            {category ? 'Edit Category' : 'Add Category'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setType('income')}
              className={`flex-1 py-2 px-4 rounded-lg font-medium transition-all ${
                type === 'income'
                  ? 'bg-emerald-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Income
            </button>
            <button
              type="button"
              onClick={() => setType('expense')}
              className={`flex-1 py-2 px-4 rounded-lg font-medium transition-all ${
                type === 'expense'
                  ? 'bg-red-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Expense
            </button>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Category Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="e.g., Groceries, Salary, Rent"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Palette className="w-4 h-4 inline mr-1" />
              Color
            </label>
            <div className="flex flex-wrap gap-2">
              {PRESET_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => {
                    setColor(c);
                    setCustomColor('');
                  }}
                  className={`w-8 h-8 rounded-lg transition-all ${
                    color === c && !customColor
                      ? 'ring-2 ring-offset-2 ring-blue-500'
                      : ''
                  }`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
            <div className="mt-2">
              <label className="text-xs text-gray-500 block mb-1">Or enter custom color:</label>
              <input
                type="color"
                value={customColor || color}
                onChange={(e) => setCustomColor(e.target.value)}
                className="w-full h-8 rounded cursor-pointer"
              />
            </div>
          </div>

          <div className="flex gap-2 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 px-4 border-2 border-gray-200 text-gray-700 font-medium rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || !name.trim()}
              className="flex-1 py-2 px-4 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg hover:from-teal-600 hover:to-blue-700 disabled:opacity-50"
            >
              {loading ? 'Saving...' : category ? 'Update' : 'Add Category'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
