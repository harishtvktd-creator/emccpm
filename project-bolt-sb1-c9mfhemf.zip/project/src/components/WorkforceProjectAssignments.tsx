import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { logAudit } from './WorkforceEmployees';
import type { WFEmployee } from './WorkforceEmployees';
import {
  FolderKanban, Plus, X, Search, Loader2, Trash2,
  Users, UserCheck, AlertCircle,
} from 'lucide-react';

type Project = { id: string; name: string; status: string | null };

type ProjectEmployee = {
  id: string;
  project_id: string;
  employee_id: string;
  assigned_at: string;
  employee: WFEmployee;
};

export function WorkforceProjectAssignments() {
  const { teamMember, isAdmin } = useAuth();
  const [projects, setProjects]             = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [assignments, setAssignments]       = useState<ProjectEmployee[]>([]);
  const [loading, setLoading]               = useState(false);
  const [projectsLoading, setProjectsLoading] = useState(true);
  const [showAddModal, setShowAddModal]     = useState(false);
  const [confirmRemove, setConfirmRemove]   = useState<ProjectEmployee | null>(null);

  useEffect(() => {
    supabase.from('projects').select('id,name,status').order('name').then(({ data }) => {
      const list = (data ?? []) as Project[];
      setProjects(list);
      if (list[0]) setSelectedProject(list[0]);
      setProjectsLoading(false);
    });
  }, []);

  const fetchAssignments = useCallback(async () => {
    if (!selectedProject) return;
    setLoading(true);
    const { data } = await supabase
      .from('workforce_project_employees')
      .select('id, project_id, employee_id, assigned_at, employee:workforce_employees(id,employee_code,name,designation,department,trade,nationality,employment_type,contact_phone,is_active,created_at)')
      .eq('project_id', selectedProject.id)
      .order('assigned_at');
    setAssignments((data ?? []) as unknown as ProjectEmployee[]);
    setLoading(false);
  }, [selectedProject]);

  useEffect(() => {
    if (!projectsLoading && selectedProject) fetchAssignments();
  }, [projectsLoading, selectedProject, fetchAssignments]);

  const handleRemove = async (assignment: ProjectEmployee) => {
    const { error } = await supabase
      .from('workforce_project_employees')
      .delete()
      .eq('id', assignment.id);
    if (!error) {
      logAudit('DELETE', 'workforce_project_employees', assignment.id,
        `${assignment.employee.name} from ${selectedProject?.name}`,
        teamMember?.id, teamMember?.name, { employee: assignment.employee.name, project: selectedProject?.name });
      setConfirmRemove(null);
      fetchAssignments();
    }
  };

  const handleAdd = async (employee: WFEmployee) => {
    if (!selectedProject) return;
    const { data, error } = await supabase
      .from('workforce_project_employees')
      .insert({
        project_id: selectedProject.id,
        employee_id: employee.id,
        assigned_by: teamMember?.id ?? null,
      })
      .select('id')
      .single();
    if (!error && data) {
      logAudit('INSERT', 'workforce_project_employees', data.id,
        `${employee.name} to ${selectedProject.name}`,
        teamMember?.id, teamMember?.name, undefined, { employee: employee.name, project: selectedProject.name });
      fetchAssignments();
    }
  };

  const assignedIds = assignments.map((a) => a.employee_id);

  if (projectsLoading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-7 h-7 animate-spin text-teal-500" />
    </div>
  );

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-bold text-gray-900 text-lg">Project Employee Assignments</h3>
          <p className="text-sm text-gray-500 mt-0.5">
            Assign employees to projects — team members can only add from these pools during daily allocation.
          </p>
        </div>
        {isAdmin && (
        <button
          onClick={() => setShowAddModal(true)}
          disabled={!selectedProject}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm shadow-sm hover:from-teal-600 hover:to-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Plus className="w-4 h-4" />Assign Employee
        </button>
        )}
      </div>

      {/* Project selector */}
      <div className="bg-white border border-gray-200 rounded-2xl p-4">
        <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Select Project</label>
        <div className="flex flex-wrap gap-2">
          {projects.map((p) => (
            <button
              key={p.id}
              onClick={() => setSelectedProject(p)}
              className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium border transition-all ${
                selectedProject?.id === p.id
                  ? 'bg-teal-600 text-white border-teal-600 shadow-sm'
                  : 'bg-white text-gray-600 border-gray-200 hover:border-teal-300 hover:text-teal-700'
              }`}
            >
              <FolderKanban className="w-3.5 h-3.5 flex-shrink-0" />
              {p.name}
            </button>
          ))}
        </div>
      </div>

      {/* Assignment count */}
      {selectedProject && !loading && (
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2.5 bg-teal-50 border border-teal-100 rounded-xl text-sm text-teal-800">
            <UserCheck className="w-4 h-4 text-teal-600" />
            <span className="font-semibold">{assignments.length}</span>
            employee{assignments.length !== 1 ? 's' : ''} assigned to
            <span className="font-semibold">{selectedProject.name}</span>
          </div>
        </div>
      )}

      {/* Assignments table */}
      {loading ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-12 flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-teal-500" />
        </div>
      ) : assignments.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-14 text-center">
          <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="font-semibold text-gray-600">No employees assigned</p>
          <p className="text-sm text-gray-400 mt-1 mb-5">
            Assign employees to {selectedProject?.name} so they can be allocated in daily timesheets.
          </p>
          {isAdmin && (
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white rounded-xl text-sm font-medium"
          >
            <Plus className="w-4 h-4" />Assign First Employee
          </button>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  {['Code', 'Name', 'Designation / Dept', 'Trade', 'Type', 'Status', 'Assigned', 'Actions'].map((h) => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {assignments.map((a) => {
                  const emp = a.employee;
                  return (
                    <tr key={a.id} className={`hover:bg-gray-50/60 transition-colors ${!emp.is_active ? 'opacity-55' : ''}`}>
                      <td className="px-4 py-3 font-mono text-xs text-gray-500 font-medium">{emp.employee_code}</td>
                      <td className="px-4 py-3 font-semibold text-gray-900">{emp.name}</td>
                      <td className="px-4 py-3">
                        <p className="text-gray-700">{emp.designation ?? '—'}</p>
                        {emp.department && <p className="text-xs text-gray-400">{emp.department}</p>}
                      </td>
                      <td className="px-4 py-3 text-gray-600">{emp.trade ?? '—'}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${
                          emp.employment_type === 'staff' ? 'bg-blue-100 text-blue-700 border-blue-200' :
                          emp.employment_type === 'labour' ? 'bg-amber-100 text-amber-700 border-amber-200' :
                          'bg-teal-100 text-teal-700 border-teal-200'
                        }`}>
                          {emp.employment_type === 'staff' ? 'INDIRECT' : emp.employment_type === 'labour' ? 'DIRECT' : 'Subcontractor'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${emp.is_active ? 'bg-green-100 text-green-700 border-green-200' : 'bg-gray-100 text-gray-500 border-gray-200'}`}>
                          {emp.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-400">
                        {new Date(a.assigned_at).toLocaleDateString('en-GB')}
                      </td>
                      <td className="px-4 py-3">
                        {isAdmin && (
                        <button
                          onClick={() => setConfirmRemove(a)}
                          className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                          title="Remove from project"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add employee to project modal */}
      {showAddModal && selectedProject && (
        <AssignEmployeeModal
          projectName={selectedProject.name}
          excludeIds={assignedIds}
          onClose={() => setShowAddModal(false)}
          onAssign={(emp) => { handleAdd(emp); setShowAddModal(false); }}
        />
      )}

      {/* Remove confirm */}
      {confirmRemove && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl p-6 max-w-sm w-full">
            <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-6 h-6 text-red-600" />
            </div>
            <h3 className="font-bold text-gray-900 text-center mb-1">Remove Assignment?</h3>
            <p className="text-sm text-gray-500 text-center mb-5">
              <span className="font-semibold text-gray-700">{confirmRemove.employee.name}</span> will be removed from{' '}
              <span className="font-semibold text-gray-700">{selectedProject?.name}</span>. Existing daily allocation records are not affected.
            </p>
            <div className="flex gap-3">
              <button onClick={() => setConfirmRemove(null)} className="flex-1 px-4 py-2.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors">Cancel</button>
              <button onClick={() => handleRemove(confirmRemove)} className="flex-1 px-4 py-2.5 bg-red-600 text-white rounded-xl text-sm font-medium hover:bg-red-700 transition-colors">Remove</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Assign Employee Modal ───────────────────────────────────── */
function AssignEmployeeModal({
  projectName, excludeIds, onClose, onAssign,
}: {
  projectName: string;
  excludeIds: string[];
  onClose: () => void;
  onAssign: (emp: WFEmployee) => void;
}) {
  const [employees, setEmployees] = useState<WFEmployee[]>([]);
  const [search, setSearch]       = useState('');
  const [loading, setLoading]     = useState(true);
  const [filterType, setFilterType] = useState<string>('all');

  useEffect(() => {
    supabase
      .from('workforce_employees')
      .select('id,employee_code,name,designation,department,trade,nationality,employment_type,contact_phone,is_active,created_at')
      .eq('is_active', true)
      .order('name')
      .then(({ data }) => {
        setEmployees(((data as WFEmployee[]) ?? []).filter((e) => !excludeIds.includes(e.id)));
        setLoading(false);
      });
  }, []);

  const filtered = employees.filter((e) => {
    const matchType = filterType === 'all' || e.employment_type === filterType;
    const matchSearch = !search || [e.name, e.employee_code, e.designation, e.trade, e.department]
      .some((f) => f?.toLowerCase().includes(search.toLowerCase()));
    return matchType && matchSearch;
  });

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between p-5 border-b border-gray-100 flex-shrink-0">
          <div>
            <h3 className="font-bold text-gray-900">Assign Employee to Project</h3>
            <p className="text-xs text-gray-500 mt-0.5">{projectName}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>
        <div className="p-4 border-b border-gray-100 space-y-3 flex-shrink-0">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text" value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, code, trade, department…" autoFocus
              className="w-full pl-9 pr-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
            />
          </div>
          <div className="flex gap-2">
            {(['all', 'staff', 'labour', 'subcontractor'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setFilterType(t)}
                className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${filterType === t ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-gray-600 border-gray-200 hover:border-teal-300'}`}
              >
                {t === 'all' ? 'All' : t === 'staff' ? 'INDIRECT' : t === 'labour' ? 'DIRECT' : 'Subcontractor'}
              </button>
            ))}
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {loading ? (
            <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-teal-500" /></div>
          ) : filtered.length === 0 ? (
            <div className="py-8 text-center text-sm text-gray-400">
              {employees.length === 0
                ? 'All active employees are already assigned to this project.'
                : 'No employees match your search.'}
            </div>
          ) : (
            <div className="space-y-1">
              {filtered.map((emp) => (
                <button
                  key={emp.id}
                  onClick={() => onAssign(emp)}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-teal-50 text-left transition-colors group"
                >
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-teal-100 to-blue-100 flex items-center justify-center flex-shrink-0 text-xs font-bold text-teal-700">
                    {emp.name.split(' ').map((w) => w[0]).join('').slice(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-gray-900 text-sm">{emp.name}</p>
                      <span className={`px-1.5 py-0.5 rounded text-xs font-medium ${
                        emp.employment_type === 'staff' ? 'bg-blue-100 text-blue-700' :
                        emp.employment_type === 'labour' ? 'bg-amber-100 text-amber-700' :
                        'bg-teal-100 text-teal-700'
                      }`}>
                        {emp.employment_type === 'staff' ? 'INDIRECT' : emp.employment_type === 'labour' ? 'DIRECT' : emp.employment_type}
                      </span>
                    </div>
                    <p className="text-xs text-gray-400">
                      {emp.employee_code}{emp.designation ? ` · ${emp.designation}` : ''}{emp.trade ? ` · ${emp.trade}` : ''}{emp.department ? ` · ${emp.department}` : ''}
                    </p>
                  </div>
                  <Plus className="w-4 h-4 text-teal-500 opacity-0 group-hover:opacity-100 flex-shrink-0 transition-opacity" />
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="flex-shrink-0 px-5 py-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-400">
          <span>{filtered.length} employee{filtered.length !== 1 ? 's' : ''} available</span>
          <AlertCircle className="w-3.5 h-3.5" />
          <span>Only active employees are shown</span>
        </div>
      </div>
    </div>
  );
}
