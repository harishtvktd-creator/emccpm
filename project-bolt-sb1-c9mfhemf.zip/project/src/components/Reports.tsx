import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/supabase';
import {
  FileText,
  Download,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Users,
  FolderKanban,
  TrendingUp,
  CalendarDays,
  UserCheck,
  ChevronDown,
  ChevronRight,
  BarChart2,
} from 'lucide-react';

type Task = Database['public']['Tables']['tasks']['Row'];
type Project = Database['public']['Tables']['projects']['Row'];
type TeamMember = Database['public']['Tables']['team_members']['Row'];

interface TaskWithDetails extends Task {
  projects: Project;
  team_members: TeamMember | null;
}

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-gray-100 text-gray-700',
  'in-progress': 'bg-blue-100 text-blue-700',
  review: 'bg-amber-100 text-amber-700',
  completed: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
};

const PRIORITY_LEFT_BORDER: Record<string, string> = {
  low: 'border-l-gray-300',
  medium: 'border-l-yellow-400',
  high: 'border-l-orange-500',
  critical: 'border-l-red-500',
};

const PRIORITY_DOT: Record<string, string> = {
  low: 'bg-gray-400',
  medium: 'bg-yellow-400',
  high: 'bg-orange-500',
  critical: 'bg-red-500',
};

function statusLabel(s: string) {
  return s === 'in-progress' ? 'In Progress' : s.charAt(0).toUpperCase() + s.slice(1);
}

function fmtDate(d: string) {
  return new Date(d + 'T00:00:00').toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

function daysOverdueText(due: string) {
  const diff = Math.floor((Date.now() - new Date(due + 'T00:00:00').getTime()) / 86400000);
  return diff > 0 ? `${diff}d overdue` : diff === 0 ? 'Due today' : `In ${-diff}d`;
}

function isOverdue(due: string, status: string) {
  return (
    status !== 'completed' &&
    status !== 'cancelled' &&
    new Date(due + 'T00:00:00') < new Date(new Date().toDateString())
  );
}

type ReportType = 'monthly' | 'due-documents' | 'overdue' | 'summary' | 'by-member' | 'by-date';

// ─── Project filter dropdown shared by both report views ─────────────────────
function ProjectFilter({
  projects,
  value,
  onChange,
  accentClass,
}: {
  projects: Project[];
  value: string;
  onChange: (v: string) => void;
  accentClass: string;
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-gray-500 mb-1">Project</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={`w-full text-sm p-2 border border-gray-200 rounded-lg bg-white focus:ring-2 ${accentClass} focus:outline-none`}
      >
        <option value="all">All Projects</option>
        {projects.map((p) => (
          <option key={p.id} value={p.id}>{p.name}</option>
        ))}
      </select>
    </div>
  );
}

// ─── Task row shared across member & date views ──────────────────────────────
function TaskRow({ task, showMember }: { task: TaskWithDetails; showMember: boolean }) {
  const overdue = isOverdue(task.due_date, task.status);
  return (
    <tr
      className={`border-b border-gray-100 hover:bg-gray-50 border-l-4 ${
        PRIORITY_LEFT_BORDER[task.priority] ?? 'border-l-gray-300'
      }`}
    >
      <td className="py-3 px-4">
        <div className="flex items-start gap-2">
          <span
            className={`mt-1.5 w-2 h-2 rounded-full flex-shrink-0 ${PRIORITY_DOT[task.priority] ?? 'bg-gray-400'}`}
          />
          <div>
            <div className="font-medium text-gray-900 leading-snug">
              {task.document_name || task.title}
            </div>
            {task.description && (
              <div className="text-xs text-gray-400 mt-0.5 line-clamp-1">{task.description}</div>
            )}
          </div>
        </div>
      </td>
      <td className="py-3 px-4 text-sm text-gray-600">{task.projects?.name ?? '—'}</td>
      {showMember && (
        <td className="py-3 px-4 text-sm text-gray-600">
          {task.team_members?.name ?? <span className="italic text-gray-400">Unassigned</span>}
        </td>
      )}
      <td className="py-3 px-4 text-sm">
        <span className={overdue ? 'text-red-600 font-semibold' : 'text-gray-600'}>
          {fmtDate(task.due_date)}
        </span>
        {overdue && (
          <div className="text-xs text-red-400 mt-0.5">{daysOverdueText(task.due_date)}</div>
        )}
      </td>
      <td className="py-3 px-4">
        <span
          className={`px-2 py-0.5 rounded text-xs font-medium ${
            STATUS_COLORS[task.status] ?? 'bg-gray-100 text-gray-700'
          }`}
        >
          {statusLabel(task.status)}
        </span>
      </td>
      <td className="py-3 px-4 text-sm capitalize text-gray-600">{task.task_type ?? '—'}</td>
    </tr>
  );
}

// ─── By-Member report ────────────────────────────────────────────────────────
function ByMemberReport({
  tasks,
  teamMembers,
  projects,
}: {
  tasks: TaskWithDetails[];
  teamMembers: TeamMember[];
  projects: Project[];
}) {
  const [selectedMember, setSelectedMember] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [projectFilter, setProjectFilter] = useState<string>('all');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const filtered = tasks
    .filter((t) => selectedMember === 'all' || t.assigned_to === selectedMember)
    .filter((t) => statusFilter === 'all' || t.status === statusFilter)
    .filter((t) => projectFilter === 'all' || t.project_id === projectFilter)
    .filter((t) => !fromDate || t.due_date >= fromDate)
    .filter((t) => !toDate || t.due_date <= toDate)
    .sort((a, b) => a.due_date.localeCompare(b.due_date));

  const exportCSV = () => {
    let csv = 'Task,Type,Project,Assigned To,Due Date,Status,Priority\n';
    filtered.forEach((t) => {
      csv += `"${t.document_name || t.title}","${t.task_type ?? ''}","${t.projects?.name ?? ''}","${
        t.team_members?.name ?? 'Unassigned'
      }","${t.due_date}","${t.status}","${t.priority}"\n`;
    });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = `tasks-by-member-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100">
      {/* Filters */}
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center gap-3 mb-5">
          <UserCheck className="w-5 h-5 text-teal-600" />
          <h2 className="text-lg font-bold text-gray-900">Tasks by Team Member</h2>
          <span className="ml-auto text-sm text-gray-500">{filtered.length} tasks</span>
          <button
            onClick={exportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white text-sm font-medium rounded-lg"
          >
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Team Member</label>
            <select
              value={selectedMember}
              onChange={(e) => setSelectedMember(e.target.value)}
              className="w-full text-sm p-2 border border-gray-200 rounded-lg bg-white focus:ring-2 focus:ring-teal-400 focus:outline-none"
            >
              <option value="all">All Members</option>
              {teamMembers.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>

          <ProjectFilter projects={projects} value={projectFilter} onChange={setProjectFilter} accentClass="focus:ring-teal-400" />

          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Status</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full text-sm p-2 border border-gray-200 rounded-lg bg-white focus:ring-2 focus:ring-teal-400 focus:outline-none"
            >
              <option value="all">All Statuses</option>
              <option value="pending">Pending</option>
              <option value="in-progress">In Progress</option>
              <option value="review">Review</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">From Date</label>
            <input
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="w-full text-sm p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-teal-400 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">To Date</label>
            <input
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="w-full text-sm p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-teal-400 focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Table */}
      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <CheckCircle2 className="w-12 h-12 text-green-400 mx-auto mb-3" />
          <p className="text-gray-500">No tasks match the current filters</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50">
                <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">
                  Task
                </th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">
                  Project
                </th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">
                  Assigned To
                </th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">
                  Due Date
                </th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">
                  Status
                </th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">
                  Type
                </th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((t) => (
                <TaskRow key={t.id} task={t} showMember={true} />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── By-Date report ──────────────────────────────────────────────────────────
function ByDateReport({
  tasks,
  teamMembers,
  projects,
}: {
  tasks: TaskWithDetails[];
  teamMembers: TeamMember[];
  projects: Project[];
}) {
  const today = new Date().toISOString().split('T')[0];
  const thirtyDays = new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0];

  const [fromDate, setFromDate] = useState(today);
  const [toDate, setToDate] = useState(thirtyDays);
  const [memberFilter, setMemberFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [projectFilter, setProjectFilter] = useState<string>('all');
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());

  const filtered = tasks
    .filter((t) => !fromDate || t.due_date >= fromDate)
    .filter((t) => !toDate || t.due_date <= toDate)
    .filter((t) => memberFilter === 'all' || t.assigned_to === memberFilter)
    .filter((t) => statusFilter === 'all' || t.status === statusFilter)
    .filter((t) => projectFilter === 'all' || t.project_id === projectFilter)
    .sort((a, b) => a.due_date.localeCompare(b.due_date));

  // Group by due_date
  const groups: Record<string, TaskWithDetails[]> = {};
  filtered.forEach((t) => {
    if (!groups[t.due_date]) groups[t.due_date] = [];
    groups[t.due_date].push(t);
  });
  const sortedDates = Object.keys(groups).sort();

  const toggleDay = (date: string) =>
    setCollapsed((prev) => {
      const next = new Set(prev);
      next.has(date) ? next.delete(date) : next.add(date);
      return next;
    });

  const exportCSV = () => {
    let csv = 'Due Date,Task,Type,Project,Assigned To,Status,Priority\n';
    filtered.forEach((t) => {
      csv += `"${t.due_date}","${t.document_name || t.title}","${t.task_type ?? ''}","${
        t.projects?.name ?? ''
      }","${t.team_members?.name ?? 'Unassigned'}","${t.status}","${t.priority}"\n`;
    });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = `tasks-by-date-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100">
      {/* Filters */}
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center gap-3 mb-5">
          <CalendarDays className="w-5 h-5 text-blue-600" />
          <h2 className="text-lg font-bold text-gray-900">Tasks by Date</h2>
          <span className="ml-auto text-sm text-gray-500">{filtered.length} tasks</span>
          <button
            onClick={exportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white text-sm font-medium rounded-lg"
          >
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">From Date</label>
            <input
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="w-full text-sm p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">To Date</label>
            <input
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="w-full text-sm p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none"
            />
          </div>
          <ProjectFilter projects={projects} value={projectFilter} onChange={setProjectFilter} accentClass="focus:ring-blue-400" />
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Team Member</label>
            <select
              value={memberFilter}
              onChange={(e) => setMemberFilter(e.target.value)}
              className="w-full text-sm p-2 border border-gray-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-400 focus:outline-none"
            >
              <option value="all">All Members</option>
              {teamMembers.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">Status</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full text-sm p-2 border border-gray-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-400 focus:outline-none"
            >
              <option value="all">All Statuses</option>
              <option value="pending">Pending</option>
              <option value="in-progress">In Progress</option>
              <option value="review">Review</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
        </div>
      </div>

      {/* Date-grouped list */}
      {sortedDates.length === 0 ? (
        <div className="text-center py-16">
          <CheckCircle2 className="w-12 h-12 text-green-400 mx-auto mb-3" />
          <p className="text-gray-500">No tasks in this date range</p>
        </div>
      ) : (
        <div className="divide-y divide-gray-100">
          {sortedDates.map((date) => {
            const dayTasks = groups[date];
            const open = !collapsed.has(date);
            const isToday = date === today;
            const isPast = date < today;
            const hasOverdue = dayTasks.some((t) => isOverdue(t.due_date, t.status));

            return (
              <div key={date}>
                {/* Day header */}
                <button
                  onClick={() => toggleDay(date)}
                  className="w-full flex items-center gap-3 px-6 py-3 hover:bg-gray-50 transition-colors text-left"
                >
                  {open ? (
                    <ChevronDown className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  )}
                  <span
                    className={`font-semibold text-sm ${
                      isToday
                        ? 'text-teal-700'
                        : hasOverdue && isPast
                        ? 'text-red-600'
                        : 'text-gray-800'
                    }`}
                  >
                    {isToday ? 'Today — ' : ''}
                    {fmtDate(date)}
                  </span>
                  {isToday && (
                    <span className="px-2 py-0.5 bg-teal-100 text-teal-700 text-xs font-medium rounded-full">
                      Today
                    </span>
                  )}
                  {hasOverdue && isPast && !isToday && (
                    <span className="px-2 py-0.5 bg-red-100 text-red-600 text-xs font-medium rounded-full">
                      Overdue
                    </span>
                  )}
                  <span className="ml-auto text-xs text-gray-400">{dayTasks.length} task{dayTasks.length !== 1 ? 's' : ''}</span>
                </button>

                {/* Tasks table for this day */}
                {open && (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="bg-gray-50 border-y border-gray-100">
                          <th className="text-left py-2 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wide pl-12">
                            Task
                          </th>
                          <th className="text-left py-2 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wide">
                            Project
                          </th>
                          <th className="text-left py-2 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wide">
                            Assigned To
                          </th>
                          <th className="text-left py-2 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wide">
                            Due Date
                          </th>
                          <th className="text-left py-2 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wide">
                            Status
                          </th>
                          <th className="text-left py-2 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wide">
                            Type
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {dayTasks.map((t) => (
                          <TaskRow key={t.id} task={t} showMember={true} />
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── Monthly Report ──────────────────────────────────────────────────────────
function MonthlyReport({
  tasks,
  teamMembers,
  projects,
}: {
  tasks: TaskWithDetails[];
  teamMembers: TeamMember[];
  projects: Project[];
}) {
  const now = new Date();
  const defaultFrom = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`;
  const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const defaultTo = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${lastDay}`;

  const [fromDate, setFromDate] = useState(defaultFrom);
  const [toDate, setToDate] = useState(defaultTo);
  const [projectFilter, setProjectFilter] = useState('all');

  const inRange = tasks.filter(
    (t) =>
      t.due_date >= fromDate &&
      t.due_date <= toDate &&
      (projectFilter === 'all' || t.project_id === projectFilter)
  );

  const today = new Date().toISOString().split('T')[0];

  const stats = {
    total:     inRange.length,
    completed: inRange.filter((t) => t.status === 'completed').length,
    pending:   inRange.filter((t) => t.status === 'pending').length,
    inProgress:inRange.filter((t) => t.status === 'in-progress').length,
    overdue:   inRange.filter((t) => t.due_date < today && t.status !== 'completed' && t.status !== 'cancelled').length,
  };

  const byMember = teamMembers
    .map((m) => {
      const mt = inRange.filter((t) => t.assigned_to === m.id);
      return {
        name: m.name,
        total:     mt.length,
        completed: mt.filter((t) => t.status === 'completed').length,
        pending:   mt.filter((t) => t.status === 'pending').length,
        inProgress:mt.filter((t) => t.status === 'in-progress').length,
        overdue:   mt.filter((t) => t.due_date < today && t.status !== 'completed' && t.status !== 'cancelled').length,
      };
    })
    .filter((r) => r.total > 0);

  const byProject = projects
    .map((p) => {
      const pt = inRange.filter((t) => t.project_id === p.id);
      return {
        name:      p.name,
        status:    p.status,
        total:     pt.length,
        completed: pt.filter((t) => t.status === 'completed').length,
        pending:   pt.filter((t) => t.status === 'pending').length,
        inProgress:pt.filter((t) => t.status === 'in-progress').length,
        overdue:   pt.filter((t) => t.due_date < today && t.status !== 'completed' && t.status !== 'cancelled').length,
      };
    })
    .filter((r) => r.total > 0);

  const exportCSV = () => {
    const lines: string[] = [];

    lines.push(`Monthly Report,${fromDate} to ${toDate}`);
    lines.push('');

    lines.push('SUMMARY');
    lines.push('Total Tasks,Completed,In Progress,Pending,Overdue');
    lines.push(`${stats.total},${stats.completed},${stats.inProgress},${stats.pending},${stats.overdue}`);
    lines.push('');

    lines.push('BY TEAM MEMBER');
    lines.push('Team Member,Total,Completed,In Progress,Pending,Overdue');
    byMember.forEach((r) =>
      lines.push(`"${r.name}",${r.total},${r.completed},${r.inProgress},${r.pending},${r.overdue}`)
    );
    lines.push('');

    lines.push('BY PROJECT');
    lines.push('Project,Status,Total,Completed,In Progress,Pending,Overdue');
    byProject.forEach((r) =>
      lines.push(`"${r.name}","${r.status}",${r.total},${r.completed},${r.inProgress},${r.pending},${r.overdue}`)
    );
    lines.push('');

    lines.push('TASK DETAILS');
    lines.push('Task,Type,Project,Assigned To,Due Date,Status,Priority');
    inRange.forEach((t) =>
      lines.push(
        `"${(t.document_name || t.title).replace(/"/g, '""')}","${t.task_type ?? ''}","${t.projects?.name ?? ''}","${t.team_members?.name ?? 'Unassigned'}","${t.due_date}","${t.status}","${t.priority}"`
      )
    );

    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `monthly-report-${fromDate}-to-${toDate}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  const statCards = [
    { label: 'Total Tasks',   value: stats.total,      color: 'text-gray-900',   bg: 'bg-gray-50  border-gray-200' },
    { label: 'Completed',     value: stats.completed,   color: 'text-green-700',  bg: 'bg-green-50 border-green-200' },
    { label: 'In Progress',   value: stats.inProgress,  color: 'text-blue-700',   bg: 'bg-blue-50  border-blue-200' },
    { label: 'Pending',       value: stats.pending,     color: 'text-amber-700',  bg: 'bg-amber-50 border-amber-200' },
    { label: 'Overdue',       value: stats.overdue,     color: 'text-red-700',    bg: 'bg-red-50   border-red-200' },
  ];

  const thCls = 'py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide text-left';
  const tdCls = (extra = '') => `py-3 px-4 text-sm text-center ${extra}`;

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
        <div className="flex flex-wrap items-end gap-4">
          <div className="flex-1 min-w-0">
            <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2 mb-4">
              <BarChart2 className="w-5 h-5 text-teal-600" />
              Monthly Report
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Start Date</label>
                <input
                  type="date"
                  value={fromDate}
                  onChange={(e) => setFromDate(e.target.value)}
                  className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-teal-400 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">End Date</label>
                <input
                  type="date"
                  value={toDate}
                  onChange={(e) => setToDate(e.target.value)}
                  className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-teal-400 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Project</label>
                <select
                  value={projectFilter}
                  onChange={(e) => setProjectFilter(e.target.value)}
                  className="w-full text-sm px-3 py-2 border border-gray-200 rounded-lg bg-white focus:ring-2 focus:ring-teal-400 focus:outline-none"
                >
                  <option value="all">All Projects</option>
                  {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
            </div>
          </div>
          <button
            onClick={exportCSV}
            className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-semibold rounded-xl text-sm hover:from-teal-600 hover:to-blue-700 transition-all shadow-sm"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        </div>

        <p className="mt-3 text-xs text-gray-400">
          Showing tasks with due dates from <span className="font-medium text-gray-600">{fmtDate(fromDate)}</span> to <span className="font-medium text-gray-600">{fmtDate(toDate)}</span>
          {projectFilter !== 'all' && <> · project: <span className="font-medium text-gray-600">{projects.find((p) => p.id === projectFilter)?.name}</span></>}
        </p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        {statCards.map((c) => (
          <div key={c.label} className={`bg-white rounded-2xl border p-5 text-center shadow-sm ${c.bg}`}>
            <p className={`text-3xl font-bold ${c.color}`}>{c.value}</p>
            <p className="text-xs text-gray-500 mt-1 font-medium">{c.label}</p>
          </div>
        ))}
      </div>

      {inRange.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-16 text-center shadow-sm">
          <CheckCircle2 className="w-14 h-14 text-green-400 mx-auto mb-4" />
          <p className="text-gray-600 font-semibold">No tasks in this date range</p>
          <p className="text-gray-400 text-sm mt-1">Adjust the start and end dates above</p>
        </div>
      ) : (
        <>
          {/* By Team Member */}
          {byMember.length > 0 && (
            <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
              <div className="flex items-center gap-3 px-6 py-4 border-b border-gray-100">
                <Users className="w-5 h-5 text-teal-600" />
                <h3 className="font-bold text-gray-900">By Team Member</h3>
                <span className="ml-auto text-xs text-gray-400">{byMember.length} member{byMember.length !== 1 ? 's' : ''}</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100">
                      <th className={thCls}>Team Member</th>
                      <th className={thCls + ' text-center'}>Total</th>
                      <th className={thCls + ' text-center'}>Completed</th>
                      <th className={thCls + ' text-center'}>In Progress</th>
                      <th className={thCls + ' text-center'}>Pending</th>
                      <th className={thCls + ' text-center'}>Overdue</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {byMember.map((r) => (
                      <tr key={r.name} className="hover:bg-gray-50 transition-colors">
                        <td className="py-3 px-4 font-medium text-gray-900">{r.name}</td>
                        <td className={tdCls('text-gray-700 font-semibold')}>{r.total}</td>
                        <td className={tdCls('text-green-600 font-medium')}>{r.completed}</td>
                        <td className={tdCls('text-blue-600')}>{r.inProgress}</td>
                        <td className={tdCls('text-amber-600')}>{r.pending}</td>
                        <td className={tdCls('text-red-600 font-semibold')}>{r.overdue || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* By Project */}
          {byProject.length > 0 && (
            <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
              <div className="flex items-center gap-3 px-6 py-4 border-b border-gray-100">
                <FolderKanban className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-gray-900">By Project</h3>
                <span className="ml-auto text-xs text-gray-400">{byProject.length} project{byProject.length !== 1 ? 's' : ''}</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100">
                      <th className={thCls}>Project</th>
                      <th className={thCls}>Status</th>
                      <th className={thCls + ' text-center'}>Total</th>
                      <th className={thCls + ' text-center'}>Completed</th>
                      <th className={thCls + ' text-center'}>In Progress</th>
                      <th className={thCls + ' text-center'}>Pending</th>
                      <th className={thCls + ' text-center'}>Overdue</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {byProject.map((r) => (
                      <tr key={r.name} className="hover:bg-gray-50 transition-colors">
                        <td className="py-3 px-4 font-medium text-gray-900">{r.name}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLORS[r.status] ?? 'bg-gray-100 text-gray-700'}`}>
                            {statusLabel(r.status)}
                          </span>
                        </td>
                        <td className={tdCls('text-gray-700 font-semibold')}>{r.total}</td>
                        <td className={tdCls('text-green-600 font-medium')}>{r.completed}</td>
                        <td className={tdCls('text-blue-600')}>{r.inProgress}</td>
                        <td className={tdCls('text-amber-600')}>{r.pending}</td>
                        <td className={tdCls('text-red-600 font-semibold')}>{r.overdue || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Task detail table */}
          <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
            <div className="flex items-center gap-3 px-6 py-4 border-b border-gray-100">
              <FileText className="w-5 h-5 text-gray-500" />
              <h3 className="font-bold text-gray-900">All Tasks in Range</h3>
              <span className="ml-auto text-xs text-gray-400">{inRange.length} task{inRange.length !== 1 ? 's' : ''}</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100">
                    <th className={thCls}>Task</th>
                    <th className={thCls}>Project</th>
                    <th className={thCls}>Assigned To</th>
                    <th className={thCls}>Due Date</th>
                    <th className={thCls}>Status</th>
                    <th className={thCls}>Priority</th>
                  </tr>
                </thead>
                <tbody>
                  {inRange.map((t) => (
                    <TaskRow key={t.id} task={t} showMember={true} />
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ─── Main Reports component ──────────────────────────────────────────────────
export function Reports() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<TaskWithDetails[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [reportType, setReportType] = useState<ReportType>('monthly');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  const fetchData = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const [tasksRes, projectsRes, membersRes] = await Promise.all([
      supabase.from('tasks').select('*, projects(*), team_members(*)').order('due_date', { ascending: true }),
      supabase.from('projects').select('*').order('name'),
      supabase.from('team_members').select('*').eq('is_active', true).order('name'),
    ]);
    if (tasksRes.data) setTasks(tasksRes.data as TaskWithDetails[]);
    if (projectsRes.data) setProjects(projectsRes.data);
    if (membersRes.data) setTeamMembers(membersRes.data);
    setLoading(false);
  }, [user]);

  useEffect(() => { fetchData(); }, [fetchData]);

  // ── existing derived data ──
  const today = new Date().toISOString().split('T')[0];

  const dueDocuments = tasks.filter(
    (t) => t.task_type === 'document' && t.due_date <= selectedDate && t.status !== 'completed' && t.status !== 'cancelled'
  );

  const overdueTasks = tasks.filter(
    (t) => t.due_date < today && t.status !== 'completed' && t.status !== 'cancelled'
  );

  const summary = {
    totalProjects: projects.length,
    activeProjects: projects.filter((p) => p.status === 'active').length,
    totalTasks: tasks.length,
    completedTasks: tasks.filter((t) => t.status === 'completed').length,
    pendingTasks: tasks.filter((t) => t.status === 'pending').length,
    overdueTasks: overdueTasks.length,
  };

  const tasksByMember = teamMembers.map((member) => {
    const mt = tasks.filter((t) => t.assigned_to === member.id);
    return {
      member,
      total: mt.length,
      completed: mt.filter((t) => t.status === 'completed').length,
      pending: mt.filter((t) => t.status === 'pending').length,
      overdue: mt.filter((t) => t.due_date < today && t.status !== 'completed' && t.status !== 'cancelled').length,
    };
  });

  const tasksByProject = projects.map((project) => {
    const pt = tasks.filter((t) => t.project_id === project.id);
    return {
      project,
      total: pt.length,
      completed: pt.filter((t) => t.status === 'completed').length,
      pending: pt.filter((t) => t.status === 'pending').length,
      overdue: pt.filter((t) => t.due_date < today && t.status !== 'completed' && t.status !== 'cancelled').length,
    };
  });

  const exportLegacyCSV = () => {
    let csv = '';
    let filename = '';
    if (reportType === 'due-documents') {
      csv = 'Document Name,Project,Assigned To,Due Date,Priority,Status\n';
      dueDocuments.forEach((t) => {
        csv += `"${t.document_name || t.title}","${t.projects?.name ?? ''}","${t.team_members?.name ?? 'Unassigned'}","${t.due_date}","${t.priority}","${t.status}"\n`;
      });
      filename = 'due-documents-report';
    } else if (reportType === 'overdue') {
      csv = 'Task,Project,Assigned To,Due Date,Priority,Status\n';
      overdueTasks.forEach((t) => {
        csv += `"${t.title}","${t.projects?.name ?? ''}","${t.team_members?.name ?? 'Unassigned'}","${t.due_date}","${t.priority}","${t.status}"\n`;
      });
      filename = 'overdue-tasks-report';
    } else return;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = `${filename}-${today}.csv`;
    a.click();
  };

  const TABS: { id: ReportType; label: string; icon: React.ReactNode }[] = [
    { id: 'monthly',     label: 'Monthly Report',  icon: <BarChart2 className="w-4 h-4" /> },
    { id: 'by-member',   label: 'By Team Member',  icon: <UserCheck className="w-4 h-4" /> },
    { id: 'by-date',     label: 'By Date',          icon: <CalendarDays className="w-4 h-4" /> },
    { id: 'due-documents', label: 'Due Documents', icon: <FileText className="w-4 h-4" /> },
    { id: 'overdue',     label: 'Overdue Tasks',    icon: <AlertTriangle className="w-4 h-4" /> },
    { id: 'summary',     label: 'Summary',          icon: <TrendingUp className="w-4 h-4" /> },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 p-6 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Reports</h1>
            <p className="text-gray-500 mt-1 text-sm">View and export task reports</p>
          </div>
          {(reportType === 'due-documents' || reportType === 'overdue') && (
            <button
              onClick={exportLegacyCSV}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg hover:from-teal-600 hover:to-blue-700"
            >
              <Download className="w-4 h-4" />
              Export CSV
            </button>
          )}
        </div>

        {/* Tab bar */}
        <div className="bg-white rounded-xl shadow-sm p-1.5 mb-6 flex gap-1 flex-wrap">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setReportType(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                reportType === tab.id
                  ? 'bg-gradient-to-r from-teal-500 to-blue-600 text-white shadow-sm'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>

        {/* ── Monthly Report ── */}
        {reportType === 'monthly' && (
          <MonthlyReport tasks={tasks} teamMembers={teamMembers} projects={projects} />
        )}

        {/* ── By Member ── */}
        {reportType === 'by-member' && (
          <ByMemberReport tasks={tasks} teamMembers={teamMembers} projects={projects} />
        )}

        {/* ── By Date ── */}
        {reportType === 'by-date' && (
          <ByDateReport tasks={tasks} teamMembers={teamMembers} projects={projects} />
        )}

        {/* ── Due Documents ── */}
        {reportType === 'due-documents' && (
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <FileText className="w-6 h-6 text-teal-600" />
                <h2 className="text-xl font-bold text-gray-900">Documents Due by Cut-off Date</h2>
              </div>
              <div className="flex items-center gap-2">
                <label className="text-sm text-gray-600">Cut-off:</label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="p-2 border border-gray-300 rounded-lg text-sm"
                />
              </div>
            </div>

            {dueDocuments.length === 0 ? (
              <div className="text-center py-12">
                <CheckCircle2 className="w-16 h-16 text-green-400 mx-auto mb-4" />
                <p className="text-gray-500">No documents due on or before the selected date</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 bg-gray-50">
                      {['Document', 'Project', 'Assigned To', 'Due Date', 'Priority', 'Status'].map((h) => (
                        <th key={h} className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {dueDocuments.map((t) => (
                      <tr key={t.id} className={`border-b border-gray-100 hover:bg-gray-50 border-l-4 ${PRIORITY_LEFT_BORDER[t.priority] ?? 'border-l-gray-300'}`}>
                        <td className="py-3 px-4 font-medium text-gray-900">{t.document_name || t.title}</td>
                        <td className="py-3 px-4 text-sm text-gray-600">{t.projects?.name}</td>
                        <td className="py-3 px-4 text-sm text-gray-600">{t.team_members?.name ?? 'Unassigned'}</td>
                        <td className="py-3 px-4 text-sm text-gray-600">{fmtDate(t.due_date)}</td>
                        <td className="py-3 px-4 text-sm capitalize text-gray-700">{t.priority}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLORS[t.status] ?? 'bg-gray-100 text-gray-700'}`}>
                            {statusLabel(t.status)}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <p className="mt-4 pt-4 border-t border-gray-100 text-sm text-gray-400">
              {dueDocuments.length} document{dueDocuments.length !== 1 ? 's' : ''} due on or before {fmtDate(selectedDate)}
            </p>
          </div>
        )}

        {/* ── Overdue ── */}
        {reportType === 'overdue' && (
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <div className="flex items-center gap-3 mb-6">
              <AlertTriangle className="w-6 h-6 text-red-500" />
              <h2 className="text-xl font-bold text-gray-900">Overdue Tasks</h2>
            </div>
            {overdueTasks.length === 0 ? (
              <div className="text-center py-12">
                <CheckCircle2 className="w-16 h-16 text-green-400 mx-auto mb-4" />
                <p className="text-gray-500">All tasks are on schedule</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 bg-gray-50">
                      {['Task', 'Project', 'Assigned To', 'Due Date', 'Days Overdue', 'Status'].map((h) => (
                        <th key={h} className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {overdueTasks.map((t) => {
                      const days = Math.floor((Date.now() - new Date(t.due_date + 'T00:00:00').getTime()) / 86400000);
                      return (
                        <tr key={t.id} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="py-3 px-4">
                            <div className="font-medium text-gray-900">{t.title}</div>
                            {t.description && <div className="text-xs text-gray-400 mt-0.5">{t.description}</div>}
                          </td>
                          <td className="py-3 px-4 text-sm text-gray-600">{t.projects?.name}</td>
                          <td className="py-3 px-4 text-sm text-gray-600">{t.team_members?.name ?? 'Unassigned'}</td>
                          <td className="py-3 px-4 text-sm text-red-600 font-medium">{fmtDate(t.due_date)}</td>
                          <td className="py-3 px-4">
                            <span className="text-red-600 font-bold text-sm">{days}d</span>
                          </td>
                          <td className="py-3 px-4">
                            <span className={`px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLORS[t.status] ?? 'bg-gray-100 text-gray-700'}`}>
                              {statusLabel(t.status)}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* ── Summary ── */}
        {reportType === 'summary' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: 'Active Projects', value: summary.activeProjects, sub: `of ${summary.totalProjects} total`, icon: <FolderKanban className="w-6 h-6 text-white" />, grad: 'from-blue-500 to-blue-600' },
                { label: 'Pending Tasks', value: summary.pendingTasks, sub: 'awaiting action', icon: <Clock className="w-6 h-6 text-white" />, grad: 'from-yellow-500 to-orange-500' },
                { label: 'Completed Tasks', value: summary.completedTasks, sub: `of ${summary.totalTasks} total`, icon: <CheckCircle2 className="w-6 h-6 text-white" />, grad: 'from-green-500 to-emerald-600' },
                { label: 'Overdue Tasks', value: summary.overdueTasks, sub: 'need attention', icon: <AlertTriangle className="w-6 h-6 text-white" />, grad: 'from-red-500 to-pink-600', valueClass: 'text-red-600' },
              ].map((card) => (
                <div key={card.label} className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
                  <div className={`w-12 h-12 bg-gradient-to-br ${card.grad} rounded-xl flex items-center justify-center mb-4`}>
                    {card.icon}
                  </div>
                  <p className="text-sm text-gray-500 mb-1">{card.label}</p>
                  <p className={`text-3xl font-bold ${card.valueClass ?? 'text-gray-900'}`}>{card.value}</p>
                  <p className="text-xs text-gray-400 mt-1">{card.sub}</p>
                </div>
              ))}
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
              <div className="flex items-center gap-3 mb-6">
                <Users className="w-5 h-5 text-teal-600" />
                <h2 className="text-lg font-bold text-gray-900">Tasks by Team Member</h2>
              </div>
              {tasksByMember.length === 0 ? (
                <p className="text-gray-400 text-center py-8">No team members yet</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200 bg-gray-50">
                        {['Team Member', 'Total', 'Completed', 'Pending', 'Overdue'].map((h) => (
                          <th key={h} className={`py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide ${h === 'Team Member' ? 'text-left' : 'text-center'}`}>
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {tasksByMember.map(({ member, total, completed, pending, overdue }) => (
                        <tr key={member.id} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="py-3 px-4 font-medium text-gray-900">{member.name}</td>
                          <td className="py-3 px-4 text-center text-gray-700">{total}</td>
                          <td className="py-3 px-4 text-center text-green-600 font-medium">{completed}</td>
                          <td className="py-3 px-4 text-center text-yellow-600">{pending}</td>
                          <td className="py-3 px-4 text-center text-red-600 font-semibold">{overdue}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
              <div className="flex items-center gap-3 mb-6">
                <FolderKanban className="w-5 h-5 text-blue-600" />
                <h2 className="text-lg font-bold text-gray-900">Tasks by Project</h2>
              </div>
              {tasksByProject.length === 0 ? (
                <p className="text-gray-400 text-center py-8">No projects yet</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200 bg-gray-50">
                        {['Project', 'Status', 'Total', 'Completed', 'Pending', 'Overdue'].map((h) => (
                          <th key={h} className={`py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide ${['Project', 'Status'].includes(h) ? 'text-left' : 'text-center'}`}>
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {tasksByProject.map(({ project, total, completed, pending, overdue }) => (
                        <tr key={project.id} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="py-3 px-4 font-medium text-gray-900">{project.name}</td>
                          <td className="py-3 px-4">
                            <span className={`px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLORS[project.status] ?? 'bg-gray-100 text-gray-700'}`}>
                              {statusLabel(project.status)}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-center text-gray-700">{total}</td>
                          <td className="py-3 px-4 text-center text-green-600 font-medium">{completed}</td>
                          <td className="py-3 px-4 text-center text-yellow-600">{pending}</td>
                          <td className="py-3 px-4 text-center text-red-600 font-semibold">{overdue}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
