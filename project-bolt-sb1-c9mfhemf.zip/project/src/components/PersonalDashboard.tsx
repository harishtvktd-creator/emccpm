import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../lib/supabase';
import {
  LayoutDashboard, AlertTriangle, Clock, CheckCircle2, CalendarDays,
  FolderOpen, ChevronDown, ChevronUp, Loader2, RefreshCw, User,
} from 'lucide-react';

type Task = {
  id: string;
  title: string;
  description: string | null;
  status: string;
  priority: string;
  due_date: string | null;
  task_type: string | null;
  notes: string | null;
  project: { id: string; name: string; project_code: string | null } | null;
};

const PRIORITY_CONFIG: Record<string, { label: string; bar: string; badge: string; border: string }> = {
  critical: { label: 'Critical', bar: 'bg-red-500',    badge: 'bg-red-100 text-red-700 border-red-200',      border: 'border-l-red-500' },
  high:     { label: 'High',     bar: 'bg-orange-400', badge: 'bg-orange-100 text-orange-700 border-orange-200', border: 'border-l-orange-400' },
  medium:   { label: 'Medium',   bar: 'bg-yellow-400', badge: 'bg-yellow-100 text-yellow-700 border-yellow-200', border: 'border-l-yellow-400' },
  low:      { label: 'Low',      bar: 'bg-gray-300',   badge: 'bg-gray-100 text-gray-600 border-gray-200',    border: 'border-l-gray-300' },
};

const STATUS_CONFIG: Record<string, { label: string; cls: string }> = {
  pending:      { label: 'Pending',     cls: 'bg-gray-100 text-gray-600 border-gray-200' },
  'in-progress':{ label: 'In Progress', cls: 'bg-blue-100 text-blue-700 border-blue-200' },
  review:       { label: 'Review',      cls: 'bg-amber-100 text-amber-700 border-amber-200' },
  completed:    { label: 'Completed',   cls: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  cancelled:    { label: 'Cancelled',   cls: 'bg-red-100 text-red-600 border-red-200' },
};

function fmtDate(d: string) {
  const [y, m, day] = d.split('-');
  return `${day}/${m}/${y}`;
}

function daysUntil(due: string): number {
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const dueDate = new Date(due); dueDate.setHours(0, 0, 0, 0);
  return Math.ceil((dueDate.getTime() - today.getTime()) / 86400000);
}

function DueBadge({ due }: { due: string }) {
  const diff = daysUntil(due);
  if (diff < 0)  return <span className="text-xs font-bold text-red-600 bg-red-50 border border-red-200 px-2 py-0.5 rounded-full">{Math.abs(diff)}d overdue</span>;
  if (diff === 0) return <span className="text-xs font-bold text-orange-600 bg-orange-50 border border-orange-200 px-2 py-0.5 rounded-full">Due today</span>;
  if (diff <= 3)  return <span className="text-xs font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">Due in {diff}d</span>;
  return <span className="text-xs text-gray-500 bg-gray-50 border border-gray-200 px-2 py-0.5 rounded-full">{fmtDate(due)}</span>;
}

function TaskCard({ task }: { task: Task }) {
  const [open, setOpen] = useState(false);
  const pc = PRIORITY_CONFIG[task.priority] ?? PRIORITY_CONFIG.medium;
  const sc = STATUS_CONFIG[task.status] ?? STATUS_CONFIG.pending;
  return (
    <div className={`bg-white rounded-xl border border-gray-100 border-l-4 ${pc.border} shadow-sm overflow-hidden transition-shadow hover:shadow-md`}>
      <button className="w-full text-left p-4" onClick={() => setOpen((o) => !o)}>
        <div className="flex items-start gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold border ${pc.badge}`}>
                {pc.label}
              </span>
              <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${sc.cls}`}>
                {sc.label}
              </span>
            </div>
            <p className="font-semibold text-gray-900 mt-1.5 text-sm leading-snug">{task.title}</p>
            {task.project && (
              <p className="text-xs text-teal-600 mt-1 flex items-center gap-1">
                <FolderOpen className="w-3 h-3" />
                {task.project.project_code ? `[${task.project.project_code}] ` : ''}{task.project.name}
              </p>
            )}
          </div>
          <div className="flex flex-col items-end gap-1.5 flex-shrink-0 ml-2">
            {task.due_date && <DueBadge due={task.due_date} />}
            {open ? <ChevronUp className="w-4 h-4 text-gray-400 mt-1" /> : <ChevronDown className="w-4 h-4 text-gray-400 mt-1" />}
          </div>
        </div>
      </button>
      {open && (task.description || task.notes || task.task_type) && (
        <div className="px-4 pb-4 space-y-2 border-t border-gray-50 pt-3">
          {task.task_type && (
            <p className="text-xs text-gray-400 uppercase tracking-wide font-semibold">{task.task_type}</p>
          )}
          {task.description && (
            <p className="text-sm text-gray-600 leading-relaxed">{task.description}</p>
          )}
          {task.notes && (
            <div className="bg-amber-50 border border-amber-100 rounded-lg px-3 py-2">
              <p className="text-xs font-semibold text-amber-700 mb-0.5">Notes</p>
              <p className="text-sm text-amber-800">{task.notes}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function SectionHeader({
  icon: Icon, title, count, color, empty,
}: { icon: React.ElementType; title: string; count: number; color: string; empty?: boolean }) {
  return (
    <div className={`flex items-center gap-3 mb-4`}>
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${color}`}>
        <Icon className="w-4.5 h-4.5 w-[18px] h-[18px] text-white" />
      </div>
      <div>
        <h3 className="font-bold text-gray-900 text-base leading-tight">{title}</h3>
        <p className="text-xs text-gray-400 mt-0.5">{count} {count === 1 ? 'task' : 'tasks'}{empty ? ' — all clear' : ''}</p>
      </div>
    </div>
  );
}

export function PersonalDashboard() {
  const { teamMember } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());

  const fetchTasks = useCallback(async () => {
    if (!teamMember) return;
    setLoading(true);
    const { data } = await supabase
      .from('tasks')
      .select('id,title,description,status,priority,due_date,task_type,notes,project:projects(id,name,project_code)')
      .eq('assigned_to', teamMember.id)
      .not('status', 'in', '("completed","cancelled")')
      .order('due_date', { ascending: true, nullsFirst: false });
    setTasks((data ?? []) as unknown as Task[]);
    setLastRefresh(new Date());
    setLoading(false);
  }, [teamMember]);

  useEffect(() => { fetchTasks(); }, [fetchTasks]);

  const today = new Date(); today.setHours(0, 0, 0, 0);

  const overdue  = tasks.filter((t) => t.due_date && new Date(t.due_date) < today);
  const upcoming = tasks.filter((t) => !t.due_date || new Date(t.due_date) >= today);

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 p-6 lg:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <div className="w-11 h-11 bg-gradient-to-br from-teal-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-md">
                <LayoutDashboard className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-xs font-semibold text-teal-600 uppercase tracking-widest">My Dashboard</p>
                <h1 className="text-2xl font-bold text-gray-900 leading-tight">
                  {greeting()}{teamMember?.name ? `, ${teamMember.name.split(' ')[0]}` : ''}
                </h1>
              </div>
            </div>
            <p className="text-sm text-gray-500 mt-1 ml-14">
              {new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </p>
          </div>
          <button
            onClick={fetchTasks}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 border border-gray-200 bg-white rounded-xl text-sm text-gray-600 hover:border-teal-300 hover:text-teal-700 transition-colors shadow-sm disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>

        {/* KPI strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <KpiTile
            label="Overdue"
            value={overdue.length}
            icon={AlertTriangle}
            color={overdue.length > 0 ? 'text-red-600 bg-red-50 border-red-100' : 'text-gray-400 bg-gray-50 border-gray-100'}
            iconColor={overdue.length > 0 ? 'text-red-500' : 'text-gray-300'}
          />
          <KpiTile
            label="Due Today"
            value={upcoming.filter((t) => t.due_date && daysUntil(t.due_date) === 0).length}
            icon={CalendarDays}
            color="text-orange-700 bg-orange-50 border-orange-100"
            iconColor="text-orange-500"
          />
          <KpiTile
            label="This Week"
            value={upcoming.filter((t) => t.due_date && daysUntil(t.due_date) <= 7 && daysUntil(t.due_date) >= 0).length}
            icon={Clock}
            color="text-blue-700 bg-blue-50 border-blue-100"
            iconColor="text-blue-400"
          />
          <KpiTile
            label="Total Active"
            value={tasks.length}
            icon={CheckCircle2}
            color="text-teal-700 bg-teal-50 border-teal-100"
            iconColor="text-teal-400"
          />
        </div>

        {loading ? (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-16 flex items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-teal-400" />
          </div>
        ) : tasks.length === 0 ? (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-16 text-center">
            <CheckCircle2 className="w-14 h-14 text-emerald-300 mx-auto mb-4" />
            <h3 className="text-lg font-bold text-gray-700 mb-1">All caught up!</h3>
            <p className="text-sm text-gray-400">You have no active tasks assigned to you.</p>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Overdue */}
            <section>
              <SectionHeader
                icon={AlertTriangle}
                title="Overdue Tasks"
                count={overdue.length}
                color={overdue.length > 0 ? 'bg-gradient-to-br from-red-500 to-rose-600' : 'bg-gray-200'}
                empty={overdue.length === 0}
              />
              {overdue.length === 0 ? (
                <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-6 text-center">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-emerald-700">No overdue tasks</p>
                  <p className="text-xs text-emerald-600 mt-0.5">Great job staying on top of your work!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {overdue
                    .sort((a, b) => {
                      const pOrd = ['critical', 'high', 'medium', 'low'];
                      const pDiff = pOrd.indexOf(a.priority) - pOrd.indexOf(b.priority);
                      if (pDiff !== 0) return pDiff;
                      return (a.due_date ?? '').localeCompare(b.due_date ?? '');
                    })
                    .map((t) => <TaskCard key={t.id} task={t} />)}
                </div>
              )}
            </section>

            {/* Upcoming */}
            <section>
              <SectionHeader
                icon={Clock}
                title="Upcoming Tasks"
                count={upcoming.length}
                color="bg-gradient-to-br from-teal-500 to-blue-600"
                empty={upcoming.length === 0}
              />
              {upcoming.length === 0 ? (
                <div className="bg-gray-50 border border-gray-100 rounded-2xl p-6 text-center">
                  <Clock className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                  <p className="text-sm text-gray-500">No upcoming tasks</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {upcoming
                    .sort((a, b) => {
                      // No due date goes last
                      if (!a.due_date && !b.due_date) return 0;
                      if (!a.due_date) return 1;
                      if (!b.due_date) return -1;
                      const dateDiff = a.due_date.localeCompare(b.due_date);
                      if (dateDiff !== 0) return dateDiff;
                      const pOrd = ['critical', 'high', 'medium', 'low'];
                      return pOrd.indexOf(a.priority) - pOrd.indexOf(b.priority);
                    })
                    .map((t) => <TaskCard key={t.id} task={t} />)}
                </div>
              )}
            </section>
          </div>
        )}

        <p className="text-center text-xs text-gray-400 pb-4">
          Last refreshed {lastRefresh.toLocaleTimeString()} · Showing tasks assigned to
          {teamMember?.name ? ` ${teamMember.name}` : ' you'}
        </p>
      </div>
    </div>
  );
}

function KpiTile({
  label, value, icon: Icon, color, iconColor,
}: { label: string; value: number; icon: React.ElementType; color: string; iconColor: string }) {
  return (
    <div className={`bg-white rounded-2xl border shadow-sm p-4 flex items-center gap-3 ${color.split(' ').filter((c) => c.startsWith('border')).join(' ')}`}>
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${color.split(' ').filter((c) => c.startsWith('bg')).join(' ')}`}>
        <Icon className={`w-5 h-5 ${iconColor}`} />
      </div>
      <div>
        <p className={`text-2xl font-bold leading-none ${color.split(' ').filter((c) => c.startsWith('text')).join(' ')}`}>{value}</p>
        <p className="text-xs text-gray-400 mt-0.5">{label}</p>
      </div>
    </div>
  );
}
