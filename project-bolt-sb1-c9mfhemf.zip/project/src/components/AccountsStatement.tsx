import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useExchangeRates } from '../hooks/useExchangeRates';
import { formatCurrency, convertCurrency, SUPPORTED_CURRENCIES, DEFAULT_CURRENCY } from '../lib/currency';
import { FileText, Loader2, Search, X, Calendar, Download, CreditCard, RefreshCw } from 'lucide-react';

type Transaction = {
  id: string;
  amount: number;
  description: string | null;
  date: string;
  currency: string;
  is_recurring: boolean;
  category: { id: string; name: string; type: string; color: string | null } | null;
  bank_account: { id: string; name: string; currency: string } | null;
};

type BankAccount = { id: string; name: string; currency: string };

export function AccountsStatement() {
  const today = new Date();
  const firstOfMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-01`;
  const todayStr = today.toISOString().split('T')[0];

  const { rates, loading: ratesLoading, lastUpdated } = useExchangeRates();
  const [displayCurrency, setDisplayCurrency] = useState(DEFAULT_CURRENCY);
  const conv = (n: number, from: string) => convertCurrency(n, from, displayCurrency, rates);

  const [rows, setRows] = useState<Transaction[]>([]);
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateFrom, setDateFrom] = useState(firstOfMonth);
  const [dateTo, setDateTo] = useState(todayStr);
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [filterAccount, setFilterAccount] = useState('all');

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [txRes, acRes] = await Promise.all([
      supabase
        .from('transactions')
        .select('id, amount, description, date, currency, is_recurring, category:categories(id,name,type,color), bank_account:bank_accounts(id,name,currency)')
        .gte('date', dateFrom)
        .lte('date', dateTo)
        .order('date', { ascending: false }),
      supabase.from('bank_accounts').select('id,name,currency').order('name'),
    ]);
    setRows((txRes.data ?? []) as unknown as Transaction[]);
    setAccounts((acRes.data ?? []) as BankAccount[]);
    setLoading(false);
  }, [dateFrom, dateTo]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const filtered = rows.filter((r) => {
    if (filterType !== 'all' && r.category?.type !== filterType) return false;
    if (filterAccount !== 'all' && r.bank_account?.id !== filterAccount) return false;
    if (search && !([r.description, r.category?.name, r.bank_account?.name]
      .some((f) => f?.toLowerCase().includes(search.toLowerCase())))) return false;
    return true;
  });

  // Running balance (chronological)
  const chronological = [...filtered].reverse();
  let running = 0;
  const withBalance = chronological.map((r) => {
    const sign = r.category?.type === 'income' ? 1 : -1;
    running += sign * conv(r.amount, r.currency);
    return { ...r, running };
  }).reverse();

  const totalIncome  = filtered.filter((r) => r.category?.type === 'income').reduce((s, r) => s + conv(r.amount, r.currency), 0);
  const totalExpense = filtered.filter((r) => r.category?.type === 'expense').reduce((s, r) => s + conv(r.amount, r.currency), 0);
  const net = totalIncome - totalExpense;

  const handleExport = () => {
    const header = 'Date,Description,Category,Type,Account,Amount,Currency\n';
    const body = filtered.map((r) =>
      `${r.date},"${r.description ?? ''}","${r.category?.name ?? ''}","${r.category?.type ?? ''}","${r.bank_account?.name ?? ''}",${r.amount},${r.currency}`
    ).join('\n');
    const blob = new Blob([header + body], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `statement_${dateFrom}_${dateTo}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-bold text-gray-900 text-lg">Statement</h3>
          <p className="text-sm text-gray-500 mt-0.5">Full account statement with running balance</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleExport}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-teal-700 to-teal-500 text-white font-semibold rounded-xl text-sm shadow-sm hover:from-teal-800 hover:to-teal-600 transition-all">
            <Download className="w-4 h-4" />Export CSV
          </button>
          <div className="flex items-center gap-2">
            {!ratesLoading && lastUpdated && (
              <span className="text-xs text-gray-400 flex items-center gap-1">
                <RefreshCw className="w-3 h-3" />Live rates
              </span>
            )}
            <select value={displayCurrency} onChange={(e) => setDisplayCurrency(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-teal-400 bg-white">
              {SUPPORTED_CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl border border-emerald-100 shadow-sm p-5">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">Total Credits</p>
          <p className="text-2xl font-bold text-emerald-600">{loading ? '—' : formatCurrency(totalIncome, displayCurrency)}</p>
          <p className="text-xs text-gray-400 mt-1">{filtered.filter((r) => r.category?.type === 'income').length} income entries</p>
        </div>
        <div className="bg-white rounded-2xl border border-rose-100 shadow-sm p-5">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">Total Debits</p>
          <p className="text-2xl font-bold text-rose-600">{loading ? '—' : formatCurrency(totalExpense, displayCurrency)}</p>
          <p className="text-xs text-gray-400 mt-1">{filtered.filter((r) => r.category?.type === 'expense').length} expense entries</p>
        </div>
        <div className={`bg-white rounded-2xl border shadow-sm p-5 ${net >= 0 ? 'border-teal-100' : 'border-orange-100'}`}>
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">Closing Balance</p>
          <p className={`text-2xl font-bold ${net >= 0 ? 'text-teal-600' : 'text-orange-600'}`}>{loading ? '—' : formatCurrency(net, displayCurrency)}</p>
          <p className="text-xs text-gray-400 mt-1">{filtered.length} total entries</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white border border-gray-200 rounded-2xl p-4">
        <div className="flex flex-wrap gap-4 items-end">
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">From</label>
            <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)}
              className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">To</label>
            <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)}
              className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Type</label>
            <select value={filterType} onChange={(e) => setFilterType(e.target.value as any)}
              className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400">
              <option value="all">All</option>
              <option value="income">Income</option>
              <option value="expense">Expense</option>
            </select>
          </div>
          {accounts.length > 0 && (
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
                <span className="flex items-center gap-1"><CreditCard className="w-3 h-3" />Account</span>
              </label>
              <select value={filterAccount} onChange={(e) => setFilterAccount(e.target.value)}
                className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400">
                <option value="all">All Accounts</option>
                {accounts.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
              </select>
            </div>
          )}
          <div className="relative flex-1 min-w-[180px]">
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Search</label>
            <Search className="absolute left-3 bottom-2.5 w-4 h-4 text-gray-400" />
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Description, category…"
              className="w-full pl-9 pr-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
            {search && <button onClick={() => setSearch('')} className="absolute right-3 bottom-2.5"><X className="w-4 h-4 text-gray-400 hover:text-gray-600" /></button>}
          </div>
          <button onClick={fetchData} className="px-4 py-2.5 bg-teal-600 text-white rounded-xl text-sm font-semibold hover:bg-teal-700 transition-colors flex items-center gap-2">
            <Calendar className="w-4 h-4" />Apply
          </button>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-12 flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-teal-500" />
        </div>
      ) : withBalance.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-14 text-center">
          <FileText className="w-12 h-12 text-gray-200 mx-auto mb-3" />
          <p className="font-semibold text-gray-500">No transactions found</p>
          <p className="text-sm text-gray-400 mt-1">Try adjusting the date range or filters.</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">Date</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Description</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">Category</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">Account</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-emerald-600 uppercase tracking-wide whitespace-nowrap">Credit</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-rose-600 uppercase tracking-wide whitespace-nowrap">Debit</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {withBalance.map((r) => {
                  const isIncome = r.category?.type === 'income';
                  return (
                    <tr key={r.id} className="hover:bg-gray-50/60 transition-colors">
                      <td className="px-4 py-3 font-mono text-xs text-gray-500 whitespace-nowrap">{fmtDate(r.date)}</td>
                      <td className="px-4 py-3 text-gray-700 max-w-[200px] truncate">
                        {r.description ?? <span className="text-gray-300">—</span>}
                        {r.is_recurring && <span className="ml-1.5 text-xs text-blue-400 font-medium">↻</span>}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {r.category ? (
                          <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-semibold border ${
                            isIncome ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-rose-50 text-rose-700 border-rose-100'}`}>
                            {r.category.name}
                          </span>
                        ) : <span className="text-gray-300 text-xs">—</span>}
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-500 whitespace-nowrap">{r.bank_account?.name ?? '—'}</td>
                      <td className="px-4 py-3 text-right font-medium text-emerald-600 whitespace-nowrap">
                        {isIncome ? formatCurrency(conv(r.amount, r.currency), displayCurrency) : ''}
                      </td>
                      <td className="px-4 py-3 text-right font-medium text-rose-600 whitespace-nowrap">
                        {!isIncome ? formatCurrency(conv(r.amount, r.currency), displayCurrency) : ''}
                      </td>
                      <td className={`px-4 py-3 text-right font-semibold whitespace-nowrap ${r.running >= 0 ? 'text-gray-700' : 'text-orange-600'}`}>
                        {formatCurrency(r.running, displayCurrency)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="bg-gray-50 border-t-2 border-gray-200">
                  <td colSpan={4} className="px-4 py-3 font-bold text-gray-700 text-sm">Totals</td>
                  <td className="px-4 py-3 text-right font-bold text-emerald-700">{formatCurrency(totalIncome, displayCurrency)}</td>
                  <td className="px-4 py-3 text-right font-bold text-rose-700">{formatCurrency(totalExpense, displayCurrency)}</td>
                  <td className={`px-4 py-3 text-right font-bold text-base ${net >= 0 ? 'text-teal-700' : 'text-orange-700'}`}>{formatCurrency(net, displayCurrency)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
