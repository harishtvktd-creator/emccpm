import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useExchangeRates } from '../hooks/useExchangeRates';
import { formatCurrency, convertCurrency, SUPPORTED_CURRENCIES, DEFAULT_CURRENCY } from '../lib/currency';
import { ArrowLeftRight, Loader2, TrendingUp, TrendingDown, Minus, RefreshCw } from 'lucide-react';

type MonthRow = {
  label: string;
  year: number;
  month: number;
  income: number;
  expense: number;
  net: number;
};

function fmtDate(d: string) {
  const [y, m, day] = d.split('-');
  return `${day}/${m}/${y}`;
}

const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function AccountsCashFlow() {
  const today = new Date();
  const [yearFilter, setYearFilter] = useState(today.getFullYear());
  const [rows, setRows] = useState<MonthRow[]>([]);
  const [loading, setLoading] = useState(true);

  const { rates, loading: ratesLoading, lastUpdated } = useExchangeRates();
  const [displayCurrency, setDisplayCurrency] = useState(DEFAULT_CURRENCY);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const from = `${yearFilter}-01-01`;
    const to = `${yearFilter}-12-31`;

    const { data: txns } = await supabase
      .from('transactions')
      .select('amount, date, category:categories(id,type)')
      .gte('date', from)
      .lte('date', to);

    // Get income/expense category ids
    const catMap = new Map<string, 'income' | 'expense'>();
    for (const t of (txns ?? []) as any[]) {
      if (t.category?.id) catMap.set(t.category.id, t.category.type);
    }

    // Bucket by month
    const monthly: Record<number, { income: number; expense: number }> = {};
    for (let m = 1; m <= 12; m++) monthly[m] = { income: 0, expense: 0 };

    for (const t of (txns ?? []) as any[]) {
      const m = parseInt(t.date.split('-')[1], 10);
      const type = t.category?.type ?? 'expense';
      if (type === 'income') monthly[m].income += t.amount;
      else monthly[m].expense += t.amount;
    }

    const result: MonthRow[] = [];
    for (let m = 1; m <= 12; m++) {
      result.push({
        label: MONTH_NAMES[m - 1],
        year: yearFilter,
        month: m,
        income: monthly[m].income,
        expense: monthly[m].expense,
        net: monthly[m].income - monthly[m].expense,
      });
    }
    setRows(result);
    setLoading(false);
  }, [yearFilter]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const totalIncome  = rows.reduce((s, r) => s + r.income, 0);
  const totalExpense = rows.reduce((s, r) => s + r.expense, 0);
  const netTotal     = totalIncome - totalExpense;
  const maxBar       = Math.max(...rows.map((r) => Math.max(r.income, r.expense)), 1);

  const years = Array.from({ length: 5 }, (_, i) => today.getFullYear() - 2 + i);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-bold text-gray-900 text-lg">Cash Flow</h3>
          <p className="text-sm text-gray-500 mt-0.5">Monthly income vs. expense overview</p>
        </div>
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Year</label>
          <select value={yearFilter} onChange={(e) => setYearFilter(Number(e.target.value))}
            className="px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400">
            {years.map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
          <div className="flex items-center gap-2">
            {!ratesLoading && lastUpdated && (
              <span className="text-xs text-gray-400 flex items-center gap-1">
                <RefreshCw className="w-3 h-3" />Live rates
              </span>
            )}
            <select value={displayCurrency} onChange={(e) => setDisplayCurrency(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-teal-400 bg-white">
              {SUPPORTED_CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl border border-emerald-100 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="w-4 h-4 text-emerald-500" />
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Total Income</p>
          </div>
          <p className="text-2xl font-bold text-emerald-600">{loading ? '—' : formatCurrency(totalIncome, displayCurrency)}</p>
          <p className="text-xs text-gray-400 mt-1">{yearFilter} full year</p>
        </div>
        <div className="bg-white rounded-2xl border border-rose-100 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-1">
            <TrendingDown className="w-4 h-4 text-rose-500" />
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Total Expense</p>
          </div>
          <p className="text-2xl font-bold text-rose-600">{loading ? '—' : formatCurrency(totalExpense, displayCurrency)}</p>
          <p className="text-xs text-gray-400 mt-1">{yearFilter} full year</p>
        </div>
        <div className={`bg-white rounded-2xl border shadow-sm p-5 ${netTotal >= 0 ? 'border-teal-100' : 'border-orange-100'}`}>
          <div className="flex items-center gap-2 mb-1">
            <Minus className={`w-4 h-4 ${netTotal >= 0 ? 'text-teal-500' : 'text-orange-500'}`} />
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Net Cash Flow</p>
          </div>
          <p className={`text-2xl font-bold ${netTotal >= 0 ? 'text-teal-600' : 'text-orange-600'}`}>{loading ? '—' : formatCurrency(netTotal, displayCurrency)}</p>
          <p className="text-xs text-gray-400 mt-1">{netTotal >= 0 ? 'Surplus' : 'Deficit'}</p>
        </div>
      </div>

      {loading ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-12 flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-teal-500" />
        </div>
      ) : (
        <>
          {/* Bar chart */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-5">Monthly Overview — {yearFilter}</p>
            <div className="flex items-end gap-2 h-36">
              {rows.map((r) => (
                <div key={r.month} className="flex-1 flex flex-col items-center gap-1">
                  <div className="w-full flex items-end gap-0.5 h-28 justify-center">
                    <div className="w-[45%] bg-emerald-200 rounded-t transition-all hover:bg-emerald-300"
                      style={{ height: `${(r.income / maxBar) * 100}%`, minHeight: r.income > 0 ? '3px' : '0' }}
                      title={`Income: ${formatCurrency(r.income, displayCurrency)}`} />
                    <div className="w-[45%] bg-rose-200 rounded-t transition-all hover:bg-rose-300"
                      style={{ height: `${(r.expense / maxBar) * 100}%`, minHeight: r.expense > 0 ? '3px' : '0' }}
                      title={`Expense: ${formatCurrency(r.expense, displayCurrency)}`} />
                  </div>
                  <span className="text-xs text-gray-400">{r.label}</span>
                </div>
              ))}
            </div>
            <div className="flex items-center gap-4 mt-4 justify-center text-xs text-gray-500">
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-emerald-200" />Income</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-rose-200" />Expense</span>
            </div>
          </div>

          {/* Monthly table */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100">
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Month</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold text-emerald-600 uppercase tracking-wide">Income</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold text-rose-600 uppercase tracking-wide">Expense</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wide">Net</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {rows.map((r) => (
                    <tr key={r.month} className={`hover:bg-gray-50/60 transition-colors ${r.income === 0 && r.expense === 0 ? 'opacity-40' : ''}`}>
                      <td className="px-4 py-3 font-medium text-gray-700">{r.label} {r.year}</td>
                      <td className="px-4 py-3 text-right text-emerald-600 font-medium">{r.income > 0 ? formatCurrency(r.income, displayCurrency) : '—'}</td>
                      <td className="px-4 py-3 text-right text-rose-600 font-medium">{r.expense > 0 ? formatCurrency(r.expense, displayCurrency) : '—'}</td>
                      <td className={`px-4 py-3 text-right font-semibold ${r.net > 0 ? 'text-teal-600' : r.net < 0 ? 'text-orange-600' : 'text-gray-400'}`}>
                        {r.income === 0 && r.expense === 0 ? '—' : formatCurrency(r.net, displayCurrency)}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-gray-50 border-t-2 border-gray-200">
                    <td className="px-4 py-3 font-bold text-gray-700">Total {yearFilter}</td>
                    <td className="px-4 py-3 text-right font-bold text-emerald-700">{formatCurrency(totalIncome, displayCurrency)}</td>
                    <td className="px-4 py-3 text-right font-bold text-rose-700">{formatCurrency(totalExpense, displayCurrency)}</td>
                    <td className={`px-4 py-3 text-right font-bold text-base ${netTotal >= 0 ? 'text-teal-700' : 'text-orange-700'}`}>{formatCurrency(netTotal, displayCurrency)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
