import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import {
  Clock, X, Loader2, AlertCircle, CheckCircle2,
  RefreshCw, Info, Users, Download, Edit2, Save, Lock, Unlock, Send,
} from 'lucide-react';

type Project      = { id: string; name: string; project_code?: string | null };
type PostedRecord = { id: string; posted_at: string; posted_by_name: string | null; notes: string | null };
type WorkScheduleDay = { day_of_week: number; normal_hours: number; is_working_day: boolean };
type DayType      = 'present' | 'absent' | 'leave' | 'holiday' | 'rest' | 'overtime';

type TSRow = {
  id:             string | null;
  employee_id:    string;
  employee_code:  string;
  employee_name:  string;
  designation:    string | null;
  trade:          string | null;
  day_type:       DayType;
  start_time:     string;   // "HH:MM" or ""
  end_time:       string;   // "HH:MM" or ""
  break_minutes:  number;
  regular_hours:  number;
  overtime_hours: number;
  notes:          string;
  saving:         boolean;
  saved:          boolean;
  error:          string | null;
};

const DAY_TYPE_TO_ATTENDANCE: Record<DayType, string> = {
  present:  'present',
  overtime: 'present',
  absent:   'leave',
  leave:    'leave',
  holiday:  'public_holiday',
  rest:     'leave',
};

const DAY_META: Record<DayType, { label: string; color: string; bg: string }> = {
  present:  { label: 'Present',        color: 'text-teal-700',   bg: 'bg-teal-50 border-teal-200' },
  absent:   { label: 'Absent',         color: 'text-red-700',    bg: 'bg-red-50 border-red-200' },
  leave:    { label: 'Leave',          color: 'text-gray-600',   bg: 'bg-gray-100 border-gray-200' },
  holiday:  { label: 'Public Holiday', color: 'text-blue-700',   bg: 'bg-blue-50 border-blue-200' },
  rest:     { label: 'Rest Day',       color: 'text-amber-700',  bg: 'bg-amber-50 border-amber-200' },
  overtime: { label: 'Overtime Day',   color: 'text-orange-700', bg: 'bg-orange-50 border-orange-200' },
};

function fmtDate(d: string) {
  const [y, m, day] = d.split('-');
  return `${day}/${m}/${y}`;
}

/** Returns { regular_hours, overtime_hours } calculated from times.
 *  normal_hours is the scheduled working hours for that day (e.g. 8).
 *  If start/end are not set, returns the current manual values unchanged. */
function calcHours(
  start: string, end: string, breakMin: number,
  normalHours: number, currentReg: number, currentOT: number,
): { regular_hours: number; overtime_hours: number } {
  if (!start || !end) return { regular_hours: currentReg, overtime_hours: currentOT };
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  let totalMin = (eh * 60 + em) - (sh * 60 + sm) - breakMin;
  if (totalMin < 0) totalMin += 24 * 60; // overnight shift
  if (totalMin <= 0) return { regular_hours: 0, overtime_hours: 0 };
  const normalMin   = normalHours * 60;
  const regular_hours  = Math.min(totalMin, normalMin) / 60;
  const overtime_hours = Math.max(0, totalMin - normalMin) / 60;
  return {
    regular_hours:  Math.round(regular_hours  * 100) / 100,
    overtime_hours: Math.round(overtime_hours * 100) / 100,
  };
}

function exportCSV(project: Project, date: string, rows: TSRow[]) {
  const header = ['#', 'Code', 'Employee', 'Designation', 'Trade', 'Day Type', 'Start', 'End', 'Break(min)', 'Reg Hrs', 'OT Hrs', 'Notes'];
  const data = rows.map((r, i) => [
    i + 1, r.employee_code,
    `"${r.employee_name.replace(/"/g, '""')}"`,
    r.designation ?? '', r.trade ?? '',
    DAY_META[r.day_type].label,
    r.start_time || '', r.end_time || '', r.break_minutes,
    r.regular_hours.toFixed(2), r.overtime_hours.toFixed(2),
    `"${(r.notes || '').replace(/"/g, '""')}"`,
  ]);
  const blob = new Blob([[header, ...data].map((r) => r.join(',')).join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `timesheet-${project.name.replace(/\s+/g, '-')}-${date}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export function TimesheetPost() {
  const { teamMember, isAdmin } = useAuth();
  const today = new Date().toISOString().split('T')[0];

  const [projects, setProjects]               = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [selectedDate, setSelectedDate]       = useState(today);
  const [rows, setRows]                       = useState<TSRow[]>([]);
  const [loading, setLoading]                 = useState(false);
  const [projectsLoading, setProjectsLoading] = useState(true);
  const [workSchedule, setWorkSchedule]       = useState<WorkScheduleDay[]>([]);
  const [postedRecord, setPostedRecord]       = useState<PostedRecord | null>(null);
  const [posting, setPosting]                 = useState(false);
  const [showBulkModal, setShowBulkModal]     = useState(false);
  const [showPostModal, setShowPostModal]     = useState(false);

  useEffect(() => {
    if (!teamMember || !isAdmin) return;
    Promise.all([
      supabase.from('projects').select('id,name,project_code').order('name'),
      supabase.from('work_schedule').select('day_of_week,normal_hours,is_working_day').order('day_of_week'),
    ]).then(([pr, ws]) => {
      const list = (pr.data ?? []) as Project[];
      setProjects(list);
      if (list[0]) setSelectedProject(list[0]);
      if (ws.data) setWorkSchedule(ws.data as WorkScheduleDay[]);
      setProjectsLoading(false);
    });
  }, [teamMember, isAdmin]);

  const getNormalHours = useCallback((date: string) => {
    const dow      = new Date(date + 'T00:00:00').getDay();
    const schedDay = workSchedule.find((s) => s.day_of_week === dow);
    return schedDay ? (schedDay.is_working_day ? schedDay.normal_hours : 0) : (dow >= 1 && dow <= 5 ? 8 : 0);
  }, [workSchedule]);

  const fetchEntries = useCallback(async () => {
    if (!selectedProject) return;
    setLoading(true);

    const dow           = new Date(selectedDate + 'T00:00:00').getDay();
    const schedDay      = workSchedule.find((s) => s.day_of_week === dow);
    const isWorking     = schedDay ? schedDay.is_working_day : (dow >= 1 && dow <= 5);
    const defaultDayType: DayType = isWorking ? 'present' : 'rest';
    const defaultRegHours         = isWorking ? (schedDay?.normal_hours ?? 8) : 0;

    const [entryRes, postedRes, assignRes] = await Promise.all([
      supabase
        .from('timesheet_entries')
        .select('id,employee_id,day_type,start_time,end_time,break_minutes,regular_hours,overtime_hours,notes')
        .eq('project_id', selectedProject.id)
        .eq('work_date', selectedDate),
      supabase
        .from('timesheet_posted_records')
        .select('id,posted_at,posted_by_name,notes')
        .eq('project_id', selectedProject.id)
        .eq('entry_date', selectedDate)
        .maybeSingle(),
      supabase
        .from('workforce_project_employees')
        .select('employee:workforce_employees(id,employee_code,name,designation,trade)')
        .eq('project_id', selectedProject.id),
    ]);

    setPostedRecord(postedRes.data as PostedRecord | null);

    const assignedEmps = ((assignRes.data ?? []) as any[])
      .map((a) => a.employee)
      .filter(Boolean) as { id: string; employee_code: string; name: string; designation: string | null; trade: string | null }[];
    const empMap = new Map(assignedEmps.map((e) => [e.id, e]));

    const existing: TSRow[] = ((entryRes.data ?? []) as any[])
      .map((d) => {
        const e = empMap.get(d.employee_id);
        if (!e) return null;
        return {
          id:             d.id,
          employee_id:    d.employee_id,
          employee_code:  e.employee_code,
          employee_name:  e.name,
          designation:    e.designation ?? null,
          trade:          e.trade ?? null,
          day_type:       d.day_type as DayType,
          start_time:     d.start_time ? d.start_time.slice(0, 5) : '',
          end_time:       d.end_time   ? d.end_time.slice(0, 5)   : '',
          break_minutes:  d.break_minutes ?? 0,
          regular_hours:  Number(d.regular_hours),
          overtime_hours: Number(d.overtime_hours),
          notes:          d.notes ?? '',
          saving: false, saved: true, error: null,
        } as TSRow;
      })
      .filter(Boolean) as TSRow[];

    const existingIds = new Set(existing.map((r) => r.employee_id));
    const autoRows: TSRow[] = assignedEmps
      .filter((e) => !existingIds.has(e.id))
      .map((e) => ({
        id:             null,
        employee_id:    e.id,
        employee_code:  e.employee_code,
        employee_name:  e.name,
        designation:    e.designation ?? null,
        trade:          e.trade ?? null,
        day_type:       defaultDayType,
        start_time:     '',
        end_time:       '',
        break_minutes:  0,
        regular_hours:  defaultRegHours,
        overtime_hours: 0,
        notes:          '',
        saving: false, saved: false, error: null,
      }));

    setRows(
      [...existing, ...autoRows].sort((a, b) => a.employee_name.localeCompare(b.employee_name))
    );
    setLoading(false);
  }, [selectedProject, selectedDate, workSchedule]);

  useEffect(() => {
    if (!projectsLoading && selectedProject) fetchEntries();
  }, [projectsLoading, selectedProject, selectedDate, fetchEntries]);

  const isPosted = !!postedRecord;
  const canEdit  = !isPosted;
  const normalHours = getNormalHours(selectedDate);

  const updateRow = (idx: number, fields: Partial<TSRow>) =>
    setRows((prev) => prev.map((r, i) => (i === idx ? { ...r, ...fields, saved: false } : r)));

  const updateTimeField = (idx: number, field: 'start_time' | 'end_time' | 'break_minutes', value: string | number) => {
    setRows((prev) => prev.map((r, i) => {
      if (i !== idx) return r;
      const updated = { ...r, [field]: value, saved: false };
      const start  = field === 'start_time'    ? (value as string) : r.start_time;
      const end    = field === 'end_time'      ? (value as string) : r.end_time;
      const brk    = field === 'break_minutes' ? (value as number) : r.break_minutes;
      const { regular_hours, overtime_hours } = calcHours(start, end, brk, normalHours, updated.regular_hours, updated.overtime_hours);
      return { ...updated, regular_hours, overtime_hours };
    }));
  };

  const saveRow = async (idx: number) => {
    const row = rows[idx];
    if (!row || row.saving || (row.saved && row.id !== null)) return;
    updateRow(idx, { saving: true, error: null });

    const payload = {
      project_id:     selectedProject!.id,
      employee_id:    row.employee_id,
      work_date:      selectedDate,
      day_type:       row.day_type,
      start_time:     row.start_time || null,
      end_time:       row.end_time   || null,
      break_minutes:  row.break_minutes,
      regular_hours:  row.regular_hours,
      overtime_hours: row.overtime_hours,
      notes:          row.notes || null,
    };

    if (row.id) {
      const { error } = await supabase.from('timesheet_entries').update(payload).eq('id', row.id);
      if (error) { updateRow(idx, { saving: false, error: error.message }); return; }
    } else {
      const { data, error } = await supabase
        .from('timesheet_entries')
        .upsert(payload, { onConflict: 'employee_id,work_date' })
        .select('id')
        .single();
      if (error) { updateRow(idx, { saving: false, error: error.message }); return; }
      if (data) setRows((prev) => prev.map((r, i) => (i === idx ? { ...r, id: data.id } : r)));
    }
    setRows((prev) => prev.map((r, i) => (i === idx ? { ...r, saving: false, saved: true } : r)));
  };

  const handleFieldBlur = (idx: number) => {
    const row = rows[idx];
    if (row && !row.saved) saveRow(idx);
  };

  const removeRow = async (idx: number) => {
    const row = rows[idx];
    if (row.id) await supabase.from('timesheet_entries').delete().eq('id', row.id);
    setRows((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleBulkApply = async (dayType: DayType, startTime: string, endTime: string, breakMin: number) => {
    setShowBulkModal(false);
    const updated = rows.map((r) => {
      const { regular_hours, overtime_hours } = calcHours(startTime, endTime, breakMin, normalHours, r.regular_hours, r.overtime_hours);
      return {
        ...r, day_type: dayType,
        start_time: startTime, end_time: endTime, break_minutes: breakMin,
        regular_hours, overtime_hours,
        saved: false, saving: true,
      };
    });
    setRows(updated);

    const results = await Promise.all(
      updated.map(async (row, idx) => {
        const payload = {
          project_id: selectedProject!.id, employee_id: row.employee_id,
          work_date: selectedDate, day_type: row.day_type,
          start_time: row.start_time || null, end_time: row.end_time || null,
          break_minutes: row.break_minutes,
          regular_hours: row.regular_hours, overtime_hours: row.overtime_hours,
          notes: row.notes || null,
        };
        let newId = row.id;
        if (row.id) {
          await supabase.from('timesheet_entries').update(payload).eq('id', row.id);
        } else {
          const { data } = await supabase.from('timesheet_entries')
            .upsert(payload, { onConflict: 'employee_id,work_date' }).select('id').single();
          if (data) newId = data.id;
        }
        return { idx, newId };
      })
    );
    setRows((prev) => prev.map((r, i) => {
      const res = results.find((x) => x.idx === i);
      return res ? { ...r, id: res.newId, saving: false, saved: true } : r;
    }));
  };

  const handlePost = async (postNotes: string) => {
    if (!selectedProject || posting) return;
    setPosting(true);

    // 1. Save all unsaved timesheet rows
    await Promise.all(rows.map((r, idx) => (!r.saved || r.id === null) ? saveRow(idx) : Promise.resolve()));

    // 2. Mark approved in timesheet_entries
    await supabase
      .from('timesheet_entries')
      .update({ approved_by: teamMember!.id, approved_at: new Date().toISOString() })
      .eq('project_id', selectedProject.id)
      .eq('work_date', selectedDate);

    // 3. Sync to workforce_daily_allocations so Daily Allocation & Reports reflect this data
    const syncPayloads = rows.map((r) => ({
      project_id:        selectedProject.id,
      employee_id:       r.employee_id,
      entry_date:        selectedDate,
      attendance_status: DAY_TYPE_TO_ATTENDANCE[r.day_type],
      start_time:        r.start_time || null,
      end_time:          r.end_time   || null,
      break_minutes:     r.break_minutes,
      notes:             r.notes || null,
      updated_by:        teamMember!.id,
    }));
    await supabase
      .from('workforce_daily_allocations')
      .upsert(syncPayloads, { onConflict: 'project_id,employee_id,entry_date' });

    // 4. Mark as posted in posted_allocations so Daily Allocation shows "Posted" status
    await supabase
      .from('posted_allocations')
      .upsert(
        { project_id: selectedProject.id, entry_date: selectedDate, posted_by: teamMember!.id, posted_by_name: teamMember!.name, notes: postNotes || null },
        { onConflict: 'project_id,entry_date', ignoreDuplicates: false }
      );

    // 5. Create posted record in timesheet_posted_records
    const { data } = await supabase
      .from('timesheet_posted_records')
      .insert({ project_id: selectedProject.id, entry_date: selectedDate, posted_by: teamMember!.id, posted_by_name: teamMember!.name, notes: postNotes || null })
      .select('id,posted_at,posted_by_name,notes')
      .single();
    if (data) setPostedRecord(data as PostedRecord);

    setPosting(false);
    setShowPostModal(false);
  };

  const handleUnpost = async () => {
    if (!selectedProject || !postedRecord) return;
    setPosting(true);
    await Promise.all([
      supabase.from('timesheet_entries')
        .update({ approved_by: null, approved_at: null })
        .eq('project_id', selectedProject.id).eq('work_date', selectedDate),
      supabase.from('timesheet_posted_records').delete().eq('id', postedRecord.id),
      // Also remove the posted_allocations entry so Daily Allocation shows "Not Posted" again
      supabase.from('posted_allocations')
        .delete()
        .eq('project_id', selectedProject.id)
        .eq('entry_date', selectedDate),
    ]);
    setPostedRecord(null);
    setPosting(false);
  };

  const presentCount  = rows.filter((r) => r.day_type === 'present' || r.day_type === 'overtime').length;
  const leaveCount    = rows.filter((r) => r.day_type !== 'present' && r.day_type !== 'overtime').length;
  const totalRegHours = rows.reduce((s, r) => s + r.regular_hours, 0);
  const totalOTHours  = rows.reduce((s, r) => s + r.overtime_hours, 0);
  const unsavedCount  = rows.filter((r) => !r.saved && !r.saving).length;

  const scheduleDay = workSchedule.find((s) => s.day_of_week === new Date(selectedDate + 'T00:00:00').getDay());

  if (!isAdmin) return (
    <div className="bg-white rounded-2xl border border-gray-100 p-14 text-center">
      <AlertCircle className="w-10 h-10 text-gray-300 mx-auto mb-3" />
      <p className="text-gray-500">Access restricted to administrators.</p>
    </div>
  );

  if (projectsLoading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-7 h-7 animate-spin text-teal-500" />
    </div>
  );

  if (projects.length === 0) return (
    <div className="bg-white rounded-2xl border border-gray-100 p-14 text-center">
      <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
      <p className="font-semibold text-gray-600">No projects found</p>
    </div>
  );

  const timeCls = 'w-full px-2 py-1.5 border border-gray-200 rounded-lg text-xs text-center focus:outline-none focus:ring-1 focus:ring-teal-400 disabled:bg-gray-50 disabled:text-gray-300 disabled:cursor-not-allowed';
  const numCls  = 'w-full px-2 py-1.5 border border-gray-200 rounded-lg text-sm text-center focus:outline-none focus:ring-1 focus:ring-teal-400 disabled:bg-gray-50 disabled:text-gray-300 disabled:cursor-not-allowed';

  return (
    <div className="space-y-4">

      {/* ── Header ──────────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-bold text-gray-900 text-lg">Post Time Sheet</h3>
          <p className="text-sm text-gray-500 mt-0.5">
            {presentCount} present
            {leaveCount > 0 && <span className="text-amber-600"> · {leaveCount} on leave</span>}
            {' · '}
            <span className="text-teal-600 font-medium">{totalRegHours.toFixed(2)}h reg</span>
            {totalOTHours > 0 && <span className="text-orange-600 font-medium"> + {totalOTHours.toFixed(2)}h OT</span>}
            {scheduleDay && (
              <span className="text-gray-400 ml-1">
                ({scheduleDay.is_working_day ? `${scheduleDay.normal_hours}h normal` : 'Rest day'})
              </span>
            )}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {rows.length > 0 && selectedProject && (
            <button
              onClick={() => exportCSV(selectedProject, selectedDate, rows)}
              className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 text-gray-600 font-medium rounded-xl text-sm hover:border-teal-300 hover:text-teal-600 transition-all"
            >
              <Download className="w-4 h-4" />Export
            </button>
          )}
          {canEdit && rows.length > 0 && (
            <button
              onClick={() => setShowBulkModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-white border-2 border-teal-400 text-teal-700 font-medium rounded-xl text-sm hover:bg-teal-50 transition-all"
            >
              <Edit2 className="w-4 h-4" />Set Hours for All
            </button>
          )}
          {canEdit && rows.length > 0 && (
            <button
              onClick={() => setShowPostModal(true)}
              disabled={posting}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-semibold rounded-xl text-sm shadow-sm hover:from-emerald-600 hover:to-teal-700 disabled:opacity-60 transition-all"
            >
              {posting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              Save &amp; Post
            </button>
          )}
          {isPosted && (
            <button
              onClick={handleUnpost}
              disabled={posting}
              className="flex items-center gap-2 px-4 py-2 bg-white border-2 border-amber-400 text-amber-700 font-semibold rounded-xl text-sm hover:bg-amber-50 disabled:opacity-60 transition-all"
            >
              {posting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Unlock className="w-4 h-4" />}
              Unpost
            </button>
          )}
        </div>
      </div>

      {/* ── Posted banner ────────────────────────────────────────────────── */}
      {isPosted && postedRecord && (
        <div className="flex items-center gap-3 px-4 py-3 bg-emerald-50 border border-emerald-200 rounded-xl text-sm text-emerald-800">
          <Lock className="w-4 h-4 flex-shrink-0 text-emerald-600" />
          <div className="flex-1">
            <span className="font-semibold">Posted</span>
            {' — '}posted by <span className="font-medium">{postedRecord.posted_by_name ?? 'Admin'}</span>
            {' on '}<span className="font-medium">{new Date(postedRecord.posted_at).toLocaleString()}</span>
            {postedRecord.notes && <span className="text-emerald-700 ml-2">· {postedRecord.notes}</span>}
          </div>
          <span className="text-xs text-emerald-600 font-medium">Editing locked · Unpost to make changes</span>
        </div>
      )}

      {/* ── Controls bar ─────────────────────────────────────────────────── */}
      <div className="bg-white border border-gray-200 rounded-2xl p-4">
        <div className="flex flex-wrap gap-4 items-end">
          <div className="flex-1 min-w-[200px]">
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Project</label>
            <select
              value={selectedProject?.id ?? ''}
              onChange={(e) => setSelectedProject(projects.find((p) => p.id === e.target.value) ?? null)}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400"
            >
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.project_code ? `[${p.project_code}] ` : ''}{p.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Date</label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
            />
          </div>
          <button
            onClick={fetchEntries}
            className="flex items-center gap-1.5 px-3 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:border-teal-300 hover:text-teal-600 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />Refresh
          </button>
        </div>
      </div>

      {/* ── Unsaved indicator ────────────────────────────────────────────── */}
      {unsavedCount > 0 && (
        <div className="flex items-center gap-3 px-4 py-2.5 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800">
          <Info className="w-4 h-4 flex-shrink-0" />
          {unsavedCount} unsaved row{unsavedCount > 1 ? 's' : ''} — changes save automatically when you leave a field.
        </div>
      )}

      {/* ── Employee table ───────────────────────────────────────────────── */}
      {loading ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-12 flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-teal-500" />
        </div>
      ) : rows.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-14 text-center">
          <Clock className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="font-semibold text-gray-600">No employees assigned</p>
          <p className="text-sm text-gray-400 mt-1">Assign employees via Timesheets → Project Assignments first.</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[1100px]">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  <th className="px-3 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide w-8">#</th>
                  <th className="px-3 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Employee</th>
                  <th className="px-3 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide w-36">Day Type</th>
                  <th className="px-3 py-3 text-center text-xs font-semibold text-gray-500 uppercase tracking-wide w-24">Start</th>
                  <th className="px-3 py-3 text-center text-xs font-semibold text-gray-500 uppercase tracking-wide w-24">End</th>
                  <th className="px-3 py-3 text-center text-xs font-semibold text-gray-500 uppercase tracking-wide w-20">Break<br/><span className="normal-case font-normal">(min)</span></th>
                  <th className="px-3 py-3 text-center text-xs font-semibold text-teal-600 uppercase tracking-wide w-24">Reg Hrs</th>
                  <th className="px-3 py-3 text-center text-xs font-semibold text-orange-500 uppercase tracking-wide w-24">OT Hrs</th>
                  <th className="px-3 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Notes</th>
                  <th className="px-3 py-3 text-center w-10"></th>
                  {!isPosted && <th className="px-3 py-3 w-10" />}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {rows.map((row, idx) => {
                  const isPresent = row.day_type === 'present' || row.day_type === 'overtime';
                  const meta = DAY_META[row.day_type];
                  return (
                    <tr
                      key={row.employee_id}
                      className={`${!row.saved ? 'bg-amber-50/20' : ''} ${!isPresent ? 'opacity-75' : ''} hover:bg-gray-50/50 transition-colors`}
                    >
                      <td className="px-3 py-2.5 text-gray-400 text-xs font-medium">{idx + 1}</td>
                      <td className="px-3 py-2.5">
                        <p className="font-semibold text-gray-900">{row.employee_name}</p>
                        <p className="text-xs text-gray-400">
                          {row.employee_code}
                          {row.designation ? ` · ${row.designation}` : ''}
                          {row.trade ? ` · ${row.trade}` : ''}
                        </p>
                      </td>
                      <td className="px-2 py-2.5">
                        {canEdit ? (
                          <select
                            value={row.day_type}
                            onChange={(e) => {
                              updateRow(idx, { day_type: e.target.value as DayType });
                              setTimeout(() => handleFieldBlur(idx), 0);
                            }}
                            className={`w-full px-2 py-1.5 border rounded-lg text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-teal-400 ${meta.bg} ${meta.color}`}
                          >
                            {(Object.entries(DAY_META) as [DayType, typeof DAY_META[DayType]][]).map(([k, v]) => (
                              <option key={k} value={k}>{v.label}</option>
                            ))}
                          </select>
                        ) : (
                          <span className={`inline-flex items-center px-2 py-1 rounded-lg text-xs font-semibold border ${meta.bg} ${meta.color}`}>
                            {meta.label}
                          </span>
                        )}
                      </td>
                      {/* Start Time */}
                      <td className="px-2 py-2.5">
                        <input
                          type="time"
                          value={row.start_time}
                          disabled={!canEdit}
                          onChange={(e) => updateTimeField(idx, 'start_time', e.target.value)}
                          onBlur={() => handleFieldBlur(idx)}
                          className={timeCls}
                        />
                      </td>
                      {/* End Time */}
                      <td className="px-2 py-2.5">
                        <input
                          type="time"
                          value={row.end_time}
                          disabled={!canEdit}
                          onChange={(e) => updateTimeField(idx, 'end_time', e.target.value)}
                          onBlur={() => handleFieldBlur(idx)}
                          className={timeCls}
                        />
                      </td>
                      {/* Break (min) */}
                      <td className="px-2 py-2.5">
                        <input
                          type="number" min="0" max="480" step="5"
                          value={row.break_minutes === 0 ? '' : row.break_minutes}
                          disabled={!canEdit}
                          onChange={(e) => updateTimeField(idx, 'break_minutes', parseInt(e.target.value) || 0)}
                          onBlur={() => handleFieldBlur(idx)}
                          placeholder="0"
                          className={numCls}
                        />
                      </td>
                      {/* Reg Hrs (auto or manual) */}
                      <td className="px-2 py-2.5">
                        <input
                          type="number" min="0" max="24" step="0.25"
                          value={row.regular_hours === 0 ? '' : row.regular_hours}
                          disabled={!canEdit}
                          onChange={(e) => updateRow(idx, { regular_hours: parseFloat(e.target.value) || 0 })}
                          onBlur={() => handleFieldBlur(idx)}
                          placeholder="0"
                          className={`${numCls} ${row.start_time && row.end_time ? 'bg-teal-50 text-teal-700 font-semibold' : ''}`}
                        />
                      </td>
                      {/* OT Hrs (auto or manual) */}
                      <td className="px-2 py-2.5">
                        <input
                          type="number" min="0" max="24" step="0.25"
                          value={row.overtime_hours === 0 ? '' : row.overtime_hours}
                          disabled={!canEdit}
                          onChange={(e) => updateRow(idx, { overtime_hours: parseFloat(e.target.value) || 0 })}
                          onBlur={() => handleFieldBlur(idx)}
                          placeholder="0"
                          className={`${numCls} ${row.start_time && row.end_time && row.overtime_hours > 0 ? 'bg-orange-50 text-orange-700 font-semibold' : ''}`}
                        />
                      </td>
                      {/* Notes */}
                      <td className="px-2 py-2.5">
                        <input
                          type="text"
                          value={row.notes}
                          disabled={!canEdit}
                          onChange={(e) => updateRow(idx, { notes: e.target.value })}
                          onBlur={() => handleFieldBlur(idx)}
                          placeholder="Optional notes…"
                          className="w-full px-2 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-teal-400 disabled:bg-gray-50 disabled:text-gray-400 disabled:cursor-not-allowed"
                        />
                      </td>
                      {/* Status icon */}
                      <td className="px-3 py-2.5 text-center">
                        {row.saving ? (
                          <Loader2 className="w-4 h-4 animate-spin text-teal-500 mx-auto" />
                        ) : row.error ? (
                          <span title={row.error}>
                            <AlertCircle className="w-4 h-4 text-red-500 mx-auto cursor-help" />
                          </span>
                        ) : row.saved && row.id ? (
                          <CheckCircle2 className="w-4 h-4 text-green-500 mx-auto" />
                        ) : (
                          <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" title="Unsaved" />
                        )}
                      </td>
                      {!isPosted && (
                        <td className="px-2 py-2.5 text-center">
                          <button
                            onClick={() => removeRow(idx)}
                            className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                            title="Remove"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
              {rows.length > 0 && (
                <tfoot>
                  <tr className="bg-gradient-to-r from-teal-50 to-blue-50 border-t-2 border-teal-100">
                    <td colSpan={6} className="px-4 py-3 text-right text-xs font-bold text-teal-700 uppercase tracking-wide">
                      Totals — {presentCount} present{leaveCount > 0 ? `, ${leaveCount} on leave` : ''}
                    </td>
                    <td className="px-3 py-3 text-center">
                      <span className="font-bold text-base text-teal-800">{totalRegHours.toFixed(2)}</span>
                    </td>
                    <td className="px-3 py-3 text-center">
                      {totalOTHours > 0
                        ? <span className="font-bold text-base text-orange-700">{totalOTHours.toFixed(2)}</span>
                        : <span className="text-gray-300">—</span>}
                    </td>
                    <td colSpan={!isPosted ? 3 : 2} />
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>
      )}

      {showBulkModal && selectedProject && (
        <BulkHoursModal
          projectName={selectedProject.name}
          employeeCount={rows.length}
          normalHours={normalHours}
          defaultDayType={rows[0]?.day_type ?? 'present'}
          defaultStart={rows[0]?.start_time ?? ''}
          defaultEnd={rows[0]?.end_time ?? ''}
          defaultBreak={rows[0]?.break_minutes ?? 0}
          onClose={() => setShowBulkModal(false)}
          onApply={handleBulkApply}
        />
      )}

      {showPostModal && selectedProject && (
        <PostTimesheetModal
          projectName={selectedProject.name}
          date={selectedDate}
          presentCount={presentCount}
          leaveCount={leaveCount}
          totalRegHours={totalRegHours}
          totalOTHours={totalOTHours}
          unsavedCount={unsavedCount}
          posting={posting}
          onClose={() => setShowPostModal(false)}
          onPost={handlePost}
        />
      )}
    </div>
  );
}

/* ── Bulk Hours Modal ────────────────────────────────────────────────────── */
function BulkHoursModal({
  projectName, employeeCount, normalHours,
  defaultDayType, defaultStart, defaultEnd, defaultBreak,
  onClose, onApply,
}: {
  projectName: string;
  employeeCount: number;
  normalHours: number;
  defaultDayType: DayType;
  defaultStart: string;
  defaultEnd: string;
  defaultBreak: number;
  onClose: () => void;
  onApply: (dayType: DayType, startTime: string, endTime: string, breakMin: number) => void;
}) {
  const [dayType,   setDayType]   = useState<DayType>(defaultDayType);
  const [startTime, setStartTime] = useState(defaultStart);
  const [endTime,   setEndTime]   = useState(defaultEnd);
  const [breakMin,  setBreakMin]  = useState(defaultBreak);

  const preview = calcHours(startTime, endTime, breakMin, normalHours, 0, 0);
  const hasPreview = startTime && endTime;

  const inp = 'w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400';
  const lbl = 'block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5';

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-teal-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
              <Edit2 className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Set Hours for All Employees</h3>
              <p className="text-xs text-gray-500 mt-0.5">{projectName} · {employeeCount} employee{employeeCount !== 1 ? 's' : ''}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 flex items-start gap-2">
            <Info className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
            This will overwrite the schedule for all {employeeCount} employee{employeeCount !== 1 ? 's' : ''}.
          </div>

          <div>
            <label className={lbl}>Day Type</label>
            <select
              value={dayType}
              onChange={(e) => setDayType(e.target.value as DayType)}
              className={`${inp} font-semibold ${DAY_META[dayType].bg} ${DAY_META[dayType].color}`}
            >
              {(Object.entries(DAY_META) as [DayType, typeof DAY_META[DayType]][]).map(([k, v]) => (
                <option key={k} value={k}>{v.label}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={lbl}>Start Time</label>
              <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} className={inp} />
            </div>
            <div>
              <label className={lbl}>End Time</label>
              <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} className={inp} />
            </div>
          </div>

          <div>
            <label className={lbl}>Break <span className="font-normal normal-case">(minutes)</span></label>
            <input type="number" min="0" max="480" step="5" value={breakMin || ''} onChange={(e) => setBreakMin(parseInt(e.target.value) || 0)} placeholder="0" className={inp} />
          </div>

          {hasPreview && (
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-teal-50 border border-teal-100 rounded-xl px-3 py-2.5 text-center">
                <p className="text-xs text-teal-600 font-medium uppercase">Reg Hrs</p>
                <p className="text-xl font-bold text-teal-800 mt-0.5">{preview.regular_hours.toFixed(2)}</p>
              </div>
              <div className="bg-orange-50 border border-orange-100 rounded-xl px-3 py-2.5 text-center">
                <p className="text-xs text-orange-600 font-medium uppercase">OT Hrs</p>
                <p className="text-xl font-bold text-orange-800 mt-0.5">{preview.overtime_hours.toFixed(2)}</p>
              </div>
            </div>
          )}

          <div className="flex items-center gap-3 pt-1">
            <button
              onClick={() => onApply(dayType, startTime, endTime, breakMin)}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm hover:from-teal-600 hover:to-blue-700 transition-all"
            >
              <Save className="w-4 h-4" />Apply to All {employeeCount} Employees
            </button>
            <button onClick={onClose} className="px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Post Timesheet Modal ────────────────────────────────────────────────── */
function PostTimesheetModal({
  projectName, date, presentCount, leaveCount,
  totalRegHours, totalOTHours, unsavedCount, posting, onClose, onPost,
}: {
  projectName: string;
  date: string;
  presentCount: number;
  leaveCount: number;
  totalRegHours: number;
  totalOTHours: number;
  unsavedCount: number;
  posting: boolean;
  onClose: () => void;
  onPost: (notes: string) => void;
}) {
  const [notes, setNotes] = useState('');

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center flex-shrink-0">
              <Send className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Save &amp; Post Time Sheet</h3>
              <p className="text-xs text-gray-500 mt-0.5">{projectName} · {fmtDate(date)}</p>
            </div>
          </div>
          <button onClick={onClose} disabled={posting} className="p-2 rounded-lg hover:bg-gray-100 disabled:opacity-50">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-teal-50 border border-teal-100 rounded-xl px-4 py-3">
              <p className="text-xs text-teal-600 font-medium uppercase tracking-wide">Present</p>
              <p className="text-2xl font-bold text-teal-800 mt-0.5">{presentCount}</p>
            </div>
            <div className="bg-gray-50 border border-gray-100 rounded-xl px-4 py-3">
              <p className="text-xs text-gray-500 font-medium uppercase tracking-wide">On Leave</p>
              <p className="text-2xl font-bold text-gray-700 mt-0.5">{leaveCount}</p>
            </div>
            <div className="bg-blue-50 border border-blue-100 rounded-xl px-4 py-3">
              <p className="text-xs text-blue-600 font-medium uppercase tracking-wide">Regular Hours</p>
              <p className="text-2xl font-bold text-blue-800 mt-0.5">{totalRegHours.toFixed(2)}<span className="text-sm font-normal ml-1">h</span></p>
            </div>
            <div className="bg-orange-50 border border-orange-100 rounded-xl px-4 py-3">
              <p className="text-xs text-orange-600 font-medium uppercase tracking-wide">Overtime Hours</p>
              <p className="text-2xl font-bold text-orange-800 mt-0.5">{totalOTHours.toFixed(2)}<span className="text-sm font-normal ml-1">h</span></p>
            </div>
          </div>

          {unsavedCount > 0 && (
            <div className="flex items-start gap-2 text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2.5">
              <Info className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
              {unsavedCount} unsaved row{unsavedCount > 1 ? 's' : ''} will be saved automatically before posting.
            </div>
          )}

          <div className="flex items-start gap-2 text-xs text-blue-800 bg-blue-50 border border-blue-200 rounded-xl px-3 py-2.5">
            <Lock className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
            Posting locks this timesheet. Editing will be disabled until an admin unposts it.
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
              Post Notes <span className="text-gray-300 font-normal normal-case">(optional)</span>
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Any remarks for this posting…"
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400 resize-none"
            />
          </div>

          <div className="flex items-center gap-3 pt-1">
            <button
              onClick={() => onPost(notes)}
              disabled={posting}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-semibold rounded-xl text-sm disabled:opacity-50 hover:from-emerald-600 hover:to-teal-700 transition-all"
            >
              {posting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              Confirm &amp; Post
            </button>
            <button onClick={onClose} disabled={posting} className="px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-100 rounded-xl transition-colors disabled:opacity-50">
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
