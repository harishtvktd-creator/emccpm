import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { NewMRForm } from './MaterialRequisitions';
import {
  ShoppingCart, Search, Download, ChevronDown, ChevronUp, ArrowUpDown,
  RefreshCw, Package, Clock, TrendingUp, CheckCircle2, AlertCircle, X, Trash2,
  Truck, Radio, Loader2, Phone, User, MapPin, Plus, CalendarClock, Paperclip,
} from 'lucide-react';

type MRStatus = 'draft' | 'created' | 'assigned' | 'in_progress' | 'po_released' | 'closed';
type DeliveryStatus = 'assigned' | 'in_transit' | 'delivered';
type DashTab = 'requisitions' | 'delivery';

type MRLineItem = {
  description: string;
  specification?: string;
  proposed_make?: string;
  country_of_origin?: string;
  quantity: number;
  unit: string;
};

type MRAttachment = { name: string; url: string; size: number };

type MR = {
  id: string;
  requisition_number: string;
  title: string;
  purpose: string | null;
  required_delivery_date: string | null;
  attachments: MRAttachment[];
  items: MRLineItem[];
  status: MRStatus;
  project_id: string | null;
  assigned_to: string | null;
  notes: string | null;
  task_id: string | null;
  po_number: string | null;
  po_vendor: string | null;
  po_date: string | null;
  po_amount: number | null;
  po_vendor_contact_name: string | null;
  po_vendor_contact_number: string | null;
  po_vendor_location: string | null;
  delivery_status: DeliveryStatus | null;
  material_coordinator_id: string | null;
  transit_remarks: string | null;
  delivery_date: string | null;
  delivery_remarks: string | null;
  delivery_updated_at: string | null;
  created_at: string;
  updated_at: string;
  projects?: { name: string } | null;
  creator?: { name: string } | null;
  coordinator?: { name: string } | null;
};

const STATUS_META: Record<MRStatus, { label: string; color: string; bg: string; dot: string }> = {
  draft:       { label: 'Draft',       color: 'text-gray-500',  bg: 'bg-gray-100',   dot: 'bg-gray-300' },
  created:     { label: 'Created',     color: 'text-gray-700',  bg: 'bg-gray-100',   dot: 'bg-gray-400' },
  assigned:    { label: 'RFQ Stage',   color: 'text-blue-700',  bg: 'bg-blue-100',   dot: 'bg-blue-500' },
  in_progress: { label: 'PM Approval', color: 'text-amber-700', bg: 'bg-amber-100',  dot: 'bg-amber-500' },
  po_released: { label: 'PO Released', color: 'text-teal-700',  bg: 'bg-teal-100',   dot: 'bg-teal-500' },
  closed:      { label: 'Closed',      color: 'text-green-700', bg: 'bg-green-100',  dot: 'bg-green-500' },
};

const DELIVERY_META: Record<DeliveryStatus, { label: string; color: string; bg: string; dot: string }> = {
  assigned:   { label: 'Assigned',   color: 'text-blue-700',  bg: 'bg-blue-100',   dot: 'bg-blue-500' },
  in_transit: { label: 'In Transit', color: 'text-amber-700', bg: 'bg-amber-100',  dot: 'bg-amber-500' },
  delivered:  { label: 'Delivered',  color: 'text-green-700', bg: 'bg-green-100',  dot: 'bg-green-500' },
};

function fmtDate(d: string) {
  const [y, m, day] = d.split('T')[0].split('-');
  return `${day}/${m}/${y}`;
}

type SortKey = 'created_at' | 'requisition_number' | 'status' | 'project' | 'creator';

const STATUS_ORDER: Record<MRStatus, number> = { draft: -1, created: 0, assigned: 1, in_progress: 2, po_released: 3, closed: 4 };

export function ProcurementDashboard() {
  const { isAdmin, teamMember } = useAuth();
  const [activeTab, setActiveTab] = useState<DashTab>('requisitions');
  const [mrs, setMrs] = useState<MR[]>([]);
  const [loading, setLoading] = useState(true);
  const [liveIndicator, setLiveIndicator] = useState(false);

  // New MR form (admin only)
  const [showNewMR, setShowNewMR] = useState(false);
  const [mrProjects, setMrProjects] = useState<{ id: string; name: string }[]>([]);

  // MR tab state
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<MRStatus | 'all'>('all');
  const [filterProject, setFilterProject] = useState('all');
  const [filterCreator, setFilterCreator] = useState('all');
  const [sortKey, setSortKey] = useState<SortKey>('created_at');
  const [sortAsc, setSortAsc] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Delivery tab state
  const [deliverySearch, setDeliverySearch] = useState('');
  const [deliveryFilter, setDeliveryFilter] = useState<DeliveryStatus | 'all'>('all');
  const [adminDeliverMR, setAdminDeliverMR] = useState<MR | null>(null);
  const [transitMR, setTransitMR] = useState<MR | null>(null);

  const fetchMRs = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('material_requisitions')
      .select('*, projects(name), creator:team_members!created_by(name), coordinator:team_members!material_coordinator_id(name)')
      .order('created_at', { ascending: false });
    setMrs((data as MR[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchMRs();
    supabase.from('projects').select('id,name').order('name').then(({ data }) => setMrProjects(data ?? []));
  }, [fetchMRs]);

  // Realtime subscription for delivery status updates
  useEffect(() => {
    const channel = supabase
      .channel('procurement-dashboard-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'material_requisitions' }, () => {
        setLiveIndicator(true);
        fetchMRs();
        setTimeout(() => setLiveIndicator(false), 2000);
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [fetchMRs]);

  const handleDeleteMR = async (mr: MR) => {
    if (!confirm(`Delete ${mr.requisition_number}?\n\n"${mr.title}"\n\nThis cannot be undone. The MR number will be reused for the next requisition.`)) return;
    if (mr.task_id) await supabase.from('tasks').delete().eq('id', mr.task_id);
    await supabase.from('material_requisitions').delete().eq('id', mr.id);
    if (expandedId === mr.id) setExpandedId(null);
    fetchMRs();
  };

  // Derived options
  const projects = Array.from(
    new Map(mrs.filter((m) => m.projects).map((m) => [(m.projects as { name: string }).name, (m.projects as { name: string }).name])).values()
  );
  const creators = Array.from(
    new Map(mrs.filter((m) => m.creator).map((m) => [(m.creator as { name: string }).name, (m.creator as { name: string }).name])).values()
  );

  // Summary counts
  const counts = {
    total:       mrs.length,
    draft:       mrs.filter((m) => m.status === 'draft').length,
    created:     mrs.filter((m) => m.status === 'created').length,
    assigned:    mrs.filter((m) => m.status === 'assigned').length,
    in_progress: mrs.filter((m) => m.status === 'in_progress').length,
    po_released: mrs.filter((m) => m.status === 'po_released').length,
    closed:      mrs.filter((m) => m.status === 'closed').length,
    open:        mrs.filter((m) => m.status !== 'closed' && m.status !== 'draft').length,
  };

  const deliveryCounts = {
    total:      mrs.filter((m) => m.delivery_status !== null).length,
    assigned:   mrs.filter((m) => m.delivery_status === 'assigned').length,
    in_transit: mrs.filter((m) => m.delivery_status === 'in_transit').length,
    delivered:  mrs.filter((m) => m.delivery_status === 'delivered').length,
  };

  // Project summary
  const projectSummary = mrs.reduce((acc, mr) => {
    const proj = (mr.projects as { name: string } | null)?.name ?? '(No Project)';
    if (!acc[proj]) acc[proj] = { total: 0, open: 0, closed: 0, po_value: 0 };
    acc[proj].total++;
    if (mr.status === 'closed') acc[proj].closed++; else acc[proj].open++;
    if (mr.po_amount) acc[proj].po_value += mr.po_amount;
    return acc;
  }, {} as Record<string, { total: number; open: number; closed: number; po_value: number }>);

  // MR filtering + sorting
  const filtered = mrs
    .filter((m) => filterStatus === 'all' || m.status === filterStatus)
    .filter((m) => filterProject === 'all' || (m.projects as { name: string } | null)?.name === filterProject)
    .filter((m) => filterCreator === 'all' || (m.creator as { name: string } | null)?.name === filterCreator)
    .filter((m) => {
      if (!search) return true;
      const q = search.toLowerCase();
      return (
        m.requisition_number.toLowerCase().includes(q) ||
        m.title.toLowerCase().includes(q) ||
        (m.po_number ?? '').toLowerCase().includes(q) ||
        (m.po_vendor ?? '').toLowerCase().includes(q) ||
        ((m.creator as { name: string } | null)?.name ?? '').toLowerCase().includes(q) ||
        ((m.projects as { name: string } | null)?.name ?? '').toLowerCase().includes(q)
      );
    })
    .sort((a, b) => {
      let cmp = 0;
      if (sortKey === 'created_at') cmp = a.created_at.localeCompare(b.created_at);
      else if (sortKey === 'requisition_number') cmp = a.requisition_number.localeCompare(b.requisition_number);
      else if (sortKey === 'status') cmp = STATUS_ORDER[a.status] - STATUS_ORDER[b.status];
      else if (sortKey === 'project') cmp = ((a.projects as { name: string } | null)?.name ?? '').localeCompare((b.projects as { name: string } | null)?.name ?? '');
      else if (sortKey === 'creator') cmp = ((a.creator as { name: string } | null)?.name ?? '').localeCompare((b.creator as { name: string } | null)?.name ?? '');
      return sortAsc ? cmp : -cmp;
    });

  // Delivery tracking list
  const deliveryMRs = mrs
    .filter((m) => m.delivery_status !== null)
    .filter((m) => deliveryFilter === 'all' || m.delivery_status === deliveryFilter)
    .filter((m) => {
      if (!deliverySearch) return true;
      const q = deliverySearch.toLowerCase();
      return (
        m.requisition_number.toLowerCase().includes(q) ||
        m.title.toLowerCase().includes(q) ||
        (m.po_number ?? '').toLowerCase().includes(q) ||
        ((m.coordinator as { name: string } | null)?.name ?? '').toLowerCase().includes(q) ||
        ((m.projects as { name: string } | null)?.name ?? '').toLowerCase().includes(q)
      );
    })
    .sort((a, b) => b.updated_at.localeCompare(a.updated_at));

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortAsc(!sortAsc);
    else { setSortKey(key); setSortAsc(false); }
  };

  const hasFilters = filterStatus !== 'all' || filterProject !== 'all' || filterCreator !== 'all' || search;

  const clearFilters = () => {
    setFilterStatus('all'); setFilterProject('all'); setFilterCreator('all'); setSearch('');
  };

  const exportCSV = () => {
    const header = ['MR Number', 'Title', 'Created By', 'Project', 'Status', 'PO Number', 'Vendor', 'PO Date', 'PO Amount (AED)', 'Created Date'];
    const rows = filtered.map((m) => [
      m.requisition_number,
      `"${m.title.replace(/"/g, '""')}"`,
      `"${(m.creator as { name: string } | null)?.name ?? ''}"`,
      `"${(m.projects as { name: string } | null)?.name ?? ''}"`,
      STATUS_META[m.status].label,
      m.po_number ?? '',
      m.po_vendor ?? '',
      m.po_date ? fmtDate(m.po_date) : '',
      m.po_amount != null ? m.po_amount.toFixed(2) : '',
      fmtDate(m.created_at),
    ]);
    const csv = [header, ...rows].map((r) => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `procurement-report-${new Date().toISOString().split('T')[0]}.csv`;
    a.click(); URL.revokeObjectURL(url);
  };

  const exportDeliveryCSV = () => {
    const header = ['MR Number', 'Title', 'Requested By', 'Project', 'PO Number', 'Vendor', 'PO Amount (AED)', 'Coordinator', 'Delivery Status', 'Delivery Date', 'Transit Remarks', 'Delivery Remarks'];
    const rows = deliveryMRs.map((m) => [
      m.requisition_number,
      `"${m.title.replace(/"/g, '""')}"`,
      `"${(m.creator as { name: string } | null)?.name ?? ''}"`,
      `"${(m.projects as { name: string } | null)?.name ?? ''}"`,
      m.po_number ?? '',
      m.po_vendor ?? '',
      m.po_amount != null ? m.po_amount.toFixed(2) : '',
      `"${(m.coordinator as { name: string } | null)?.name ?? ''}"`,
      m.delivery_status ? DELIVERY_META[m.delivery_status].label : '',
      m.delivery_date ? fmtDate(m.delivery_date) : '',
      `"${(m.transit_remarks ?? '').replace(/"/g, '""')}"`,
      `"${(m.delivery_remarks ?? '').replace(/"/g, '""')}"`,
    ]);
    const csv = [header, ...rows].map((r) => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `delivery-tracking-${new Date().toISOString().split('T')[0]}.csv`;
    a.click(); URL.revokeObjectURL(url);
  };

  const SortBtn = ({ k, label }: { k: SortKey; label: string }) => (
    <button onClick={() => toggleSort(k)} className="flex items-center gap-1 text-left hover:text-teal-600 select-none transition-colors">
      {label}
      {sortKey === k
        ? sortAsc ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />
        : <ArrowUpDown className="w-3.5 h-3.5 opacity-40" />}
    </button>
  );

  return (
    <>
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* Page header */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold text-gray-900">Procurement Dashboard</h1>
              {liveIndicator && (
                <span className="flex items-center gap-1.5 text-xs font-semibold text-emerald-600 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full">
                  <Radio className="w-3 h-3 animate-pulse" />Live update
                </span>
              )}
            </div>
            <p className="text-gray-500 text-sm mt-0.5">Track all material requisitions and purchase orders</p>
          </div>
          <div className="flex items-center gap-2">
            {isAdmin && (
              <button
                onClick={() => setShowNewMR(true)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-gradient-to-r from-teal-500 to-blue-600 text-white text-sm font-medium hover:from-teal-600 hover:to-blue-700 transition-all shadow-sm"
              >
                <Plus className="w-4 h-4" />
                New Requisition
              </button>
            )}
            <button onClick={fetchMRs} disabled={loading} className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm text-gray-600 hover:border-teal-300 hover:text-teal-600 transition-colors">
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </button>
            <button
              onClick={activeTab === 'delivery' ? exportDeliveryCSV : exportCSV}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-gray-200 bg-white text-sm text-gray-600 hover:border-teal-300 hover:text-teal-600 transition-colors"
            >
              <Download className="w-4 h-4" />
              Export CSV
            </button>
          </div>
        </div>

        {/* Summary metric cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { label: 'Total MRs',    value: counts.total,       icon: Package,       color: 'text-gray-700',  bg: 'bg-gray-100',   border: 'border-gray-200' },
            { label: 'Open',         value: counts.open,        icon: AlertCircle,   color: 'text-blue-700',  bg: 'bg-blue-50',    border: 'border-blue-100' },
            { label: 'PM Approval',  value: counts.in_progress, icon: Clock,         color: 'text-amber-700', bg: 'bg-amber-50',   border: 'border-amber-100' },
            { label: 'PO Released',  value: counts.po_released, icon: TrendingUp,    color: 'text-teal-700',  bg: 'bg-teal-50',    border: 'border-teal-100' },
            { label: 'Closed',       value: counts.closed,      icon: CheckCircle2,  color: 'text-green-700', bg: 'bg-green-50',   border: 'border-green-100' },
            { label: 'Drafts',       value: counts.draft,       icon: ShoppingCart,  color: 'text-gray-500',  bg: 'bg-gray-50',    border: 'border-gray-200' },
          ].map((c) => (
            <div key={c.label} className={`bg-white rounded-xl border ${c.border} p-4 flex flex-col gap-2`}>
              <div className={`w-8 h-8 ${c.bg} rounded-lg flex items-center justify-center`}>
                <c.icon className={`w-4 h-4 ${c.color}`} />
              </div>
              <div>
                <p className={`text-2xl font-bold ${c.color}`}>{c.value}</p>
                <p className="text-xs text-gray-500 mt-0.5">{c.label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="flex border-b border-gray-100">
            {([
              { id: 'requisitions', label: 'Material Requisitions', icon: ShoppingCart, badge: counts.total },
              { id: 'delivery',     label: 'Delivery Tracking',     icon: Truck,        badge: deliveryCounts.total },
            ] as { id: DashTab; label: string; icon: React.ElementType; badge: number }[]).map(({ id, label, icon: Icon, badge }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={`flex items-center gap-2 px-5 py-3.5 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === id
                    ? 'border-teal-500 text-teal-700 bg-teal-50/40'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
                <span className={`text-xs rounded-full px-1.5 py-0.5 font-bold ${activeTab === id ? 'bg-teal-100 text-teal-700' : 'bg-gray-100 text-gray-500'}`}>
                  {badge}
                </span>
              </button>
            ))}
          </div>

          {/* ── REQUISITIONS TAB ─────────────────────────────────── */}
          {activeTab === 'requisitions' && (
            <>
              {/* Project summary */}
              {Object.keys(projectSummary).length > 0 && (
                <div className="border-b border-gray-100">
                  <div className="px-5 py-3 bg-gray-50 border-b border-gray-100">
                    <h2 className="font-semibold text-gray-700 text-sm">Project-wise Summary</h2>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="bg-gray-50 border-b border-gray-100">
                          <th className="text-left px-5 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Project</th>
                          <th className="text-right px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Total MRs</th>
                          <th className="text-right px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Open</th>
                          <th className="text-right px-4 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Closed</th>
                          <th className="text-right px-5 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Total PO Value (AED)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {Object.entries(projectSummary).map(([proj, s]) => (
                          <tr key={proj} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                            <td className="px-5 py-2.5 text-sm font-medium text-gray-800">{proj}</td>
                            <td className="px-4 py-2.5 text-sm text-right text-gray-700">{s.total}</td>
                            <td className="px-4 py-2.5 text-sm text-right"><span className={s.open > 0 ? 'text-amber-600 font-medium' : 'text-gray-400'}>{s.open}</span></td>
                            <td className="px-4 py-2.5 text-sm text-right"><span className={s.closed > 0 ? 'text-green-600 font-medium' : 'text-gray-400'}>{s.closed}</span></td>
                            <td className="px-5 py-2.5 text-sm text-right font-semibold text-teal-700">
                              {s.po_value > 0 ? `AED ${s.po_value.toLocaleString('en-AE', { minimumFractionDigits: 2 })}` : '—'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Toolbar */}
              <div className="p-5 border-b border-gray-100 space-y-3">
                <div className="flex flex-wrap items-center gap-3">
                  <div className="relative flex-1 min-w-[200px]">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type="text" value={search} onChange={(e) => setSearch(e.target.value)}
                      placeholder="Search MR number, title, vendor, creator…"
                      className="w-full pl-9 pr-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400"
                    />
                    {search && <button onClick={() => setSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2 p-0.5 text-gray-400 hover:text-gray-600"><X className="w-3.5 h-3.5" /></button>}
                  </div>
                  {hasFilters && (
                    <button onClick={clearFilters} className="flex items-center gap-1 px-2.5 py-2 rounded-lg text-xs text-red-500 hover:bg-red-50 border border-red-200 transition-colors">
                      <X className="w-3 h-3" /> Clear all
                    </button>
                  )}
                </div>
                <div className="flex flex-wrap gap-3">
                  <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value as MRStatus | 'all')} className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-teal-400">
                    <option value="all">All Statuses</option>
                    {Object.entries(STATUS_META).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                  </select>
                  <select value={filterProject} onChange={(e) => setFilterProject(e.target.value)} className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-teal-400">
                    <option value="all">All Projects</option>
                    {projects.map((p) => <option key={p} value={p}>{p}</option>)}
                  </select>
                  <select value={filterCreator} onChange={(e) => setFilterCreator(e.target.value)} className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-teal-400">
                    <option value="all">All Members</option>
                    {creators.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                  <span className="text-sm text-gray-400 self-center ml-auto">{filtered.length} of {mrs.length} MRs</span>
                </div>
              </div>

              {/* MR table */}
              {loading ? (
                <div className="py-20 flex items-center justify-center"><RefreshCw className="w-7 h-7 animate-spin text-teal-400" /></div>
              ) : filtered.length === 0 ? (
                <div className="py-16 text-center">
                  <ShoppingCart className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-600 font-medium">No requisitions found</p>
                  {hasFilters && <button onClick={clearFilters} className="text-teal-600 text-sm hover:underline mt-1">Clear filters</button>}
                </div>
              ) : (
                <>
                  <div className="hidden md:block overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="bg-gray-50 border-b border-gray-200">
                          <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide"><SortBtn k="requisition_number" label="MR #" /></th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Title</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide"><SortBtn k="creator" label="Submitted By" /></th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide"><SortBtn k="project" label="Project" /></th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide"><SortBtn k="status" label="Status" /></th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Req. Delivery</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">PO Number</th>
                          <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">PO Amount</th>
                          <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide"><SortBtn k="created_at" label="Date" /></th>
                          {isAdmin && <th className="px-3 py-3" />}
                        </tr>
                      </thead>
                      <tbody>
                        {filtered.map((mr) => {
                          const meta = STATUS_META[mr.status];
                          return (
                            <tr key={mr.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                              <td className="px-5 py-3">
                                <button onClick={() => setExpandedId(expandedId === mr.id ? null : mr.id)} className="font-mono text-sm font-semibold text-teal-700 hover:text-teal-900 hover:underline">
                                  {mr.requisition_number}
                                </button>
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-800 max-w-[200px] truncate">{mr.title}</td>
                              <td className="px-4 py-3 text-sm text-gray-600">{(mr.creator as { name: string } | null)?.name ?? '—'}</td>
                              <td className="px-4 py-3 text-sm text-gray-600">{(mr.projects as { name: string } | null)?.name ?? '—'}</td>
                              <td className="px-4 py-3">
                                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${meta.bg} ${meta.color}`}>
                                  <span className={`w-1.5 h-1.5 rounded-full ${meta.dot}`} />{meta.label}
                                </span>
                              </td>
                              <td className="px-4 py-3 text-sm">
                                {mr.required_delivery_date
                                  ? <span className="font-medium text-amber-700">{fmtDate(mr.required_delivery_date)}</span>
                                  : <span className="text-gray-300">—</span>}
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-600 font-mono">{mr.po_number ?? '—'}</td>
                              <td className="px-4 py-3 text-sm text-right font-medium text-gray-800">
                                {mr.po_amount != null ? `AED ${mr.po_amount.toLocaleString('en-AE', { minimumFractionDigits: 2 })}` : '—'}
                              </td>
                              <td className="px-5 py-3 text-sm text-gray-500">{fmtDate(mr.created_at)}</td>
                              {isAdmin && (
                                <td className="px-3 py-3">
                                  <button onClick={() => handleDeleteMR(mr)} className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors" title="Delete MR">
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </td>
                              )}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  <div className="md:hidden divide-y divide-gray-100">
                    {filtered.map((mr) => {
                      const meta = STATUS_META[mr.status];
                      return (
                        <div key={mr.id} className="p-4">
                          <div className="flex items-start justify-between gap-2 mb-1.5">
                            <div>
                              <span className="font-mono text-sm font-bold text-teal-700">{mr.requisition_number}</span>
                              <p className="text-sm text-gray-800 mt-0.5">{mr.title}</p>
                            </div>
                            <div className="flex items-center gap-1.5 flex-shrink-0">
                              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold ${meta.bg} ${meta.color}`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${meta.dot}`} />{meta.label}
                              </span>
                              {isAdmin && (
                                <button onClick={() => handleDeleteMR(mr)} className="p-1 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors" title="Delete MR">
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-500 mt-2">
                            <span>{(mr.creator as { name: string } | null)?.name ?? '—'}</span>
                            {mr.projects && <span>{(mr.projects as { name: string }).name}</span>}
                            {mr.po_number && <span className="font-mono font-medium text-teal-700">{mr.po_number}</span>}
                            <span>{fmtDate(mr.created_at)}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}

              {/* Expanded row detail */}
              {expandedId && (() => {
                const mr = mrs.find((m) => m.id === expandedId);
                if (!mr) return null;
                return (
                  <div className="border-t-2 border-teal-100 bg-teal-50/40 px-5 py-5 space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-gray-900">{mr.requisition_number} — Details</h4>
                      <button onClick={() => setExpandedId(null)} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"><X className="w-4 h-4 text-gray-500" /></button>
                    </div>
                    {mr.required_delivery_date && (
                      <div className="inline-flex items-center gap-2 px-3 py-2 bg-amber-50 border border-amber-200 rounded-lg">
                        <CalendarClock className="w-4 h-4 text-amber-600 flex-shrink-0" />
                        <span className="text-sm font-semibold text-amber-800">Required by {fmtDate(mr.required_delivery_date)}</span>
                      </div>
                    )}
                    {mr.purpose && <p className="text-sm text-gray-700"><span className="font-semibold">Remarks: </span>{mr.purpose}</p>}
                    {mr.items.length > 0 && (
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm border border-gray-100 rounded-xl overflow-hidden">
                          <thead>
                            <tr className="bg-white">
                              {['Material Description', 'Specification', 'Proposed Make', 'Country', 'Qty', 'Unit'].map((h) => (
                                <th key={h} className="text-left px-3 py-2 text-xs font-semibold text-gray-500">{h}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {mr.items.map((item, i) => (
                              <tr key={i} className="border-t border-gray-100 bg-white">
                                <td className="px-3 py-2 text-gray-800">{item.description}</td>
                                <td className="px-3 py-2 text-gray-600">{item.specification ?? '—'}</td>
                                <td className="px-3 py-2 text-gray-600">{item.proposed_make ?? '—'}</td>
                                <td className="px-3 py-2 text-gray-600">{item.country_of_origin ?? '—'}</td>
                                <td className="px-3 py-2 text-right text-gray-700">{item.quantity}</td>
                                <td className="px-3 py-2 text-gray-500">{item.unit}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                    {mr.po_number && (
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                          {[
                            { label: 'PO Number', value: mr.po_number },
                            { label: 'Vendor',    value: mr.po_vendor ?? '—' },
                            { label: 'PO Date',   value: mr.po_date ? fmtDate(mr.po_date) : '—' },
                            { label: 'PO Amount', value: mr.po_amount != null ? `AED ${mr.po_amount.toLocaleString('en-AE', { minimumFractionDigits: 2 })}` : '—' },
                          ].map((f) => (
                            <div key={f.label} className="bg-white rounded-lg border border-gray-100 px-3 py-2.5">
                              <p className="text-xs font-semibold text-gray-500 mb-0.5">{f.label}</p>
                              <p className="text-sm font-medium text-gray-800">{f.value}</p>
                            </div>
                          ))}
                        </div>
                        {(mr.po_vendor_contact_name || mr.po_vendor_contact_number || mr.po_vendor_location) && (
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            {mr.po_vendor_contact_name && (
                              <div className="bg-white rounded-lg border border-gray-100 px-3 py-2.5 flex items-start gap-2">
                                <User className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                                <div>
                                  <p className="text-xs font-semibold text-gray-500 mb-0.5">Contact Name</p>
                                  <p className="text-sm font-medium text-gray-800">{mr.po_vendor_contact_name}</p>
                                </div>
                              </div>
                            )}
                            {mr.po_vendor_contact_number && (
                              <div className="bg-white rounded-lg border border-gray-100 px-3 py-2.5 flex items-start gap-2">
                                <Phone className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                                <div>
                                  <p className="text-xs font-semibold text-gray-500 mb-0.5">Contact Number</p>
                                  <p className="text-sm font-medium text-gray-800">{mr.po_vendor_contact_number}</p>
                                </div>
                              </div>
                            )}
                            {mr.po_vendor_location && (
                              <div className="bg-white rounded-lg border border-gray-100 px-3 py-2.5 flex items-start gap-2">
                                <MapPin className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                                <div>
                                  <p className="text-xs font-semibold text-gray-500 mb-0.5">Location</p>
                                  <p className="text-sm font-medium text-gray-800">{mr.po_vendor_location}</p>
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                    {mr.delivery_status && (
                      <div className={`rounded-xl border px-4 py-3 ${mr.delivery_status === 'delivered' ? 'bg-green-50 border-green-100' : 'bg-amber-50 border-amber-100'}`}>
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Delivery Status</p>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${DELIVERY_META[mr.delivery_status].bg} ${DELIVERY_META[mr.delivery_status].color}`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${DELIVERY_META[mr.delivery_status].dot}`} />
                            {DELIVERY_META[mr.delivery_status].label}
                          </span>
                          {(mr.coordinator as { name: string } | null)?.name && (
                            <span className="text-sm text-gray-600">· {(mr.coordinator as { name: string }).name}</span>
                          )}
                          {mr.delivery_date && <span className="text-sm font-semibold text-green-700">· Delivered {fmtDate(mr.delivery_date)}</span>}
                        </div>
                        {mr.transit_remarks && <p className="text-sm text-amber-700 mt-1"><span className="font-semibold">Transit Remarks: </span>{mr.transit_remarks}</p>}
                        {mr.delivery_remarks && <p className="text-sm text-gray-600 mt-1">{mr.delivery_remarks}</p>}
                      </div>
                    )}
                    {mr.attachments && mr.attachments.length > 0 && (
                      <div>
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Attachments ({mr.attachments.length})</p>
                        <div className="flex flex-wrap gap-2">
                          {mr.attachments.map((att, i) => (
                            <a
                              key={i}
                              href={att.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              download={att.name}
                              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-lg text-xs font-medium text-blue-700 hover:bg-blue-100 hover:border-blue-300 transition-colors"
                            >
                              <Paperclip className="w-3 h-3 flex-shrink-0" />
                              <span className="max-w-[200px] truncate">{att.name}</span>
                              <span className="text-blue-400 flex-shrink-0">({(att.size / 1024).toFixed(0)} KB)</span>
                              <Download className="w-3 h-3 flex-shrink-0 text-blue-400" />
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}

              <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
                <p className="text-xs text-gray-400">Showing {filtered.length} of {mrs.length} requisitions</p>
                <button onClick={exportCSV} className="flex items-center gap-1 text-xs text-teal-600 hover:text-teal-700 font-medium">
                  <Download className="w-3.5 h-3.5" /> Export filtered results
                </button>
              </div>
            </>
          )}

          {/* ── DELIVERY TRACKING TAB ────────────────────────────── */}
          {activeTab === 'delivery' && (
            <>
              {/* Delivery metric cards */}
              <div className="p-5 border-b border-gray-100">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
                  {[
                    { label: 'Total',      value: deliveryCounts.total,      icon: Truck,        color: 'text-gray-700',  bg: 'bg-gray-100',   border: 'border-gray-200' },
                    { label: 'Assigned',   value: deliveryCounts.assigned,   icon: Package,      color: 'text-blue-700',  bg: 'bg-blue-50',    border: 'border-blue-100' },
                    { label: 'In Transit', value: deliveryCounts.in_transit, icon: Clock,        color: 'text-amber-700', bg: 'bg-amber-50',   border: 'border-amber-100' },
                    { label: 'Delivered',  value: deliveryCounts.delivered,  icon: CheckCircle2, color: 'text-green-700', bg: 'bg-green-50',   border: 'border-green-100' },
                  ].map((c) => (
                    <div key={c.label} className={`bg-white rounded-xl border ${c.border} p-4 flex items-center gap-3`}>
                      <div className={`w-9 h-9 ${c.bg} rounded-lg flex items-center justify-center flex-shrink-0`}>
                        <c.icon className={`w-4 h-4 ${c.color}`} />
                      </div>
                      <div>
                        <p className={`text-xl font-bold ${c.color}`}>{c.value}</p>
                        <p className="text-xs text-gray-500">{c.label}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Delivery search + filter */}
                <div className="flex flex-wrap gap-3">
                  <div className="relative flex-1 min-w-[200px]">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type="text" value={deliverySearch} onChange={(e) => setDeliverySearch(e.target.value)}
                      placeholder="Search MR, PO number, coordinator, project…"
                      className="w-full pl-9 pr-8 py-2 border border-gray-200 rounded-lg text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400"
                    />
                    {deliverySearch && <button onClick={() => setDeliverySearch('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"><X className="w-3.5 h-3.5" /></button>}
                  </div>
                  <select value={deliveryFilter} onChange={(e) => setDeliveryFilter(e.target.value as typeof deliveryFilter)} className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-teal-400">
                    <option value="all">All Delivery Statuses</option>
                    <option value="assigned">Assigned</option>
                    <option value="in_transit">In Transit</option>
                    <option value="delivered">Delivered</option>
                  </select>
                </div>
              </div>

              {/* Delivery table */}
              {loading ? (
                <div className="py-20 flex items-center justify-center"><RefreshCw className="w-7 h-7 animate-spin text-teal-400" /></div>
              ) : deliveryMRs.length === 0 ? (
                <div className="py-16 text-center">
                  <Truck className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-600 font-medium">
                    {deliveryCounts.total === 0 ? 'No deliveries tracked yet' : 'No deliveries match the filter'}
                  </p>
                  <p className="text-gray-400 text-sm mt-1">Deliveries appear here once a PO is closed and assigned to a Material Coordinator.</p>
                </div>
              ) : (
                <>
                  <div className="hidden md:block overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="bg-gray-50 border-b border-gray-200">
                          <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">MR #</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Title</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Requested By</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Project</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">PO / Vendor</th>
                          <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">PO Amount</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Coordinator</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Delivery Status</th>
                          <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Delivery Date</th>
                          {isAdmin && <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Actions</th>}
                        </tr>
                      </thead>
                      <tbody>
                        {deliveryMRs.map((mr) => {
                          const dmeta = DELIVERY_META[mr.delivery_status!];
                          return (
                            <tr key={mr.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                              <td className="px-5 py-3 font-mono text-sm font-semibold text-teal-700">{mr.requisition_number}</td>
                              <td className="px-4 py-3 text-sm text-gray-800 max-w-[160px] truncate">{mr.title}</td>
                              <td className="px-4 py-3 text-sm text-blue-700 font-medium">{(mr.creator as { name: string } | null)?.name ?? '—'}</td>
                              <td className="px-4 py-3 text-sm text-gray-600">{(mr.projects as { name: string } | null)?.name ?? '—'}</td>
                              <td className="px-4 py-3">
                                <p className="text-sm font-mono text-gray-700">{mr.po_number ?? '—'}</p>
                                {mr.po_vendor && <p className="text-xs text-gray-400 truncate max-w-[140px]">{mr.po_vendor}</p>}
                                {mr.po_vendor_contact_name && (
                                  <p className="text-xs text-gray-400 flex items-center gap-1">
                                    <User className="w-3 h-3" />{mr.po_vendor_contact_name}
                                  </p>
                                )}
                                {mr.po_vendor_contact_number && (
                                  <p className="text-xs text-gray-400 flex items-center gap-1">
                                    <Phone className="w-3 h-3" />{mr.po_vendor_contact_number}
                                  </p>
                                )}
                                {mr.po_vendor_location && (
                                  <p className="text-xs text-gray-400 flex items-center gap-1">
                                    <MapPin className="w-3 h-3" />{mr.po_vendor_location}
                                  </p>
                                )}
                              </td>
                              <td className="px-4 py-3 text-sm text-right font-medium text-gray-800">
                                {mr.po_amount != null ? `AED ${mr.po_amount.toLocaleString('en-AE', { minimumFractionDigits: 2 })}` : '—'}
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-600">{(mr.coordinator as { name: string } | null)?.name ?? '—'}</td>
                              <td className="px-4 py-3">
                                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${dmeta.bg} ${dmeta.color}`}>
                                  <span className={`w-1.5 h-1.5 rounded-full ${dmeta.dot}`} />{dmeta.label}
                                </span>
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-700 font-medium">
                                {mr.delivery_date ? <span className="text-green-700">{fmtDate(mr.delivery_date)}</span> : '—'}
                              </td>
                              {isAdmin && (
                                <td className="px-4 py-3">
                                  <div className="flex items-center gap-1.5">
                                    {mr.delivery_status === 'assigned' && (
                                      <button
                                        onClick={() => setTransitMR(mr)}
                                        className="flex items-center gap-1 px-2.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold rounded-lg transition-colors"
                                      >
                                        <Truck className="w-3 h-3" />
                                        In Transit
                                      </button>
                                    )}
                                    {mr.delivery_status === 'in_transit' && (
                                      <button
                                        onClick={() => setAdminDeliverMR(mr)}
                                        className="flex items-center gap-1 px-2.5 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs font-semibold rounded-lg transition-colors"
                                      >
                                        <CheckCircle2 className="w-3 h-3" />
                                        Delivered
                                      </button>
                                    )}
                                    {mr.delivery_status === 'delivered' && (
                                      <span className="text-xs text-green-600 font-semibold flex items-center gap-1">
                                        <CheckCircle2 className="w-3.5 h-3.5" />Done
                                      </span>
                                    )}
                                  </div>
                                </td>
                              )}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* Mobile cards */}
                  <div className="md:hidden divide-y divide-gray-100">
                    {deliveryMRs.map((mr) => {
                      const dmeta = DELIVERY_META[mr.delivery_status!];
                      return (
                        <div key={mr.id} className="p-4">
                          <div className="flex items-start justify-between gap-2 mb-1.5">
                            <div>
                              <span className="font-mono text-sm font-bold text-teal-700">{mr.requisition_number}</span>
                              <p className="text-sm text-gray-800 mt-0.5">{mr.title}</p>
                            </div>
                            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold flex-shrink-0 ${dmeta.bg} ${dmeta.color}`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${dmeta.dot}`} />{dmeta.label}
                            </span>
                          </div>
                          <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-500 mt-2">
                            {mr.projects && <span>{(mr.projects as { name: string }).name}</span>}
                            {mr.po_number && <span className="font-mono text-teal-700">{mr.po_number}</span>}
                            {(mr.coordinator as { name: string } | null)?.name && <span>{(mr.coordinator as { name: string }).name}</span>}
                            {mr.delivery_date && <span className="text-green-600 font-medium">Delivered: {fmtDate(mr.delivery_date)}</span>}
                          </div>
                          {(mr.po_vendor_contact_name || mr.po_vendor_contact_number || mr.po_vendor_location) && (
                            <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-xs text-gray-400 mt-1">
                              {mr.po_vendor_contact_name && <span className="flex items-center gap-1"><User className="w-3 h-3" />{mr.po_vendor_contact_name}</span>}
                              {mr.po_vendor_contact_number && <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{mr.po_vendor_contact_number}</span>}
                              {mr.po_vendor_location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{mr.po_vendor_location}</span>}
                            </div>
                          )}
                          {mr.transit_remarks && <p className="text-xs text-amber-700 mt-1 italic">{mr.transit_remarks}</p>}
                          {mr.delivery_remarks && <p className="text-xs text-gray-500 mt-1 italic">{mr.delivery_remarks}</p>}
                          {isAdmin && (
                            <div className="mt-2 flex gap-2">
                              {mr.delivery_status === 'assigned' && (
                                <button onClick={() => setTransitMR(mr)} className="flex items-center gap-1 px-2.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold rounded-lg">
                                  <Truck className="w-3 h-3" />Mark In Transit
                                </button>
                              )}
                              {mr.delivery_status === 'in_transit' && (
                                <button onClick={() => setAdminDeliverMR(mr)} className="flex items-center gap-1 px-2.5 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs font-semibold rounded-lg">
                                  <CheckCircle2 className="w-3 h-3" />Mark Delivered
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </>
              )}

              <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
                <p className="text-xs text-gray-400">Showing {deliveryMRs.length} of {deliveryCounts.total} deliveries</p>
                <button onClick={exportDeliveryCSV} className="flex items-center gap-1 text-xs text-teal-600 hover:text-teal-700 font-medium">
                  <Download className="w-3.5 h-3.5" /> Export delivery report
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>

    {adminDeliverMR && (
      <AdminDeliveredModal
        mr={adminDeliverMR}
        onClose={() => setAdminDeliverMR(null)}
        onSaved={() => { setAdminDeliverMR(null); fetchMRs(); }}
      />
    )}
    {transitMR && (
      <AdminInTransitModal
        mr={transitMR}
        onClose={() => setTransitMR(null)}
        onSaved={() => { setTransitMR(null); fetchMRs(); }}
      />
    )}
    {showNewMR && teamMember && (
      <NewMRForm
        teamMemberId={teamMember.id}
        projects={mrProjects}
        onClose={() => setShowNewMR(false)}
        onCreated={() => { setShowNewMR(false); fetchMRs(); }}
      />
    )}
    </>
  );
}

/* ── Admin In Transit Modal ──────────────────────────── */
function AdminInTransitModal({ mr, onClose, onSaved }: {
  mr: MR; onClose: () => void; onSaved: () => void;
}) {
  const [remarks, setRemarks] = useState('');
  const [saving, setSaving]   = useState(false);
  const [error, setError]     = useState<string | null>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const { error: err } = await supabase.from('material_requisitions').update({
      delivery_status: 'in_transit',
      transit_remarks: remarks.trim() || null,
      delivery_updated_at: new Date().toISOString(),
    }).eq('id', mr.id);
    setSaving(false);
    if (err) { setError(err.message); return; }
    onSaved();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div>
            <h3 className="font-bold text-gray-900">Mark as In Transit</h3>
            <p className="text-xs text-gray-500 mt-0.5">{mr.requisition_number} · {mr.title}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100"><X className="w-5 h-5 text-gray-500" /></button>
        </div>
        <form onSubmit={handleSave} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
              Transit Remarks <span className="text-gray-400 font-normal">(optional)</span>
            </label>
            <textarea value={remarks} onChange={(e) => setRemarks(e.target.value)} rows={3}
              placeholder="e.g. Dispatched via courier — expected delivery in 2 days"
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 resize-none" />
          </div>
          {error && (
            <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl px-3 py-2.5">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />{error}
            </div>
          )}
          <div className="flex items-center gap-3 pt-1">
            <button type="submit" disabled={saving}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-medium rounded-xl text-sm disabled:opacity-60 hover:from-amber-600 hover:to-orange-600 transition-all">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Truck className="w-4 h-4" />}
              {saving ? 'Saving…' : 'Confirm In Transit'}
            </button>
            <button type="button" onClick={onClose} className="px-4 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* ── Admin Delivered Modal ───────────────────────────── */
function AdminDeliveredModal({ mr, onClose, onSaved }: {
  mr: MR; onClose: () => void; onSaved: () => void;
}) {
  const [deliveryDate, setDeliveryDate] = useState(new Date().toISOString().split('T')[0]);
  const [remarks, setRemarks]           = useState('');
  const [saving, setSaving]             = useState(false);
  const [error, setError]               = useState<string | null>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!deliveryDate) { setError('Delivery date is required.'); return; }
    setSaving(true);
    const { error: err } = await supabase.from('material_requisitions').update({
      delivery_status: 'delivered',
      delivery_date: deliveryDate,
      delivery_remarks: remarks.trim() || null,
      delivery_updated_at: new Date().toISOString(),
    }).eq('id', mr.id);
    setSaving(false);
    if (err) { setError(err.message); return; }
    onSaved();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div>
            <h3 className="font-bold text-gray-900">Mark as Delivered</h3>
            <p className="text-xs text-gray-500 mt-0.5">{mr.requisition_number} · {mr.title}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100"><X className="w-5 h-5 text-gray-500" /></button>
        </div>
        <form onSubmit={handleSave} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
              Delivery Date <span className="text-red-400">*</span>
            </label>
            <input type="date" value={deliveryDate} onChange={(e) => setDeliveryDate(e.target.value)} required
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
              Remarks <span className="text-gray-400 font-normal">(optional)</span>
            </label>
            <textarea value={remarks} onChange={(e) => setRemarks(e.target.value)} rows={3}
              placeholder="e.g. Delivered to site — all items accounted for"
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 resize-none" />
          </div>
          {error && (
            <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl px-3 py-2.5">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />{error}
            </div>
          )}
          <div className="flex items-center gap-3 pt-1">
            <button type="submit" disabled={saving}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-green-500 to-teal-600 text-white font-medium rounded-xl text-sm disabled:opacity-60 hover:from-green-600 hover:to-teal-700 transition-all">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
              {saving ? 'Saving…' : 'Confirm Delivery'}
            </button>
            <button type="button" onClick={onClose} className="px-4 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
