import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/supabase';
import {
  ClipboardList,
  Plus,
  X,
  Edit2,
  Trash2,
  Calendar,
  FileText,
  Flag,
  User,
  CheckCircle2,
} from 'lucide-react';

type Task = Database['public']['Tables']['tasks']['Row'];
type Project = Database['public']['Tables']['projects']['Row'];
type TeamMember = Database['public']['Tables']['team_members']['Row'];

interface TaskWithDetails extends Task {
  projects: Project;
  team_members: TeamMember | null;
}

export function TaskBoard() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<TaskWithDetails[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingTask, setEditingTask] = useState<TaskWithDetails | null>(null);
  const [filterProject, setFilterProject] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterMember, setFilterMember] = useState<string>('all');
  const [selectedTaskType, setSelectedTaskType] = useState<string>('all');

  const fetchData = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    try {
      const [tasksRes, projectsRes, membersRes] = await Promise.all([
        supabase
          .from('tasks')
          .select('*, projects(*), team_members(*)')
          .order('due_date', { ascending: true }),
        supabase.from('projects').select('*').order('name'),
        supabase.from('team_members').select('*').eq('is_active', true).order('name'),
      ]);

      if (tasksRes.data) setTasks(tasksRes.data as TaskWithDetails[]);
      if (projectsRes.data) setProjects(projectsRes.data);
      if (membersRes.data) setTeamMembers(membersRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }

    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this task?')) return;

    try {
      await supabase.from('tasks').delete().eq('id', id);
      fetchData();
    } catch (error) {
      console.error('Error deleting task:', error);
    }
  };

  const handleStatusChange = async (task: TaskWithDetails, newStatus: string) => {
    try {
      const updateData: { status: string; completed_date?: string } = { status: newStatus };
      if (newStatus === 'completed') {
        updateData.completed_date = new Date().toISOString().split('T')[0];
      }

      await supabase.from('tasks').update(updateData).eq('id', task.id);
      fetchData();
    } catch (error) {
      console.error('Error updating task:', error);
    }
  };

  const handleSave = () => {
    setShowModal(false);
    setEditingTask(null);
    fetchData();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-gray-100 text-gray-700';
      case 'in-progress':
        return 'bg-blue-100 text-blue-700';
      case 'review':
        return 'bg-yellow-100 text-yellow-700';
      case 'completed':
        return 'bg-green-100 text-green-700';
      case 'cancelled':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'low':
        return 'text-gray-500';
      case 'medium':
        return 'text-yellow-600';
      case 'high':
        return 'text-orange-600';
      case 'critical':
        return 'text-red-600';
      default:
        return 'text-gray-500';
    }
  };

  const getTaskTypeIcon = (type: string) => {
    switch (type) {
      case 'document':
        return <FileText className="w-4 h-4" />;
      case 'milestone':
        return <CheckCircle2 className="w-4 h-4" />;
      case 'review':
        return <Edit2 className="w-4 h-4" />;
      default:
        return <ClipboardList className="w-4 h-4" />;
    }
  };

  const isOverdue = (dueDate: string, status: string) => {
    return status !== 'completed' && status !== 'cancelled' && new Date(dueDate) < new Date();
  };

  const filteredTasks = tasks.filter((task) => {
    const projectMatch = filterProject === 'all' || task.project_id === filterProject;
    const statusMatch = filterStatus === 'all' || task.status === filterStatus;
    const memberMatch = filterMember === 'all' || task.assigned_to === filterMember;
    const typeMatch = selectedTaskType === 'all' || task.task_type === selectedTaskType;
    return projectMatch && statusMatch && memberMatch && typeMatch;
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Task Board</h1>
            <p className="text-gray-600 mt-1">Manage and track all your tasks and documents</p>
          </div>
          <button
            onClick={() => {
              setEditingTask(null);
              setShowModal(true);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg"
          >
            <Plus className="w-5 h-5" />
            Add Task
          </button>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-sm p-4 mb-6 flex flex-wrap gap-4">
          <div className="flex-1 min-w-[180px]">
            <label className="block text-xs font-medium text-gray-500 mb-1">Project</label>
            <select
              value={filterProject}
              onChange={(e) => setFilterProject(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg"
            >
              <option value="all">All Projects</option>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex-1 min-w-[180px]">
            <label className="block text-xs font-medium text-gray-500 mb-1">Team Member</label>
            <select
              value={filterMember}
              onChange={(e) => setFilterMember(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg"
            >
              <option value="all">All Members</option>
              {teamMembers.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex-1 min-w-[180px]">
            <label className="block text-xs font-medium text-gray-500 mb-1">Status</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg"
            >
              <option value="all">All Statuses</option>
              <option value="pending">Pending</option>
              <option value="in-progress">In Progress</option>
              <option value="review">Review</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>

          <div className="flex-1 min-w-[180px]">
            <label className="block text-xs font-medium text-gray-500 mb-1">Type</label>
            <select
              value={selectedTaskType}
              onChange={(e) => setSelectedTaskType(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg"
            >
              <option value="all">All Types</option>
              <option value="task">Task</option>
              <option value="document">Document</option>
              <option value="milestone">Milestone</option>
              <option value="review">Review</option>
            </select>
          </div>
        </div>

        {/* Tasks */}
        {filteredTasks.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 border border-gray-100 text-center">
            <ClipboardList className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No Tasks Found</h3>
            <p className="text-gray-500 mb-4">
              {tasks.length === 0
                ? 'Create your first task to get started'
                : 'Try adjusting your filters'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredTasks.map((task) => (
              <div
                key={task.id}
                className={`bg-white rounded-xl shadow-sm p-5 border-l-4 transition-all hover:shadow-md ${
                  isOverdue(task.due_date, task.status)
                    ? 'border-red-500'
                    : task.status === 'completed'
                    ? 'border-green-500'
                    : 'border-gray-200'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-gray-400">{getTaskTypeIcon(task.task_type)}</span>
                      <h3 className="font-semibold text-gray-900">{task.title}</h3>
                      <span
                        className={`px-2 py-0.5 rounded text-xs font-medium ${getStatusColor(
                          task.status
                        )}`}
                      >
                        {task.status}
                      </span>
                      {isOverdue(task.due_date, task.status) && (
                        <span className="px-2 py-0.5 rounded text-xs font-medium bg-red-100 text-red-700">
                          Overdue
                        </span>
                      )}
                    </div>

                    {task.description && (
                      <p className="text-sm text-gray-600 mb-2">{task.description}</p>
                    )}

                    <div className="flex flex-wrap items-center gap-4 text-sm">
                      <div className="flex items-center gap-1 text-gray-500">
                        <FolderKanban className="w-4 h-4" />
                        <span>{task.projects.name}</span>
                      </div>

                      <div
                        className={`flex items-center gap-1 ${
                          isOverdue(task.due_date, task.status)
                            ? 'text-red-600 font-medium'
                            : 'text-gray-500'
                        }`}
                      >
                        <Calendar className="w-4 h-4" />
                        <span>{task.due_date.split('-').reverse().join('/')}</span>
                      </div>

                      {task.team_members && (
                        <div className="flex items-center gap-1 text-gray-500">
                          <User className="w-4 h-4" />
                          <span>{task.team_members.name}</span>
                        </div>
                      )}

                      <div className={`flex items-center gap-1 ${getPriorityColor(task.priority)}`}>
                        <Flag className="w-4 h-4" />
                        <span className="capitalize">{task.priority}</span>
                      </div>

                      {task.document_name && (
                        <div className="flex items-center gap-1 text-gray-500">
                          <FileText className="w-4 h-4" />
                          <span>{task.document_name}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <select
                      value={task.status}
                      onChange={(e) => handleStatusChange(task, e.target.value)}
                      className="text-sm border border-gray-300 rounded px-2 py-1"
                    >
                      <option value="pending">Pending</option>
                      <option value="in-progress">In Progress</option>
                      <option value="review">Review</option>
                      <option value="completed">Completed</option>
                      <option value="cancelled">Cancelled</option>
                    </select>

                    <button
                      onClick={() => {
                        setEditingTask(task);
                        setShowModal(true);
                      }}
                      className="p-2 text-gray-400 hover:text-gray-600"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleDelete(task.id)}
                      className="p-2 text-gray-400 hover:text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Modal */}
        {showModal && (
          <TaskModal
            task={editingTask}
            projects={projects}
            teamMembers={teamMembers}
            userId={user!.id}
            onClose={() => {
              setShowModal(false);
              setEditingTask(null);
            }}
            onSave={handleSave}
          />
        )}
      </div>
    </div>
  );
}

// Import the icon that was used in the component
import { FolderKanban } from 'lucide-react';

function TaskModal({
  task,
  projects,
  teamMembers,
  userId,
  onClose,
  onSave,
}: {
  task: TaskWithDetails | null;
  projects: Project[];
  teamMembers: TeamMember[];
  userId: string;
  onClose: () => void;
  onSave: () => void;
}) {
  const [projectId, setProjectId] = useState(task?.project_id || '');
  const [assignedTo, setAssignedTo] = useState(task?.assigned_to || '');
  const [title, setTitle] = useState(task?.title || '');
  const [description, setDescription] = useState(task?.description || '');
  const [taskType, setTaskType] = useState<'task' | 'document' | 'milestone' | 'review'>(
    task?.task_type || 'task'
  );
  const [status, setStatus] = useState<'pending' | 'in-progress' | 'review' | 'completed' | 'cancelled'>(
    task?.status || 'pending'
  );
  const [priority, setPriority] = useState<'low' | 'medium' | 'high' | 'critical'>(
    task?.priority || 'medium'
  );
  const [dueDate, setDueDate] = useState(
    task?.due_date || new Date().toISOString().split('T')[0]
  );
  const [documentName, setDocumentName] = useState(task?.document_name || '');
  const [notes, setNotes] = useState(task?.notes || '');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const taskData = {
        project_id: projectId,
        assigned_to: assignedTo || null,
        title,
        description: description || null,
        task_type: taskType,
        status,
        priority,
        due_date: dueDate,
        document_name: taskType === 'document' ? documentName || null : null,
        notes: notes || null,
        created_by: userId,
      };

      if (task) {
        await supabase.from('tasks').update(taskData).eq('id', task.id);
      } else {
        await supabase.from('tasks').insert(taskData);
      }

      onSave();
    } catch (error) {
      console.error('Error saving task:', error);
    }
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full p-6 my-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-900">
            {task ? 'Edit Task' : 'Create New Task'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Project *</label>
            <select
              value={projectId}
              onChange={(e) => setProjectId(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg"
              required
            >
              <option value="">Select a project</option>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Task Title *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg"
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Task Type</label>
              <select
                value={taskType}
                onChange={(e) => setTaskType(e.target.value as 'task' | 'document' | 'milestone' | 'review')}
                className="w-full p-2 border border-gray-300 rounded-lg"
              >
                <option value="task">Task</option>
                <option value="document">Document</option>
                <option value="milestone">Milestone</option>
                <option value="review">Review</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as 'low' | 'medium' | 'high' | 'critical')}
                className="w-full p-2 border border-gray-300 rounded-lg"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="critical">Critical</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as 'pending' | 'in-progress' | 'review' | 'completed' | 'cancelled')}
                className="w-full p-2 border border-gray-300 rounded-lg"
              >
                <option value="pending">Pending</option>
                <option value="in-progress">In Progress</option>
                <option value="review">Review</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Due Date *</label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-lg"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Assign To</label>
            <select
              value={assignedTo}
              onChange={(e) => setAssignedTo(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg"
            >
              <option value="">Unassigned</option>
              {teamMembers.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>

          {taskType === 'document' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Document Name</label>
              <input
                type="text"
                value={documentName}
                onChange={(e) => setDocumentName(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-lg"
                placeholder="Enter document name"
              />
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg"
              rows={2}
            />
          </div>

          <div className="flex gap-2 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 px-4 border-2 border-gray-200 text-gray-700 font-medium rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || !title.trim() || !projectId}
              className="flex-1 py-2 px-4 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg disabled:opacity-50"
            >
              {loading ? 'Saving...' : task ? 'Update Task' : 'Create Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
