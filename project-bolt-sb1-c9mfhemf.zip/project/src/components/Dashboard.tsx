import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/supabase';
import {
  Users,
  FolderKanban,
  ClipboardList,
  AlertTriangle,
  CheckCircle2,
  Clock,
  TrendingUp,
  Calendar,
  CalendarClock,
  ChevronRight,
} from 'lucide-react';

type Project = Database['public']['Tables']['projects']['Row'];
type Task = Database['public']['Tables']['tasks']['Row'];
type TeamMember = Database['public']['Tables']['team_members']['Row'];

interface TaskWithDetails extends Task {
  projects: Project;
  team_members: TeamMember | null;
}

interface DashboardProps {
  onNavigate: (view: 'dashboard' | 'team' | 'projects' | 'tasks' | 'reports') => void;
}

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-gray-100 text-gray-700',
  'in-progress': 'bg-blue-100 text-blue-700',
  review: 'bg-amber-100 text-amber-700',
  completed: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
};

const PRIORITY_LEFT: Record<string, string> = {
  low: 'border-l-gray-300',
  medium: 'border-l-yellow-400',
  high: 'border-l-orange-500',
  critical: 'border-l-red-500',
};

const PRIORITY_TEXT: Record<string, string> = {
  low: 'text-gray-500',
  medium: 'text-yellow-600',
  high: 'text-orange-600',
  critical: 'text-red-600',
};

function statusLabel(s: string) {
  return s === 'in-progress' ? 'In Progress' : s.charAt(0).toUpperCase() + s.slice(1);
}

function fmtDate(d: string) {
  return new Date(d + 'T00:00:00').toLocaleDateString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric',
  });
}

function dayLabel(date: string, today: string) {
  const d = new Date(date + 'T00:00:00');
  const t = new Date(today + 'T00:00:00');
  const diff = Math.round((d.getTime() - t.getTime()) / 86400000);
  if (diff < 0) return `${Math.abs(diff)}d overdue`;
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Tomorrow';
  return `In ${diff} days`;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    totalProjects: 0,
    activeProjects: 0,
    totalTeamMembers: 0,
    totalTasks: 0,
    pendingTasks: 0,
    overdueTasks: 0,
    completedTasks: 0,
  });
  const [recentTasks, setRecentTasks] = useState<TaskWithDetails[]>([]);
  const [overdueTasks, setOverdueTasks] = useState<TaskWithDetails[]>([]);
  const [upcomingTasks, setUpcomingTasks] = useState<TaskWithDetails[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchDashboardData = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    try {
      const today = new Date().toISOString().split('T')[0];
      const in3days = new Date(Date.now() + 3 * 86400000).toISOString().split('T')[0];

      const [
        { count: projectCount },
        { count: activeProjectCount },
        { count: teamCount },
        { count: taskCount },
        { count: pendingCount },
        { count: completedCount },
        { data: overdueData },
        { data: recentData },
        { data: upcomingData },
      ] = await Promise.all([
        supabase.from('projects').select('*', { count: 'exact', head: true }),
        supabase.from('projects').select('*', { count: 'exact', head: true }).eq('status', 'active'),
        supabase.from('team_members').select('*', { count: 'exact', head: true }).eq('is_active', true),
        supabase.from('tasks').select('*', { count: 'exact', head: true }),
        supabase.from('tasks').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('tasks').select('*', { count: 'exact', head: true }).eq('status', 'completed'),
        // All overdue (not just top 5) for the dashboard panel
        supabase
          .from('tasks')
          .select('*, projects(*), team_members(*)')
          .lt('due_date', today)
          .not('status', 'in', '("completed","cancelled")')
          .order('due_date', { ascending: true }),
        supabase
          .from('tasks')
          .select('*, projects(*), team_members(*)')
          .order('created_at', { ascending: false })
          .limit(5),
        // Tasks due in next 3 days (today inclusive), not yet completed/cancelled
        supabase
          .from('tasks')
          .select('*, projects(*), team_members(*)')
          .gte('due_date', today)
          .lte('due_date', in3days)
          .not('status', 'in', '("completed","cancelled")')
          .order('due_date', { ascending: true }),
      ]);

      setStats({
        totalProjects: projectCount || 0,
        activeProjects: activeProjectCount || 0,
        totalTeamMembers: teamCount || 0,
        totalTasks: taskCount || 0,
        pendingTasks: pendingCount || 0,
        overdueTasks: overdueData?.length || 0,
        completedTasks: completedCount || 0,
      });

      setOverdueTasks((overdueData as TaskWithDetails[]) || []);
      setRecentTasks((recentData as TaskWithDetails[]) || []);
      setUpcomingTasks((upcomingData as TaskWithDetails[]) || []);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    }

    setLoading(false);
  }, [user]);

  useEffect(() => { fetchDashboardData(); }, [fetchDashboardData]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500" />
      </div>
    );
  }

  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Overview of your team's projects and tasks</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div
            className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 cursor-pointer hover:shadow-xl transition-shadow"
            onClick={() => onNavigate('projects')}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
                <FolderKanban className="w-6 h-6 text-white" />
              </div>
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-sm text-gray-600 mb-1">Active Projects</p>
            <p className="text-3xl font-bold text-gray-900">{stats.activeProjects}</p>
            <p className="text-sm text-gray-500 mt-2">of {stats.totalProjects} total</p>
          </div>

          <div
            className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 cursor-pointer hover:shadow-xl transition-shadow"
            onClick={() => onNavigate('team')}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
            </div>
            <p className="text-sm text-gray-600 mb-1">Team Members</p>
            <p className="text-3xl font-bold text-gray-900">{stats.totalTeamMembers}</p>
            <p className="text-sm text-gray-500 mt-2">Active members</p>
          </div>

          <div
            className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 cursor-pointer hover:shadow-xl transition-shadow"
            onClick={() => onNavigate('tasks')}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-xl flex items-center justify-center">
                <Clock className="w-6 h-6 text-white" />
              </div>
            </div>
            <p className="text-sm text-gray-600 mb-1">Pending Tasks</p>
            <p className="text-3xl font-bold text-gray-900">{stats.pendingTasks}</p>
            <p className="text-sm text-gray-500 mt-2">of {stats.totalTasks} total</p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-pink-600 rounded-xl flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-white" />
              </div>
            </div>
            <p className="text-sm text-gray-600 mb-1">Overdue Tasks</p>
            <p className="text-3xl font-bold text-red-600">{stats.overdueTasks}</p>
            <p className="text-sm text-gray-500 mt-2">Need attention</p>
          </div>
        </div>

        {/* ── Upcoming Tasks (Next 3 Days) ── */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 mb-6">
          <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-gradient-to-br from-teal-500 to-blue-600 rounded-xl flex items-center justify-center">
                <CalendarClock className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-gray-900">Upcoming Tasks</h2>
                <p className="text-xs text-gray-500">Tasks due in the next 3 days</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {upcomingTasks.length > 0 && (
                <span className="flex items-center gap-1.5 px-3 py-1 bg-teal-100 text-teal-700 text-xs font-semibold rounded-full">
                  <Calendar className="w-3.5 h-3.5" />
                  {upcomingTasks.length} task{upcomingTasks.length !== 1 ? 's' : ''}
                </span>
              )}
              <button
                onClick={() => onNavigate('tasks')}
                className="flex items-center gap-1 text-sm text-teal-600 hover:text-teal-700 font-medium"
              >
                View All
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {upcomingTasks.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle2 className="w-12 h-12 text-green-400 mx-auto mb-3" />
              <p className="text-gray-600 font-medium">Nothing due in the next 3 days.</p>
              <p className="text-sm text-gray-400 mt-1">Enjoy the clear schedule!</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-50">
              {upcomingTasks.map((task) => {
                const isToday = task.due_date === today;
                const label = dayLabel(task.due_date, today);
                return (
                  <div
                    key={task.id}
                    className={`flex items-start gap-4 px-6 py-4 hover:bg-gray-50 transition-colors border-l-4 ${
                      PRIORITY_LEFT[task.priority] ?? 'border-l-gray-200'
                    }`}
                  >
                    <div
                      className={`flex-shrink-0 w-20 text-center px-2 py-1.5 rounded-lg text-xs font-semibold leading-tight ${
                        isToday ? 'bg-teal-100 text-teal-700' : 'bg-blue-50 text-blue-700'
                      }`}
                    >
                      <div className="text-[10px] font-normal opacity-75 mb-0.5">{fmtDate(task.due_date)}</div>
                      <div>{label}</div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="font-semibold text-gray-900 leading-snug text-sm">{task.title}</p>
                          <p className="text-xs text-gray-500 mt-0.5">
                            {task.projects?.name}
                            {task.team_members && (
                              <span className="ml-2 text-gray-400">· {task.team_members.name}</span>
                            )}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <span className={`text-xs font-semibold capitalize ${PRIORITY_TEXT[task.priority] ?? 'text-gray-500'}`}>
                            {task.priority}
                          </span>
                          <span className={`px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLORS[task.status] ?? 'bg-gray-100 text-gray-700'}`}>
                            {statusLabel(task.status)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Content Grid — Overdue + Recent */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Overdue Tasks */}
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-500" />
                <h2 className="text-lg font-semibold text-gray-900">Overdue Tasks</h2>
              </div>
              <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm font-medium">
                {overdueTasks.length}
              </span>
            </div>

            {overdueTasks.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-3" />
                <p className="text-gray-500">No overdue tasks. Great job!</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                {overdueTasks.map((task) => (
                  <div key={task.id} className="p-4 bg-red-50 rounded-xl border border-red-100">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-medium text-gray-900 text-sm">{task.title}</h3>
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLORS[task.status] ?? 'bg-gray-100 text-gray-700'}`}>
                        {statusLabel(task.status)}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{task.projects?.name}</p>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-red-600 flex items-center gap-1 text-xs">
                        <Calendar className="w-3.5 h-3.5" />
                        {fmtDate(task.due_date)}
                      </span>
                      {task.team_members && (
                        <span className="text-gray-500 text-xs">{task.team_members.name}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent Tasks */}
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-gray-600" />
                <h2 className="text-lg font-semibold text-gray-900">Recent Tasks</h2>
              </div>
              <button
                onClick={() => onNavigate('tasks')}
                className="text-sm text-teal-600 hover:text-teal-700 font-medium"
              >
                View All
              </button>
            </div>

            {recentTasks.length === 0 ? (
              <div className="text-center py-8">
                <ClipboardList className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No tasks yet. Create your first task!</p>
              </div>
            ) : (
              <div className="space-y-3">
                {recentTasks.map((task) => (
                  <div key={task.id} className="p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-medium text-gray-900 text-sm">{task.title}</h3>
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLORS[task.status] ?? 'bg-gray-100 text-gray-700'}`}>
                        {statusLabel(task.status)}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{task.projects?.name}</p>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-500 flex items-center gap-1 text-xs">
                        <Calendar className="w-3.5 h-3.5" />
                        {fmtDate(task.due_date)}
                      </span>
                      <span className={`text-xs font-medium capitalize ${PRIORITY_TEXT[task.priority] ?? 'text-gray-500'}`}>
                        {task.priority}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
