import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useExchangeRates } from '../hooks/useExchangeRates';
import { formatCurrency, convertCurrency, SUPPORTED_CURRENCIES, DEFAULT_CURRENCY } from '../lib/currency';
import { PieChart, Loader2, TrendingUp, TrendingDown, Activity, RefreshCw } from 'lucide-react';

type CategoryLine = { id: string; name: string; type: 'income' | 'expense'; total: number };

const QUARTERS = [
  { label: 'Q1', months: [1, 2, 3] },
  { label: 'Q2', months: [4, 5, 6] },
  { label: 'Q3', months: [7, 8, 9] },
  { label: 'Q4', months: [10, 11, 12] },
];

export function AccountsProfitLoss() {
  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [period, setPeriod] = useState<'annual' | 'Q1' | 'Q2' | 'Q3' | 'Q4'>('annual');
  const [lines, setLines] = useState<CategoryLine[]>([]);
  const [loading, setLoading] = useState(true);

  const { rates, loading: ratesLoading, lastUpdated } = useExchangeRates();
  const [displayCurrency, setDisplayCurrency] = useState(DEFAULT_CURRENCY);

  const fetchData = useCallback(async () => {
    setLoading(true);
    let from: string, to: string;
    if (period === 'annual') {
      from = `${year}-01-01`; to = `${year}-12-31`;
    } else {
      const q = QUARTERS.find((q) => q.label === period)!;
      const m1 = String(q.months[0]).padStart(2, '0');
      const m3 = q.months[2];
      const lastDay = new Date(year, m3, 0).getDate();
      from = `${year}-${m1}-01`;
      to = `${year}-${String(m3).padStart(2, '0')}-${lastDay}`;
    }

    const { data: txns } = await supabase
      .from('transactions')
      .select('amount, category:categories(id,name,type)')
      .gte('date', from)
      .lte('date', to);

    const catAgg = new Map<string, CategoryLine>();
    for (const t of (txns ?? []) as any[]) {
      const cat = t.category;
      if (!cat) continue;
      if (!catAgg.has(cat.id)) catAgg.set(cat.id, { id: cat.id, name: cat.name, type: cat.type, total: 0 });
      catAgg.get(cat.id)!.total += t.amount;
    }
    setLines([...catAgg.values()].sort((a, b) => b.total - a.total));
    setLoading(false);
  }, [year, period]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const income  = lines.filter((l) => l.type === 'income');
  const expense = lines.filter((l) => l.type === 'expense');
  const totalIncome  = income.reduce((s, l) => s + l.total, 0);
  const totalExpense = expense.reduce((s, l) => s + l.total, 0);
  const grossProfit  = totalIncome - totalExpense;

  const years = Array.from({ length: 5 }, (_, i) => today.getFullYear() - 2 + i);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-bold text-gray-900 text-lg">Profit & Loss</h3>
          <p className="text-sm text-gray-500 mt-0.5">Revenue, costs, and net result by period</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <select value={year} onChange={(e) => setYear(Number(e.target.value))}
            className="px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400">
            {years.map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
          {(['annual', 'Q1', 'Q2', 'Q3', 'Q4'] as const).map((p) => (
            <button key={p} onClick={() => setPeriod(p)}
              className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all ${period === p ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-gray-600 border-gray-200 hover:border-teal-300'}`}>
              {p === 'annual' ? 'Annual' : p}
            </button>
          ))}
          <div className="flex items-center gap-2">
            {!ratesLoading && lastUpdated && (
              <span className="text-xs text-gray-400 flex items-center gap-1">
                <RefreshCw className="w-3 h-3" />Live rates
              </span>
            )}
            <select value={displayCurrency} onChange={(e) => setDisplayCurrency(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-teal-400 bg-white">
              {SUPPORTED_CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl border border-emerald-100 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="w-4 h-4 text-emerald-500" />
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Total Revenue</p>
          </div>
          <p className="text-2xl font-bold text-emerald-600">{loading ? '—' : formatCurrency(totalIncome, displayCurrency)}</p>
        </div>
        <div className="bg-white rounded-2xl border border-rose-100 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-1">
            <TrendingDown className="w-4 h-4 text-rose-500" />
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Total Costs</p>
          </div>
          <p className="text-2xl font-bold text-rose-600">{loading ? '—' : formatCurrency(totalExpense, displayCurrency)}</p>
        </div>
        <div className={`bg-white rounded-2xl border shadow-sm p-5 ${grossProfit >= 0 ? 'border-teal-100' : 'border-orange-100'}`}>
          <div className="flex items-center gap-2 mb-1">
            <Activity className={`w-4 h-4 ${grossProfit >= 0 ? 'text-teal-500' : 'text-orange-500'}`} />
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Net Result</p>
          </div>
          <p className={`text-2xl font-bold ${grossProfit >= 0 ? 'text-teal-600' : 'text-orange-600'}`}>{loading ? '—' : formatCurrency(grossProfit, displayCurrency)}</p>
          {!loading && totalIncome > 0 && (
            <p className="text-xs text-gray-400 mt-1">
              {((grossProfit / totalIncome) * 100).toFixed(1)}% margin
            </p>
          )}
        </div>
      </div>

      {loading ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-12 flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-teal-500" />
        </div>
      ) : lines.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-14 text-center">
          <PieChart className="w-12 h-12 text-gray-200 mx-auto mb-3" />
          <p className="font-semibold text-gray-500">No data for this period</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Revenue */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-50 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-500" />
              <h4 className="font-bold text-gray-800 text-sm">Revenue</h4>
              <span className="ml-auto font-bold text-emerald-600 text-sm">{formatCurrency(totalIncome, displayCurrency)}</span>
            </div>
            {income.length === 0 ? (
              <p className="px-5 py-6 text-sm text-gray-400 text-center">No income entries</p>
            ) : (
              <table className="w-full text-sm">
                <tbody className="divide-y divide-gray-50">
                  {income.map((l) => (
                    <tr key={l.id} className="hover:bg-emerald-50/30 transition-colors">
                      <td className="px-5 py-3 text-gray-700">{l.name}</td>
                      <td className="px-5 py-3 text-right font-semibold text-emerald-600">{formatCurrency(l.total, displayCurrency)}</td>
                      <td className="px-5 py-3 text-right text-xs text-gray-400 w-16">
                        {totalIncome > 0 ? `${((l.total / totalIncome) * 100).toFixed(0)}%` : ''}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* Costs */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-50 flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-rose-500" />
              <h4 className="font-bold text-gray-800 text-sm">Costs & Expenses</h4>
              <span className="ml-auto font-bold text-rose-600 text-sm">{formatCurrency(totalExpense, displayCurrency)}</span>
            </div>
            {expense.length === 0 ? (
              <p className="px-5 py-6 text-sm text-gray-400 text-center">No expense entries</p>
            ) : (
              <table className="w-full text-sm">
                <tbody className="divide-y divide-gray-50">
                  {expense.map((l) => (
                    <tr key={l.id} className="hover:bg-rose-50/30 transition-colors">
                      <td className="px-5 py-3 text-gray-700">{l.name}</td>
                      <td className="px-5 py-3 text-right font-semibold text-rose-600">{formatCurrency(l.total, displayCurrency)}</td>
                      <td className="px-5 py-3 text-right text-xs text-gray-400 w-16">
                        {totalExpense > 0 ? `${((l.total / totalExpense) * 100).toFixed(0)}%` : ''}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

      {/* P&L Summary */}
      {!loading && lines.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="px-5 py-4 bg-gray-50 border-b border-gray-100">
            <h4 className="font-bold text-gray-800 text-sm">P&L Summary</h4>
          </div>
          <div className="divide-y divide-gray-50">
            <div className="flex justify-between px-5 py-3 text-sm">
              <span className="text-gray-600">Total Revenue</span>
              <span className="font-semibold text-emerald-600">{formatCurrency(totalIncome, displayCurrency)}</span>
            </div>
            <div className="flex justify-between px-5 py-3 text-sm">
              <span className="text-gray-600">Total Expenses</span>
              <span className="font-semibold text-rose-600">({formatCurrency(totalExpense, displayCurrency)})</span>
            </div>
            <div className={`flex justify-between px-5 py-4 text-base font-bold border-t-2 border-gray-200 ${grossProfit >= 0 ? 'bg-teal-50/40' : 'bg-orange-50/40'}`}>
              <span className={grossProfit >= 0 ? 'text-teal-700' : 'text-orange-700'}>Net {grossProfit >= 0 ? 'Profit' : 'Loss'}</span>
              <span className={grossProfit >= 0 ? 'text-teal-700' : 'text-orange-700'}>{formatCurrency(grossProfit, displayCurrency)}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
