import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import {
  BarChart3, Download, Loader2, Search, X, Filter,
  Clock, Users, FolderKanban, AlertCircle, Timer, TrendingUp,
  Plane, Stethoscope, Star, RotateCcw, CheckCircle2,
} from 'lucide-react';
import { WorkforceExportModal } from './WorkforceExportModal';

type ProjectSummary = {
  project_id: string;
  project_name: string;
  employee_count: number;
  total_hours: number;
  regular_hours: number;
  ot_hours: number;
  entry_count: number;
};

type EmployeeSummary = {
  employee_id: string;
  employee_code: string;
  employee_name: string;
  designation: string | null;
  total_hours: number;
  regular_hours: number;
  ot_hours: number;
  days_worked: number;
  days_leave: number;
  days_sick: number;
  days_public_holiday: number;
  days_annual_leave: number;
  days_compensation_leave: number;
};

type WorkScheduleDay = { day_of_week: number; normal_hours: number };
type ProjectWeeklyRow = { project_id: string; day_of_week: number; normal_hours: number };
type DateOverride = { date_from: string; date_to: string; normal_hours: number; project_id: string | null };

type AuditLog = {
  id: string;
  action: 'INSERT' | 'UPDATE' | 'DELETE';
  entity_type: string;
  entity_label: string | null;
  performed_by_name: string | null;
  performed_at: string;
};

function fmtDate(d: string) {
  if (!d) return '';
  const [y, m, day] = d.split('T')[0].split('-');
  return `${day}/${m}/${y}`;
}

function fmtDateTime(d: string) {
  if (!d) return '';
  const date = new Date(d);
  return date.toLocaleString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export function WorkforceReports() {
  const { isAdmin } = useAuth();

  const today = new Date().toISOString().split('T')[0];
  const firstOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];

  const [activeSection, setActiveSection] = useState<'normal' | 'overtime' | 'combined' | 'audit'>('normal');
  const [showExport, setShowExport] = useState(false);
  const [dateFrom, setDateFrom]     = useState(firstOfMonth);
  const [dateTo, setDateTo]         = useState(today);
  const [filterProject, setFilterProject] = useState('all');
  const [projects, setProjects]     = useState<{ id: string; name: string }[]>([]);
  const [projectSummary, setProjectSummary] = useState<ProjectSummary[]>([]);
  const [empSummary, setEmpSummary] = useState<EmployeeSummary[]>([]);
  const [auditLogs, setAuditLogs]   = useState<AuditLog[]>([]);
  const [loading, setLoading]       = useState(false);
  const [auditSearch, setAuditSearch] = useState('');
  const [workSchedule, setWorkSchedule] = useState<WorkScheduleDay[]>([]);
  const [projectWeekly, setProjectWeekly] = useState<ProjectWeeklyRow[]>([]);
  const [dateOverrides, setDateOverrides] = useState<DateOverride[]>([]);

  useEffect(() => {
    supabase.from('projects').select('id,name').order('name').then(({ data }) => setProjects(data ?? []));
    Promise.all([
      supabase.from('work_schedule').select('day_of_week,normal_hours'),
      supabase.from('work_schedule_project_weekly').select('project_id,day_of_week,normal_hours'),
      supabase.from('work_schedule_date_overrides').select('date_from,date_to,normal_hours,project_id'),
    ]).then(([ws, pw, do_]) => {
      if (ws.data) setWorkSchedule(ws.data as WorkScheduleDay[]);
      if (pw.data) setProjectWeekly(pw.data as ProjectWeeklyRow[]);
      if (do_.data) setDateOverrides(do_.data as DateOverride[]);
    });
  }, []);

  const getNormalHours = useCallback((dateStr: string, projectId: string | null): number => {
    const dow = new Date(dateStr + 'T00:00:00').getDay();
    const dateMatch = (ov: DateOverride) => dateStr >= ov.date_from && dateStr <= ov.date_to;
    const pdOv = dateOverrides.find((ov) => dateMatch(ov) && ov.project_id === projectId);
    if (pdOv) return pdOv.normal_hours;
    const gdOv = dateOverrides.find((ov) => dateMatch(ov) && !ov.project_id);
    if (gdOv) return gdOv.normal_hours;
    if (projectId) {
      const pw = projectWeekly.find((r) => r.project_id === projectId && r.day_of_week === dow);
      if (pw) return pw.normal_hours;
    }
    return workSchedule.find((s) => s.day_of_week === dow)?.normal_hours ?? 0;
  }, [workSchedule, projectWeekly, dateOverrides]);

  const fetchReports = useCallback(async () => {
    setLoading(true);

    let q = supabase
      .from('workforce_daily_allocations')
      .select('project_id, employee_id, entry_date, start_time, end_time, break_minutes, attendance_status, projects(name), employee:workforce_employees(id,employee_code,name,designation)')
      .gte('entry_date', dateFrom)
      .lte('entry_date', dateTo);

    if (filterProject !== 'all') q = q.eq('project_id', filterProject);

    const { data } = await q;
    const rows = (data ?? []) as any[];

    // Pass 1: compute raw hours per row
    const rawRows = rows.map((r) => {
      const status = r.attendance_status ?? 'present';
      let hrs = 0;
      if (status === 'present' && r.start_time && r.end_time) {
        const [sh, sm] = r.start_time.split(':').map(Number);
        const [eh, em] = r.end_time.split(':').map(Number);
        const mins = (eh * 60 + em) - (sh * 60 + sm) - (r.break_minutes ?? 0);
        hrs = mins > 0 ? Math.round(mins * 100 / 60) / 100 : 0;
      }
      return { ...r, hrs, status };
    });

    // Project summary: per-row OT vs project-specific schedule (unchanged)
    const projMap = new Map<string, ProjectSummary>();
    const projEmpMap = new Map<string, Set<string>>();
    for (const r of rawRows) {
      const normalHrs = getNormalHours(r.entry_date, r.project_id ?? null);
      const regular = Math.round(Math.min(r.hrs, normalHrs) * 100) / 100;
      const ot      = Math.round(Math.max(0, r.hrs - normalHrs) * 100) / 100;
      const existing = projMap.get(r.project_id);
      if (existing) {
        existing.total_hours   += r.hrs;
        existing.regular_hours += regular;
        existing.ot_hours      += ot;
        existing.entry_count   += 1;
      } else {
        projMap.set(r.project_id, {
          project_id: r.project_id,
          project_name: r.projects?.name ?? 'Unknown',
          employee_count: 1,
          total_hours: r.hrs,
          regular_hours: regular,
          ot_hours: ot,
          entry_count: 1,
        });
      }
      if (!projEmpMap.has(r.project_id)) projEmpMap.set(r.project_id, new Set());
      projEmpMap.get(r.project_id)!.add(r.employee_id);
    }
    projMap.forEach((v, k) => { v.employee_count = projEmpMap.get(k)?.size ?? 0; });
    setProjectSummary(Array.from(projMap.values()).sort((a, b) => b.total_hours - a.total_hours));

    // Employee summary: OT calculated on total daily hours across ALL projects.
    // When a project filter is active, also fetch hours from other projects so the
    // daily threshold is applied correctly.
    const presentRows = rawRows.filter((r) => r.status === 'present' && r.hrs > 0);
    const crossHrsMap = new Map<string, number>(); // "empId::date" -> hours at OTHER projects

    if (filterProject !== 'all' && presentRows.length > 0) {
      const empIds = [...new Set(presentRows.map((r: any) => r.employee_id as string))];
      const { data: crossData } = await supabase
        .from('workforce_daily_allocations')
        .select('employee_id, entry_date, start_time, end_time, break_minutes')
        .gte('entry_date', dateFrom)
        .lte('entry_date', dateTo)
        .neq('project_id', filterProject)
        .eq('attendance_status', 'present')
        .in('employee_id', empIds);
      for (const c of (crossData ?? []) as any[]) {
        if (!c.start_time || !c.end_time) continue;
        const [sh, sm] = c.start_time.split(':').map(Number);
        const [eh, em] = c.end_time.split(':').map(Number);
        const mins = (eh * 60 + em) - (sh * 60 + sm) - (c.break_minutes ?? 0);
        const h = mins > 0 ? Math.round(mins * 100 / 60) / 100 : 0;
        const key = `${c.employee_id}::${c.entry_date}`;
        crossHrsMap.set(key, Math.round(((crossHrsMap.get(key) ?? 0) + h) * 100) / 100);
      }
    }

    // Build per-employee-day totals (including cross-project hours when filtered)
    const dayTotalMap = new Map<string, number>(); // "empId::date" -> total hours that day
    for (const r of presentRows) {
      const key = `${r.employee_id}::${r.entry_date}`;
      dayTotalMap.set(key, Math.round(((dayTotalMap.get(key) ?? 0) + r.hrs) * 100) / 100);
    }
    // Add cross-project hours to day totals
    for (const [key, crossHrs] of crossHrsMap) {
      dayTotalMap.set(key, Math.round(((dayTotalMap.get(key) ?? 0) + crossHrs) * 100) / 100);
    }

    // Compute reg/OT per employee-day using global (cross-project) schedule
    const dayRegOTMap = new Map<string, { regular: number; ot: number; thisProjectHrs: number }>();
    for (const r of presentRows) {
      const key = `${r.employee_id}::${r.entry_date}`;
      if (dayRegOTMap.has(key)) continue; // already computed for this employee-day
      const totalHrs = dayTotalMap.get(key) ?? r.hrs;
      const normalHrs = getNormalHours(r.entry_date, null); // global schedule for cross-project OT
      const dayReg = Math.round(Math.min(totalHrs, normalHrs) * 100) / 100;
      const dayOT  = Math.round(Math.max(0, totalHrs - normalHrs) * 100) / 100;

      // When a project is filtered, attribute only this project's proportional share of reg/OT
      const crossHrs = crossHrsMap.get(key) ?? 0;
      let regular: number;
      let ot: number;
      if (filterProject !== 'all' && crossHrs > 0) {
        // Use splitHoursForProject logic: cross-project hours consume regular capacity first
        const remainingNormal = Math.max(0, normalHrs - Math.min(crossHrs, normalHrs));
        const projHrs = (dayTotalMap.get(key) ?? 0) - crossHrs;
        regular = Math.round(Math.min(projHrs, remainingNormal) * 100) / 100;
        ot      = Math.round(Math.max(0, projHrs - remainingNormal) * 100) / 100;
      } else {
        regular = dayReg;
        ot      = dayOT;
      }
      dayRegOTMap.set(key, { regular, ot, thisProjectHrs: r.hrs });
    }

    // Accumulate employee summary — each employee-day counted exactly once for hours/OT
    const empMap = new Map<string, EmployeeSummary>();
    const processedDays = new Set<string>();

    for (const r of rawRows) {
      const empKey = r.employee_id;
      const dKey   = `${r.employee_id}::${r.entry_date}`;

      if (!empMap.has(empKey)) {
        empMap.set(empKey, {
          employee_id: empKey,
          employee_code: r.employee?.employee_code ?? '',
          employee_name: r.employee?.name ?? 'Unknown',
          designation: r.employee?.designation ?? null,
          total_hours: 0,
          regular_hours: 0,
          ot_hours: 0,
          days_worked: 0,
          days_leave: 0,
          days_sick: 0,
          days_public_holiday: 0,
          days_annual_leave: 0,
          days_compensation_leave: 0,
        });
      }

      const emp = empMap.get(empKey)!;

      if (r.status === 'present') {
        if (!processedDays.has(dKey)) {
          processedDays.add(dKey);
          const dayData = dayRegOTMap.get(dKey);
          if (dayData) {
            // total_hours shows only hours in this dataset (not cross-project hours)
            const projHrs = (dayTotalMap.get(dKey) ?? 0) - (crossHrsMap.get(dKey) ?? 0);
            emp.total_hours   = Math.round((emp.total_hours   + projHrs)       * 100) / 100;
            emp.regular_hours = Math.round((emp.regular_hours + dayData.regular) * 100) / 100;
            emp.ot_hours      = Math.round((emp.ot_hours      + dayData.ot)      * 100) / 100;
          }
          emp.days_worked += 1;
        }
      } else {
        const leaveKey = `${dKey}::${r.status}`;
        if (!processedDays.has(leaveKey)) {
          processedDays.add(leaveKey);
          if (r.status === 'leave')                  emp.days_leave             += 1;
          else if (r.status === 'sick_leave')         emp.days_sick              += 1;
          else if (r.status === 'public_holiday')     emp.days_public_holiday    += 1;
          else if (r.status === 'annual_leave')       emp.days_annual_leave      += 1;
          else if (r.status === 'compensation_leave') emp.days_compensation_leave += 1;
        }
      }
    }
    setEmpSummary(Array.from(empMap.values()).sort((a, b) => b.total_hours - a.total_hours));

    if (isAdmin) {
      const { data: logs } = await supabase
        .from('workforce_audit_logs')
        .select('id,action,entity_type,entity_label,performed_by_name,performed_at')
        .order('performed_at', { ascending: false })
        .limit(200);
      setAuditLogs((logs ?? []) as AuditLog[]);
    }

    setLoading(false);
  }, [dateFrom, dateTo, filterProject, isAdmin, getNormalHours]);

  useEffect(() => { fetchReports(); }, [fetchReports]);

  const totalHours    = empSummary.reduce((s, e) => s + e.total_hours, 0);
  const totalEmp      = empSummary.length;
  const totalOTHours  = empSummary.reduce((s, e) => s + e.ot_hours, 0);
  const totalRegHours = empSummary.reduce((s, e) => s + e.regular_hours, 0);
  const totalEntries  = projectSummary.reduce((s, p) => s + p.entry_count, 0);

  const exportNormalCSV = () => {
    const header = ['#', 'Employee', 'Code', 'Designation', 'Days Worked', 'Regular Hours', 'Leave', 'Sick', 'PH', 'AL', 'CL'];
    const rows = empSummary.map((e, i) => [
      i + 1,
      `"${e.employee_name.replace(/"/g, '""')}"`,
      e.employee_code,
      `"${(e.designation ?? '').replace(/"/g, '""')}"`,
      e.days_worked,
      e.regular_hours.toFixed(2),
      e.days_leave,
      e.days_sick,
      e.days_public_holiday,
      e.days_annual_leave,
      e.days_compensation_leave,
    ]);
    downloadCSV([header, ...rows], `normal-time-report-${dateFrom}-to-${dateTo}.csv`);
  };

  const exportOTCSV = () => {
    const header = ['#', 'Employee', 'Code', 'Designation', 'Days Worked', 'OT Hours'];
    const rows = empSummary.filter((e) => e.ot_hours > 0).map((e, i) => [
      i + 1,
      `"${e.employee_name.replace(/"/g, '""')}"`,
      e.employee_code,
      `"${(e.designation ?? '').replace(/"/g, '""')}"`,
      e.days_worked,
      e.ot_hours.toFixed(2),
    ]);
    downloadCSV([header, ...rows], `overtime-report-${dateFrom}-to-${dateTo}.csv`);
  };

  const exportCombinedCSV = () => {
    const header = ['#', 'Employee', 'Code', 'Designation', 'Days Worked', 'Regular Hours', 'OT Hours', 'Total Hours'];
    const rows = empSummary.map((e, i) => [
      i + 1,
      `"${e.employee_name.replace(/"/g, '""')}"`,
      e.employee_code,
      `"${(e.designation ?? '').replace(/"/g, '""')}"`,
      e.days_worked,
      e.regular_hours.toFixed(2),
      e.ot_hours.toFixed(2),
      e.total_hours.toFixed(2),
    ]);
    downloadCSV([header, ...rows], `combined-report-${dateFrom}-to-${dateTo}.csv`);
  };

  function downloadCSV(rows: (string | number)[][], filename: string) {
    const blob = new Blob([rows.map((r) => r.join(',')).join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  }

  const filteredLogs = auditLogs.filter((l) => {
    if (!auditSearch) return true;
    const q = auditSearch.toLowerCase();
    return (l.entity_label ?? '').toLowerCase().includes(q) ||
      (l.performed_by_name ?? '').toLowerCase().includes(q) ||
      l.action.toLowerCase().includes(q) ||
      l.entity_type.toLowerCase().includes(q);
  });

  const ACTION_STYLE: Record<string, string> = {
    INSERT: 'bg-green-100 text-green-700 border-green-200',
    UPDATE: 'bg-blue-100 text-blue-700 border-blue-200',
    DELETE: 'bg-red-100 text-red-700 border-red-200',
  };

  const SECTION_TABS = [
    { id: 'normal' as const, label: 'Normal Time', icon: Clock, color: 'teal' },
    { id: 'overtime' as const, label: 'Overtime', icon: Timer, color: 'orange' },
    { id: 'combined' as const, label: 'Combined (Normal + OT)', icon: TrendingUp, color: 'blue' },
    ...(isAdmin ? [{ id: 'audit' as const, label: 'Audit Log', icon: Search, color: 'gray' }] : []),
  ];

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-bold text-gray-900 text-lg">Workforce Reports</h3>
          <p className="text-sm text-gray-500 mt-0.5">Manpower utilization — Normal Time &amp; Overtime analysis</p>
        </div>
        <button
          onClick={() => setShowExport(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-teal-700 to-teal-500 text-white font-semibold rounded-xl text-sm shadow-sm hover:from-teal-800 hover:to-teal-600 transition-all"
        >
          <Download className="w-4 h-4" />Monthly Report Export
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white border border-gray-200 rounded-2xl p-4">
        <div className="flex flex-wrap gap-4 items-end">
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">From</label>
            <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">To</label>
            <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
          </div>
          <div className="flex-1 min-w-[180px]">
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Project</label>
            <select value={filterProject} onChange={(e) => setFilterProject(e.target.value)} className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400">
              <option value="all">All Projects</option>
              {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          <div className="flex items-end gap-2">
            <button onClick={fetchReports} className="flex items-center gap-1.5 px-4 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm hover:from-teal-600 hover:to-blue-700 transition-all">
              <Filter className="w-4 h-4" />Apply
            </button>
            <button onClick={() => { setDateFrom(firstOfMonth); setDateTo(today); setFilterProject('all'); }} className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50">
              Reset
            </button>
          </div>
        </div>
        <p className="text-xs text-gray-400 mt-2">
          {fmtDate(dateFrom)} — {fmtDate(dateTo)}
          {filterProject !== 'all' && ` · ${projects.find((p) => p.id === filterProject)?.name ?? ''}`}
        </p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-7 h-7 animate-spin text-teal-500" />
        </div>
      ) : (
        <>
          {/* KPI row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Regular Hours', value: totalRegHours.toFixed(1), icon: Clock, color: 'from-teal-500 to-blue-600' },
              { label: 'Overtime Hours', value: totalOTHours.toFixed(1), icon: Timer, color: 'from-orange-500 to-red-500' },
              { label: 'Unique Employees', value: totalEmp, icon: Users, color: 'from-blue-500 to-cyan-500' },
              { label: 'Projects Active', value: projectSummary.length, icon: FolderKanban, color: 'from-amber-500 to-orange-600' },
            ].map((card) => (
              <div key={card.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${card.color} flex items-center justify-center mb-3`}>
                  <card.icon className="w-5 h-5 text-white" />
                </div>
                <p className="text-2xl font-bold text-gray-900">{card.value}</p>
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mt-0.5">{card.label}</p>
              </div>
            ))}
          </div>

          {/* Section tabs */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-1.5 flex gap-1">
            {SECTION_TABS.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveSection(id)}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-sm font-semibold transition-all ${
                  activeSection === id
                    ? id === 'overtime'
                      ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-sm'
                      : id === 'combined'
                        ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white shadow-sm'
                        : id === 'audit'
                          ? 'bg-gradient-to-r from-gray-600 to-gray-700 text-white shadow-sm'
                          : 'bg-gradient-to-r from-teal-500 to-blue-600 text-white shadow-sm'
                    : 'text-gray-500 hover:text-gray-800 hover:bg-gray-50'
                }`}
              >
                <Icon className="w-4 h-4" />{label}
              </button>
            ))}
          </div>

          {empSummary.length === 0 ? (
            <div className="bg-white rounded-2xl border border-gray-100 p-14 text-center">
              <BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="font-semibold text-gray-600">No data for selected period</p>
              <p className="text-sm text-gray-400 mt-1">Adjust the date range or create some daily allocations first.</p>
            </div>
          ) : (
            <>
              {/* ── Normal Time Report ── */}
              {activeSection === 'normal' && (
                <div className="space-y-5">
                  {/* Project breakdown */}
                  <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                    <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between gap-3">
                      <div>
                        <h4 className="font-bold text-gray-900">Regular Hours by Project</h4>
                        <p className="text-xs text-gray-400 mt-0.5">{projectSummary.length} project{projectSummary.length !== 1 ? 's' : ''} · {totalEntries} records</p>
                      </div>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-gray-50 border-b border-gray-100">
                            {['Project', 'Employees', 'Records', 'Regular Hrs', 'OT Hrs', 'Total Hrs'].map((h) => (
                              <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                          {projectSummary.map((p) => (
                            <tr key={p.project_id} className="hover:bg-gray-50/50">
                              <td className="px-4 py-3 font-semibold text-gray-900">{p.project_name}</td>
                              <td className="px-4 py-3 text-gray-600">{p.employee_count}</td>
                              <td className="px-4 py-3 text-gray-600">{p.entry_count}</td>
                              <td className="px-4 py-3">
                                <div className="flex items-center gap-2">
                                  <div className="flex-1 bg-teal-100 rounded-full h-1.5 max-w-[60px]">
                                    <div className="bg-teal-500 rounded-full h-1.5" style={{ width: `${Math.min(100, (p.regular_hours / Math.max(...projectSummary.map((x) => x.total_hours))) * 100)}%` }} />
                                  </div>
                                  <span className="font-semibold text-teal-700">{p.regular_hours.toFixed(1)}h</span>
                                </div>
                              </td>
                              <td className="px-4 py-3">
                                {p.ot_hours > 0
                                  ? <span className="font-semibold text-orange-600">{p.ot_hours.toFixed(1)}h</span>
                                  : <span className="text-gray-300">—</span>}
                              </td>
                              <td className="px-4 py-3 font-bold text-gray-900">{p.total_hours.toFixed(1)}h</td>
                            </tr>
                          ))}
                        </tbody>
                        <tfoot>
                          <tr className="bg-gradient-to-r from-teal-50 to-blue-50 border-t-2 border-teal-100">
                            <td colSpan={3} className="px-4 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wide">Totals</td>
                            <td className="px-4 py-3 font-bold text-teal-800">{totalRegHours.toFixed(1)}h</td>
                            <td className="px-4 py-3 font-bold text-orange-700">{totalOTHours.toFixed(1)}h</td>
                            <td className="px-4 py-3 font-bold text-gray-900">{totalHours.toFixed(1)}h</td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </div>

                  {/* Employee Normal Time */}
                  <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                    <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between gap-3 flex-wrap">
                      <div>
                        <h4 className="font-bold text-gray-900">Normal Time — Employee Detail</h4>
                        <p className="text-xs text-gray-400 mt-0.5">{empSummary.length} employees · attendance breakdown included</p>
                      </div>
                      <button onClick={exportNormalCSV} className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 text-gray-600 font-medium rounded-xl text-sm hover:border-teal-300 hover:text-teal-600 transition-all">
                        <Download className="w-4 h-4" />Export
                      </button>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-gray-50 border-b border-gray-100">
                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">#</th>
                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Employee</th>
                            <th className="px-4 py-2.5 text-right text-xs font-semibold text-teal-600 uppercase tracking-wide whitespace-nowrap">Reg Hrs</th>
                            <th className="px-4 py-2.5 text-center text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">
                              <span className="flex items-center justify-center gap-1"><CheckCircle2 className="w-3 h-3 text-teal-500" />Present</span>
                            </th>
                            <th className="px-4 py-2.5 text-center text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">
                              <span className="flex items-center justify-center gap-1"><X className="w-3 h-3 text-gray-400" />Leave</span>
                            </th>
                            <th className="px-4 py-2.5 text-center text-xs font-semibold text-red-500 uppercase tracking-wide whitespace-nowrap">
                              <span className="flex items-center justify-center gap-1"><Stethoscope className="w-3 h-3" />Sick</span>
                            </th>
                            <th className="px-4 py-2.5 text-center text-xs font-semibold text-blue-500 uppercase tracking-wide whitespace-nowrap">
                              <span className="flex items-center justify-center gap-1"><Star className="w-3 h-3" />PH</span>
                            </th>
                            <th className="px-4 py-2.5 text-center text-xs font-semibold text-amber-600 uppercase tracking-wide whitespace-nowrap">
                              <span className="flex items-center justify-center gap-1"><Plane className="w-3 h-3" />AL</span>
                            </th>
                            <th className="px-4 py-2.5 text-center text-xs font-semibold text-purple-600 uppercase tracking-wide whitespace-nowrap">
                              <span className="flex items-center justify-center gap-1"><RotateCcw className="w-3 h-3" />CL</span>
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                          {empSummary.map((e, idx) => (
                            <tr key={e.employee_id} className="hover:bg-gray-50/50">
                              <td className="px-4 py-3 text-gray-400 text-xs">{idx + 1}</td>
                              <td className="px-4 py-3">
                                <p className="font-semibold text-gray-900">{e.employee_name}</p>
                                <p className="text-xs text-gray-400">{e.employee_code}{e.designation ? ` · ${e.designation}` : ''}</p>
                              </td>
                              <td className="px-4 py-3 text-right"><span className="font-semibold text-teal-700">{e.regular_hours.toFixed(1)}h</span></td>
                              <td className="px-4 py-3 text-center text-gray-700 font-medium">{e.days_worked}</td>
                              <td className="px-4 py-3 text-center">{e.days_leave > 0 ? <span className="font-medium text-gray-600">{e.days_leave}</span> : <span className="text-gray-200">—</span>}</td>
                              <td className="px-4 py-3 text-center">{e.days_sick > 0 ? <span className="font-medium text-red-600">{e.days_sick}</span> : <span className="text-gray-200">—</span>}</td>
                              <td className="px-4 py-3 text-center">{e.days_public_holiday > 0 ? <span className="font-medium text-blue-600">{e.days_public_holiday}</span> : <span className="text-gray-200">—</span>}</td>
                              <td className="px-4 py-3 text-center">{e.days_annual_leave > 0 ? <span className="font-medium text-amber-600">{e.days_annual_leave}</span> : <span className="text-gray-200">—</span>}</td>
                              <td className="px-4 py-3 text-center">{e.days_compensation_leave > 0 ? <span className="font-medium text-purple-600">{e.days_compensation_leave}</span> : <span className="text-gray-200">—</span>}</td>
                            </tr>
                          ))}
                        </tbody>
                        {empSummary.length > 0 && (
                          <tfoot>
                            <tr className="bg-gradient-to-r from-teal-50 to-blue-50 border-t-2 border-teal-100">
                              <td colSpan={2} className="px-4 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wide">Totals</td>
                              <td className="px-4 py-3 text-right font-bold text-teal-800">{totalRegHours.toFixed(1)}h</td>
                              <td className="px-4 py-3 text-center font-bold text-gray-700">{empSummary.reduce((s, e) => s + e.days_worked, 0)}</td>
                              <td className="px-4 py-3 text-center font-bold text-gray-600">{empSummary.reduce((s, e) => s + e.days_leave, 0) || '—'}</td>
                              <td className="px-4 py-3 text-center font-bold text-red-600">{empSummary.reduce((s, e) => s + e.days_sick, 0) || '—'}</td>
                              <td className="px-4 py-3 text-center font-bold text-blue-600">{empSummary.reduce((s, e) => s + e.days_public_holiday, 0) || '—'}</td>
                              <td className="px-4 py-3 text-center font-bold text-amber-600">{empSummary.reduce((s, e) => s + e.days_annual_leave, 0) || '—'}</td>
                              <td className="px-4 py-3 text-center font-bold text-purple-600">{empSummary.reduce((s, e) => s + e.days_compensation_leave, 0) || '—'}</td>
                            </tr>
                          </tfoot>
                        )}
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* ── Overtime Report ── */}
              {activeSection === 'overtime' && (
                <div className="space-y-5">
                  {/* OT summary banner */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {[
                      { label: 'Total OT Hours', value: totalOTHours.toFixed(1) + 'h', color: 'from-orange-500 to-red-500', icon: Timer },
                      { label: 'Employees with OT', value: empSummary.filter((e) => e.ot_hours > 0).length, color: 'from-red-500 to-rose-600', icon: Users },
                      { label: 'Avg OT per Employee', value: empSummary.filter((e) => e.ot_hours > 0).length > 0
                          ? (totalOTHours / empSummary.filter((e) => e.ot_hours > 0).length).toFixed(1) + 'h'
                          : '0h', color: 'from-amber-500 to-orange-500', icon: Clock },
                    ].map((card) => (
                      <div key={card.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                        <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${card.color} flex items-center justify-center mb-3`}>
                          <card.icon className="w-5 h-5 text-white" />
                        </div>
                        <p className="text-2xl font-bold text-gray-900">{card.value}</p>
                        <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mt-0.5">{card.label}</p>
                      </div>
                    ))}
                  </div>

                  {/* OT by project */}
                  <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                    <div className="px-5 py-4 border-b border-gray-100">
                      <h4 className="font-bold text-gray-900">Overtime by Project</h4>
                      <p className="text-xs text-gray-400 mt-0.5">{projectSummary.filter((p) => p.ot_hours > 0).length} projects with OT</p>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-gray-50 border-b border-gray-100">
                            {['Project', 'OT Hours', '% of Total Hours', 'Employees'].map((h) => (
                              <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                          {projectSummary.filter((p) => p.ot_hours > 0).sort((a, b) => b.ot_hours - a.ot_hours).map((p) => (
                            <tr key={p.project_id} className="hover:bg-gray-50/50">
                              <td className="px-4 py-3 font-semibold text-gray-900">{p.project_name}</td>
                              <td className="px-4 py-3">
                                <div className="flex items-center gap-2">
                                  <div className="flex-1 bg-orange-100 rounded-full h-1.5 max-w-[60px]">
                                    <div className="bg-orange-500 rounded-full h-1.5" style={{ width: `${Math.min(100, (p.ot_hours / Math.max(...projectSummary.filter((x) => x.ot_hours > 0).map((x) => x.ot_hours))) * 100)}%` }} />
                                  </div>
                                  <span className="font-bold text-orange-700">{p.ot_hours.toFixed(1)}h</span>
                                </div>
                              </td>
                              <td className="px-4 py-3 text-gray-600">
                                {p.total_hours > 0 ? ((p.ot_hours / p.total_hours) * 100).toFixed(1) : '0'}%
                              </td>
                              <td className="px-4 py-3 text-gray-600">{p.employee_count}</td>
                            </tr>
                          ))}
                          {projectSummary.filter((p) => p.ot_hours > 0).length === 0 && (
                            <tr>
                              <td colSpan={4} className="px-4 py-10 text-center text-sm text-gray-400">No overtime recorded for this period.</td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* OT by employee */}
                  <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                    <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between gap-3 flex-wrap">
                      <div>
                        <h4 className="font-bold text-gray-900">Overtime — Employee Detail</h4>
                        <p className="text-xs text-gray-400 mt-0.5">{empSummary.filter((e) => e.ot_hours > 0).length} employees with overtime</p>
                      </div>
                      <button onClick={exportOTCSV} className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 text-gray-600 font-medium rounded-xl text-sm hover:border-orange-300 hover:text-orange-600 transition-all">
                        <Download className="w-4 h-4" />Export OT
                      </button>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-gray-50 border-b border-gray-100">
                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">#</th>
                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Employee</th>
                            <th className="px-4 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase tracking-wide">Days</th>
                            <th className="px-4 py-2.5 text-right text-xs font-semibold text-orange-500 uppercase tracking-wide whitespace-nowrap">OT Hrs</th>
                            <th className="px-4 py-2.5 text-right text-xs font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">OT %</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                          {empSummary.filter((e) => e.ot_hours > 0).map((e, idx) => (
                            <tr key={e.employee_id} className="hover:bg-gray-50/50">
                              <td className="px-4 py-3 text-gray-400 text-xs">{idx + 1}</td>
                              <td className="px-4 py-3">
                                <p className="font-semibold text-gray-900">{e.employee_name}</p>
                                <p className="text-xs text-gray-400">{e.employee_code}{e.designation ? ` · ${e.designation}` : ''}</p>
                              </td>
                              <td className="px-4 py-3 text-right text-gray-600">{e.days_worked}</td>
                              <td className="px-4 py-3 text-right"><span className="font-bold text-orange-600">{e.ot_hours.toFixed(1)}h</span></td>
                              <td className="px-4 py-3 text-right text-gray-400 text-xs">
                                {e.total_hours > 0 ? ((e.ot_hours / e.total_hours) * 100).toFixed(0) : 0}%
                              </td>
                            </tr>
                          ))}
                          {empSummary.filter((e) => e.ot_hours > 0).length === 0 && (
                            <tr>
                              <td colSpan={5} className="px-4 py-10 text-center text-sm text-gray-400">No overtime recorded for this period.</td>
                            </tr>
                          )}
                        </tbody>
                        {empSummary.filter((e) => e.ot_hours > 0).length > 0 && (
                          <tfoot>
                            <tr className="bg-gradient-to-r from-orange-50 to-red-50 border-t-2 border-orange-100">
                              <td colSpan={3} className="px-4 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wide">Totals</td>
                              <td className="px-4 py-3 text-right font-bold text-orange-700">{totalOTHours.toFixed(1)}h</td>
                              <td className="px-4 py-3 text-right text-xs font-bold text-gray-400">
                                {totalHours > 0 ? ((totalOTHours / totalHours) * 100).toFixed(0) : 0}%
                              </td>
                            </tr>
                          </tfoot>
                        )}
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* ── Combined Report ── */}
              {activeSection === 'combined' && (
                <div className="space-y-5">
                  {/* Summary KPIs */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {[
                      { label: 'Regular Hours', value: totalRegHours.toFixed(1) + 'h', pct: totalHours > 0 ? ((totalRegHours / totalHours) * 100).toFixed(0) + '%' : '—', color: 'from-teal-500 to-blue-600', icon: Clock },
                      { label: 'Overtime Hours', value: totalOTHours.toFixed(1) + 'h', pct: totalHours > 0 ? ((totalOTHours / totalHours) * 100).toFixed(0) + '%' : '—', color: 'from-orange-500 to-red-500', icon: Timer },
                      { label: 'Total Hours', value: totalHours.toFixed(1) + 'h', pct: '100%', color: 'from-blue-500 to-cyan-500', icon: TrendingUp },
                    ].map((card) => (
                      <div key={card.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                        <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${card.color} flex items-center justify-center mb-3`}>
                          <card.icon className="w-5 h-5 text-white" />
                        </div>
                        <p className="text-2xl font-bold text-gray-900">{card.value}</p>
                        <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mt-0.5">{card.label} <span className="text-gray-300">· {card.pct}</span></p>
                      </div>
                    ))}
                  </div>

                  {/* Combined by project */}
                  <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                    <div className="px-5 py-4 border-b border-gray-100">
                      <h4 className="font-bold text-gray-900">Combined Hours by Project</h4>
                      <p className="text-xs text-gray-400 mt-0.5">{projectSummary.length} project{projectSummary.length !== 1 ? 's' : ''} · regular + overtime</p>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-gray-50 border-b border-gray-100">
                            {['Project', 'Employees', 'Records', 'Regular Hrs', 'OT Hrs', 'Total Hrs', 'OT %'].map((h) => (
                              <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                          {projectSummary.map((p) => (
                            <tr key={p.project_id} className="hover:bg-gray-50/50">
                              <td className="px-4 py-3 font-semibold text-gray-900">{p.project_name}</td>
                              <td className="px-4 py-3 text-gray-600">{p.employee_count}</td>
                              <td className="px-4 py-3 text-gray-600">{p.entry_count}</td>
                              <td className="px-4 py-3">
                                <div className="flex items-center gap-2">
                                  <div className="flex-1 bg-teal-100 rounded-full h-1.5 max-w-[50px]">
                                    <div className="bg-teal-500 rounded-full h-1.5" style={{ width: `${p.total_hours > 0 ? (p.regular_hours / p.total_hours) * 100 : 0}%` }} />
                                  </div>
                                  <span className="font-semibold text-teal-700">{p.regular_hours.toFixed(1)}h</span>
                                </div>
                              </td>
                              <td className="px-4 py-3">
                                {p.ot_hours > 0
                                  ? <div className="flex items-center gap-2">
                                      <div className="flex-1 bg-orange-100 rounded-full h-1.5 max-w-[50px]">
                                        <div className="bg-orange-500 rounded-full h-1.5" style={{ width: `${p.total_hours > 0 ? (p.ot_hours / p.total_hours) * 100 : 0}%` }} />
                                      </div>
                                      <span className="font-semibold text-orange-600">{p.ot_hours.toFixed(1)}h</span>
                                    </div>
                                  : <span className="text-gray-300">—</span>}
                              </td>
                              <td className="px-4 py-3 font-bold text-gray-900">{p.total_hours.toFixed(1)}h</td>
                              <td className="px-4 py-3 text-xs text-gray-400">
                                {p.total_hours > 0 ? ((p.ot_hours / p.total_hours) * 100).toFixed(0) : 0}%
                              </td>
                            </tr>
                          ))}
                        </tbody>
                        <tfoot>
                          <tr className="bg-gradient-to-r from-blue-50 to-cyan-50 border-t-2 border-blue-100">
                            <td colSpan={3} className="px-4 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wide">Totals</td>
                            <td className="px-4 py-3 font-bold text-teal-800">{totalRegHours.toFixed(1)}h</td>
                            <td className="px-4 py-3 font-bold text-orange-700">{totalOTHours.toFixed(1)}h</td>
                            <td className="px-4 py-3 font-bold text-gray-900">{totalHours.toFixed(1)}h</td>
                            <td className="px-4 py-3 text-xs font-bold text-gray-400">
                              {totalHours > 0 ? ((totalOTHours / totalHours) * 100).toFixed(0) : 0}%
                            </td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </div>

                  {/* Combined by employee */}
                  <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                    <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between gap-3 flex-wrap">
                      <div>
                        <h4 className="font-bold text-gray-900">Combined — Employee Detail</h4>
                        <p className="text-xs text-gray-400 mt-0.5">{empSummary.length} employees · regular + overtime hours</p>
                      </div>
                      <button onClick={exportCombinedCSV} className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 text-gray-600 font-medium rounded-xl text-sm hover:border-blue-300 hover:text-blue-600 transition-all">
                        <Download className="w-4 h-4" />Export
                      </button>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-gray-50 border-b border-gray-100">
                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">#</th>
                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Employee</th>
                            <th className="px-4 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase tracking-wide">Days</th>
                            <th className="px-4 py-2.5 text-right text-xs font-semibold text-teal-600 uppercase tracking-wide whitespace-nowrap">Reg Hrs</th>
                            <th className="px-4 py-2.5 text-right text-xs font-semibold text-orange-500 uppercase tracking-wide whitespace-nowrap">OT Hrs</th>
                            <th className="px-4 py-2.5 text-right text-xs font-semibold text-gray-700 uppercase tracking-wide">Total</th>
                            <th className="px-4 py-2.5 text-right text-xs font-semibold text-gray-400 uppercase tracking-wide whitespace-nowrap">OT %</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                          {empSummary.map((e, idx) => (
                            <tr key={e.employee_id} className="hover:bg-gray-50/50">
                              <td className="px-4 py-3 text-gray-400 text-xs">{idx + 1}</td>
                              <td className="px-4 py-3">
                                <p className="font-semibold text-gray-900">{e.employee_name}</p>
                                <p className="text-xs text-gray-400">{e.employee_code}{e.designation ? ` · ${e.designation}` : ''}</p>
                              </td>
                              <td className="px-4 py-3 text-right text-gray-600">{e.days_worked}</td>
                              <td className="px-4 py-3 text-right"><span className="font-semibold text-teal-700">{e.regular_hours.toFixed(1)}h</span></td>
                              <td className="px-4 py-3 text-right">
                                {e.ot_hours > 0
                                  ? <span className="font-bold text-orange-600">{e.ot_hours.toFixed(1)}h</span>
                                  : <span className="text-gray-300">—</span>}
                              </td>
                              <td className="px-4 py-3 text-right"><span className="font-bold text-gray-900">{e.total_hours.toFixed(1)}h</span></td>
                              <td className="px-4 py-3 text-right text-gray-400 text-xs">
                                {e.total_hours > 0 ? ((e.ot_hours / e.total_hours) * 100).toFixed(0) : 0}%
                              </td>
                            </tr>
                          ))}
                        </tbody>
                        {empSummary.length > 0 && (
                          <tfoot>
                            <tr className="bg-gradient-to-r from-blue-50 to-cyan-50 border-t-2 border-blue-100">
                              <td colSpan={3} className="px-4 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wide">Totals</td>
                              <td className="px-4 py-3 text-right font-bold text-teal-800">{totalRegHours.toFixed(1)}h</td>
                              <td className="px-4 py-3 text-right font-bold text-orange-700">{totalOTHours.toFixed(1)}h</td>
                              <td className="px-4 py-3 text-right font-bold text-gray-900">{totalHours.toFixed(1)}h</td>
                              <td className="px-4 py-3 text-right text-xs font-bold text-gray-400">
                                {totalHours > 0 ? ((totalOTHours / totalHours) * 100).toFixed(0) : 0}%
                              </td>
                            </tr>
                          </tfoot>
                        )}
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* ── Audit Log ── */}
              {activeSection === 'audit' && isAdmin && (
                <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                  <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between flex-wrap gap-3">
                    <div>
                      <h4 className="font-bold text-gray-900">Audit Log</h4>
                      <p className="text-xs text-gray-400 mt-0.5">Last 200 workforce actions</p>
                    </div>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="text" value={auditSearch} onChange={(e) => setAuditSearch(e.target.value)}
                        placeholder="Search logs…"
                        className="pl-9 pr-8 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 w-56"
                      />
                      {auditSearch && (
                        <button onClick={() => setAuditSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2">
                          <X className="w-3.5 h-3.5 text-gray-400" />
                        </button>
                      )}
                    </div>
                  </div>
                  {filteredLogs.length === 0 ? (
                    <div className="p-8 text-center text-sm text-gray-400">
                      {auditLogs.length === 0 ? 'No audit records yet.' : 'No records match your search.'}
                    </div>
                  ) : (
                    <div className="overflow-x-auto max-h-96">
                      <table className="w-full text-sm">
                        <thead className="sticky top-0">
                          <tr className="bg-gray-50 border-b border-gray-100">
                            {['Time', 'Action', 'Type', 'Record', 'By'].map((h) => (
                              <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                          {filteredLogs.map((log) => (
                            <tr key={log.id} className="hover:bg-gray-50/50">
                              <td className="px-4 py-2.5 text-xs text-gray-400 whitespace-nowrap">{fmtDateTime(log.performed_at)}</td>
                              <td className="px-4 py-2.5">
                                <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${ACTION_STYLE[log.action] ?? 'bg-gray-100 text-gray-600'}`}>
                                  {log.action}
                                </span>
                              </td>
                              <td className="px-4 py-2.5 text-xs text-gray-500">{log.entity_type.replace('workforce_', '').replace(/_/g, ' ')}</td>
                              <td className="px-4 py-2.5 text-gray-700 text-xs max-w-[220px] truncate" title={log.entity_label ?? ''}>{log.entity_label ?? '—'}</td>
                              <td className="px-4 py-2.5 text-gray-600 text-xs">{log.performed_by_name ?? '—'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </>
      )}

      {showExport && (
        <WorkforceExportModal
          projects={projects}
          onClose={() => setShowExport(false)}
        />
      )}
    </div>
  );
}
