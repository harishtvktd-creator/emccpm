import { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../lib/supabase';
import {
  Mail, Lock, Eye, EyeOff, ShieldCheck, User, ArrowLeft,
  SendHorizonal, Info, AlertTriangle, CheckCircle2, AlertCircle, X,
} from 'lucide-react';

type LoginMode = 'admin' | 'member';
type Screen = 'login' | 'forgot';

type FlashMessage = { id: string; message: string; type: 'info' | 'warning' | 'success' | 'error' };

const FLASH_STYLES: Record<FlashMessage['type'], { bg: string; border: string; text: string; icon: React.ElementType }> = {
  info:    { bg: 'bg-blue-50',   border: 'border-blue-200',  text: 'text-blue-800',  icon: Info },
  warning: { bg: 'bg-amber-50',  border: 'border-amber-200', text: 'text-amber-800', icon: AlertTriangle },
  success: { bg: 'bg-green-50',  border: 'border-green-200', text: 'text-green-800', icon: CheckCircle2 },
  error:   { bg: 'bg-red-50',    border: 'border-red-200',   text: 'text-red-800',   icon: AlertCircle },
};

export function Auth() {
  const [mode, setMode] = useState<LoginMode>('admin');
  const [screen, setScreen] = useState<Screen>('login');
  const [isMemberSignUp, setIsMemberSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [flash, setFlash] = useState<FlashMessage | null>(null);
  const [flashDismissed, setFlashDismissed] = useState(false);
  const { signIn, signUp } = useAuth();

  useEffect(() => {
    supabase
      .from('flash_messages')
      .select('id,message,type')
      .eq('is_active', true)
      .limit(1)
      .maybeSingle()
      .then(({ data }) => {
        if (data) setFlash(data as FlashMessage);
      });
  }, []);

  const resetForm = () => {
    setEmail('');
    setPassword('');
    setError(null);
    setSuccessMsg(null);
  };

  const handleModeSwitch = (m: LoginMode) => {
    setMode(m);
    setScreen('login');
    setIsMemberSignUp(false);
    resetForm();
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}`,
    });

    if (error) {
      setError(error.message);
    } else {
      setSuccessMsg('Password reset link sent! Check your email inbox.');
    }
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    if (isMemberSignUp) {
      const { error } = await signUp(email, password);
      if (error) {
        setError(error.message);
      } else {
        setSuccessMsg('Account created! Sign in now to view your assigned tasks.');
        setIsMemberSignUp(false);
        resetForm();
      }
    } else {
      const { error } = await signIn(email, password);
      if (error) setError(error.message);
    }

    setLoading(false);
  };

  const isAdminMode = mode === 'admin';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">

          {/* Header */}
          <div className="px-8 pt-8 pb-6 text-center border-b border-gray-100">
            <div className="inline-flex items-center justify-center w-20 h-20 mb-4">
              <img src="/EMCC_Logo..jpg" alt="EMCC Logo" className="w-20 h-20 object-contain" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">EMCC Projects Division</h1>
            <p className="text-gray-500 mt-1 text-sm">Project & Task Management</p>
          </div>

          {/* Flash message banner */}
          {flash && !flashDismissed && (() => {
            const s = FLASH_STYLES[flash.type];
            const Icon = s.icon;
            return (
              <div className={`mx-5 mt-4 flex items-start gap-3 px-4 py-3 rounded-xl border ${s.bg} ${s.border} ${s.text} text-sm`}>
                <Icon className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <p className="flex-1 font-medium leading-snug whitespace-pre-wrap">{flash.message}</p>
                <button
                  type="button"
                  onClick={() => setFlashDismissed(true)}
                  className={`flex-shrink-0 rounded p-0.5 hover:bg-black/10 transition-colors ${s.text}`}
                  aria-label="Dismiss"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })()}

          {/* Mode switcher — only on login screen */}
          {screen === 'login' && (
            <div className="px-8 pt-6">
              <div className="flex bg-gray-100 rounded-xl p-1 mb-6">
                <button
                  type="button"
                  onClick={() => handleModeSwitch('admin')}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-sm font-medium transition-all ${
                    isAdminMode ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <ShieldCheck className={`w-4 h-4 ${isAdminMode ? 'text-teal-600' : 'text-gray-400'}`} />
                  Admin Login
                </button>
                <button
                  type="button"
                  onClick={() => handleModeSwitch('member')}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-sm font-medium transition-all ${
                    !isAdminMode ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <User className={`w-4 h-4 ${!isAdminMode ? 'text-blue-600' : 'text-gray-400'}`} />
                  Team Member
                </button>
              </div>

              <div
                className={`flex items-start gap-3 p-3 rounded-lg mb-5 text-xs ${
                  isAdminMode
                    ? 'bg-teal-50 border border-teal-100 text-teal-800'
                    : 'bg-blue-50 border border-blue-100 text-blue-800'
                }`}
              >
                {isAdminMode
                  ? <ShieldCheck className="w-4 h-4 mt-0.5 flex-shrink-0 text-teal-600" />
                  : <User className="w-4 h-4 mt-0.5 flex-shrink-0 text-blue-600" />}
                <span>
                  {isAdminMode
                    ? 'Full access to manage projects, tasks, team members, and reports.'
                    : isMemberSignUp
                    ? 'Create your account using your registered email address.'
                    : 'View your assigned tasks and due dates.'}
                </span>
              </div>
            </div>
          )}

          {/* Forgot password screen */}
          {screen === 'forgot' ? (
            <div className="px-8 pb-8">
              <button
                type="button"
                onClick={() => { setScreen('login'); resetForm(); }}
                className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-700 mb-5 mt-6 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to sign in
              </button>

              <h2 className="text-lg font-bold text-gray-900 mb-1">Reset your password</h2>
              <p className="text-sm text-gray-500 mb-5">
                Enter your email address and we'll send a reset link.
              </p>

              <form onSubmit={handleForgotPassword} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-teal-400 focus:border-transparent"
                      placeholder="you@emcc.com"
                      required
                      autoComplete="email"
                    />
                  </div>
                </div>

                {error && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-xs text-red-700">{error}</p>
                  </div>
                )}
                {successMsg && (
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-xs text-green-700">{successMsg}</p>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading || !email}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white font-medium rounded-lg transition-all disabled:opacity-50"
                >
                  <SendHorizonal className="w-4 h-4" />
                  {loading ? 'Sending...' : 'Send Reset Link'}
                </button>
              </form>
            </div>
          ) : (
            /* Login / Sign-up form */
            <form onSubmit={handleSubmit} className="px-8 pb-6 space-y-4">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all"
                    placeholder="you@emcc.com"
                    required
                    autoComplete="email"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => { setScreen('forgot'); resetForm(); }}
                    className="text-xs text-teal-600 hover:text-teal-500 transition-colors"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-12 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all"
                    placeholder="••••••••"
                    required
                    minLength={6}
                    autoComplete={isMemberSignUp ? 'new-password' : 'current-password'}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-xs text-red-700">{error}</p>
                </div>
              )}
              {successMsg && (
                <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-xs text-green-700">{successMsg}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className={`w-full py-2.5 px-4 text-white font-medium rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-sm ${
                  isAdminMode
                    ? 'bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700'
                    : 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700'
                }`}
              >
                {loading
                  ? 'Please wait...'
                  : isAdminMode
                  ? 'Sign In as Admin'
                  : isMemberSignUp
                  ? 'Create Account'
                  : 'Sign In'}
              </button>
            </form>
          )}

          {/* Team member sign-up toggle */}
          {screen === 'login' && !isAdminMode && (
            <div className="px-8 pb-8 text-center">
              <p className="text-sm text-gray-500">
                {isMemberSignUp ? 'Already have an account? ' : "Don't have an account? "}
                <button
                  type="button"
                  onClick={() => {
                    setIsMemberSignUp(!isMemberSignUp);
                    resetForm();
                  }}
                  className="font-medium text-blue-600 hover:text-blue-500 transition-colors"
                >
                  {isMemberSignUp ? 'Sign in' : 'Sign up'}
                </button>
              </p>
            </div>
          )}
        </div>

        <p className="text-center text-xs text-gray-400 mt-4">
          {screen === 'forgot'
            ? 'Check your spam folder if the email does not arrive within a few minutes.'
            : isAdminMode
            ? 'Admin access is restricted to authorized personnel.'
            : 'Sign up using the email address registered by your administrator.'}
        </p>
      </div>
    </div>
  );
}
