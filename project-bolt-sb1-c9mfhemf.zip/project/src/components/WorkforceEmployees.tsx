import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import {
  Users, Plus, Search, Edit3, Trash2, X, Save, Loader2,
  AlertCircle, Download, ToggleLeft, ToggleRight,
} from 'lucide-react';

type EmploymentType = 'staff' | 'labour' | 'subcontractor';

export type WFEmployee = {
  id: string;
  employee_code: string;
  name: string;
  designation: string | null;
  department: string | null;
  trade: string | null;
  nationality: string | null;
  employment_type: EmploymentType;
  contact_phone: string | null;
  is_active: boolean;
  created_at: string;
};

const EMP_TYPE_LABEL: Record<EmploymentType, string> = {
  staff: 'INDIRECT',
  labour: 'DIRECT',
  subcontractor: 'Subcontractor',
};

const EMP_TYPE_COLOR: Record<EmploymentType, string> = {
  staff: 'bg-blue-100 text-blue-700 border-blue-200',
  labour: 'bg-amber-100 text-amber-700 border-amber-200',
  subcontractor: 'bg-teal-100 text-teal-700 border-teal-200',
};

export function logAudit(
  action: 'INSERT' | 'UPDATE' | 'DELETE',
  entityType: string,
  entityId: string,
  label: string,
  performedBy: string | null | undefined,
  performedByName: string | null | undefined,
  oldData?: object,
  newData?: object,
) {
  supabase.from('workforce_audit_logs').insert({
    action,
    entity_type: entityType,
    entity_id: entityId,
    entity_label: label,
    old_data: oldData ?? null,
    new_data: newData ?? null,
    performed_by: performedBy ?? null,
    performed_by_name: performedByName ?? null,
  }).then(() => {});
}

export function WorkforceEmployees() {
  const { teamMember, isAdmin } = useAuth();
  const [employees, setEmployees] = useState<WFEmployee[]>([]);
  const [hoursMap, setHoursMap]   = useState<Map<string, { hours: number; days: number }>>(new Map());
  const [loading, setLoading]     = useState(true);
  const [search, setSearch]       = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('active');
  const [filterType, setFilterType]     = useState<EmploymentType | 'all'>('all');
  const [showForm, setShowForm]         = useState(false);
  const [editTarget, setEditTarget]     = useState<WFEmployee | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<WFEmployee | null>(null);
  const [deleteError, setDeleteError]     = useState<string | null>(null);

  const fetchEmployees = useCallback(async () => {
    setLoading(true);
    const now = new Date();
    const firstOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];

    let empData: WFEmployee[] = [];
    if (isAdmin) {
      const { data } = await supabase.from('workforce_employees').select('*').order('name');
      empData = (data as WFEmployee[]) ?? [];
    } else {
      const { data: myProjects } = await supabase
        .from('project_members').select('project_id').eq('team_member_id', teamMember!.id);
      const projectIds = (myProjects ?? []).map((p: any) => p.project_id);
      if (projectIds.length === 0) { setEmployees([]); setLoading(false); return; }

      const { data: assignments } = await supabase
        .from('workforce_project_employees').select('employee_id').in('project_id', projectIds);
      const empIds = [...new Set((assignments ?? []).map((a: any) => a.employee_id))];
      if (empIds.length === 0) { setEmployees([]); setLoading(false); return; }

      const { data } = await supabase
        .from('workforce_employees').select('*').in('id', empIds).order('name');
      empData = (data as WFEmployee[]) ?? [];
    }

    setEmployees(empData);

    // Fetch this month's allocations to compute hours per employee
    const empIds = empData.map((e) => e.id);
    if (empIds.length > 0) {
      const { data: allocs } = await supabase
        .from('workforce_daily_allocations')
        .select('employee_id, start_time, end_time, break_minutes')
        .in('employee_id', empIds)
        .gte('entry_date', firstOfMonth);

      const map = new Map<string, { hours: number; days: number }>();
      (allocs ?? []).forEach((r: any) => {
        if (!r.start_time || !r.end_time) return;
        const [sh, sm] = r.start_time.split(':').map(Number);
        const [eh, em] = r.end_time.split(':').map(Number);
        if ([sh, sm, eh, em].some(isNaN)) return;
        const mins = (eh * 60 + em) - (sh * 60 + sm) - Math.max(0, r.break_minutes || 0);
        const hrs = mins > 0 ? Math.round(mins * 100 / 60) / 100 : 0;
        const prev = map.get(r.employee_id) ?? { hours: 0, days: 0 };
        map.set(r.employee_id, { hours: Math.round((prev.hours + hrs) * 100) / 100, days: prev.days + 1 });
      });
      setHoursMap(map);
    }

    setLoading(false);
  }, [isAdmin, teamMember]);

  useEffect(() => { fetchEmployees(); }, [fetchEmployees]);

  const filtered = employees
    .filter((e) =>
      filterStatus === 'all'
        ? true
        : filterStatus === 'active' ? e.is_active : !e.is_active
    )
    .filter((e) => filterType === 'all' || e.employment_type === filterType)
    .filter((e) => {
      if (!search) return true;
      const q = search.toLowerCase();
      return [e.name, e.employee_code, e.designation, e.department, e.trade, e.nationality]
        .some((f) => f?.toLowerCase().includes(q));
    });

  const countBy = (status: 'all' | 'active' | 'inactive') =>
    status === 'all' ? employees.length
    : employees.filter((e) => status === 'active' ? e.is_active : !e.is_active).length;

  const handleToggleActive = async (emp: WFEmployee) => {
    const newVal = !emp.is_active;
    const { error } = await supabase
      .from('workforce_employees')
      .update({ is_active: newVal })
      .eq('id', emp.id);
    if (!error) {
      logAudit('UPDATE', 'workforce_employees', emp.id, emp.name,
        teamMember?.id, teamMember?.name, { is_active: emp.is_active }, { is_active: newVal });
      fetchEmployees();
    }
  };

  const handleDelete = async (emp: WFEmployee) => {
    setDeleteError(null);
    const { error } = await supabase.from('workforce_employees').delete().eq('id', emp.id);
    if (error) {
      const isFkViolation = error.code === '23503' || error.message.toLowerCase().includes('foreign key');
      setDeleteError(isFkViolation
        ? 'Cannot delete — employee has existing allocation or assignment records. Deactivate instead.'
        : error.message);
      return;
    }
    logAudit('DELETE', 'workforce_employees', emp.id, emp.name,
      teamMember?.id, teamMember?.name, emp);
    setConfirmDelete(null);
    fetchEmployees();
  };

  const exportCSV = () => {
    const header = ['Code', 'Name', 'Designation', 'Department', 'Trade', 'Nationality', 'Type', 'Phone', 'Hrs (Month)', 'Days (Month)', 'Status'];
    const rows = filtered.map((e) => {
      const h = hoursMap.get(e.id);
      return [
        e.employee_code,
        `"${e.name.replace(/"/g, '""')}"`,
        e.designation ?? '',
        e.department ?? '',
        e.trade ?? '',
        e.nationality ?? '',
        EMP_TYPE_LABEL[e.employment_type],
        e.contact_phone ?? '',
        h ? h.hours.toFixed(1) : '0',
        h ? h.days : '0',
        e.is_active ? 'Active' : 'Inactive',
      ];
    });
    const blob = new Blob([[header, ...rows].map((r) => r.join(',')).join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `workforce-employees-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-7 h-7 animate-spin text-teal-500" />
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-bold text-gray-900 text-lg">Employee Master</h3>
          <p className="text-sm text-gray-500 mt-0.5">
            {filtered.length} of {employees.length} employees{!isAdmin && ' (read-only)'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {filtered.length > 0 && (
            <button
              onClick={exportCSV}
              className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 text-gray-600 font-medium rounded-xl text-sm hover:border-teal-300 hover:text-teal-600 transition-all"
            >
              <Download className="w-4 h-4" />Export
            </button>
          )}
          {isAdmin && (
            <button
              onClick={() => { setEditTarget(null); setShowForm(true); }}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm shadow-sm hover:from-teal-600 hover:to-blue-700 transition-all"
            >
              <Plus className="w-4 h-4" />Add Employee
            </button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white border border-gray-200 rounded-2xl p-4 space-y-3">
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text" value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, code, designation, trade…"
              className="w-full pl-9 pr-8 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
            />
            {search && (
              <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2">
                <X className="w-4 h-4 text-gray-400 hover:text-gray-600" />
              </button>
            )}
          </div>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value as typeof filterType)}
            className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400"
          >
            <option value="all">All Types</option>
            <option value="staff">Staff</option>
            <option value="labour">Labour</option>
            <option value="subcontractor">Subcontractor</option>
          </select>
        </div>
        <div className="flex gap-2 flex-wrap">
          {(['active', 'inactive', 'all'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${filterStatus === s ? 'bg-gray-800 text-white border-gray-800' : 'bg-white text-gray-600 border-gray-200 hover:border-gray-400'}`}
            >
              {s === 'active' ? `Active (${countBy('active')})` : s === 'inactive' ? `Inactive (${countBy('inactive')})` : `All (${countBy('all')})`}
            </button>
          ))}
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Total Active', value: employees.filter((e) => e.is_active).length, color: 'text-teal-700 bg-teal-50 border-teal-100' },
          { label: 'INDIRECT', value: employees.filter((e) => e.is_active && e.employment_type === 'staff').length, color: 'text-blue-700 bg-blue-50 border-blue-100' },
          { label: 'DIRECT', value: employees.filter((e) => e.is_active && e.employment_type === 'labour').length, color: 'text-amber-700 bg-amber-50 border-amber-100' },
          { label: 'Subcontractors', value: employees.filter((e) => e.is_active && e.employment_type === 'subcontractor').length, color: 'text-teal-700 bg-teal-50 border-teal-100' },
        ].map((card) => (
          <div key={card.label} className={`rounded-xl border px-4 py-3 ${card.color}`}>
            <p className="text-2xl font-bold">{card.value}</p>
            <p className="text-xs font-semibold mt-0.5 opacity-70">{card.label}</p>
          </div>
        ))}
      </div>

      {/* Table */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-14 text-center">
          <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="font-semibold text-gray-600">No employees found</p>
          {isAdmin && employees.length === 0 && (
            <button
              onClick={() => setShowForm(true)}
              className="mt-4 inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white rounded-xl text-sm font-medium"
            >
              <Plus className="w-4 h-4" />Add First Employee
            </button>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  {['Code', 'Name', 'Designation / Dept', 'Trade', 'Type', 'Nationality', 'Phone', 'Hrs (Month)', 'Status', ...(isAdmin ? ['Actions'] : [])].map((h) => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.map((emp) => (
                  <tr key={emp.id} className={`hover:bg-gray-50/60 transition-colors ${!emp.is_active ? 'opacity-55' : ''}`}>
                    <td className="px-4 py-3 font-mono text-xs text-gray-500 font-medium">{emp.employee_code}</td>
                    <td className="px-4 py-3">
                      <p className="font-semibold text-gray-900">{emp.name}</p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-gray-700">{emp.designation ?? '—'}</p>
                      {emp.department && <p className="text-xs text-gray-400">{emp.department}</p>}
                    </td>
                    <td className="px-4 py-3 text-gray-600">{emp.trade ?? '—'}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${EMP_TYPE_COLOR[emp.employment_type]}`}>
                        {EMP_TYPE_LABEL[emp.employment_type]}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-500 text-sm">{emp.nationality ?? '—'}</td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{emp.contact_phone ?? '—'}</td>
                    <td className="px-4 py-3">
                      {(() => {
                        const h = hoursMap.get(emp.id);
                        if (!h || h.hours === 0) return <span className="text-gray-300 text-xs">—</span>;
                        return (
                          <div>
                            <p className={`font-bold text-sm ${h.hours >= 160 ? 'text-teal-700' : h.hours >= 80 ? 'text-blue-700' : 'text-amber-700'}`}>
                              {h.hours.toFixed(1)}h
                            </p>
                            <p className="text-xs text-gray-400">{h.days}d</p>
                          </div>
                        );
                      })()}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${emp.is_active ? 'bg-green-100 text-green-700 border-green-200' : 'bg-gray-100 text-gray-500 border-gray-200'}`}>
                        {emp.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    {isAdmin && (
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => { setEditTarget(emp); setShowForm(true); }}
                            className="p-1.5 rounded-lg text-gray-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                            title="Edit"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleToggleActive(emp)}
                            className="p-1.5 rounded-lg text-gray-400 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                            title={emp.is_active ? 'Deactivate' : 'Activate'}
                          >
                            {emp.is_active ? <ToggleRight className="w-3.5 h-3.5" /> : <ToggleLeft className="w-3.5 h-3.5" />}
                          </button>
                          <button
                            onClick={() => { setConfirmDelete(emp); setDeleteError(null); }}
                            className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add/Edit modal */}
      {showForm && (
        <EmployeeFormModal
          employee={editTarget}
          onClose={() => { setShowForm(false); setEditTarget(null); }}
          onSaved={(action, emp, oldEmp) => {
            logAudit(action, 'workforce_employees', emp.id, emp.name,
              teamMember?.id, teamMember?.name, oldEmp, emp);
            fetchEmployees();
            setShowForm(false);
            setEditTarget(null);
          }}
        />
      )}

      {/* Delete confirm */}
      {confirmDelete && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl p-6 max-w-sm w-full">
            <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-6 h-6 text-red-600" />
            </div>
            <h3 className="font-bold text-gray-900 text-center mb-1">Delete Employee?</h3>
            <p className="text-sm text-gray-500 text-center mb-4">
              <span className="font-semibold text-gray-700">{confirmDelete.name}</span> ({confirmDelete.employee_code}) will be permanently removed.
            </p>
            {deleteError && (
              <div className="flex items-start gap-2 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2 mb-4">
                <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />{deleteError}
              </div>
            )}
            <div className="flex gap-3">
              <button onClick={() => { setConfirmDelete(null); setDeleteError(null); }} className="flex-1 px-4 py-2.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors">Cancel</button>
              <button onClick={() => handleDelete(confirmDelete)} className="flex-1 px-4 py-2.5 bg-red-600 text-white rounded-xl text-sm font-medium hover:bg-red-700 transition-colors">Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Employee Form Modal ─────────────────────────────────────── */
function EmployeeFormModal({
  employee, onClose, onSaved,
}: {
  employee: WFEmployee | null;
  onClose: () => void;
  onSaved: (action: 'INSERT' | 'UPDATE', emp: WFEmployee, oldEmp?: WFEmployee) => void;
}) {
  const [code,  setCode]  = useState(employee?.employee_code ?? '');
  const [name,  setName]  = useState(employee?.name ?? '');
  const [desig, setDesig] = useState(employee?.designation ?? '');
  const [dept,  setDept]  = useState(employee?.department ?? '');
  const [trade, setTrade] = useState(employee?.trade ?? '');
  const [natl,  setNatl]  = useState(employee?.nationality ?? '');
  const [type,  setType]  = useState<EmploymentType>(employee?.employment_type ?? 'labour');
  const [phone, setPhone] = useState(employee?.contact_phone ?? '');
  const [saving, setSaving] = useState(false);
  const [error,  setError]  = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !name.trim()) { setError('Employee Code and Name are required.'); return; }
    setSaving(true); setError(null);

    const payload = {
      employee_code: code.trim(),
      name: name.trim(),
      designation: desig.trim() || null,
      department: dept.trim() || null,
      trade: trade.trim() || null,
      nationality: natl.trim() || null,
      employment_type: type,
      contact_phone: phone.trim() || null,
    };

    if (employee) {
      const { data, error: err } = await supabase
        .from('workforce_employees').update(payload).eq('id', employee.id).select().single();
      if (err) { setError(err.message); setSaving(false); return; }
      onSaved('UPDATE', data as WFEmployee, employee);
    } else {
      const { data, error: err } = await supabase
        .from('workforce_employees').insert(payload).select().single();
      if (err) { setError(err.message); setSaving(false); return; }
      onSaved('INSERT', data as WFEmployee);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <h3 className="font-bold text-gray-900">{employee ? 'Edit Employee' : 'Add New Employee'}</h3>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100"><X className="w-5 h-5 text-gray-500" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Employee Code <span className="text-red-400">*</span></label>
              <input type="text" value={code} onChange={(e) => setCode(e.target.value)} placeholder="e.g. EMP-001" required className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Employment Type</label>
              <select value={type} onChange={(e) => setType(e.target.value as EmploymentType)} className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400">
                <option value="staff">INDIRECT</option>
                <option value="labour">DIRECT</option>
                <option value="subcontractor">Subcontractor</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Full Name <span className="text-red-400">*</span></label>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Employee full name" required className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Designation</label>
              <input type="text" value={desig} onChange={(e) => setDesig(e.target.value)} placeholder="e.g. Site Foreman" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Department</label>
              <input type="text" value={dept} onChange={(e) => setDept(e.target.value)} placeholder="e.g. Electrical" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Trade</label>
              <input type="text" value={trade} onChange={(e) => setTrade(e.target.value)} placeholder="e.g. Electrician" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Nationality</label>
              <input type="text" value={natl} onChange={(e) => setNatl(e.target.value)} placeholder="e.g. Indian" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Contact Phone</label>
            <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="e.g. +971 50 123 4567" className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
          </div>
          {error && (
            <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl px-3 py-2.5">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />{error}
            </div>
          )}
          <div className="flex items-center gap-3 pt-2 border-t border-gray-100">
            <button type="submit" disabled={saving} className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-xl text-sm disabled:opacity-60 hover:from-teal-600 hover:to-blue-700 transition-all">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              {saving ? 'Saving…' : employee ? 'Update Employee' : 'Add Employee'}
            </button>
            <button type="button" onClick={onClose} className="px-4 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
