import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/supabase';
import {
  FolderKanban,
  Plus,
  X,
  Edit2,
  Trash2,
  Calendar,
  DollarSign,
  Users,
  MoreVertical,
  Hash,
} from 'lucide-react';

type Project = Database['public']['Tables']['projects']['Row'];
type TeamMember = Database['public']['Tables']['team_members']['Row'];
type ProjectMember = Database['public']['Tables']['project_members']['Row'];

interface ProjectWithMembers extends Project {
  project_members?: (ProjectMember & { team_members: TeamMember })[];
}

export function Projects() {
  const { user, isAdmin } = useAuth();
  const [projects, setProjects] = useState<ProjectWithMembers[]>([]);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingProject, setEditingProject] = useState<ProjectWithMembers | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const fetchData = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    try {
      const [projectsRes, membersRes] = await Promise.all([
        supabase
          .from('projects')
          .select(`
            *,
            project_members (
              *,
              team_members (*)
            )
          `)
          .order('project_code', { ascending: false }),
        supabase.from('team_members').select('*').eq('is_active', true),
      ]);

      if (projectsRes.data) setProjects(projectsRes.data as ProjectWithMembers[]);
      if (membersRes.data) setTeamMembers(membersRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }

    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this project?')) return;

    try {
      await supabase.from('projects').delete().eq('id', id);
      fetchData();
    } catch (error) {
      console.error('Error deleting project:', error);
    }
  };

  const handleSave = () => {
    setShowModal(false);
    setEditingProject(null);
    fetchData();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'planning':
        return 'bg-purple-100 text-purple-700';
      case 'active':
        return 'bg-green-100 text-green-700';
      case 'on-hold':
        return 'bg-yellow-100 text-yellow-700';
      case 'completed':
        return 'bg-blue-100 text-blue-700';
      case 'cancelled':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'low':
        return 'border-gray-300';
      case 'medium':
        return 'border-yellow-400';
      case 'high':
        return 'border-orange-500';
      case 'critical':
        return 'border-red-500';
      default:
        return 'border-gray-300';
    }
  };

  const filteredProjects = projects.filter((p) =>
    filterStatus === 'all' ? true : p.status === filterStatus
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Projects</h1>
            <p className="text-gray-600 mt-1">Manage your team projects</p>
          </div>
          {isAdmin && (
          <button
            onClick={() => {
              setEditingProject(null);
              setShowModal(true);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg hover:from-teal-600 hover:to-blue-700"
          >
            <Plus className="w-5 h-5" />
            New Project
          </button>
          )}
        </div>

        {/* Filter */}
        <div className="mb-6 flex gap-2 flex-wrap">
          {['all', 'planning', 'active', 'on-hold', 'completed', 'cancelled'].map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                filterStatus === status
                  ? 'bg-gradient-to-r from-teal-500 to-blue-600 text-white'
                  : 'bg-white text-gray-600 hover:bg-gray-50'
              }`}
            >
              {status.charAt(0).toUpperCase() + status.slice(1).replace('-', ' ')}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        {filteredProjects.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 border border-gray-100 text-center">
            <FolderKanban className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              {filterStatus !== 'all' ? 'No projects in this status' : 'No Projects Yet'}
            </h3>
            <p className="text-gray-500 mb-4">
              {filterStatus !== 'all'
                ? 'Try selecting a different status filter'
                : 'Create your first project to get started'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project) => (
              <div
                key={project.id}
                className={`bg-white rounded-2xl shadow-lg p-6 border-l-4 transition-all hover:shadow-xl ${getPriorityColor(
                  project.priority
                )}`}
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="font-semibold text-gray-900 text-lg">{project.name}</h3>
                    {project.project_code && (
                      <div className="flex items-center gap-1 mt-0.5">
                        <Hash className="w-3 h-3 text-gray-400" />
                        <span className="text-xs font-mono text-gray-500">{project.project_code}</span>
                      </div>
                    )}
                    <span
                      className={`inline-block mt-1 px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(
                        project.status
                      )}`}
                    >
                      {project.status}
                    </span>
                  </div>
                  {isAdmin && (
                  <div className="relative group">
                    <button className="p-2 text-gray-400 hover:text-gray-600">
                      <MoreVertical className="w-5 h-5" />
                    </button>
                    <div className="absolute right-0 mt-1 w-32 bg-white rounded-lg shadow-lg border opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-10">
                      <button
                        onClick={() => {
                          setEditingProject(project);
                          setShowModal(true);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
                      >
                        <Edit2 className="w-4 h-4" /> Edit
                      </button>
                      <button
                        onClick={() => handleDelete(project.id)}
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-600 hover:bg-gray-50"
                      >
                        <Trash2 className="w-4 h-4" /> Delete
                      </button>
                    </div>
                  </div>
                  )}
                </div>

                {project.description && (
                  <p className="text-sm text-gray-600 mb-4 line-clamp-2">{project.description}</p>
                )}

                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-gray-600">
                    <Calendar className="w-4 h-4 text-gray-400" />
                    <span>
                      {new Date(project.start_date).toLocaleDateString()}
                      {project.end_date && ` - ${new Date(project.end_date).toLocaleDateString()}`}
                    </span>
                  </div>

                  {project.budget && (
                    <div className="flex items-center gap-2 text-gray-600">
                      <DollarSign className="w-4 h-4 text-gray-400" />
                      <span>{Number(project.budget).toLocaleString()}</span>
                    </div>
                  )}

                  <div className="flex items-center gap-2 text-gray-600">
                    <Users className="w-4 h-4 text-gray-400" />
                    <span>{project.project_members?.length || 0} team members</span>
                  </div>
                </div>

                {project.project_members && project.project_members.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-gray-100">
                    <div className="flex -space-x-2">
                      {project.project_members.slice(0, 5).map((pm) => (
                        <div
                          key={pm.id}
                          className="w-8 h-8 bg-gradient-to-br from-teal-500 to-blue-600 rounded-full flex items-center justify-center text-white text-xs font-medium border-2 border-white"
                          title={pm.team_members.name}
                        >
                          {pm.team_members.name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2)}
                        </div>
                      ))}
                      {project.project_members.length > 5 && (
                        <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-gray-700 text-xs font-medium border-2 border-white">
                          +{project.project_members.length - 5}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Modal */}
        {showModal && user && (
          <ProjectModal
            project={editingProject}
            teamMembers={teamMembers}
            userId={user.id}
            onClose={() => {
              setShowModal(false);
              setEditingProject(null);
            }}
            onSave={handleSave}
          />
        )}
      </div>
    </div>
  );
}

function ProjectModal({
  project,
  teamMembers,
  userId,
  onClose,
  onSave,
}: {
  project: ProjectWithMembers | null;
  teamMembers: TeamMember[];
  userId: string;
  onClose: () => void;
  onSave: () => void;
}) {
  const [name, setName] = useState(project?.name || '');
  const [projectCode, setProjectCode] = useState(project?.project_code || '');
  const [description, setDescription] = useState(project?.description || '');
  const [status, setStatus] = useState<'planning' | 'active' | 'on-hold' | 'completed' | 'cancelled'>(
    project?.status || 'planning'
  );
  const [priority, setPriority] = useState<'low' | 'medium' | 'high' | 'critical'>(
    project?.priority || 'medium'
  );
  const [startDate, setStartDate] = useState(project?.start_date || new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(project?.end_date || '');
  const [budget, setBudget] = useState(project?.budget?.toString() || '');
  const [loading, setLoading] = useState(false);
  const [saveError, setSaveError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSaveError('');

    try {
      const projectData = {
        name,
        project_code: projectCode.trim() || null,
        description: description || null,
        status,
        priority,
        start_date: startDate,
        end_date: endDate || null,
        budget: budget ? parseFloat(budget) : null,
        created_by: userId,
      };

      let projectId = project?.id;

      if (project) {
        const { error } = await supabase.from('projects').update(projectData).eq('id', project.id);
        if (error) throw new Error(error.message);
      } else {
        const { data, error } = await supabase.from('projects').insert(projectData).select();
        if (error) throw new Error(error.message);
        projectId = data?.[0]?.id;
      }

      // Auto-assign all active team members to every project
      if (projectId && teamMembers.length > 0) {
        await supabase.from('project_members').delete().eq('project_id', projectId);
        const memberData = teamMembers.map((m) => ({
          project_id: projectId,
          team_member_id: m.id,
        }));
        const { error } = await supabase.from('project_members').insert(memberData);
        if (error) throw new Error(error.message);
      }

      onSave();
    } catch (err: unknown) {
      console.error('Error saving project:', err);
      setSaveError(err instanceof Error ? err.message : String(err));
    }
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full p-6 my-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-900">
            {project ? 'Edit Project' : 'Create New Project'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Project Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Project Code</label>
              <input
                type="text"
                value={projectCode}
                onChange={(e) => setProjectCode(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 font-mono"
                placeholder="e.g. PRJ-001"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                rows={3}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as 'planning' | 'active' | 'on-hold' | 'completed' | 'cancelled')}
                className="w-full p-2 border border-gray-300 rounded-lg"
              >
                <option value="planning">Planning</option>
                <option value="active">Active</option>
                <option value="on-hold">On Hold</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as 'low' | 'medium' | 'high' | 'critical')}
                className="w-full p-2 border border-gray-300 rounded-lg"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="critical">Critical</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-lg"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-lg"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Budget (Optional)</label>
              <input
                type="number"
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-lg"
                placeholder="Enter budget amount"
              />
            </div>
          </div>

          {saveError && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
              {saveError}
            </div>
          )}

          <div className="flex gap-2 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 px-4 border-2 border-gray-200 text-gray-700 font-medium rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || !name.trim()}
              className="flex-1 py-2 px-4 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg disabled:opacity-50"
            >
              {loading ? 'Saving...' : project ? 'Update Project' : 'Create Project'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
