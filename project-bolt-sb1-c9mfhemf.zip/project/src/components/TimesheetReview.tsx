import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import {
  CheckCircle2, ChevronDown, ChevronUp, ClipboardCheck, Clock,
  Download, Loader2, RefreshCw, Search, Trash2, X, AlertCircle,
  Plane, Stethoscope, Star, RotateCcw, Filter, Info, CalendarCheck,
} from 'lucide-react';

// ── Types ─────────────────────────────────────────────────────────────────────

type AttendanceStatus =
  | 'present' | 'leave' | 'sick_leave'
  | 'public_holiday' | 'annual_leave' | 'compensation_leave';

const ATTENDANCE_META: Record<AttendanceStatus, { label: string; short: string; color: string; bg: string; icon: React.ElementType }> = {
  present:            { label: 'Present',           short: 'P',  color: 'text-teal-700',   bg: 'bg-teal-50 border-teal-200',    icon: CheckCircle2 },
  leave:              { label: 'Leave',              short: 'L',  color: 'text-gray-600',   bg: 'bg-gray-100 border-gray-200',   icon: X },
  sick_leave:         { label: 'Sick Leave',         short: 'SL', color: 'text-red-700',    bg: 'bg-red-50 border-red-200',      icon: Stethoscope },
  public_holiday:     { label: 'Public Holiday',     short: 'PH', color: 'text-blue-700',   bg: 'bg-blue-50 border-blue-200',    icon: Star },
  annual_leave:       { label: 'Annual Leave',       short: 'AL', color: 'text-amber-700',  bg: 'bg-amber-50 border-amber-200',  icon: Plane },
  compensation_leave: { label: 'Compensation Leave', short: 'CL', color: 'text-purple-700', bg: 'bg-purple-50 border-purple-200',icon: RotateCcw },
};

type PostedRecord = {
  id: string;
  project_id: string;
  entry_date: string;
  posted_at: string;
  posted_by_name: string | null;
  notes: string | null;
  confirmed_at: string | null;
  confirmed_by: string | null;
  projects: { id: string; name: string; project_code: string | null } | null;
};

type EditRow = {
  id: string;
  employee_id: string;
  employee_code: string;
  employee_name: string;
  designation: string | null;
  trade: string | null;
  attendance_status: AttendanceStatus;
  start_time: string;
  end_time: string;
  break_minutes: number;
  notes: string;
  saving: boolean;
  error: string | null;
};

// ── Helpers ───────────────────────────────────────────────────────────────────

function calcHours(start: string, end: string, breakMins: number): number | null {
  if (!start || !end) return null;
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  if ([sh, sm, eh, em].some(isNaN)) return null;
  const mins = (eh * 60 + em) - (sh * 60 + sm) - Math.max(0, breakMins);
  return mins > 0 ? Math.round(mins * 100 / 60) / 100 : 0;
}

function fmtDate(d: string) {
  const [y, m, day] = d.split('-');
  return `${day}/${m}/${y}`;
}

function fmtDateTime(ts: string) {
  return new Date(ts).toLocaleString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

function dayName(d: string) {
  return new Date(d + 'T00:00:00').toLocaleDateString('en-GB', { weekday: 'short' });
}

function exportCSV(record: PostedRecord, rows: EditRow[]) {
  const proj = record.projects?.name ?? 'Unknown';
  const header = ['#','Code','Employee','Designation','Trade','Status','Start','End','Break(min)','Hours','Notes'];
  const data = rows.map((r, i) => {
    const hrs = calcHours(r.start_time, r.end_time, r.break_minutes);
    return [
      i + 1, r.employee_code,
      `"${r.employee_name.replace(/"/g,'""')}"`,
      r.designation ?? '', r.trade ?? '',
      ATTENDANCE_META[r.attendance_status]?.label ?? r.attendance_status,
      r.start_time || '', r.end_time || '',
      r.break_minutes,
      hrs !== null ? hrs.toFixed(2) : '',
      `"${r.notes.replace(/"/g,'""')}"`,
    ];
  });
  const total = rows.filter((r) => r.attendance_status === 'present')
    .reduce((s, r) => s + (calcHours(r.start_time, r.end_time, r.break_minutes) ?? 0), 0);
  data.push(['','','','','','','','TOTAL','',total.toFixed(2),'']);

  const csv = [header, ...data].map((r) => r.join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `timesheet-${proj.replace(/\s+/g,'-')}-${record.entry_date}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// ── Expanded Detail ───────────────────────────────────────────────────────────

function ExpandedDetail({ record, onRecordChange }: {
  record: PostedRecord;
  onRecordChange: (updated: PostedRecord) => void;
}) {
  const { teamMember } = useAuth();
  const [rows, setRows]           = useState<EditRow[]>([]);
  const [loading, setLoading]     = useState(true);
  const [confirming, setConfirming]   = useState(false);
  const [confirmError, setConfirmError] = useState<string | null>(null);

  const loadRows = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('workforce_daily_allocations')
      .select('*, employee:workforce_employees(id,employee_code,name,designation,trade)')
      .eq('project_id', record.project_id)
      .eq('entry_date', record.entry_date)
      .order('created_at');

    setRows((data ?? []).map((r: any) => ({
      id: r.id,
      employee_id: r.employee_id,
      employee_code: r.employee?.employee_code ?? '—',
      employee_name: r.employee?.name ?? '—',
      designation: r.employee?.designation ?? null,
      trade: r.employee?.trade ?? null,
      attendance_status: r.attendance_status as AttendanceStatus,
      start_time: r.start_time ?? '',
      end_time: r.end_time ?? '',
      break_minutes: r.break_minutes ?? 0,
      notes: r.notes ?? '',
      saving: false,
      error: null,
    })));
    setLoading(false);
  }, [record.project_id, record.entry_date]);

  useEffect(() => { loadRows(); }, [loadRows]);

  const update = (idx: number, fields: Partial<EditRow>) =>
    setRows((prev) => prev.map((r, i) => i === idx ? { ...r, ...fields } : r));

  const saveRow = async (idx: number) => {
    const row = rows[idx];
    update(idx, { saving: true, error: null });
    const { error } = await supabase
      .from('workforce_daily_allocations')
      .update({
        attendance_status: row.attendance_status,
        start_time: row.start_time || null,
        end_time: row.end_time || null,
        break_minutes: row.break_minutes,
        notes: row.notes || null,
        updated_by: teamMember?.id ?? null,
      })
      .eq('id', row.id);
    update(idx, { saving: false, error: error?.message ?? null });
  };

  const deleteRow = async (idx: number) => {
    const row = rows[idx];
    if (!confirm(`Delete ${row.employee_name}'s entry? This cannot be undone.`)) return;
    const { error } = await supabase
      .from('workforce_daily_allocations')
      .delete()
      .eq('id', row.id);
    if (!error) setRows((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleConfirm = async () => {
    if (!teamMember) return;
    setConfirming(true);
    setConfirmError(null);
    const confirmedAt = new Date().toISOString();
    const { error } = await supabase
      .from('posted_allocations')
      .update({ confirmed_at: confirmedAt, confirmed_by: teamMember.id })
      .eq('id', record.id);
    setConfirming(false);
    if (error) {
      setConfirmError(error.message);
    } else {
      onRecordChange({ ...record, confirmed_at: confirmedAt, confirmed_by: teamMember.id });
    }
  };

  const handleUnconfirm = async () => {
    if (!confirm('Remove confirmation from this record?')) return;
    setConfirming(true);
    setConfirmError(null);
    const { error } = await supabase
      .from('posted_allocations')
      .update({ confirmed_at: null, confirmed_by: null })
      .eq('id', record.id);
    setConfirming(false);
    if (error) {
      setConfirmError(error.message);
    } else {
      onRecordChange({ ...record, confirmed_at: null, confirmed_by: null });
    }
  };

  const presentRows = rows.filter((r) => r.attendance_status === 'present');
  const totalHours  = presentRows.reduce((s, r) => s + (calcHours(r.start_time, r.end_time, r.break_minutes) ?? 0), 0);

  const inp = 'w-full px-2 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-teal-400';

  return (
    <div className="border-t border-gray-100 bg-gray-50/40">
      {/* Summary bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3 border-b border-gray-100">
        <div className="flex items-center gap-4 text-sm">
          <span className="text-gray-500">
            <span className="font-semibold text-gray-800">{rows.length}</span> employees ·{' '}
            <span className="font-semibold text-teal-700">{presentRows.length}</span> present ·{' '}
            <span className="font-semibold text-teal-700">{totalHours.toFixed(1)}h</span> total
          </span>
          {record.confirmed_at ? (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full text-xs font-semibold">
              <CheckCircle2 className="w-3 h-3" />
              Confirmed {fmtDateTime(record.confirmed_at)}
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-100 text-amber-700 rounded-full text-xs font-semibold">
              <Clock className="w-3 h-3" />
              Pending Confirmation
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {confirmError && (
            <span className="text-xs text-red-600 bg-red-50 border border-red-200 px-3 py-1.5 rounded-lg">
              {confirmError}
            </span>
          )}
          {rows.length > 0 && (
            <button
              onClick={() => exportCSV(record, rows)}
              className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-200 rounded-lg bg-white text-sm text-gray-600 hover:border-teal-300 hover:text-teal-600 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />Export
            </button>
          )}
          {record.confirmed_at ? (
            <button
              onClick={handleUnconfirm}
              disabled={confirming}
              className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-200 rounded-lg bg-white text-sm text-gray-600 hover:border-red-300 hover:text-red-600 transition-colors disabled:opacity-60"
            >
              {confirming ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <X className="w-3.5 h-3.5" />}
              Unconfirm
            </button>
          ) : (
            <button
              onClick={handleConfirm}
              disabled={confirming || rows.length === 0}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-semibold rounded-lg text-sm hover:from-emerald-600 hover:to-teal-700 disabled:opacity-60 transition-all"
            >
              {confirming ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ClipboardCheck className="w-3.5 h-3.5" />}
              Confirm Day
            </button>
          )}
        </div>
      </div>

      {/* Employee table */}
      {loading ? (
        <div className="py-10 flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-teal-500" />
        </div>
      ) : rows.length === 0 ? (
        <div className="py-10 text-center text-sm text-gray-500">No employee entries found for this date.</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[900px]">
            <thead>
              <tr className="border-b border-gray-200 bg-white">
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-400 uppercase tracking-wide w-8">#</th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Employee</th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide w-44">Status</th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide w-28">Start</th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide w-28">End</th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide w-24">Break</th>
                <th className="px-4 py-2.5 text-center text-xs font-semibold text-teal-600 uppercase tracking-wide w-20">Hours</th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Notes</th>
                <th className="px-4 py-2.5 w-16 text-center text-xs font-semibold text-gray-400 uppercase tracking-wide">Save</th>
                <th className="px-4 py-2.5 w-10" />
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {rows.map((row, idx) => {
                const isPresent = row.attendance_status === 'present';
                const hrs = isPresent ? calcHours(row.start_time, row.end_time, row.break_minutes) : null;
                const meta = ATTENDANCE_META[row.attendance_status];

                return (
                  <tr key={row.id} className={`hover:bg-blue-50/30 transition-colors ${!isPresent ? 'opacity-70' : ''}`}>
                    <td className="px-4 py-2.5 text-gray-400 text-xs">{idx + 1}</td>
                    <td className="px-4 py-2.5">
                      <p className="font-semibold text-gray-900">{row.employee_name}</p>
                      <p className="text-xs text-gray-400">
                        {row.employee_code}
                        {row.designation ? ` · ${row.designation}` : ''}
                        {row.trade ? ` · ${row.trade}` : ''}
                      </p>
                    </td>
                    <td className="px-2 py-2">
                      <select
                        value={row.attendance_status}
                        onChange={(e) => {
                          update(idx, { attendance_status: e.target.value as AttendanceStatus });
                          setTimeout(() => saveRow(idx), 0);
                        }}
                        className={`w-full px-2 py-1.5 border rounded-lg text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-teal-400 ${meta.bg} ${meta.color}`}
                      >
                        {(Object.entries(ATTENDANCE_META) as [AttendanceStatus, typeof ATTENDANCE_META[AttendanceStatus]][]).map(([k, v]) => (
                          <option key={k} value={k}>{v.label}</option>
                        ))}
                      </select>
                    </td>
                    <td className="px-2 py-2">
                      <input
                        type="time" value={row.start_time}
                        disabled={!isPresent}
                        onChange={(e) => update(idx, { start_time: e.target.value })}
                        onBlur={() => saveRow(idx)}
                        className={`${inp} disabled:bg-gray-50 disabled:text-gray-300 disabled:cursor-not-allowed`}
                      />
                    </td>
                    <td className="px-2 py-2">
                      <input
                        type="time" value={row.end_time}
                        disabled={!isPresent}
                        onChange={(e) => update(idx, { end_time: e.target.value })}
                        onBlur={() => saveRow(idx)}
                        className={`${inp} disabled:bg-gray-50 disabled:text-gray-300 disabled:cursor-not-allowed`}
                      />
                    </td>
                    <td className="px-2 py-2">
                      <input
                        type="number" min="0"
                        value={row.break_minutes === 0 ? '' : row.break_minutes}
                        disabled={!isPresent}
                        onChange={(e) => update(idx, { break_minutes: Math.max(0, parseInt(e.target.value) || 0) })}
                        onBlur={() => saveRow(idx)}
                        placeholder="0"
                        className={`${inp} text-center disabled:bg-gray-50 disabled:text-gray-300 disabled:cursor-not-allowed`}
                      />
                    </td>
                    <td className="px-4 py-2.5 text-center">
                      {hrs !== null ? (
                        <span className="font-bold text-teal-700">{hrs.toFixed(2)}h</span>
                      ) : (
                        <span className="text-gray-300 text-sm">—</span>
                      )}
                    </td>
                    <td className="px-2 py-2">
                      <input
                        type="text" value={row.notes}
                        onChange={(e) => update(idx, { notes: e.target.value })}
                        onBlur={() => saveRow(idx)}
                        placeholder="Notes…"
                        className={inp}
                      />
                    </td>
                    <td className="px-4 py-2.5 text-center">
                      {row.saving ? (
                        <Loader2 className="w-4 h-4 animate-spin text-teal-500 mx-auto" />
                      ) : row.error ? (
                        <span title={row.error}>
                          <AlertCircle className="w-4 h-4 text-red-500 mx-auto cursor-help" />
                        </span>
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-green-400 mx-auto" />
                      )}
                    </td>
                    <td className="px-2 py-2.5 text-center">
                      <button
                        onClick={() => deleteRow(idx)}
                        className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                        title="Delete entry"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="bg-gray-50 border-t-2 border-gray-200">
                <td colSpan={6} className="px-4 py-2.5 text-sm font-semibold text-gray-700">
                  Total — {presentRows.length} of {rows.length} present
                </td>
                <td className="px-4 py-2.5 text-center">
                  <span className="font-bold text-teal-700">{totalHours.toFixed(2)}h</span>
                </td>
                <td colSpan={3} />
              </tr>
            </tfoot>
          </table>
        </div>
      )}
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────

type StatusFilter = 'all' | 'pending' | 'confirmed';

export function TimesheetReview() {
  const today = new Date().toISOString().split('T')[0];
  const firstOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];

  const [records, setRecords]         = useState<PostedRecord[]>([]);
  const [loading, setLoading]         = useState(true);
  const [projects, setProjects]       = useState<{ id: string; name: string }[]>([]);
  const [expandedId, setExpandedId]   = useState<string | null>(null);
  const [dateFrom, setDateFrom]       = useState(firstOfMonth);
  const [dateTo, setDateTo]           = useState(today);
  const [projectFilter, setProjectFilter] = useState('all');
  const [statusFilter, setStatusFilter]   = useState<StatusFilter>('all');
  const [search, setSearch]           = useState('');

  const fetchRecords = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('posted_allocations')
      .select('*, projects(id,name,project_code)')
      .gte('entry_date', dateFrom)
      .lte('entry_date', dateTo)
      .order('entry_date', { ascending: false });
    setRecords((data as PostedRecord[]) ?? []);
    setLoading(false);
  }, [dateFrom, dateTo]);

  useEffect(() => {
    fetchRecords();
    supabase.from('projects').select('id,name').order('name').then(({ data }) => setProjects(data ?? []));
  }, [fetchRecords]);

  const updateRecord = (updated: PostedRecord) =>
    setRecords((prev) => prev.map((r) => r.id === updated.id ? updated : r));

  const filtered = records
    .filter((r) => projectFilter === 'all' || r.project_id === projectFilter)
    .filter((r) => {
      if (statusFilter === 'confirmed') return !!r.confirmed_at;
      if (statusFilter === 'pending')   return !r.confirmed_at;
      return true;
    })
    .filter((r) => {
      if (!search) return true;
      const q = search.toLowerCase();
      return (
        (r.projects?.name ?? '').toLowerCase().includes(q) ||
        (r.projects?.project_code ?? '').toLowerCase().includes(q) ||
        (r.posted_by_name ?? '').toLowerCase().includes(q) ||
        r.entry_date.includes(q)
      );
    });

  const counts = {
    total:     records.length,
    pending:   records.filter((r) => !r.confirmed_at).length,
    confirmed: records.filter((r) => !!r.confirmed_at).length,
  };

  const sel = 'text-sm border border-gray-200 rounded-xl px-3 py-2 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-teal-400';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 p-6 lg:p-8">
      <div className="max-w-screen-2xl mx-auto space-y-6">

        {/* Page header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Posted Timesheets Review</h1>
            <p className="text-gray-500 text-sm mt-0.5">Review, edit and confirm timesheets submitted by team members</p>
          </div>
          <button
            onClick={fetchRecords}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-xl bg-white text-sm text-gray-600 hover:border-teal-300 hover:text-teal-600 transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-3 gap-4">
          {[
            { label: 'Total Posted', value: counts.total,     color: 'text-gray-800',   bg: 'bg-gray-100',   border: 'border-gray-200', icon: CalendarCheck },
            { label: 'Pending Review', value: counts.pending, color: 'text-amber-700',  bg: 'bg-amber-50',   border: 'border-amber-200', icon: Clock },
            { label: 'Confirmed',    value: counts.confirmed, color: 'text-emerald-700',bg: 'bg-emerald-50', border: 'border-emerald-200', icon: CheckCircle2 },
          ].map((c) => (
            <div key={c.label} className={`bg-white rounded-2xl border ${c.border} p-5 flex items-center gap-4`}>
              <div className={`w-10 h-10 ${c.bg} rounded-xl flex items-center justify-center flex-shrink-0`}>
                <c.icon className={`w-5 h-5 ${c.color}`} />
              </div>
              <div>
                <p className={`text-2xl font-bold ${c.color}`}>{c.value}</p>
                <p className="text-xs text-gray-500 font-medium mt-0.5">{c.label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Filter bar */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="flex flex-wrap gap-3 items-end">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">From</label>
              <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className={sel} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">To</label>
              <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className={sel} />
            </div>
            <select value={projectFilter} onChange={(e) => setProjectFilter(e.target.value)} className={sel}>
              <option value="all">All Projects</option>
              {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as StatusFilter)} className={sel}>
              <option value="all">All Statuses</option>
              <option value="pending">Pending Review</option>
              <option value="confirmed">Confirmed</option>
            </select>
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text" value={search} onChange={(e) => setSearch(e.target.value)}
                placeholder="Search project, posted by, date…"
                className="w-full pl-9 pr-8 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
              />
              {search && (
                <button onClick={() => setSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            <div className="flex items-center gap-1.5 ml-auto text-xs text-gray-500">
              <Filter className="w-3.5 h-3.5" />
              {filtered.length} of {records.length} records
            </div>
          </div>
        </div>

        {/* Records list */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          {loading ? (
            <div className="py-20 flex items-center justify-center">
              <Loader2 className="w-8 h-8 animate-spin text-teal-400" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="py-20 text-center">
              <CalendarCheck className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-600 font-medium">No posted timesheets found</p>
              <p className="text-gray-400 text-sm mt-1">
                {records.length === 0
                  ? 'No timesheets have been posted in this date range.'
                  : 'Adjust your filters to see results.'}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {filtered.map((record) => {
                const isExpanded    = expandedId === record.id;
                const isConfirmed   = !!record.confirmed_at;
                const projectName   = record.projects?.name ?? '—';
                const projectCode   = record.projects?.project_code;

                return (
                  <div key={record.id}>
                    {/* Record row */}
                    <div
                      className={`flex items-center gap-4 px-5 py-4 cursor-pointer hover:bg-gray-50/60 transition-colors ${isExpanded ? 'bg-teal-50/30' : ''}`}
                      onClick={() => setExpandedId(isExpanded ? null : record.id)}
                    >
                      {/* Date block */}
                      <div className="flex-shrink-0 w-16 text-center">
                        <p className="text-xs font-semibold text-gray-400 uppercase">{dayName(record.entry_date)}</p>
                        <p className="text-lg font-bold text-gray-800 leading-tight">{record.entry_date.split('-')[2]}</p>
                        <p className="text-xs text-gray-500">{record.entry_date.split('-').slice(0,2).join('/')}</p>
                      </div>

                      {/* Project + posted info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-semibold text-gray-900 truncate">{projectName}</p>
                          {projectCode && (
                            <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs font-mono rounded-md">
                              {projectCode}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-gray-400 mt-0.5">
                          Posted by <span className="font-medium text-gray-600">{record.posted_by_name ?? 'Unknown'}</span>
                          {' · '}{fmtDateTime(record.posted_at)}
                          {record.notes && <span className="italic ml-1 text-gray-400">· {record.notes}</span>}
                        </p>
                      </div>

                      {/* Status */}
                      <div className="flex-shrink-0">
                        {isConfirmed ? (
                          <div className="text-right">
                            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-100 text-emerald-800 rounded-full text-xs font-semibold">
                              <CheckCircle2 className="w-3.5 h-3.5" />Confirmed
                            </span>
                            <p className="text-xs text-gray-400 mt-1">{fmtDate(record.confirmed_at!.split('T')[0])}</p>
                          </div>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-100 text-amber-700 rounded-full text-xs font-semibold">
                            <Clock className="w-3.5 h-3.5" />Pending
                          </span>
                        )}
                      </div>

                      {/* Expand chevron */}
                      <div className="flex-shrink-0 pl-2">
                        {isExpanded
                          ? <ChevronUp className="w-5 h-5 text-teal-500" />
                          : <ChevronDown className="w-5 h-5 text-gray-400" />}
                      </div>
                    </div>

                    {/* Expanded detail */}
                    {isExpanded && (
                      <ExpandedDetail
                        record={record}
                        onRecordChange={updateRecord}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Footer */}
          {!loading && filtered.length > 0 && (
            <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
              <p className="text-xs text-gray-400">
                {filtered.length} record{filtered.length !== 1 ? 's' : ''} · {fmtDate(dateFrom)} — {fmtDate(dateTo)}
              </p>
              <div className="flex items-center gap-3 text-xs text-gray-500">
                <span className="inline-flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" />
                  {counts.pending} pending
                </span>
                <span className="inline-flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                  {counts.confirmed} confirmed
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Help note */}
        <div className="flex items-start gap-2 text-xs text-gray-500 bg-white rounded-xl border border-gray-100 p-4">
          <Info className="w-4 h-4 flex-shrink-0 text-gray-400 mt-0.5" />
          <span>
            Click any record to expand and review individual employee entries. You can edit attendance status, times, and notes inline — changes save automatically. Use the <strong>Confirm Day</strong> button to mark a record as reviewed. Delete individual employee rows to correct erroneous or duplicate entries.
          </span>
        </div>

      </div>
    </div>
  );
}
