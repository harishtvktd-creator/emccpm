import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useExchangeRates } from '../hooks/useExchangeRates';
import { formatCurrency, convertCurrency, SUPPORTED_CURRENCIES, DEFAULT_CURRENCY } from '../lib/currency';
import { TrendingDown, Loader2, Search, X, Calendar, CreditCard, ChevronUp, ChevronDown as ChevronDownIcon, RefreshCw } from 'lucide-react';

type Transaction = {
  id: string;
  amount: number;
  description: string | null;
  date: string;
  currency: string;
  category: { id: string; name: string; color: string | null } | null;
  bank_account: { id: string; name: string } | null;
};

function fmtDate(d: string) {
  const [y, m, day] = d.split('-');
  return `${day}/${m}/${y}`;
}

type SortKey = 'date' | 'amount' | 'category';
type SortDir = 'asc' | 'desc';

export function AccountsExpense() {
  const today = new Date();
  const firstOfMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-01`;
  const todayStr = today.toISOString().split('T')[0];

  const { rates, loading: ratesLoading, lastUpdated } = useExchangeRates();
  const [displayCurrency, setDisplayCurrency] = useState(DEFAULT_CURRENCY);
  const conv = (n: number, from: string) => convertCurrency(n, from, displayCurrency, rates);

  const [rows, setRows] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateFrom, setDateFrom] = useState(firstOfMonth);
  const [dateTo, setDateTo] = useState(todayStr);
  const [search, setSearch] = useState('');
  const [sortKey, setSortKey] = useState<SortKey>('date');
  const [sortDir, setSortDir] = useState<SortDir>('desc');

  const fetchData = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('transactions')
      .select('id, amount, description, date, currency, category:categories(id,name,color), bank_account:bank_accounts(id,name)')
      .gte('date', dateFrom)
      .lte('date', dateTo)
      .order('date', { ascending: false });

    const ids = [...new Set((data ?? []).map((r: any) => r.category?.id).filter(Boolean))];
    let expenseIds = new Set<string>();
    if (ids.length) {
      const { data: cats } = await supabase.from('categories').select('id,type').in('id', ids);
      expenseIds = new Set((cats ?? []).filter((c: any) => c.type === 'expense').map((c: any) => c.id));
    }
    setRows((data ?? []).filter((r: any) => !r.category || expenseIds.has(r.category?.id)) as Transaction[]);
    setLoading(false);
  }, [dateFrom, dateTo]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const filtered = rows.filter((r) => {
    if (!search) return true;
    return [r.description, r.category?.name, r.bank_account?.name]
      .some((f) => f?.toLowerCase().includes(search.toLowerCase()));
  });

  const sorted = [...filtered].sort((a, b) => {
    let cmp = 0;
    if (sortKey === 'date') cmp = a.date.localeCompare(b.date);
    else if (sortKey === 'amount') cmp = a.amount - b.amount;
    else if (sortKey === 'category') cmp = (a.category?.name ?? '').localeCompare(b.category?.name ?? '');
    return sortDir === 'asc' ? cmp : -cmp;
  });

  const total = filtered.reduce((s, r) => s + conv(r.amount, r.currency), 0);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else { setSortKey(key); setSortDir('desc'); }
  };

  const SortIcon = ({ k }: { k: SortKey }) =>
    sortKey === k ? (sortDir === 'asc' ? <ChevronUp className="w-3 h-3 inline ml-0.5" /> : <ChevronDownIcon className="w-3 h-3 inline ml-0.5" />) : null;

  // Group by category for the breakdown card
  const byCat = filtered.reduce<Record<string, { name: string; total: number }>>((acc, r) => {
    const key = r.category?.id ?? 'uncategorized';
    if (!acc[key]) acc[key] = { name: r.category?.name ?? 'Uncategorized', total: 0 };
    acc[key].total += conv(r.amount, r.currency);
    return acc;
  }, {});
  const topCats = Object.values(byCat).sort((a, b) => b.total - a.total).slice(0, 3);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-bold text-gray-900 text-lg">Expense</h3>
          <p className="text-sm text-gray-500 mt-0.5">All expense transactions within the selected period</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">Period Total</p>
          <p className="text-2xl font-bold text-rose-600">{loading ? '—' : formatCurrency(total, displayCurrency)}</p>
          <p className="text-xs text-gray-400 mt-1">{filtered.length} transaction{filtered.length !== 1 ? 's' : ''}</p>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">Avg per Entry</p>
          <p className="text-2xl font-bold text-gray-700">{loading || filtered.length === 0 ? '—' : formatCurrency(total / filtered.length, displayCurrency)}</p>
          <p className="text-xs text-gray-400 mt-1">Per transaction</p>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2">Top Categories</p>
          {topCats.length === 0 ? <p className="text-xs text-gray-300">No data</p> : (
            <div className="space-y-1">
              {topCats.map((c) => (
                <div key={c.name} className="flex justify-between items-center text-xs">
                  <span className="text-gray-600 truncate max-w-[120px]">{c.name}</span>
                  <span className="font-semibold text-rose-600 ml-2">{formatCurrency(c.total, displayCurrency)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-2xl p-4">
        <div className="flex flex-wrap gap-4 items-end">
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">From</label>
            <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)}
              className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">To</label>
            <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)}
              className="px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-400" />
          </div>
          <div className="relative flex-1 min-w-[200px]">
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Search</label>
            <Search className="absolute left-3 bottom-2.5 w-4 h-4 text-gray-400" />
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Description, category…"
              className="w-full pl-9 pr-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-400" />
            {search && <button onClick={() => setSearch('')} className="absolute right-3 bottom-2.5"><X className="w-4 h-4 text-gray-400 hover:text-gray-600" /></button>}
          </div>
          <div className="flex items-center gap-2">
            {!ratesLoading && lastUpdated && (
              <span className="text-xs text-gray-400 flex items-center gap-1">
                <RefreshCw className="w-3 h-3" />Live rates
              </span>
            )}
            <select value={displayCurrency} onChange={(e) => setDisplayCurrency(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-rose-400 bg-white">
              {SUPPORTED_CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <button onClick={fetchData} className="px-4 py-2.5 bg-rose-600 text-white rounded-xl text-sm font-semibold hover:bg-rose-700 transition-colors flex items-center gap-2">
            <Calendar className="w-4 h-4" />Apply
          </button>
        </div>
      </div>

      {loading ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-12 flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-rose-500" />
        </div>
      ) : sorted.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-14 text-center">
          <TrendingDown className="w-12 h-12 text-gray-200 mx-auto mb-3" />
          <p className="font-semibold text-gray-500">No expense transactions found</p>
          <p className="text-sm text-gray-400 mt-1">Try adjusting your date range or search term.</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  <th onClick={() => toggleSort('date')} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer whitespace-nowrap hover:text-gray-700">
                    Date <SortIcon k="date" />
                  </th>
                  <th onClick={() => toggleSort('category')} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer whitespace-nowrap hover:text-gray-700">
                    Category <SortIcon k="category" />
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Description</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">
                    <span className="flex items-center gap-1"><CreditCard className="w-3.5 h-3.5" />Account</span>
                  </th>
                  <th onClick={() => toggleSort('amount')} className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer whitespace-nowrap hover:text-gray-700">
                    Amount <SortIcon k="amount" />
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {sorted.map((r) => (
                  <tr key={r.id} className="hover:bg-gray-50/60 transition-colors">
                    <td className="px-4 py-3 font-mono text-xs text-gray-500 whitespace-nowrap">{fmtDate(r.date)}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      {r.category ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-100">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                          {r.category.name}
                        </span>
                      ) : <span className="text-gray-300 text-xs">—</span>}
                    </td>
                    <td className="px-4 py-3 text-gray-600 max-w-[220px] truncate">{r.description ?? <span className="text-gray-300">—</span>}</td>
                    <td className="px-4 py-3 text-xs text-gray-500 whitespace-nowrap">{r.bank_account?.name ?? '—'}</td>
                    <td className="px-4 py-3 text-right font-semibold text-rose-600 whitespace-nowrap">{formatCurrency(conv(r.amount, r.currency), displayCurrency)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-rose-50/60 border-t-2 border-rose-100">
                  <td colSpan={4} className="px-4 py-3 text-sm font-bold text-gray-700">Total</td>
                  <td className="px-4 py-3 text-right font-bold text-rose-700 text-base">{formatCurrency(total, displayCurrency)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
