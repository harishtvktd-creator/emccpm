import { useState, useEffect, useMemo, useCallback } from 'react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../lib/supabase';
import {
  Target,
  X,
  ChevronLeft,
  ChevronRight,
  Edit2,
  Trash2,
  DollarSign,
} from 'lucide-react';
import type { Database } from '../lib/supabase';

type Category = Database['public']['Tables']['categories']['Row'];
type PlannedBudget = Database['public']['Tables']['planned_budgets']['Row'];

interface BudgetWithCategory extends PlannedBudget {
  categories: Category;
}

const monthNames = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

interface BudgetPlanningProps {
  onBack: () => void;
}

export function BudgetPlanning({ onBack }: BudgetPlanningProps) {
  const { user } = useAuth();
  const [categories, setCategories] = useState<Category[]>([]);
  const [budgets, setBudgets] = useState<BudgetWithCategory[]>([]);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [loading, setLoading] = useState(true);
  const [showBudgetModal, setShowBudgetModal] = useState(false);
  const [editingBudget, setEditingBudget] = useState<BudgetWithCategory | null>(null);

  const fetchData = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const [categoriesRes, budgetsRes] = await Promise.all([
        supabase.from('categories').select('*').eq('user_id', user.id),
        supabase
          .from('planned_budgets')
          .select('*, categories(*)')
          .eq('user_id', user.id)
          .eq('year', selectedYear),
      ]);

      if (categoriesRes.data) setCategories(categoriesRes.data);
      if (budgetsRes.data) setBudgets(budgetsRes.data as BudgetWithCategory[]);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
    setLoading(false);
  }, [user, selectedYear]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const monthlyBudgets = useMemo(() => {
    const result: Record<number, BudgetWithCategory[]> = {};
    for (let i = 0; i < 12; i++) {
      result[i] = budgets.filter((b) => b.month === i);
    }
    return result;
  }, [budgets]);

  const yearlyBudgets = useMemo(() => {
    return budgets.filter((b) => b.month === null);
  }, [budgets]);

  const handleDeleteBudget = async (id: string) => {
    if (!confirm('Are you sure you want to delete this budget?')) return;

    try {
      await supabase.from('planned_budgets').delete().eq('id', id);
      fetchData();
    } catch (error) {
      console.error('Error deleting budget:', error);
    }
  };

  const handleBudgetSaved = () => {
    setShowBudgetModal(false);
    setEditingBudget(null);
    fetchData();
  };

  const navigateYear = (direction: 'prev' | 'next') => {
    setSelectedYear((prev) => (direction === 'prev' ? prev - 1 : prev + 1));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50">
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="text-gray-600 hover:text-gray-900">
              <X className="w-6 h-6" />
            </button>
            <div className="flex items-center gap-2">
              <Target className="w-6 h-6 text-gray-600" />
              <h1 className="text-xl font-bold text-gray-900">Budget Planning</h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigateYear('prev')}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <span className="text-lg font-semibold text-gray-900 min-w-[80px] text-center">
              {selectedYear}
            </span>
            <button
              onClick={() => navigateYear('next')}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Yearly Budgets */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Yearly Budgets</h2>
            <button
              onClick={() => {
                setEditingBudget(null);
                setShowBudgetModal(true);
              }}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg hover:from-teal-600 hover:to-blue-700 transition-all"
            >
              <DollarSign className="w-4 h-4" />
              Add Yearly Budget
            </button>
          </div>

          {yearlyBudgets.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Target className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No yearly budgets set for {selectedYear}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {yearlyBudgets.map((budget) => (
                <div
                  key={budget.id}
                  className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-teal-50 rounded-xl border border-blue-200"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: budget.categories.color }}
                    >
                      <div className="w-5 h-5 bg-white rounded opacity-80" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{budget.categories.name}</p>
                      <p className="text-sm text-gray-500">
                        Yearly - {budget.categories.type}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <p className="text-xl font-bold text-gray-900">
                      ${Number(budget.amount).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setEditingBudget(budget);
                          setShowBudgetModal(true);
                        }}
                        className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteBudget(budget.id)}
                        className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Monthly Budgets Grid */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Monthly Budgets</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {monthNames.map((month, i) => {
              const monthBudgets = monthlyBudgets[i];
              const incomeTotal = monthBudgets
                .filter((b) => b.categories.type === 'income')
                .reduce((sum, b) => sum + Number(b.amount), 0);
              const expenseTotal = monthBudgets
                .filter((b) => b.categories.type === 'expense')
                .reduce((sum, b) => sum + Number(b.amount), 0);

              return (
                <div
                  key={month}
                  className="p-5 bg-gray-50 rounded-xl border-2 border-gray-200 hover:border-blue-300 transition-all"
                >
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold text-gray-900">{month}</h3>
                    <button
                      onClick={() => {
                        setEditingBudget(null);
                        setShowBudgetModal(true);
                      }}
                      className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                      title="Add budget"
                    >
                      <DollarSign className="w-4 h-4" />
                    </button>
                  </div>

                  {monthBudgets.length === 0 ? (
                    <p className="text-sm text-gray-400 py-4 text-center">No budgets set</p>
                  ) : (
                    <div className="space-y-2">
                      {monthBudgets.map((budget) => (
                        <div
                          key={budget.id}
                          className="flex items-center justify-between p-2 bg-white rounded-lg group"
                        >
                          <div className="flex items-center gap-2">
                            <div
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: budget.categories.color }}
                            />
                            <span className="text-sm text-gray-700">
                              {budget.categories.name}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium text-gray-900">
                              ${Number(budget.amount).toLocaleString('en-US', { minimumFractionDigits: 0 })}
                            </span>
                            <div className="hidden group-hover:flex gap-1">
                              <button
                                onClick={() => {
                                  setEditingBudget(budget);
                                  setShowBudgetModal(true);
                                }}
                                className="p-1 text-gray-400 hover:text-gray-600"
                              >
                                <Edit2 className="w-3 h-3" />
                              </button>
                              <button
                                onClick={() => handleDeleteBudget(budget.id)}
                                className="p-1 text-gray-400 hover:text-red-600"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}

                      <div className="pt-2 mt-2 border-t border-gray-200">
                        <div className="flex justify-between text-sm">
                          <span className="text-emerald-600">Income:</span>
                          <span className="font-medium text-emerald-600">
                            ${incomeTotal.toLocaleString('en-US', { minimumFractionDigits: 0 })}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-red-600">Expenses:</span>
                          <span className="font-medium text-red-600">
                            ${expenseTotal.toLocaleString('en-US', { minimumFractionDigits: 0 })}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm pt-1 border-t border-gray-200">
                          <span className="text-gray-700 font-medium">Net:</span>
                          <span className={`font-bold ${incomeTotal - expenseTotal >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
                            ${(incomeTotal - expenseTotal).toLocaleString('en-US', { minimumFractionDigits: 0 })}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </main>

      {showBudgetModal && (
        <BudgetModal
          budget={editingBudget}
          categories={categories}
          userId={user!.id}
          year={selectedYear}
          onClose={() => {
            setShowBudgetModal(false);
            setEditingBudget(null);
          }}
          onSave={handleBudgetSaved}
        />
      )}
    </div>
  );
}

function BudgetModal({
  budget,
  categories,
  userId,
  year,
  onClose,
  onSave,
}: {
  budget: BudgetWithCategory | null;
  categories: Category[];
  userId: string;
  year: number;
  onClose: () => void;
  onSave: () => void;
}) {
  const [categoryId, setCategoryId] = useState(budget?.category_id || '');
  const [amount, setAmount] = useState(budget?.amount.toString() || '');
  const [scope, setScope] = useState<'monthly' | 'yearly'>(
    budget?.month !== null ? 'monthly' : 'yearly'
  );
  const [month, setMonth] = useState(budget?.month?.toString() || new Date().getMonth().toString());
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const budgetData = {
        user_id: userId,
        category_id: categoryId,
        amount: parseFloat(amount),
        month: scope === 'monthly' ? parseInt(month) : null,
        year,
      };

      if (budget) {
        await supabase
          .from('planned_budgets')
          .update(budgetData)
          .eq('id', budget.id);
      } else {
        await supabase.from('planned_budgets').insert(budgetData);
      }
      onSave();
    } catch (error) {
      console.error('Error saving budget:', error);
    }
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-900">
            {budget ? 'Edit Budget' : 'Add Budget'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setScope('monthly')}
              className={`flex-1 py-2 px-4 rounded-lg font-medium transition-all ${
                scope === 'monthly'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Monthly
            </button>
            <button
              type="button"
              onClick={() => setScope('yearly')}
              className={`flex-1 py-2 px-4 rounded-lg font-medium transition-all ${
                scope === 'yearly'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Yearly
            </button>
          </div>

          {scope === 'monthly' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Month</label>
              <select
                value={month}
                onChange={(e) => setMonth(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {monthNames.map((m, i) => (
                  <option key={i} value={i}>
                    {m}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
            <select
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            >
              <option value="">Select category</option>
              <optgroup label="Income">
                {categories
                  .filter((c) => c.type === 'income')
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
              </optgroup>
              <optgroup label="Expenses">
                {categories
                  .filter((c) => c.type === 'expense')
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
              </optgroup>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Planned Amount
            </label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="number"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="0.00"
                required
              />
            </div>
          </div>

          <p className="text-xs text-gray-500">
            Year: {year}
          </p>

          <div className="flex gap-2 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 px-4 border-2 border-gray-200 text-gray-700 font-medium rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || !categoryId || !amount}
              className="flex-1 py-2 px-4 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg hover:from-teal-600 hover:to-blue-700 disabled:opacity-50"
            >
              {loading ? 'Saving...' : budget ? 'Update' : 'Add Budget'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
