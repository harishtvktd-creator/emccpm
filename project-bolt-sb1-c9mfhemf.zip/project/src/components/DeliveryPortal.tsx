import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import {
  Truck, CheckCircle2, Clock, Package, PackageSearch, Loader2,
  ChevronDown, ChevronUp, ChevronRight, X, AlertCircle, RefreshCw,
  Phone, User, MapPin, Search, Download, Filter, ArrowUpDown, SortAsc, SortDesc,
  Paperclip,
} from 'lucide-react';

type DeliveryStatus = 'assigned' | 'in_transit' | 'delivered';
type SortKey = 'created_at' | 'requisition_number' | 'project' | 'status';

type MRAttachment = { name: string; url: string; size: number };

type MR = {
  id: string;
  requisition_number: string;
  title: string;
  purpose: string | null;
  preferred_supplier: string | null;
  required_delivery_date: string | null;
  po_number: string | null;
  po_vendor: string | null;
  po_date: string | null;
  po_amount: number | null;
  po_vendor_contact_name: string | null;
  po_vendor_contact_number: string | null;
  po_vendor_location: string | null;
  delivery_status: DeliveryStatus;
  delivery_date: string | null;
  delivery_remarks: string | null;
  transit_remarks: string | null;
  delivery_updated_at: string | null;
  attachments: MRAttachment[];
  created_at: string;
  projects?: { name: string } | null;
  creator?: { name: string } | null;
};

const DELIVERY_STEPS: { key: DeliveryStatus; label: string }[] = [
  { key: 'assigned',   label: 'Assigned' },
  { key: 'in_transit', label: 'In Transit' },
  { key: 'delivered',  label: 'Delivered' },
];

const DELIVERY_META: Record<DeliveryStatus, { label: string; color: string; bg: string; dot: string; border: string }> = {
  assigned:   { label: 'Assigned',   color: 'text-blue-700',  bg: 'bg-blue-50',   dot: 'bg-blue-500',   border: 'border-blue-200' },
  in_transit: { label: 'In Transit', color: 'text-amber-700', bg: 'bg-amber-50',  dot: 'bg-amber-500',  border: 'border-amber-200' },
  delivered:  { label: 'Delivered',  color: 'text-green-700', bg: 'bg-green-50',  dot: 'bg-green-500',  border: 'border-green-200' },
};

const STEP_IDX: Record<DeliveryStatus, number> = { assigned: 0, in_transit: 1, delivered: 2 };

function fmtDate(d: string) {
  const [y, m, day] = d.split('T')[0].split('-');
  return `${day}/${m}/${y}`;
}

function DeliveryStepper({ status }: { status: DeliveryStatus }) {
  const current = STEP_IDX[status];
  return (
    <div className="flex items-center gap-0 overflow-x-auto py-1">
      {DELIVERY_STEPS.map((step, i) => {
        const done = i < current; const active = i === current;
        return (
          <div key={step.key} className="flex items-center">
            <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
              active ? 'bg-teal-600 text-white' : done ? 'bg-teal-100 text-teal-700' : 'bg-gray-100 text-gray-400'
            }`}>
              {done ? <CheckCircle2 className="w-3 h-3" /> : <span className="w-3 h-3 rounded-full border-2 border-current inline-block" />}
              {step.label}
            </div>
            {i < DELIVERY_STEPS.length - 1 && (
              <ChevronRight className={`w-3.5 h-3.5 flex-shrink-0 mx-0.5 ${i < current ? 'text-teal-400' : 'text-gray-300'}`} />
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ── In Transit Modal ──────────────────────────────────── */
function InTransitModal({ mr, onClose, onSaved }: {
  mr: MR; onClose: () => void; onSaved: () => void;
}) {
  const [remarks, setRemarks] = useState('');
  const [saving, setSaving]   = useState(false);
  const [error, setError]     = useState<string | null>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const { error: err } = await supabase.from('material_requisitions').update({
      delivery_status:     'in_transit',
      transit_remarks:     remarks.trim() || null,
      delivery_updated_at: new Date().toISOString(),
    }).eq('id', mr.id);
    setSaving(false);
    if (err) { setError(err.message); return; }
    onSaved();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div>
            <h3 className="font-bold text-gray-900">Mark as In Transit</h3>
            <p className="text-xs text-gray-500 mt-0.5">{mr.requisition_number} · {mr.title}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100"><X className="w-5 h-5 text-gray-500" /></button>
        </div>
        <form onSubmit={handleSave} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
              Transit Remarks <span className="text-gray-400 font-normal">(optional)</span>
            </label>
            <textarea
              value={remarks} onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Dispatched from supplier — expected arrival 3 days"
              rows={3}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 resize-none"
            />
          </div>
          {error && (
            <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl px-3 py-2.5">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />{error}
            </div>
          )}
          <div className="flex items-center gap-3 pt-1">
            <button type="submit" disabled={saving} className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-medium rounded-xl text-sm disabled:opacity-60 hover:from-amber-600 hover:to-orange-600 transition-all shadow-sm">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Truck className="w-4 h-4" />}
              {saving ? 'Saving…' : 'Confirm In Transit'}
            </button>
            <button type="button" onClick={onClose} className="px-4 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* ── Delivered Modal ────────────────────────────────────── */
function DeliveredModal({ mr, onClose, onSaved }: {
  mr: MR; onClose: () => void; onSaved: () => void;
}) {
  const [deliveryDate, setDeliveryDate] = useState(new Date().toISOString().split('T')[0]);
  const [remarks, setRemarks]           = useState('');
  const [saving, setSaving]             = useState(false);
  const [error, setError]               = useState<string | null>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!deliveryDate) { setError('Delivery date is required.'); return; }
    setSaving(true);
    const { error: err } = await supabase.from('material_requisitions').update({
      delivery_status:     'delivered',
      delivery_date:       deliveryDate,
      delivery_remarks:    remarks.trim() || null,
      delivery_updated_at: new Date().toISOString(),
    }).eq('id', mr.id);
    setSaving(false);
    if (err) { setError(err.message); return; }
    onSaved();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div>
            <h3 className="font-bold text-gray-900">Mark as Delivered</h3>
            <p className="text-xs text-gray-500 mt-0.5">{mr.requisition_number} · {mr.title}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100"><X className="w-5 h-5 text-gray-500" /></button>
        </div>
        <form onSubmit={handleSave} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
              Delivery Date <span className="text-red-400">*</span>
            </label>
            <input
              type="date" value={deliveryDate} onChange={(e) => setDeliveryDate(e.target.value)} required
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
              Remarks <span className="text-gray-400 font-normal">(optional)</span>
            </label>
            <textarea
              value={remarks} onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Delivered to site — all items accounted for"
              rows={3}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 resize-none"
            />
          </div>
          {error && (
            <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl px-3 py-2.5">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />{error}
            </div>
          )}
          <div className="flex items-center gap-3 pt-1">
            <button type="submit" disabled={saving} className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-green-500 to-teal-600 text-white font-medium rounded-xl text-sm disabled:opacity-60 hover:from-green-600 hover:to-teal-700 transition-all shadow-sm">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
              {saving ? 'Saving…' : 'Confirm Delivery'}
            </button>
            <button type="button" onClick={onClose} className="px-4 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* ── CSV export ─────────────────────────────────────────── */
function exportDeliveriesCSV(mrs: MR[]) {
  const header = [
    'MR Number', 'Date', 'Title', 'Requested By', 'Project',
    'PO Number', 'Vendor', 'PO Amount (AED)',
    'Delivery Status', 'Delivery Date', 'Transit Remarks', 'Delivery Remarks',
  ];
  const rows = mrs.map((mr) => [
    mr.requisition_number,
    fmtDate(mr.created_at),
    `"${mr.title.replace(/"/g, '""')}"`,
    `"${((mr.creator as { name: string } | null)?.name ?? '').replace(/"/g, '""')}"`,
    `"${((mr.projects as { name: string } | null)?.name ?? '').replace(/"/g, '""')}"`,
    mr.po_number ?? '',
    `"${(mr.po_vendor ?? '').replace(/"/g, '""')}"`,
    mr.po_amount != null ? mr.po_amount.toFixed(2) : '',
    DELIVERY_META[mr.delivery_status].label,
    mr.delivery_date ? fmtDate(mr.delivery_date) : '',
    `"${(mr.transit_remarks ?? '').replace(/"/g, '""')}"`,
    `"${(mr.delivery_remarks ?? '').replace(/"/g, '""')}"`,
  ]);
  const csv  = [header, ...rows].map((r) => r.join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url;
  a.download = `Deliveries-${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

/* ── Main component ─────────────────────────────────────── */
export function DeliveryPortal() {
  const { teamMember } = useAuth();
  const [mrs, setMrs]                 = useState<MR[]>([]);
  const [projects, setProjects]       = useState<string[]>([]);
  const [loading, setLoading]         = useState(true);
  const [expandedId, setExpandedId]   = useState<string | null>(null);
  const [deliverMR, setDeliverMR]     = useState<MR | null>(null);
  const [transitMR, setTransitMR]     = useState<MR | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  /* Filters */
  const [search, setSearch]               = useState('');
  const [filterStatus, setFilterStatus]   = useState<DeliveryStatus | 'all'>('all');
  const [filterProject, setFilterProject] = useState('all');
  const [filterFrom, setFilterFrom]       = useState('');
  const [filterTo, setFilterTo]           = useState('');
  const [sortKey, setSortKey]             = useState<SortKey>('created_at');
  const [sortAsc, setSortAsc]             = useState(false);

  const fetchMRs = useCallback(async () => {
    if (!teamMember) return;
    setLoading(true);
    const { data } = await supabase
      .from('material_requisitions')
      .select('id,requisition_number,title,purpose,preferred_supplier,required_delivery_date,po_number,po_vendor,po_date,po_amount,po_vendor_contact_name,po_vendor_contact_number,po_vendor_location,delivery_status,delivery_date,delivery_remarks,transit_remarks,delivery_updated_at,attachments,created_at,projects(name),creator:team_members!created_by(name)')
      .not('delivery_status', 'is', null)
      .order('created_at', { ascending: false });
    const list = (data as MR[]) ?? [];
    setMrs(list);
    const projs = Array.from(new Set(list.map((m) => (m.projects as { name: string } | null)?.name).filter(Boolean))) as string[];
    setProjects(projs);
    setLoading(false);
  }, [teamMember]);

  useEffect(() => { fetchMRs(); }, [fetchMRs]);

  const counts = {
    total:      mrs.length,
    assigned:   mrs.filter((m) => m.delivery_status === 'assigned').length,
    in_transit: mrs.filter((m) => m.delivery_status === 'in_transit').length,
    delivered:  mrs.filter((m) => m.delivery_status === 'delivered').length,
  };

  /* Filtering + sorting */
  const filtered = mrs
    .filter((m) => filterStatus === 'all' || m.delivery_status === filterStatus)
    .filter((m) => filterProject === 'all' || (m.projects as { name: string } | null)?.name === filterProject)
    .filter((m) => !filterFrom || m.created_at.split('T')[0] >= filterFrom)
    .filter((m) => !filterTo   || m.created_at.split('T')[0] <= filterTo)
    .filter((m) => {
      if (!search) return true;
      const q = search.toLowerCase();
      return (
        m.requisition_number.toLowerCase().includes(q) ||
        m.title.toLowerCase().includes(q) ||
        (m.po_number ?? '').toLowerCase().includes(q) ||
        (m.po_vendor ?? '').toLowerCase().includes(q) ||
        ((m.projects as { name: string } | null)?.name ?? '').toLowerCase().includes(q) ||
        ((m.creator  as { name: string } | null)?.name ?? '').toLowerCase().includes(q)
      );
    })
    .sort((a, b) => {
      let cmp = 0;
      if      (sortKey === 'created_at')         cmp = a.created_at.localeCompare(b.created_at);
      else if (sortKey === 'requisition_number') cmp = a.requisition_number.localeCompare(b.requisition_number);
      else if (sortKey === 'project')            cmp = ((a.projects as { name: string } | null)?.name ?? '').localeCompare((b.projects as { name: string } | null)?.name ?? '');
      else if (sortKey === 'status')             cmp = STEP_IDX[a.delivery_status] - STEP_IDX[b.delivery_status];
      return sortAsc ? cmp : -cmp;
    });

  const activeFilters = [filterStatus !== 'all', filterProject !== 'all', !!filterFrom, !!filterTo].filter(Boolean).length;
  const clearFilters  = () => { setFilterStatus('all'); setFilterProject('all'); setFilterFrom(''); setFilterTo(''); };
  const toggleSort    = (k: SortKey) => { if (sortKey === k) setSortAsc((a) => !a); else { setSortKey(k); setSortAsc(false); } };

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-7 h-7 animate-spin text-teal-500" />
    </div>
  );

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-bold text-gray-900 text-lg">My Deliveries</h3>
          <p className="text-sm text-gray-500 mt-0.5">{filtered.length} of {mrs.length} deliveries</p>
        </div>
        <div className="flex items-center gap-2">
          {filtered.length > 0 && (
            <button
              onClick={() => exportDeliveriesCSV(filtered)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm text-gray-600 hover:border-teal-300 hover:text-teal-600 transition-colors"
            >
              <Download className="w-4 h-4" />
              Export ({filtered.length})
            </button>
          )}
          <button onClick={fetchMRs} disabled={loading} className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm text-gray-600 hover:border-teal-300 hover:text-teal-600 transition-colors">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      {/* Metric cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Total',       value: counts.total,      icon: Package,      color: 'text-gray-700',  bg: 'bg-gray-100',   border: 'border-gray-200' },
          { label: 'Assigned',    value: counts.assigned,   icon: Truck,        color: 'text-blue-700',  bg: 'bg-blue-50',    border: 'border-blue-100' },
          { label: 'In Transit',  value: counts.in_transit, icon: Clock,        color: 'text-amber-700', bg: 'bg-amber-50',   border: 'border-amber-100' },
          { label: 'Delivered',   value: counts.delivered,  icon: CheckCircle2, color: 'text-green-700', bg: 'bg-green-50',   border: 'border-green-100' },
        ].map((c) => (
          <div key={c.label} className={`bg-white rounded-xl border ${c.border} p-4 flex items-center gap-3 cursor-pointer hover:shadow-sm transition-shadow`} onClick={() => setFilterStatus(c.label === 'Total' ? 'all' : c.label.toLowerCase().replace(' ', '_') as DeliveryStatus)}>
            <div className={`w-9 h-9 ${c.bg} rounded-lg flex items-center justify-center flex-shrink-0`}>
              <c.icon className={`w-4 h-4 ${c.color}`} />
            </div>
            <div>
              <p className={`text-xl font-bold ${c.color}`}>{c.value}</p>
              <p className="text-xs text-gray-500">{c.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Search + filter toolbar */}
      <div className="space-y-2">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text" value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search MR number, title, PO, vendor, project, requester…"
              className="w-full pl-9 pr-8 py-2.5 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400"
            />
            {search && <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>}
          </div>
          <button
            onClick={() => setShowFilters((f) => !f)}
            className={`flex items-center gap-1.5 px-3 py-2.5 rounded-xl text-sm font-medium border transition-all ${showFilters || activeFilters > 0 ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-gray-600 border-gray-200 hover:border-teal-300'}`}
          >
            <Filter className="w-4 h-4" />
            Filters
            {activeFilters > 0 && <span className="bg-white text-teal-700 text-xs rounded-full w-4 h-4 flex items-center justify-center font-bold">{activeFilters}</span>}
          </button>
          {activeFilters > 0 && (
            <button onClick={clearFilters} className="flex items-center gap-1 px-3 py-2.5 rounded-xl text-sm text-red-500 hover:bg-red-50 border border-red-200 transition-colors">
              <X className="w-3.5 h-3.5" />Clear
            </button>
          )}
        </div>

        {/* Expanded filter panel */}
        {showFilters && (
          <div className="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Status</label>
                <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value as typeof filterStatus)} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400">
                  <option value="all">All Statuses</option>
                  <option value="assigned">Assigned</option>
                  <option value="in_transit">In Transit</option>
                  <option value="delivered">Delivered</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Project</label>
                <select value={filterProject} onChange={(e) => setFilterProject(e.target.value)} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400">
                  <option value="all">All Projects</option>
                  {projects.map((p) => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Date From</label>
                <input type="date" value={filterFrom} onChange={(e) => setFilterFrom(e.target.value)} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Date To</label>
                <input type="date" value={filterTo} onChange={(e) => setFilterTo(e.target.value)} className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-teal-400" />
              </div>
            </div>
            {/* Sort row */}
            <div className="pt-3 border-t border-gray-100">
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Sort By</label>
              <div className="flex flex-wrap gap-2">
                {([
                  { key: 'created_at',         label: 'Date' },
                  { key: 'requisition_number', label: 'MR Number' },
                  { key: 'project',            label: 'Project' },
                  { key: 'status',             label: 'Status' },
                ] as { key: SortKey; label: string }[]).map(({ key, label }) => (
                  <button key={key} onClick={() => toggleSort(key)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${sortKey === key ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-gray-600 border-gray-200 hover:border-teal-300'}`}>
                    {label}
                    {sortKey === key
                      ? (sortAsc ? <SortAsc className="w-3.5 h-3.5" /> : <SortDesc className="w-3.5 h-3.5" />)
                      : <ArrowUpDown className="w-3.5 h-3.5 opacity-40" />}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Active filter chips */}
        {activeFilters > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {filterStatus !== 'all' && (
              <span className="flex items-center gap-1 px-2 py-0.5 bg-teal-100 text-teal-700 rounded-full text-xs font-medium">
                Status: {DELIVERY_META[filterStatus as DeliveryStatus]?.label ?? filterStatus}
                <button onClick={() => setFilterStatus('all')}><X className="w-3 h-3" /></button>
              </span>
            )}
            {filterProject !== 'all' && (
              <span className="flex items-center gap-1 px-2 py-0.5 bg-teal-100 text-teal-700 rounded-full text-xs font-medium">
                Project: {filterProject}<button onClick={() => setFilterProject('all')}><X className="w-3 h-3 ml-0.5" /></button>
              </span>
            )}
            {filterFrom && (
              <span className="flex items-center gap-1 px-2 py-0.5 bg-teal-100 text-teal-700 rounded-full text-xs font-medium">
                From: {fmtDate(filterFrom)}<button onClick={() => setFilterFrom('')}><X className="w-3 h-3 ml-0.5" /></button>
              </span>
            )}
            {filterTo && (
              <span className="flex items-center gap-1 px-2 py-0.5 bg-teal-100 text-teal-700 rounded-full text-xs font-medium">
                To: {fmtDate(filterTo)}<button onClick={() => setFilterTo('')}><X className="w-3 h-3 ml-0.5" /></button>
              </span>
            )}
          </div>
        )}

        {/* Quick status pills */}
        <div className="flex flex-wrap gap-2">
          {([
            { key: 'all',        label: `All (${counts.total})` },
            { key: 'assigned',   label: `Assigned (${counts.assigned})` },
            { key: 'in_transit', label: `In Transit (${counts.in_transit})` },
            { key: 'delivered',  label: `Delivered (${counts.delivered})` },
          ] as { key: typeof filterStatus; label: string }[]).map(({ key, label }) => (
            <button key={key} onClick={() => setFilterStatus(key)} className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${filterStatus === key ? 'bg-gray-800 text-white border-gray-800' : 'bg-white text-gray-600 border-gray-200 hover:border-gray-400'}`}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* MR list */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-14 text-center">
          <PackageSearch className="w-14 h-14 text-gray-300 mx-auto mb-4" />
          <p className="font-semibold text-gray-700">
            {mrs.length === 0 ? 'No deliveries assigned yet' : 'No deliveries match this filter'}
          </p>
          {mrs.length === 0 && <p className="text-sm text-gray-400 mt-1">Deliveries will appear here once a PO is released by the Procurement Lead.</p>}
          {activeFilters > 0 && <button onClick={clearFilters} className="text-teal-600 text-sm hover:underline mt-2">Clear filters</button>}
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((mr) => {
            const meta       = DELIVERY_META[mr.delivery_status];
            const expanded   = expandedId === mr.id;
            const creatorName = (mr.creator as { name: string } | null)?.name;
            return (
              <div key={mr.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="flex items-start gap-3 p-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Truck className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-0.5">
                      <span className="font-bold text-gray-900 font-mono text-sm">{mr.requisition_number}</span>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${meta.bg} ${meta.color} ${meta.border}`}>
                        <span className={`inline-block w-1.5 h-1.5 rounded-full ${meta.dot} mr-1`} />
                        {meta.label}
                      </span>
                    </div>
                    <p className="text-sm text-gray-700 truncate">{mr.title}</p>
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 mt-1 text-xs text-gray-400">
                      <span>{fmtDate(mr.created_at)}</span>
                      {creatorName && <span className="text-blue-600 font-medium">· Requested by {creatorName}</span>}
                      {mr.projects && <span>· {(mr.projects as { name: string }).name}</span>}
                      {mr.po_number && <span className="text-teal-600 font-medium">· PO: {mr.po_number}</span>}
                      {mr.po_vendor && <span>· {mr.po_vendor}</span>}
                      {mr.delivery_date && <span className="text-green-600 font-medium">· Delivered: {fmtDate(mr.delivery_date)}</span>}
                      {mr.attachments?.length > 0 && (
                        <span className="flex items-center gap-1 text-blue-500">
                          <Paperclip className="w-3 h-3" />{mr.attachments.length} file{mr.attachments.length !== 1 ? 's' : ''}
                        </span>
                      )}
                    </div>
                    {mr.transit_remarks && mr.delivery_status !== 'delivered' && (
                      <p className="text-xs text-amber-700 mt-1 bg-amber-50 px-2 py-0.5 rounded-md inline-block">
                        Transit: {mr.transit_remarks}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {mr.delivery_status === 'assigned' && (
                      <button
                        onClick={() => setTransitMR(mr)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold rounded-lg transition-colors"
                      >
                        <Truck className="w-3.5 h-3.5" />
                        Mark In Transit
                      </button>
                    )}
                    {mr.delivery_status === 'in_transit' && (
                      <button
                        onClick={() => setDeliverMR(mr)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs font-semibold rounded-lg transition-colors"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Mark Delivered
                      </button>
                    )}
                    {mr.delivery_status === 'delivered' && (
                      <span className="flex items-center gap-1 text-xs text-green-600 font-semibold bg-green-50 px-3 py-1.5 rounded-lg border border-green-200">
                        <CheckCircle2 className="w-3.5 h-3.5" />Delivered
                      </span>
                    )}
                    <button onClick={() => setExpandedId(expanded ? null : mr.id)} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors">
                      {expanded ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
                    </button>
                  </div>
                </div>

                {/* Progress stepper */}
                <div className="px-4 pb-3">
                  <DeliveryStepper status={mr.delivery_status} />
                </div>

                {/* Expanded details */}
                {expanded && (
                  <div className="border-t border-gray-100 px-4 py-4 space-y-3 bg-gray-50/50">
                    {/* Requested by */}
                    {creatorName && (
                      <div className="flex items-center gap-2 text-sm text-gray-700">
                        <User className="w-4 h-4 text-gray-400 flex-shrink-0" />
                        <span className="font-semibold text-gray-600">Requested by:</span>
                        <span className="font-medium text-blue-700">{creatorName}</span>
                      </div>
                    )}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {[
                        { label: 'PO Number', value: mr.po_number ?? '—' },
                        { label: 'Vendor',    value: mr.po_vendor ?? '—' },
                        { label: 'PO Date',   value: mr.po_date ? fmtDate(mr.po_date) : '—' },
                        { label: 'PO Amount', value: mr.po_amount != null ? `AED ${mr.po_amount.toLocaleString('en-AE', { minimumFractionDigits: 2 })}` : '—' },
                      ].map((f) => (
                        <div key={f.label} className="bg-white rounded-lg border border-gray-100 px-3 py-2.5">
                          <p className="text-xs font-semibold text-gray-500 mb-0.5">{f.label}</p>
                          <p className="text-sm font-medium text-gray-800">{f.value}</p>
                        </div>
                      ))}
                    </div>
                    {(mr.po_vendor_contact_name || mr.po_vendor_contact_number || mr.po_vendor_location) && (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        {mr.po_vendor_contact_name && (
                          <div className="bg-white rounded-lg border border-gray-100 px-3 py-2.5 flex items-start gap-2">
                            <User className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                            <div><p className="text-xs font-semibold text-gray-500 mb-0.5">Contact Name</p><p className="text-sm font-medium text-gray-800">{mr.po_vendor_contact_name}</p></div>
                          </div>
                        )}
                        {mr.po_vendor_contact_number && (
                          <div className="bg-white rounded-lg border border-gray-100 px-3 py-2.5 flex items-start gap-2">
                            <Phone className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                            <div><p className="text-xs font-semibold text-gray-500 mb-0.5">Contact Number</p><p className="text-sm font-medium text-gray-800">{mr.po_vendor_contact_number}</p></div>
                          </div>
                        )}
                        {mr.po_vendor_location && (
                          <div className="bg-white rounded-lg border border-gray-100 px-3 py-2.5 flex items-start gap-2">
                            <MapPin className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                            <div><p className="text-xs font-semibold text-gray-500 mb-0.5">Location</p><p className="text-sm font-medium text-gray-800">{mr.po_vendor_location}</p></div>
                          </div>
                        )}
                      </div>
                    )}
                    {mr.transit_remarks && (
                      <div className="bg-amber-50 border border-amber-100 rounded-xl px-4 py-3">
                        <p className="text-xs font-semibold text-amber-600 uppercase tracking-wide mb-1">Transit Remarks</p>
                        <p className="text-sm text-amber-800">{mr.transit_remarks}</p>
                      </div>
                    )}
                    {mr.delivery_date && (
                      <div className="bg-green-50 border border-green-100 rounded-xl px-4 py-3">
                        <p className="text-xs font-semibold text-green-600 uppercase tracking-wide mb-1">Delivery Confirmed</p>
                        <p className="text-sm font-bold text-green-800">{fmtDate(mr.delivery_date)}</p>
                        {mr.delivery_remarks && <p className="text-sm text-green-700 mt-1">{mr.delivery_remarks}</p>}
                      </div>
                    )}
                    {mr.attachments?.length > 0 && (
                      <div>
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Attachments ({mr.attachments.length})</p>
                        <div className="flex flex-wrap gap-2">
                          {mr.attachments.map((att, i) => (
                            <a
                              key={i}
                              href={att.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              download={att.name}
                              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-lg text-xs font-medium text-blue-700 hover:bg-blue-100 hover:border-blue-300 transition-colors"
                            >
                              <Paperclip className="w-3 h-3 flex-shrink-0" />
                              <span className="max-w-[200px] truncate">{att.name}</span>
                              <span className="text-blue-400">({(att.size / 1024).toFixed(0)} KB)</span>
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                    {mr.preferred_supplier && (
                      <p className="text-sm text-gray-600"><span className="font-semibold text-gray-700">Preferred Supplier: </span>{mr.preferred_supplier}</p>
                    )}
                    {mr.purpose && (
                      <p className="text-sm text-gray-600"><span className="font-semibold text-gray-700">Remarks: </span>{mr.purpose}</p>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {transitMR && (
        <InTransitModal
          mr={transitMR}
          onClose={() => setTransitMR(null)}
          onSaved={() => { setTransitMR(null); fetchMRs(); }}
        />
      )}
      {deliverMR && (
        <DeliveredModal
          mr={deliverMR}
          onClose={() => setDeliverMR(null)}
          onSaved={() => { setDeliverMR(null); fetchMRs(); }}
        />
      )}
    </div>
  );
}
