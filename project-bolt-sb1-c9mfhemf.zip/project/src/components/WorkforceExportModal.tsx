/**
 * WorkforceExportModal
 * Date-range Normal Time / Overtime reports — PDF (A3 landscape) + Excel (.xlsx)
 * Features: company logo, complete employee list, colour-coded status cells, day-of-week row,
 *           daily column totals, per-employee totals, legend, frozen panes (Excel).
 */
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import {
  X, Loader2, FileText, Table2, Download, AlertCircle,
  ChevronDown, ChevronUp, Eye,
} from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import ExcelJS from 'exceljs';

// ── Branding ──────────────────────────────────────────────────
const COMPANY  = 'EMCC Projects Division';
const TAGLINE  = 'Workforce Management System';
const LOGO_URL = '/EMCC_Logo..jpg';

// ── Status maps ───────────────────────────────────────────────
const S_SHORT: Record<string, string> = {
  present: 'P', leave: 'L', sick_leave: 'SL',
  public_holiday: 'PH', annual_leave: 'AL', compensation_leave: 'CL',
};
const S_FULL: Record<string, string> = {
  present: 'Present', leave: 'Leave', sick_leave: 'Sick Leave',
  public_holiday: 'Public Holiday', annual_leave: 'Annual Leave',
  compensation_leave: 'Compensation Leave',
};
const S_PDF_BG: Record<string, [number,number,number]> = {
  present:            [219,234,254],
  leave:              [243,244,246],
  sick_leave:         [254,226,226],
  public_holiday:     [219,234,254],
  annual_leave:       [254,243,199],
  compensation_leave: [237,233,254],
};
const S_PDF_FG: Record<string, [number,number,number]> = {
  present:            [30,64,175],
  leave:              [55,65,81],
  sick_leave:         [153,27,27],
  public_holiday:     [30,64,175],
  annual_leave:       [146,64,14],
  compensation_leave: [91,33,182],
};
const S_XL_BG: Record<string, string> = {
  present: 'FFDBEAFE', leave: 'FFF3F4F6', sick_leave: 'FFFEE2E2',
  public_holiday: 'FFDBEAFE', annual_leave: 'FFFEF3C7', compensation_leave: 'FFEDE9FE',
};
const S_XL_FG: Record<string, string> = {
  present: 'FF1E40AF', leave: 'FF374151', sick_leave: 'FF991B1B',
  public_holiday: 'FF1E40AF', annual_leave: 'FF92400E', compensation_leave: 'FF5B21B6',
};

// ── Types ─────────────────────────────────────────────────────
type DayEntry  = { regular: number; ot: number; status: string; notes: string | null };
type EmpRecord = {
  employee_id: string; employee_code: string; employee_name: string;
  designation: string | null; assigned_project_codes: string; days: Map<string, DayEntry>;
  total_regular: number; total_ot: number; total_hours: number;
};
type WSD = { day_of_week: number; normal_hours: number };
type PWR = { project_id: string; day_of_week: number; normal_hours: number };
type DOV = { date_from: string; date_to: string; normal_hours: number; project_id: string | null };

// ── Helpers ───────────────────────────────────────────────────
const p2 = (n: number) => String(n).padStart(2, '0');

/** Returns every calendar date (YYYY-MM-DD) from df to dt inclusive. */
function getDatesInRange(df: string, dt: string): string[] {
  const result: string[] = [];
  const cur = new Date(df + 'T00:00:00');
  const end = new Date(dt + 'T00:00:00');
  while (cur <= end) {
    const y = cur.getFullYear();
    const m = String(cur.getMonth() + 1).padStart(2, '0');
    const d = String(cur.getDate()).padStart(2, '0');
    result.push(`${y}-${m}-${d}`);
    cur.setDate(cur.getDate() + 1);
  }
  return result;
}

function fmtShort(d: string) {
  if (!d) return '';
  const [y, m, day] = d.split('-');
  return `${day}/${m}/${y}`;
}

function workHrs(s: string | null, e: string | null, brk: number): number {
  if (!s || !e) return 0;
  const [sh, sm] = s.split(':').map(Number);
  const [eh, em] = e.split(':').map(Number);
  const m = (eh * 60 + em) - (sh * 60 + sm) - (brk ?? 0);
  return m > 0 ? Math.round(m * 100 / 60) / 100 : 0;
}
function normalHrs(date: string, pid: string | null, ws: WSD[], pw: PWR[], ov: DOV[]): number {
  const dow = new Date(date + 'T00:00:00').getDay();
  const hit = (o: DOV) => date >= o.date_from && date <= o.date_to;
  const a = ov.find(o => hit(o) && o.project_id === pid); if (a) return a.normal_hours;
  const b = ov.find(o => hit(o) && !o.project_id);        if (b) return b.normal_hours;
  if (pid) { const c = pw.find(r => r.project_id === pid && r.day_of_week === dow); if (c) return c.normal_hours; }
  return ws.find(s => s.day_of_week === dow)?.normal_hours ?? 0;
}
async function imgBase64(url: string): Promise<string | null> {
  try {
    const blob = await (await fetch(url)).blob();
    return await new Promise(res => { const r = new FileReader(); r.onload = () => res(r.result as string); r.onerror = () => res(null); r.readAsDataURL(blob); });
  } catch { return null; }
}

// ── Component ─────────────────────────────────────────────────
export function WorkforceExportModal({
  projects, onClose,
}: { projects: { id: string; name: string }[]; onClose: () => void }) {

  const now = new Date();
  const defaultFrom = `${now.getFullYear()}-${p2(now.getMonth() + 1)}-01`;
  const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const defaultTo = `${now.getFullYear()}-${p2(now.getMonth() + 1)}-${p2(lastDay)}`;

  const [type,     setType]     = useState<'normal' | 'overtime'>('normal');
  const [proj,     setProj]     = useState('all');
  const [dateFrom, setDateFrom] = useState(defaultFrom);
  const [dateTo,   setDateTo]   = useState(defaultTo);
  const [empType,  setEmpType]  = useState<'all' | 'staff' | 'labour' | 'subcontractor'>('all');
  const [busy,     setBusy]     = useState<null | 'load' | 'pdf' | 'excel'>(null);
  const [err,      setErr]      = useState<string | null>(null);
  const [recs,     setRecs]     = useState<EmpRecord[]>([]);
  const [loaded,   setLoaded]   = useState(false);
  const [open,     setOpen]     = useState(false);
  const [logo,     setLogo]     = useState<string | null>(null);
  const [ws,  setWs]  = useState<WSD[]>([]);
  const [pw,  setPw]  = useState<PWR[]>([]);
  const [ov,  setOv]  = useState<DOV[]>([]);

  useEffect(() => {
    imgBase64(LOGO_URL).then(setLogo);
    Promise.all([
      supabase.from('work_schedule').select('day_of_week,normal_hours'),
      supabase.from('work_schedule_project_weekly').select('project_id,day_of_week,normal_hours'),
      supabase.from('work_schedule_date_overrides').select('date_from,date_to,normal_hours,project_id'),
    ]).then(([a, b, c]) => {
      if (a.data) setWs(a.data as WSD[]);
      if (b.data) setPw(b.data as PWR[]);
      if (c.data) setOv(c.data as DOV[]);
    });
  }, []);

  useEffect(() => { setLoaded(false); setRecs([]); }, [type, proj, dateFrom, dateTo, empType]);

  // Derived from date range
  const allDates   = getDatesInRange(dateFrom, dateTo);
  const nd         = allDates.length;
  const projName   = proj === 'all' ? 'All Projects' : (projects.find(p => p.id === proj)?.name ?? '');
  const title      = type === 'normal' ? 'Normal Time Report' : 'Overtime Report';
  const rangeLabel = `${fmtShort(dateFrom)} – ${fmtShort(dateTo)}`;
  const EMP_TYPE_LABELS: Record<string, string> = { all: 'All Types', staff: 'INDIRECT', labour: 'DIRECT', subcontractor: 'Subcontractor' };
  const empTypeName = EMP_TYPE_LABELS[empType] ?? 'All Types';

  // ── Fetch all employees + allocations ─────────────────────
  const fetchAll = async (): Promise<EmpRecord[]> => {
    const pid = proj === 'all' ? null : proj;

    let empList: { id: string; employee_code: string; name: string; designation: string | null; employment_type: string }[] = [];
    if (pid) {
      const { data } = await supabase
        .from('workforce_project_employees')
        .select('employee:workforce_employees(id,employee_code,name,designation,employment_type)')
        .eq('project_id', pid);
      empList = ((data ?? []) as any[]).map(d => d.employee).filter(Boolean);
    } else {
      const { data } = await supabase
        .from('workforce_employees').select('id,employee_code,name,designation,employment_type')
        .eq('is_active', true).order('name');
      empList = (data ?? []) as any[];
    }

    if (empType !== 'all') {
      empList = empList.filter(e => e.employment_type === empType);
    }

    let q = supabase
      .from('workforce_daily_allocations')
      .select('project_id,employee_id,entry_date,start_time,end_time,break_minutes,attendance_status,notes')
      .gte('entry_date', dateFrom).lte('entry_date', dateTo);
    if (pid) q = q.eq('project_id', pid);
    const { data: allocs } = await q;

    // Build per-employee project codes from the actual allocations in the date range —
    // not from all-time assignments. Only projects the employee worked on in this period appear.
    const allocProjectIds = [...new Set(
      (allocs ?? []).map((r: any) => r.project_id as string).filter(Boolean)
    )];
    const projCodeLookup = new Map<string, string>(); // project_id → project_code
    if (allocProjectIds.length > 0) {
      const { data: projRows } = await supabase
        .from('projects').select('id,project_code').in('id', allocProjectIds);
      for (const p of (projRows ?? []) as any[]) {
        if (p.project_code) projCodeLookup.set(p.id, p.project_code);
      }
    }
    const projCodeMap = new Map<string, string>(); // employee_id → "CODE1, CODE2"
    for (const r of (allocs ?? []) as any[]) {
      const code = projCodeLookup.get(r.project_id);
      if (!code) continue;
      const prev = projCodeMap.get(r.employee_id);
      if (!prev) { projCodeMap.set(r.employee_id, code); continue; }
      if (!prev.split(', ').includes(code)) projCodeMap.set(r.employee_id, `${prev}, ${code}`);
    }

    // Pass 1: collect all raw entries per (employee, date) — an employee may have
    // allocations on multiple projects for the same date.
    type RawEntry = { hrs: number; status: string; notes: string | null };
    const rawDayMap = new Map<string, RawEntry[]>(); // key = "empId::date"
    for (const r of (allocs ?? []) as any[]) {
      const st = r.attendance_status ?? 'present';
      const h  = st === 'present' ? workHrs(r.start_time, r.end_time, r.break_minutes ?? 0) : 0;
      const key = `${r.employee_id}::${r.entry_date}`;
      if (!rawDayMap.has(key)) rawDayMap.set(key, []);
      rawDayMap.get(key)!.push({ hrs: h, status: st, notes: r.notes ?? null });
    }

    // Pass 2: aggregate per (employee, date) → single DayEntry with correct reg/OT.
    // Total hours across all projects on a day are summed before applying the threshold.
    const dayMap = new Map<string, Map<string, DayEntry>>();
    for (const [key, entries] of rawDayMap) {
      const sepIdx = key.indexOf('::');
      const empId  = key.slice(0, sepIdx);
      const date   = key.slice(sepIdx + 2);

      const presentEntries = entries.filter(e => e.status === 'present');
      // If any entry is present the day counts as present; otherwise use the first non-present status.
      const status  = presentEntries.length > 0 ? 'present' : entries[0].status;
      const totalH  = Math.round(presentEntries.reduce((s, e) => s + e.hrs, 0) * 100) / 100;

      // Use project-specific schedule when filtered to one project, global schedule otherwise.
      const nh  = normalHrs(date, pid, ws, pw, ov);
      const reg = Math.round(Math.min(totalH, nh) * 100) / 100;
      const ot  = Math.round(Math.max(0, totalH - nh) * 100) / 100;

      const notes = entries.filter(e => e.notes).map(e => e.notes).slice(0, 3).join('; ') || null;

      if (!dayMap.has(empId)) dayMap.set(empId, new Map());
      dayMap.get(empId)!.set(date, { regular: reg, ot, status, notes });
    }

    return empList.map(emp => {
      const d = dayMap.get(emp.id) ?? new Map<string, DayEntry>();
      let tr = 0, to_ = 0, th = 0;
      for (const [, e] of d) { tr += e.regular; to_ += e.ot; th += e.regular + e.ot; }
      return {
        employee_id: emp.id, employee_code: emp.employee_code,
        employee_name: emp.name, designation: emp.designation,
        assigned_project_codes: projCodeMap.get(emp.id) ?? '',
        days: d,
        total_regular: Math.round(tr * 100) / 100,
        total_ot:      Math.round(to_ * 100) / 100,
        total_hours:   Math.round(th * 100) / 100,
      };
    }).sort((a, b) => a.employee_name.localeCompare(b.employee_name));
  };

  const getData = async () => {
    if (loaded && recs.length > 0) return recs;
    const d = await fetchAll(); setRecs(d); setLoaded(true); return d;
  };

  const handleLoad = async () => {
    setBusy('load'); setErr(null);
    try { const d = await fetchAll(); setRecs(d); setLoaded(true); setOpen(true); }
    catch (e: any) { setErr(e.message ?? 'Failed to load data'); }
    finally { setBusy(null); }
  };

  const grandTotal = (data: EmpRecord[]) =>
    type === 'normal' ? data.reduce((s, e) => s + e.total_regular, 0)
                      : data.reduce((s, e) => s + e.total_ot, 0);

  const cellHrs = (entry: DayEntry | undefined): number =>
    !entry || entry.status !== 'present' ? 0
    : type === 'normal' ? entry.regular : entry.ot;

  // ── PDF ───────────────────────────────────────────────────
  const exportPDF = async () => {
    setBusy('pdf'); setErr(null);
    try {
      const data = await getData();
      const doc  = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a3' });
      const W    = doc.internal.pageSize.getWidth();
      const H    = doc.internal.pageSize.getHeight();

      const DARK:  [number,number,number] = [30,  58, 138];
      const TEAL:  [number,number,number] = [37,  99, 235];
      const LT:    [number,number,number] = [191,219, 254];
      const SUB:   [number,number,number] = [219,234, 254];
      const WHITE: [number,number,number] = [255,255,255];
      const NAVY:  [number,number,number] = [15, 23, 42];

      doc.setFillColor(...DARK); doc.rect(0, 0, W, 30, 'F');
      if (logo) {
        try { doc.addImage(logo, 'PNG', 5, 4, 22, 22); } catch { /* skip */ }
      } else {
        doc.setFillColor(...TEAL); doc.roundedRect(5, 4, 22, 22, 3, 3, 'F');
        doc.setTextColor(...WHITE); doc.setFont('helvetica','bold'); doc.setFontSize(10);
        doc.text('WF', 16, 17, { align: 'center' });
      }
      doc.setTextColor(...WHITE); doc.setFont('helvetica','bold'); doc.setFontSize(15);
      doc.text(COMPANY, 31, 13);
      doc.setFont('helvetica','normal'); doc.setFontSize(8);
      doc.setTextColor(...LT); doc.text(TAGLINE, 31, 20);
      doc.setTextColor(...WHITE); doc.setFont('helvetica','bold'); doc.setFontSize(14);
      doc.text(title, W - 7, 12, { align: 'right' });
      doc.setFont('helvetica','normal'); doc.setFontSize(9);
      doc.text(`From: ${fmtShort(dateFrom)}  –  To: ${fmtShort(dateTo)}  ·  ${projName}  ·  ${empTypeName}`, W - 7, 19, { align: 'right' });
      doc.setFontSize(7.5); doc.setTextColor(...LT);
      doc.text(`Generated: ${new Date().toLocaleDateString('en-GB')}`, W - 7, 26, { align: 'right' });

      doc.setFillColor(...SUB); doc.rect(0, 30, W, 9, 'F');
      const gt = grandTotal(data);
      doc.setFont('helvetica','bold'); doc.setFontSize(8); doc.setTextColor(...DARK);
      doc.text(`Start: ${fmtShort(dateFrom)}  ·  End: ${fmtShort(dateTo)}  ·  ${data.length} Employees  ·  ${nd} Days  ·  ${empTypeName}`, 7, 36);
      doc.text(`Total ${type === 'normal' ? 'Regular' : 'OT'} Hours: ${gt.toFixed(2)} h`, W - 7, 36, { align: 'right' });
      doc.setFillColor(...TEAL); doc.rect(0, 39, W, 0.7, 'F');

      const FIXED = 5;
      const statusGrid: string[][] = [];

      const body: (string | number)[][] = data.map((emp, ri) => {
        const sRow: string[] = [];
        const dcells = allDates.map(dateStr => {
          const ent = emp.days.get(dateStr);
          sRow.push(ent?.status ?? '');
          if (!ent) return '';
          if (ent.status !== 'present') return S_SHORT[ent.status] ?? ent.status;
          const h = cellHrs(ent);
          return h > 0 ? h.toFixed(2) : '0.00';
        });
        statusGrid.push(sRow);
        const tot = type === 'normal' ? emp.total_regular : emp.total_ot;
        const rmk = Array.from(emp.days.values()).filter(e => e.notes).map(e => e.notes).slice(0, 2).join('; ');
        return [ri + 1, emp.employee_code, emp.employee_name, emp.designation ?? '', emp.assigned_project_codes, ...dcells, tot.toFixed(2), rmk];
      });

      const dtRow = allDates.map(dateStr => {
        const tot = data.reduce((s, emp) => {
          const e = emp.days.get(dateStr); return (!e || e.status !== 'present') ? s : s + cellHrs(e);
        }, 0);
        return tot > 0 ? tot.toFixed(1) : '';
      });
      body.push(['', '', 'DAILY TOTAL', '', '', ...dtRow, gt.toFixed(2), '']);

      const DOW_NAMES = ['Su','Mo','Tu','We','Th','Fr','Sa'];
      const dowLabels = ['','','','','', ...allDates.map(d => DOW_NAMES[new Date(d + 'T00:00:00').getDay()]), '', ''];

      // ── Full-width layout calculation ──────────────────────
      const marginL = 5, marginR = 5;
      const availW  = W - marginL - marginR;
      // Fixed column widths (mm)
      const CW = { sl: 8, code: 14, name: 28, desig: 20, proj: 22, tot: 16 };
      const fixedSum = CW.sl + CW.code + CW.name + CW.desig + CW.proj + CW.tot;
      const dayMinW  = 5.2;
      const rawDayW  = nd > 0 ? (availW - fixedSum - 20) / nd : dayMinW;
      const dayW     = Math.max(dayMinW, rawDayW);
      const remarksW = Math.max(16, availW - fixedSum - dayW * nd);

      const cs: Record<number, object> = {
        0: { cellWidth: CW.sl,   halign: 'center' },
        1: { cellWidth: CW.code },
        2: { cellWidth: CW.name },
        3: { cellWidth: CW.desig },
        4: { cellWidth: CW.proj },
      };
      allDates.forEach((_, i) => { cs[FIXED + i] = { cellWidth: dayW, halign: 'center', fontSize: 6.5 }; });
      cs[FIXED + nd]     = { cellWidth: CW.tot, halign: 'center' };
      cs[FIXED + nd + 1] = { cellWidth: remarksW };

      // Column headers: show day number (DD) from each date
      const dayHeaders = allDates.map(d => d.slice(8));

      autoTable(doc, {
        head: [['Sl#','Code','Name','Designation','Assigned Project Codes',...dayHeaders, type==='normal' ? 'Normal Hrs' : 'OT Hrs', 'Remarks']],
        body: [dowLabels, ...body],
        startY: 40.5,
        margin: { left: marginL, right: marginR },
        tableWidth: availW,
        styles: { fontSize: 7.5, cellPadding: { top: 1.8, bottom: 1.8, left: 1.5, right: 1 }, lineColor: [191,219,254], lineWidth: 0.18, overflow: 'ellipsize' },
        headStyles: { fillColor: TEAL, textColor: WHITE, fontStyle: 'bold', fontSize: 7, halign: 'center', valign: 'middle', minCellHeight: 8 },
        alternateRowStyles: { fillColor: [239,246,255] },
        columnStyles: cs,
        didParseCell: ({ row, column, cell }) => {
          const ri = row.index, ci = column.index;

          if (ri === 0) {
            if (ci >= FIXED && ci < FIXED + nd) {
              const d = new Date(allDates[ci - FIXED] + 'T00:00:00').getDay();
              const wk = d === 0 || d === 6;
              cell.styles.fillColor  = wk ? [127,29,29] : DARK;
              cell.styles.textColor  = wk ? [252,165,165] : LT;
            } else { cell.styles.fillColor = DARK; }
            cell.styles.fontStyle = 'bold'; cell.styles.fontSize = 6; cell.styles.halign = 'center'; cell.styles.minCellHeight = 5.5;
            return;
          }

          if (ri === body.length) {
            cell.styles.fillColor = LT; cell.styles.textColor = DARK; cell.styles.fontStyle = 'bold'; return;
          }

          const empIdx = ri - 1;
          if (ci >= FIXED && ci < FIXED + nd) {
            const st = statusGrid[empIdx]?.[ci - FIXED] ?? '';
            if (st && st !== 'present') {
              cell.styles.fillColor = S_PDF_BG[st] ?? [243,244,246];
              cell.styles.textColor = S_PDF_FG[st] ?? [55,65,81];
              cell.styles.fontStyle = 'bold';
            } else if (st === 'present') {
              const key = allDates[ci - FIXED];
              const h = cellHrs(data[empIdx]?.days.get(key));
              if (h > 0) {
                cell.styles.fillColor = type === 'normal' ? [219,234,254] : [254,243,199];
                cell.styles.textColor = type === 'normal' ? [30,64,175] : [146,64,14];
                cell.styles.fontStyle = 'bold';
              }
            }
          }
          if (ci === FIXED + nd) {
            cell.styles.fontStyle = 'bold';
            cell.styles.textColor = type === 'normal' ? [30,58,138] : [180,50,0];
            cell.styles.fillColor = type === 'normal' ? [219,234,254] : [254,243,199];
          }
        },
      });

      const pages = (doc as any).internal.getNumberOfPages();
      for (let pg = 1; pg <= pages; pg++) {
        doc.setPage(pg);
        doc.setFillColor(...DARK); doc.rect(0, H - 9, W, 9, 'F');
        doc.setFontSize(6.5); doc.setFont('helvetica','normal'); doc.setTextColor(...LT);
        doc.text('CONFIDENTIAL — For internal use only', 7, H - 3.5);
        doc.text(`${COMPANY}  ·  ${title}  ·  ${rangeLabel}`, W / 2, H - 3.5, { align: 'center' });
        doc.text(`Page ${pg} / ${pages}`, W - 7, H - 3.5, { align: 'right' });
      }

      const finalY = (doc as any).lastAutoTable?.finalY ?? 120;
      if (finalY + 16 < H - 12) {
        doc.setPage(pages);
        const lx = 7, ly = finalY + 4;
        doc.setFont('helvetica','bold'); doc.setFontSize(7.5); doc.setTextColor(...DARK);
        doc.text('Status Legend:', lx, ly);
        const items = ['present','leave','sick_leave','public_holiday','annual_leave','compensation_leave'];
        doc.setFontSize(7);
        items.forEach((s, i) => {
          const x = lx + i * 43;
          doc.setFillColor(...S_PDF_BG[s]); doc.roundedRect(x, ly + 2.5, 6, 4.5, 1, 1, 'F');
          doc.setFont('helvetica','bold'); doc.setTextColor(...S_PDF_FG[s]);
          doc.text(S_SHORT[s], x + 3, ly + 5.8, { align: 'center' });
          doc.setFont('helvetica','normal'); doc.setTextColor(...NAVY);
          doc.text(S_FULL[s], x + 8, ly + 5.8);
        });
      }

      doc.save(`${type}-report-${dateFrom}-to-${dateTo}-${empType !== 'all' ? empType + '-' : ''}${projName.replace(/\s+/g, '-')}.pdf`);
    } catch (e: any) { setErr(e.message ?? 'PDF export failed'); }
    finally { setBusy(null); }
  };

  // ── Excel ─────────────────────────────────────────────────
  const exportExcel = async () => {
    setBusy('excel'); setErr(null);
    try {
      const data = await getData();
      const wb   = new ExcelJS.Workbook();
      wb.creator = COMPANY; wb.created = new Date();

      const ws_ = wb.addWorksheet(title.replace(/\s/g,'_'), {
        pageSetup: { orientation: 'landscape', fitToPage: true, fitToWidth: 1, paperSize: 8 },
      });

      const F = 5, T = 2;
      const COLS = F + nd + T;

      ws_.getColumn(1).width = 5;
      ws_.getColumn(2).width = 11;
      ws_.getColumn(3).width = 24;
      ws_.getColumn(4).width = 18;
      ws_.getColumn(5).width = 22;
      // A3 landscape printable width ≈ 163 char-units; subtract fixed + tail columns
      const xlFixedSum = 5 + 11 + 24 + 18 + 22; // 80
      const xlTailSum  = 14 + 22;                // 36
      const xlDayW     = nd > 0 ? Math.max(4.5, (163 - xlFixedSum - xlTailSum) / nd) : 4.5;
      for (let i = 1; i <= nd; i++) ws_.getColumn(F + i).width = xlDayW;
      ws_.getColumn(F + nd + 1).width = 14;
      ws_.getColumn(F + nd + 2).width = 22;

      const C_DARK = '1E3A8A', C_TEAL = '2563EB', C_LT = 'BFDBFE', C_SUB = 'DBEAFE';
      const sf = (a: string) => ({ type: 'pattern' as const, pattern: 'solid' as const, fgColor: { argb: a } });
      const bt = (a: string) => ({ style: 'thin'   as const, color: { argb: a } });
      const bm = (a: string) => ({ style: 'medium' as const, color: { argb: a } });
      const f  = (o: Partial<ExcelJS.Font>) => ({ name: 'Calibri', ...o });

      // ── Row 1: Company header ──
      ws_.getRow(1).height = 44;
      const half = Math.round(COLS * 0.55);
      ws_.mergeCells(1, 1, 1, half);
      ws_.mergeCells(1, half + 1, 1, COLS);
      const r1L = ws_.getCell(1, 1);
      r1L.value     = COMPANY;
      r1L.font      = f({ bold: true, size: 18, color: { argb: 'FFFFFFFF' } });
      r1L.fill      = sf('FF' + C_DARK);
      r1L.alignment = { vertical: 'middle', horizontal: 'center' };
      const r1R = ws_.getCell(1, half + 1);
      r1R.value     = TAGLINE;
      r1R.font      = f({ italic: true, size: 10, color: { argb: 'FF' + C_LT } });
      r1R.fill      = sf('FF' + C_DARK);
      r1R.alignment = { vertical: 'middle', horizontal: 'right', indent: 1 };
      if (logo) {
        try {
          const raw = logo.replace(/^data:image\/\w+;base64,/, '');
          const id  = wb.addImage({ base64: raw, extension: 'png' });
          ws_.addImage(id, { tl: { col: 0.15, row: 0.2 }, ext: { width: 58, height: 42 } });
        } catch { /* skip */ }
      }

      // ── Row 2: Report title ──
      ws_.getRow(2).height = 20;
      const h2 = Math.round(COLS * 0.5);
      ws_.mergeCells(2, 1, 2, h2);
      ws_.mergeCells(2, h2 + 1, 2, COLS);
      const r2L = ws_.getCell(2, 1);
      r2L.value     = title;
      r2L.font      = f({ bold: true, size: 13, color: { argb: 'FFFFFFFF' } });
      r2L.fill      = sf('FF' + C_TEAL);
      r2L.alignment = { vertical: 'middle', horizontal: 'left', indent: 2 };
      const r2R = ws_.getCell(2, h2 + 1);
      r2R.value     = `From: ${fmtShort(dateFrom)}  –  To: ${fmtShort(dateTo)}  ·  ${projName}  ·  ${empTypeName}`;
      r2R.font      = f({ size: 10, color: { argb: 'FFFFFFFF' } });
      r2R.fill      = sf('FF' + C_TEAL);
      r2R.alignment = { vertical: 'middle', horizontal: 'right', indent: 1 };

      // ── Row 3: Sub-info ──
      ws_.getRow(3).height = 14;
      const h3 = Math.round(COLS * 0.5);
      ws_.mergeCells(3, 1, 3, h3);
      ws_.mergeCells(3, h3 + 1, 3, COLS);
      const gt = grandTotal(data);
      const r3L = ws_.getCell(3, 1);
      r3L.value     = `Start: ${fmtShort(dateFrom)}  ·  End: ${fmtShort(dateTo)}  ·  ${data.length} Employees  ·  ${nd} Days  ·  ${empTypeName}`;
      r3L.font      = f({ bold: true, size: 9, color: { argb: 'FF' + C_DARK } });
      r3L.fill      = sf('FF' + C_SUB);
      r3L.alignment = { vertical: 'middle', horizontal: 'left', indent: 2 };
      const r3R = ws_.getCell(3, h3 + 1);
      r3R.value     = `Total ${type === 'normal' ? 'Regular' : 'OT'} Hours: ${gt.toFixed(2)} h  ·  ${new Date().toLocaleDateString('en-GB')}`;
      r3R.font      = f({ size: 9, color: { argb: 'FF' + C_DARK } });
      r3R.fill      = sf('FF' + C_SUB);
      r3R.alignment = { vertical: 'middle', horizontal: 'right', indent: 1 };

      // ── Row 4: accent bar ──
      ws_.getRow(4).height = 3;
      for (let c = 1; c <= COLS; c++) ws_.getCell(4, c).fill = sf('FF' + C_DARK);

      // ── Row 5: Column headers ──
      const HDR = 5;
      ws_.getRow(HDR).height = 22;
      const hdrs = ['Sl#','Code','Name','Designation','Assigned Project Codes',
        ...allDates.map(d => d.slice(8)),   // DD column headers
        type === 'normal' ? 'Normal Hrs' : 'OT Hrs', 'Remarks'];
      hdrs.forEach((v, i) => {
        const c = ws_.getCell(HDR, i + 1);
        c.value = v; c.font = f({ bold: true, size: 9, color: { argb: 'FFFFFFFF' } });
        c.fill  = sf('FF' + C_DARK);
        c.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
        c.border = { bottom: bt('FF' + C_TEAL), right: bt('FF' + C_DARK) };
      });

      // ── Row 6: Day-of-week row ──
      const DOW = 6;
      ws_.getRow(DOW).height = 11;
      ws_.mergeCells(DOW, 1, DOW, F);
      ws_.getCell(DOW, 1).fill = sf('FF' + C_DARK);
      const DOW_N = ['Su','Mo','Tu','We','Th','Fr','Sa'];
      allDates.forEach((dateStr, i) => {
        const col = F + i + 1;
        const dw  = new Date(dateStr + 'T00:00:00').getDay();
        const wk  = dw === 0 || dw === 6;
        const c   = ws_.getCell(DOW, col);
        c.value   = DOW_N[dw];
        c.font    = f({ bold: true, size: 7.5, color: { argb: wk ? 'FFFCA5A5' : 'FFBFDBFE' } });
        c.fill    = sf(wk ? 'FF7F1D1D' : 'FF1E3A8A');
        c.alignment = { vertical: 'middle', horizontal: 'center' };
      });
      [F + nd + 1, F + nd + 2].forEach(c => ws_.getCell(DOW, c).fill = sf('FF' + C_DARK));

      // Freeze panes
      ws_.views = [{ state: 'frozen', xSplit: F, ySplit: DOW, activeCell: `E${DOW + 1}` }];

      // ── Data rows ──
      data.forEach((emp, ri) => {
        const rn  = DOW + 1 + ri;
        const row = ws_.getRow(rn);
        row.height = 14;
        const alt = ri % 2 === 1 ? 'FFF0FDFA' : 'FFFFFFFF';

        const fix = (col: number, val: ExcelJS.CellValue, bold = false) => {
          const c = row.getCell(col);
          c.value = val; c.font = f({ size: 9, bold, color: { argb: 'FF111827' } });
          c.fill  = sf(alt);
          c.alignment = { vertical: 'middle', horizontal: col === 1 ? 'center' : 'left', indent: col > 1 ? 1 : 0 };
          c.border = { bottom: bt('FFE5E7EB'), right: bt('FFE5E7EB') };
        };
        fix(1, ri + 1); fix(2, emp.employee_code); fix(3, emp.employee_name, true); fix(4, emp.designation ?? ''); fix(5, emp.assigned_project_codes);

        allDates.forEach((dateStr, i) => {
          const col = F + i + 1;
          const ent = emp.days.get(dateStr);
          const c   = row.getCell(col);
          c.border  = { bottom: bt('FFE5E7EB'), right: bt('FFCDD8D8') };
          c.alignment = { vertical: 'middle', horizontal: 'center' };

          if (!ent) {
            c.fill = sf('FFF9FAFB');
          } else if (ent.status !== 'present') {
            c.value = S_SHORT[ent.status] ?? ent.status;
            c.font  = f({ bold: true, size: 8, color: { argb: 'FF' + S_XL_FG[ent.status] } });
            c.fill  = sf(S_XL_BG[ent.status]);
          } else {
            const h = cellHrs(ent);
            c.value  = h;
            c.numFmt = '0.00';
            c.font   = f({ bold: h >= 8, size: 8.5, color: { argb: h > 0 ? (type === 'normal' ? 'FF1E40AF' : 'FF92400E') : 'FFD1D5DB' } });
            c.fill   = sf(h > 0 ? (type === 'normal' ? 'FFDBEAFE' : 'FFFEF3C7') : alt);
          }
        });

        const tot  = type === 'normal' ? emp.total_regular : emp.total_ot;
        const tc   = row.getCell(F + nd + 1);
        tc.value   = tot; tc.numFmt = '0.00';
        tc.font    = f({ bold: true, size: 10, color: { argb: type === 'normal' ? 'FF1E3A8A' : 'FFBF360C' } });
        tc.fill    = sf(type === 'normal' ? 'FFBFDBFE' : 'FFFFE0B2');
        tc.alignment = { vertical: 'middle', horizontal: 'center' };
        tc.border  = { bottom: bt('FFE5E7EB'), right: bm('FF' + C_TEAL) };

        const rmk = Array.from(emp.days.values()).filter(e => e.notes).map(e => e.notes).slice(0, 3).join('; ');
        const rc  = row.getCell(F + nd + 2);
        rc.value  = rmk || ''; rc.font = f({ italic: true, size: 8, color: { argb: 'FF6B7280' } });
        rc.fill   = sf(alt); rc.alignment = { vertical: 'middle', horizontal: 'left', indent: 1 };
        rc.border = { bottom: bt('FFE5E7EB') };
      });

      // ── Total row ──
      const TR = DOW + 1 + data.length;
      ws_.getRow(TR).height = 18;
      ws_.mergeCells(TR, 1, TR, F);
      const tlc = ws_.getCell(TR, 1);
      tlc.value = 'TOTAL'; tlc.font = f({ bold: true, size: 10, color: { argb: 'FFFFFFFF' } });
      tlc.fill  = sf('FF' + C_TEAL); tlc.alignment = { vertical: 'middle', horizontal: 'center' };
      tlc.border = { top: bm('FF' + C_DARK), bottom: bm('FF' + C_DARK) };

      allDates.forEach((dateStr, i) => {
        const dt  = data.reduce((s, emp) => {
          const e = emp.days.get(dateStr); return (!e || e.status !== 'present') ? s : s + cellHrs(e);
        }, 0);
        const c = ws_.getCell(TR, F + i + 1);
        if (dt > 0) { c.value = dt; c.numFmt = '0.0'; }
        c.font    = f({ bold: true, size: 8, color: { argb: 'FF' + C_DARK } });
        c.fill    = sf('FF' + C_LT);
        c.alignment = { vertical: 'middle', horizontal: 'center' };
        c.border  = { top: bm('FF' + C_TEAL), bottom: bm('FF' + C_TEAL) };
      });

      const gtc = ws_.getCell(TR, F + nd + 1);
      gtc.value  = gt; gtc.numFmt = '0.00';
      gtc.font   = f({ bold: true, size: 11, color: { argb: 'FFFFFFFF' } });
      gtc.fill   = sf('FF' + C_TEAL);
      gtc.alignment = { vertical: 'middle', horizontal: 'center' };
      gtc.border = { top: bm('FF' + C_DARK), bottom: bm('FF' + C_DARK) };
      ws_.getCell(TR, F + nd + 2).fill = sf('FF' + C_TEAL);

      // ── Legend ──
      const LR = TR + 2;
      ws_.getRow(LR).height = 12; ws_.getRow(LR + 1).height = 14;
      ws_.mergeCells(LR, 1, LR, 8);
      const lg = ws_.getCell(LR, 1);
      lg.value = 'Status Legend:'; lg.font = f({ bold: true, size: 9, color: { argb: 'FF' + C_DARK } });
      ['present','leave','sick_leave','public_holiday','annual_leave','compensation_leave'].forEach((s, i) => {
        const c = ws_.getCell(LR + 1, i + 1);
        c.value = `${S_SHORT[s]} = ${S_FULL[s]}`;
        c.font  = f({ bold: true, size: 8, color: { argb: 'FF' + S_XL_FG[s] } });
        c.fill  = sf(S_XL_BG[s]);
        c.alignment = { vertical: 'middle', horizontal: 'center' };
        c.border = { top: bt('FFAAAAAA'), bottom: bt('FFAAAAAA'), left: bt('FFAAAAAA'), right: bt('FFAAAAAA') };
      });

      const buf  = await wb.xlsx.writeBuffer();
      const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href = url; a.download = `${type}-report-${dateFrom}-to-${dateTo}-${empType !== 'all' ? empType + '-' : ''}${projName.replace(/\s+/g,'-')}.xlsx`;
      a.click(); URL.revokeObjectURL(url);
    } catch (e: any) { setErr(e.message ?? 'Excel export failed'); }
    finally { setBusy(null); }
  };

  // ── Render ────────────────────────────────────────────────
  const working = !!busy;
  const gtDisp  = loaded ? grandTotal(recs).toFixed(2) : null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl my-4 overflow-hidden">

        {/* Header */}
        <div className="bg-gradient-to-r from-blue-800 to-blue-600 px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 bg-white/20 rounded-xl flex items-center justify-center">
              <Download className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-white text-lg leading-tight">Monthly Report Export</h3>
              <p className="text-blue-200 text-xs mt-0.5">Date-range breakdown · PDF &amp; Excel · Company Logo</p>
            </div>
          </div>
          <button onClick={onClose} disabled={working}
            className="p-2 rounded-xl hover:bg-white/20 text-white transition-colors disabled:opacity-40">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">

          {/* Report type */}
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Report Type</p>
            <div className="grid grid-cols-2 gap-3">
              {(['normal','overtime'] as const).map(t => {
                const on = type === t;
                return (
                  <button key={t} onClick={() => setType(t)}
                    className={`flex items-center gap-3 px-4 py-3.5 rounded-xl border-2 text-left transition-all ${
                      on ? (t==='normal' ? 'border-blue-500 bg-blue-50' : 'border-orange-500 bg-orange-50') : 'border-gray-200 hover:border-gray-300'
                    }`}>
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${on ? (t==='normal' ? 'bg-blue-500' : 'bg-orange-500') : 'bg-gray-100'}`}>
                      {t === 'normal'
                        ? <FileText className={`w-4 h-4 ${on ? 'text-white' : 'text-gray-400'}`} />
                        : <Table2   className={`w-4 h-4 ${on ? 'text-white' : 'text-gray-400'}`} />}
                    </div>
                    <div>
                      <p className={`font-semibold text-sm ${on ? (t==='normal' ? 'text-blue-800' : 'text-orange-800') : 'text-gray-700'}`}>
                        {t === 'normal' ? 'Normal Time Report' : 'Overtime Report'}
                      </p>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {t === 'normal' ? 'Regular duty hours per day' : 'Overtime hours per day'}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Filters — Project + Start Date + End Date */}
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Project</label>
              <select value={proj} onChange={e => setProj(e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-400">
                <option value="all">All Projects</option>
                {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Start Date</label>
              <input
                type="date"
                value={dateFrom}
                onChange={e => setDateFrom(e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">End Date</label>
              <input
                type="date"
                value={dateTo}
                min={dateFrom}
                onChange={e => setDateTo(e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
              />
            </div>
          </div>

          {/* Employee Type filter */}
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Employee Type</p>
            <div className="grid grid-cols-4 gap-2">
              {([
                { key: 'all',           label: 'All Types',     sub: 'No filter applied' },
                { key: 'labour',        label: 'DIRECT',        sub: 'Labour employees' },
                { key: 'staff',         label: 'INDIRECT',      sub: 'Staff employees' },
                { key: 'subcontractor', label: 'Subcontractor', sub: 'Subcontract workers' },
              ] as const).map(({ key, label, sub }) => {
                const on = empType === key;
                return (
                  <button key={key} onClick={() => setEmpType(key)}
                    className={`flex flex-col items-start px-3 py-3 rounded-xl border-2 text-left transition-all ${
                      on ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                    }`}>
                    <span className={`text-xs font-bold leading-tight ${on ? 'text-blue-800' : 'text-gray-700'}`}>{label}</span>
                    <span className="text-xs text-gray-400 mt-0.5 leading-tight">{sub}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Date range summary */}
          <div className="flex items-center flex-wrap gap-2 px-4 py-2.5 bg-blue-50 border border-blue-100 rounded-xl text-sm">
            <span className="text-blue-600 font-semibold">{rangeLabel}</span>
            <span className="text-blue-400">·</span>
            <span className="text-blue-600">{nd} day{nd !== 1 ? 's' : ''}</span>
            <span className="text-blue-400">·</span>
            <span className="text-blue-600">{projName}</span>
            {empType !== 'all' && (
              <>
                <span className="text-blue-400">·</span>
                <span className="font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded-full text-xs">{empTypeName}</span>
              </>
            )}
          </div>

          {/* Error */}
          {err && (
            <div className="flex items-start gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl px-4 py-3">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />{err}
            </div>
          )}

          {/* Preview panel */}
          <div className="border border-gray-200 rounded-xl overflow-hidden">
            <div className="px-4 py-3 bg-gray-50 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 min-w-0">
                <Eye className="w-4 h-4 text-gray-400 flex-shrink-0" />
                <span className="text-sm font-medium text-gray-700 truncate">
                  {loaded ? `${recs.length} employees · ${rangeLabel} · ${projName}${empType !== 'all' ? ` · ${empTypeName}` : ''}` : 'Load data to preview before exporting'}
                </span>
                {loaded && gtDisp && (
                  <span className={`text-xs font-bold px-2 py-0.5 rounded-full flex-shrink-0 ${
                    type === 'normal' ? 'bg-blue-100 text-blue-800' : 'bg-orange-100 text-orange-800'
                  }`}>{type === 'normal' ? 'Reg' : 'OT'}: {gtDisp}h</span>
                )}
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                {loaded && recs.length > 0 && (
                  <button onClick={() => setOpen(v => !v)}
                    className="flex items-center gap-1 text-xs text-gray-500 hover:text-gray-700 px-2 py-1 rounded-lg hover:bg-gray-100 transition-colors">
                    {open ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    {open ? 'Hide' : 'Show'}
                  </button>
                )}
                <button onClick={handleLoad} disabled={working}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-300 rounded-lg text-xs font-semibold text-gray-700 hover:border-blue-400 hover:text-blue-700 disabled:opacity-50 transition-all">
                  {busy === 'load' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Eye className="w-3.5 h-3.5" />}
                  {loaded ? 'Reload' : 'Load Data'}
                </button>
              </div>
            </div>

            {open && loaded && recs.length > 0 && (
              <div className="overflow-x-auto max-h-52 border-t border-gray-100">
                <table className="w-full text-xs">
                  <thead className="sticky top-0 bg-blue-800">
                    <tr>
                      <th className="px-2 py-1.5 text-white font-semibold text-center">#</th>
                      <th className="px-2 py-1.5 text-white font-semibold text-left whitespace-nowrap">Code</th>
                      <th className="px-2 py-1.5 text-white font-semibold text-left min-w-[120px]">Name</th>
                      <th className="px-2 py-1.5 text-blue-300 font-semibold text-left hidden md:table-cell">Designation</th>
                      <th className="px-2 py-1.5 text-blue-300 font-semibold text-left hidden md:table-cell whitespace-nowrap">Assigned Project Codes</th>
                      {allDates.map(d => <th key={d} className="px-0.5 py-1.5 text-blue-300 font-semibold w-6 text-center">{d.slice(8)}</th>)}
                      <th className={`px-2 py-1.5 font-bold text-center whitespace-nowrap ${type==='normal'?'text-blue-200':'text-orange-200'}`}>Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {recs.map((emp, idx) => (
                      <tr key={emp.employee_id} className={idx % 2 === 1 ? 'bg-blue-50/30' : ''}>
                        <td className="px-2 py-1 text-gray-400 text-center">{idx + 1}</td>
                        <td className="px-2 py-1 font-medium text-gray-600">{emp.employee_code}</td>
                        <td className="px-2 py-1 font-semibold text-gray-900">{emp.employee_name}</td>
                        <td className="px-2 py-1 text-gray-500 hidden md:table-cell">{emp.designation || '—'}</td>
                        <td className="px-2 py-1 text-gray-500 hidden md:table-cell font-mono text-xs">{emp.assigned_project_codes || '—'}</td>
                        {allDates.map(dateStr => {
                          const ent = emp.days.get(dateStr);
                          if (!ent) return <td key={dateStr} className="px-0.5 py-1 text-center text-gray-200">·</td>;
                          if (ent.status !== 'present') {
                            const clr: Record<string,string> = { leave:'text-gray-500', sick_leave:'text-red-600', public_holiday:'text-blue-600', annual_leave:'text-amber-600', compensation_leave:'text-purple-600' };
                            return <td key={dateStr} className={`px-0.5 py-1 text-center font-bold ${clr[ent.status]??'text-gray-500'}`}>{S_SHORT[ent.status]}</td>;
                          }
                          const h = cellHrs(ent);
                          return <td key={dateStr} className={`px-0.5 py-1 text-center font-medium ${h>0?(type==='normal'?'text-blue-700':'text-orange-600'):'text-gray-300'}`}>{h>0?h.toFixed(1):'—'}</td>;
                        })}
                        <td className={`px-2 py-1 text-center font-bold ${type==='normal'?'text-blue-800':'text-orange-700'}`}>
                          {(type==='normal'?emp.total_regular:emp.total_ot).toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Export buttons */}
          <div className="flex items-center gap-3">
            <button onClick={exportPDF} disabled={working}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-red-600 to-rose-600 text-white font-bold rounded-xl text-sm shadow hover:from-red-700 hover:to-rose-700 disabled:opacity-50 transition-all">
              {busy === 'pdf' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
              Export PDF
            </button>
            <button onClick={exportExcel} disabled={working}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-emerald-600 to-green-700 text-white font-bold rounded-xl text-sm shadow hover:from-emerald-700 hover:to-green-800 disabled:opacity-50 transition-all">
              {busy === 'excel' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Table2 className="w-4 h-4" />}
              Export Excel
            </button>
            <button onClick={onClose} disabled={working}
              className="px-5 py-3 text-sm font-medium text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors disabled:opacity-50">
              Cancel
            </button>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-1.5 border-t border-gray-100 pt-3">
            {[
              { k:'P',  l:'Present',            c:'text-blue-800 bg-blue-50 border-blue-200' },
              { k:'L',  l:'Leave',              c:'text-gray-600 bg-gray-100 border-gray-200' },
              { k:'SL', l:'Sick Leave',         c:'text-red-700 bg-red-50 border-red-200' },
              { k:'PH', l:'Public Holiday',     c:'text-blue-700 bg-blue-50 border-blue-200' },
              { k:'AL', l:'Annual Leave',       c:'text-amber-700 bg-amber-50 border-amber-200' },
              { k:'CL', l:'Compensation Leave', c:'text-purple-700 bg-purple-50 border-purple-200' },
            ].map(i => (
              <span key={i.k} className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-semibold border ${i.c}`}>
                <span className="font-black">{i.k}</span>{i.l}
              </span>
            ))}
          </div>

        </div>
      </div>
    </div>
  );
}
