import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/supabase';
import {
  Users,
  Plus,
  X,
  Edit2,
  Trash2,
  Mail,
  Building2,
  UserCheck,
  UserX,
  KeyRound,
  CheckCircle2,
  Eye,
  EyeOff,
  AlertCircle,
  ShoppingCart,
  Shield,
  Truck,
  Clock,
  FolderKanban,
  Loader2,
  Search,
  Check,
  FolderOpen,
  Landmark,
} from 'lucide-react';

type TeamMember = Database['public']['Tables']['team_members']['Row'];
type Project = { id: string; name: string; status: string | null };
type ProjectMember = { id: string; project_id: string; team_member_id: string; role_in_project: string | null };

/* ── Project Assignment Modal ───────────────────────────────── */
function ProjectAssignmentModal({
  member,
  onClose,
}: {
  member: TeamMember;
  onClose: () => void;
}) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [assignments, setAssignments] = useState<ProjectMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [projRes, assignRes] = await Promise.all([
      supabase.from('projects').select('id,name,status').order('name'),
      supabase.from('project_members').select('*').eq('team_member_id', member.id),
    ]);
    setProjects((projRes.data ?? []) as Project[]);
    setAssignments((assignRes.data ?? []) as ProjectMember[]);
    setLoading(false);
  }, [member.id]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const isAssigned = (projectId: string) =>
    assignments.some((a) => a.project_id === projectId);

  const toggleProject = async (project: Project) => {
    setSaving(project.id);
    setError(null);
    if (isAssigned(project.id)) {
      const existing = assignments.find((a) => a.project_id === project.id);
      if (!existing) { setSaving(null); return; }
      const { error: err } = await supabase.from('project_members').delete().eq('id', existing.id);
      if (err) { setError(err.message); setSaving(null); return; }
      setAssignments((prev) => prev.filter((a) => a.id !== existing.id));
    } else {
      const { data, error: err } = await supabase.from('project_members').insert({
        project_id: project.id,
        team_member_id: member.id,
        role_in_project: null,
      }).select().single();
      if (err) { setError(err.message); setSaving(null); return; }
      setAssignments((prev) => [...prev, data as ProjectMember]);
    }
    setSaving(null);
  };

  const filtered = projects.filter(
    (p) => !search || p.name.toLowerCase().includes(search.toLowerCase())
  );

  const assignedCount = assignments.length;

  const selectAll = async () => {
    const toAssign = filtered.filter((p) => !isAssigned(p.id));
    for (const project of toAssign) {
      const { data, error: err } = await supabase.from('project_members').insert({
        project_id: project.id,
        team_member_id: member.id,
        role_in_project: null,
      }).select().single();
      if (!err && data) setAssignments((prev) => [...prev, data as ProjectMember]);
    }
  };

  const deselectAll = async () => {
    const toRemove = filtered
      .map((p) => assignments.find((a) => a.project_id === p.id))
      .filter(Boolean) as ProjectMember[];
    for (const existing of toRemove) {
      const { error: err } = await supabase.from('project_members').delete().eq('id', existing.id);
      if (!err) setAssignments((prev) => prev.filter((a) => a.id !== existing.id));
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-blue-600 rounded-xl flex items-center justify-center">
              <FolderKanban className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900">Project Assignments</h2>
              <p className="text-xs text-gray-500">
                {member.name} · {assignedCount} project{assignedCount !== 1 ? 's' : ''} assigned
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 p-1 rounded-lg hover:bg-gray-100 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search + bulk actions */}
        <div className="px-6 pt-4 pb-2 space-y-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search projects..."
              className="w-full pl-9 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
            />
          </div>
          {!loading && filtered.length > 0 && (
            <div className="flex items-center gap-2">
              <button
                onClick={selectAll}
                disabled={!!saving || filtered.every((p) => isAssigned(p.id))}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-teal-700 bg-teal-50 border border-teal-200 rounded-lg hover:bg-teal-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <Check className="w-3 h-3" />
                Select All
              </button>
              <button
                onClick={deselectAll}
                disabled={!!saving || filtered.every((p) => !isAssigned(p.id))}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-600 bg-gray-100 border border-gray-200 rounded-lg hover:bg-gray-200 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <X className="w-3 h-3" />
                Deselect All
              </button>
              <span className="ml-auto text-xs text-gray-400">
                {filtered.filter((p) => isAssigned(p.id)).length} / {filtered.length} selected
              </span>
            </div>
          )}
        </div>

        {/* Project list */}
        <div className="flex-1 overflow-y-auto px-6 pb-6 space-y-2 mt-2">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-teal-400" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-10">
              <FolderOpen className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500 text-sm">{search ? 'No projects match your search' : 'No projects available'}</p>
            </div>
          ) : (
            filtered.map((project) => {
              const assigned = isAssigned(project.id);
              const isSaving = saving === project.id;
              return (
                <button
                  key={project.id}
                  onClick={() => toggleProject(project)}
                  disabled={isSaving}
                  className={`w-full flex items-center gap-3 p-3.5 rounded-xl border-2 text-left transition-all ${
                    assigned
                      ? 'border-teal-500 bg-teal-50'
                      : 'border-gray-200 bg-white hover:border-teal-300 hover:bg-gray-50'
                  } disabled:opacity-60`}
                >
                  {isSaving ? (
                    <Loader2 className="w-5 h-5 animate-spin text-teal-500 flex-shrink-0" />
                  ) : (
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                      assigned ? 'border-teal-500 bg-teal-500' : 'border-gray-300'
                    }`}>
                      {assigned && <Check className="w-3 h-3 text-white" />}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-semibold truncate ${assigned ? 'text-teal-800' : 'text-gray-800'}`}>
                      {project.name}
                    </p>
                    {project.status && (
                      <p className="text-xs text-gray-400 capitalize mt-0.5">{project.status}</p>
                    )}
                  </div>
                  {assigned && (
                    <span className="text-xs font-semibold text-teal-600 bg-teal-100 px-2 py-0.5 rounded-full flex-shrink-0">
                      Assigned
                    </span>
                  )}
                </button>
              );
            })
          )}
        </div>

        {error && (
          <div className="mx-6 mb-4 flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl px-3 py-2.5">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            {error}
          </div>
        )}

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-100 flex items-center justify-between">
          <p className="text-xs text-gray-400">
            Click a project to toggle assignment
          </p>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-gradient-to-r from-teal-500 to-blue-600 text-white text-sm font-medium rounded-lg hover:from-teal-600 hover:to-blue-700 transition-all"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}

export function TeamMembers() {
  const { user, teamMember: currentMember, isAdmin } = useAuth();
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingMember, setEditingMember] = useState<TeamMember | null>(null);
  const [loginMember, setLoginMember] = useState<TeamMember | null>(null);
  const [projectMember, setProjectMember] = useState<TeamMember | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchMembers = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('team_members')
      .select('*')
      .order('name', { ascending: true });
    if (data) setMembers(data);
    if (error) console.error('Error fetching members:', error);
    setLoading(false);
  }, [user]);

  useEffect(() => { fetchMembers(); }, [fetchMembers]);

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this team member?')) return;
    await supabase.from('team_members').delete().eq('id', id);
    fetchMembers();
  };

  const handleToggleActive = async (member: TeamMember) => {
    await supabase.from('team_members').update({ is_active: !member.is_active }).eq('id', member.id);
    fetchMembers();
  };

  const handleSetProcurementLead = async (member: TeamMember) => {
    if (member.is_procurement_lead) {
      // Remove the lead flag
      await supabase.from('team_members').update({ is_procurement_lead: false }).eq('id', member.id);
    } else {
      // Clear any existing lead first, then set this one
      await supabase.from('team_members').update({ is_procurement_lead: false }).eq('is_procurement_lead', true);
      await supabase.from('team_members').update({ is_procurement_lead: true }).eq('id', member.id);
    }
    fetchMembers();
  };

  const handleToggleAdmin = async (member: TeamMember) => {
    if (member.id === currentMember?.id) {
      alert('You cannot remove your own admin access.');
      return;
    }
    const action = member.is_admin ? 'revoke admin access from' : 'grant admin access to';
    if (!confirm(`Are you sure you want to ${action} ${member.name}?`)) return;
    await supabase.from('team_members').update({ is_admin: !member.is_admin }).eq('id', member.id);
    fetchMembers();
  };

  const handleToggleMaterialCoordinator = async (member: TeamMember) => {
    const action = member.is_material_coordinator ? 'remove Material Coordinator role from' : 'assign Material Coordinator role to';
    if (!confirm(`Are you sure you want to ${action} ${member.name}?`)) return;
    await supabase.from('team_members').update({ is_material_coordinator: !member.is_material_coordinator }).eq('id', member.id);
    fetchMembers();
  };

  const handleToggleTimeKeeper = async (member: TeamMember) => {
    const action = (member as any).is_time_keeper ? 'remove Time Keeper role from' : 'assign Time Keeper role to';
    if (!confirm(`Are you sure you want to ${action} ${member.name}?`)) return;
    await supabase.from('team_members').update({ is_time_keeper: !(member as any).is_time_keeper }).eq('id', member.id);
    fetchMembers();
  };

  const handleToggleAccountant = async (member: TeamMember) => {
    const action = (member as any).is_accountant ? 'remove Accountant role from' : 'assign Accountant role to';
    if (!confirm(`Are you sure you want to ${action} ${member.name}?`)) return;
    await supabase.from('team_members').update({ is_accountant: !(member as any).is_accountant }).eq('id', member.id);
    fetchMembers();
  };

  const filteredMembers = members.filter(
    (m) =>
      m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Team Members</h1>
            <p className="text-gray-600 mt-1">Manage your team of {members.length} members</p>
          </div>
          {isAdmin && (
          <button
            onClick={() => { setEditingMember(null); setShowModal(true); }}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg hover:from-teal-600 hover:to-blue-700 transition-all"
          >
            <Plus className="w-5 h-5" />
            Add Member
          </button>
          )}
        </div>

        {/* Search */}
        <div className="mb-6">
          <input
            type="text"
            placeholder="Search members by name, email, or department..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        {/* Members Grid */}
        {filteredMembers.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 border border-gray-100 text-center">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              {searchTerm ? 'No members found' : 'No Team Members Yet'}
            </h3>
            <p className="text-gray-500 mb-4">
              {searchTerm ? 'Try a different search term' : 'Add your first team member to get started'}
            </p>
            {!searchTerm && isAdmin && (
              <button
                onClick={() => setShowModal(true)}
                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg"
              >
                <Plus className="w-5 h-5" />
                Add First Member
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMembers.map((member) => (
              <div
                key={member.id}
                className={`bg-white rounded-2xl shadow-lg p-6 border-2 transition-all ${
                  member.is_active ? 'border-gray-100' : 'border-gray-300 opacity-60'
                }`}
              >
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-teal-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                      {member.name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2)}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{member.name}</h3>
                      <p className="text-sm text-gray-500">{member.role}</p>
                    </div>
                  </div>
                  {isAdmin && (
                  <div className="flex gap-1">
                    <button
                      onClick={() => setProjectMember(member)}
                      className="p-2 text-gray-400 hover:text-teal-600 hover:bg-teal-50 transition-colors rounded"
                      title="Assign Projects"
                    >
                      <FolderKanban className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleToggleActive(member)}
                      className={`p-2 rounded transition-colors ${
                        member.is_active ? 'text-green-600 hover:bg-green-50' : 'text-gray-400 hover:bg-gray-50'
                      }`}
                      title={member.is_active ? 'Deactivate' : 'Activate'}
                    >
                      {member.is_active ? <UserCheck className="w-4 h-4" /> : <UserX className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={() => { setEditingMember(member); setShowModal(true); }}
                      className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                      title="Edit member"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(member.id)}
                      className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                      title="Delete member"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Mail className="w-4 h-4 text-gray-400" />
                    <span className="truncate">{member.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Building2 className="w-4 h-4 text-gray-400" />
                    <span>{member.department}</span>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-gray-100 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                        member.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'
                      }`}
                    >
                      {member.is_active ? 'Active' : 'Inactive'}
                    </span>

                    {/* Login status + action — admin only */}
                    {isAdmin && (member.user_id ? (
                      <div className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                        <span className="text-xs text-green-600 font-medium">Login set</span>
                        <button
                          onClick={() => setLoginMember(member)}
                          className="ml-1 text-xs text-blue-500 hover:text-blue-700 underline"
                          title="Reset password"
                        >
                          Reset
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setLoginMember(member)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-xs font-medium transition-colors border border-blue-200"
                      >
                        <KeyRound className="w-3.5 h-3.5" />
                        Create Login
                      </button>
                    ))}
                  </div>

                  {/* Roles & Permissions — admin only */}
                  {isAdmin && (
                  <div className="rounded-xl border border-gray-100 bg-gray-50/60 p-3">
                    <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2.5">Roles & Permissions</p>
                    <div className="space-y-1.5">
                      <RoleCheckbox
                        icon={Shield}
                        label="Admin User"
                        description="Full system access"
                        checked={member.is_admin}
                        disabled={member.id === currentMember?.id}
                        disabledTitle="Cannot change your own admin status"
                        color="blue"
                        onToggle={() => handleToggleAdmin(member)}
                      />
                      <RoleCheckbox
                        icon={ShoppingCart}
                        label="Procurement Lead"
                        description="Manage & release purchase orders"
                        checked={member.is_procurement_lead}
                        color="orange"
                        onToggle={() => handleSetProcurementLead(member)}
                      />
                      <RoleCheckbox
                        icon={Truck}
                        label="Material Coordinator"
                        description="Delivery tracking access"
                        checked={member.is_material_coordinator}
                        color="emerald"
                        onToggle={() => handleToggleMaterialCoordinator(member)}
                      />
                      <RoleCheckbox
                        icon={Clock}
                        label="Time Keeper"
                        description="Timesheet-only access"
                        checked={(member as any).is_time_keeper ?? false}
                        color="cyan"
                        onToggle={() => handleToggleTimeKeeper(member)}
                      />
                      <RoleCheckbox
                        icon={Landmark}
                        label="Accountant"
                        description="Full Accounts module access"
                        checked={(member as any).is_accountant ?? false}
                        color="teal"
                        onToggle={() => handleToggleAccountant(member)}
                      />
                    </div>
                  </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Add/Edit Member Modal */}
        {showModal && (
          <MemberModal
            member={editingMember}
            onClose={() => { setShowModal(false); setEditingMember(null); }}
            onSave={() => { setShowModal(false); setEditingMember(null); fetchMembers(); }}
          />
        )}

        {/* Create/Reset Login Modal */}
        {loginMember && (
          <LoginModal
            member={loginMember}
            onClose={() => setLoginMember(null)}
            onSave={() => { setLoginMember(null); fetchMembers(); }}
          />
        )}

        {/* Project Assignment Modal */}
        {projectMember && (
          <ProjectAssignmentModal
            member={projectMember}
            onClose={() => setProjectMember(null)}
          />
        )}
      </div>
    </div>
  );
}

/* ── Role Checkbox ──────────────────────────────────────────── */
const ROLE_COLORS = {
  blue:    { box: 'bg-blue-600 border-blue-600',    row: 'bg-blue-50 border-blue-200',    label: 'text-blue-800',    icon: 'text-blue-600' },
  orange:  { box: 'bg-orange-500 border-orange-500', row: 'bg-orange-50 border-orange-200', label: 'text-orange-800',  icon: 'text-orange-500' },
  emerald: { box: 'bg-emerald-600 border-emerald-600', row: 'bg-emerald-50 border-emerald-200', label: 'text-emerald-800', icon: 'text-emerald-600' },
  cyan:    { box: 'bg-cyan-600 border-cyan-600',    row: 'bg-cyan-50 border-cyan-200',    label: 'text-cyan-800',    icon: 'text-cyan-600' },
  teal:    { box: 'bg-teal-600 border-teal-600',    row: 'bg-teal-50 border-teal-200',    label: 'text-teal-800',    icon: 'text-teal-600' },
};

function RoleCheckbox({
  icon: Icon, label, description, checked, disabled, disabledTitle, color, onToggle,
}: {
  icon: React.ElementType;
  label: string;
  description: string;
  checked: boolean;
  disabled?: boolean;
  disabledTitle?: string;
  color: keyof typeof ROLE_COLORS;
  onToggle: () => void;
}) {
  const c = ROLE_COLORS[color];
  return (
    <button
      type="button"
      onClick={onToggle}
      disabled={disabled}
      title={disabled ? disabledTitle : undefined}
      className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg border transition-all text-left ${
        checked ? `${c.row}` : 'bg-white border-gray-200 hover:border-gray-300 hover:bg-gray-50'
      } disabled:cursor-not-allowed disabled:opacity-55`}
    >
      {/* Checkbox */}
      <div className={`w-4.5 h-4.5 w-[18px] h-[18px] flex-shrink-0 rounded border-2 flex items-center justify-center transition-all ${
        checked ? `${c.box}` : 'border-gray-300 bg-white'
      }`}>
        {checked && (
          <svg className="w-2.5 h-2.5 text-white" viewBox="0 0 10 10" fill="none">
            <path d="M1.5 5l2.5 2.5 4.5-4.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        )}
      </div>
      {/* Icon */}
      <Icon className={`w-3.5 h-3.5 flex-shrink-0 ${checked ? c.icon : 'text-gray-400'}`} />
      {/* Text */}
      <div className="flex-1 min-w-0">
        <p className={`text-xs font-semibold leading-tight ${checked ? c.label : 'text-gray-700'}`}>{label}</p>
        <p className="text-xs text-gray-400 leading-tight mt-0.5">{description}</p>
      </div>
    </button>
  );
}

function LoginModal({
  member,
  onClose,
  onSave,
}: {
  member: TeamMember;
  onClose: () => void;
  onSave: () => void;
}) {
  const { session } = useAuth();
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const isReset = !!member.user_id;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!session) return;
    setError(null);
    setLoading(true);

    try {
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-team-member-login`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${session.access_token}`,
            Apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
          },
          body: JSON.stringify({
            email: member.email,
            password,
            team_member_id: member.id,
          }),
        }
      );

      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed');
      // Store password hint for admin export
      await supabase.from('team_members').update({ login_password_hint: password }).eq('id', member.id);
      setSuccess(true);
      setTimeout(() => { onSave(); }, 1500);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
    }
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
              <KeyRound className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900">
                {isReset ? 'Reset Login Password' : 'Create Login Credentials'}
              </h2>
              <p className="text-xs text-gray-500">{member.name}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Email display */}
        <div className="mb-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
          <p className="text-xs text-gray-500 mb-0.5">Login Email (fixed)</p>
          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-gray-400" />
            <span className="text-sm font-medium text-gray-800">{member.email}</span>
          </div>
        </div>

        {success ? (
          <div className="flex flex-col items-center py-6 gap-3">
            <CheckCircle2 className="w-12 h-12 text-green-500" />
            <p className="text-green-700 font-semibold">
              {isReset ? 'Password updated!' : 'Login created successfully!'}
            </p>
            <p className="text-xs text-gray-500 text-center">
              {member.name} can now sign in with the Team Member portal.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {isReset ? 'New Password' : 'Set Password'}
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pr-10 pl-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                  placeholder="Minimum 6 characters"
                  required
                  minLength={6}
                  autoComplete="new-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-red-700">{error}</p>
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2 px-4 border-2 border-gray-200 text-gray-700 font-medium rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading || password.length < 6}
                className="flex-1 py-2 px-4 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-medium rounded-lg disabled:opacity-50 transition-all"
              >
                {loading ? 'Saving...' : isReset ? 'Update Password' : 'Create Login'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

function MemberModal({
  member,
  onClose,
  onSave,
}: {
  member: TeamMember | null;
  onClose: () => void;
  onSave: () => void;
}) {
  const [name, setName] = useState(member?.name || '');
  const [email, setEmail] = useState(member?.email || '');
  const [role, setRole] = useState(member?.role || 'Team Member');
  const [department, setDepartment] = useState(member?.department || 'General');
  const [isActive, setIsActive] = useState(member?.is_active ?? true);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const data = { name, email, role, department, is_active: isActive, user_id: member?.user_id || null };
    if (member) {
      await supabase.from('team_members').update(data).eq('id', member.id);
    } else {
      await supabase.from('team_members').insert(data);
    }
    setLoading(false);
    onSave();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-900">
            {member ? 'Edit Team Member' : 'Add Team Member'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Role</label>
            <input
              type="text"
              value={role}
              onChange={(e) => setRole(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="e.g., Developer, Designer, Manager"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
            <input
              type="text"
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="e.g., Engineering, Design, Marketing"
            />
          </div>
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="active"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              className="rounded border-gray-300"
            />
            <label htmlFor="active" className="text-sm text-gray-700">Active team member</label>
          </div>
          <div className="flex gap-2 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 px-4 border-2 border-gray-200 text-gray-700 font-medium rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || !name.trim() || !email.trim()}
              className="flex-1 py-2 px-4 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg disabled:opacity-50"
            >
              {loading ? 'Saving...' : member ? 'Update' : 'Add Member'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
