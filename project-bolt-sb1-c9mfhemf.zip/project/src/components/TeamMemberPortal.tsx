import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/supabase';
import { DeliveryPortal } from './DeliveryPortal';
import {
  ClipboardList,
  LogOut,
  CheckCircle2,
  Clock,
  AlertTriangle,
  CalendarDays,
  ChevronDown,
  ChevronUp,
  User,
  Filter,
  ArrowUpDown,
  X,
  FileText,
  Truck,
} from 'lucide-react';

type Task = Database['public']['Tables']['tasks']['Row'];
type Project = Database['public']['Tables']['projects']['Row'];

interface TaskWithProject extends Task {
  projects: Project;
}

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-gray-100 text-gray-700 border-gray-200',
  'in-progress': 'bg-blue-100 text-blue-700 border-blue-200',
  review: 'bg-amber-100 text-amber-700 border-amber-200',
  completed: 'bg-green-100 text-green-700 border-green-200',
  cancelled: 'bg-red-100 text-red-700 border-red-200',
};

const PRIORITY_BORDER: Record<string, string> = {
  low: 'border-l-gray-300',
  medium: 'border-l-yellow-400',
  high: 'border-l-orange-500',
  critical: 'border-l-red-500',
};

const PRIORITY_BADGE: Record<string, string> = {
  low: 'bg-gray-100 text-gray-600',
  medium: 'bg-yellow-100 text-yellow-700',
  high: 'bg-orange-100 text-orange-700',
  critical: 'bg-red-100 text-red-700',
};

function fmtDate(d: string) {
  const [year, month, day] = d.split('-');
  return `${day}/${month}/${year}`;
}

function statusLabel(s: string) {
  return s === 'in-progress' ? 'In Progress' : s.charAt(0).toUpperCase() + s.slice(1);
}

type FilterStatus = 'all' | 'pending' | 'in-progress' | 'review' | 'completed' | 'cancelled';
type SortKey = 'due_date' | 'priority' | 'status' | 'project';
type PortalTab = 'documentation' | 'deliveries';

const PRIORITY_ORDER: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3 };
const STATUS_ORDER: Record<string, number> = { 'in-progress': 0, review: 1, pending: 2, completed: 3, cancelled: 4 };

export function TeamMemberPortal() {
  const { teamMember, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState<PortalTab>(
    (teamMember?.is_material_coordinator || teamMember?.is_admin)
      ? 'deliveries'
      : 'documentation'
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50">
      {/* Top bar */}
      <header className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-3 flex items-center gap-3">
          <img src="/EMCC_Logo..jpg" alt="EMCC" className="w-9 h-9 object-contain" />
          <div className="flex-1">
            <h1 className="font-bold text-gray-900 text-sm leading-tight">EMCC Projects Division</h1>
            <p className="text-xs text-gray-500">Team Member Portal</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 bg-teal-50 px-3 py-1.5 rounded-lg border border-teal-100">
              <User className="w-4 h-4 text-teal-600" />
              <span className="text-sm font-medium text-teal-800">{teamMember?.name}</span>
              {teamMember?.role && (
                <span className="text-xs text-teal-600 bg-teal-100 px-1.5 py-0.5 rounded">{teamMember.role}</span>
              )}
              {teamMember?.is_procurement_lead && (
                <span className="text-xs text-orange-600 bg-orange-100 px-1.5 py-0.5 rounded font-semibold">Procurement Lead</span>
              )}
              {teamMember?.is_material_coordinator && (
                <span className="text-xs text-emerald-600 bg-emerald-100 px-1.5 py-0.5 rounded font-semibold">Material Coordinator</span>
              )}
            </div>
            <button
              onClick={signOut}
              className="flex items-center gap-1.5 px-3 py-1.5 text-sm text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        </div>

        {/* Tab navigation */}
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <nav className="flex gap-0 -mb-px overflow-x-auto">
            {([
              { id: 'documentation',    label: 'Documentation',    icon: FileText,    show: true },
              { id: 'deliveries',       label: 'Deliveries',       icon: Truck,        show: !!(teamMember?.is_material_coordinator || teamMember?.is_procurement_lead || teamMember?.is_admin) },
            ] as { id: PortalTab; label: string; icon: React.ElementType; show: boolean }[])
              .filter((t) => t.show)
              .map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setActiveTab(id)}
                  className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
                    activeTab === id
                      ? 'border-teal-500 text-teal-700'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {label}
                </button>
              ))}
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        {activeTab === 'documentation' && <DocumentationTab teamMember={teamMember} />}
        {activeTab === 'deliveries' && !!(teamMember?.is_material_coordinator || teamMember?.is_procurement_lead || teamMember?.is_admin) && <DeliveryPortal />}
      </main>
    </div>
  );
}

/* ──────────────────────────────────────────────────────── */
/* Documentation tab (tasks)                               */
/* ──────────────────────────────────────────────────────── */

function DocumentationTab({ teamMember }: { teamMember: Database['public']['Tables']['team_members']['Row'] | null }) {
  const [tasks, setTasks] = useState<TaskWithProject[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<FilterStatus>('all');
  const [filterProject, setFilterProject] = useState<string>('all');
  const [filterDateFrom, setFilterDateFrom] = useState('');
  const [filterDateTo, setFilterDateTo] = useState('');
  const [sortKey, setSortKey] = useState<SortKey>('due_date');
  const [sortAsc, setSortAsc] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  const today = new Date().toISOString().split('T')[0];

  const fetchTasks = useCallback(async () => {
    if (!teamMember) return;
    setLoading(true);
    const { data } = await supabase
      .from('tasks')
      .select('*, projects(*)')
      .eq('assigned_to', teamMember.id)
      .order('due_date', { ascending: true });
    setTasks((data as TaskWithProject[]) ?? []);
    setLoading(false);
  }, [teamMember]);

  useEffect(() => { fetchTasks(); }, [fetchTasks]);

  const projects = Array.from(
    new Map(tasks.map((t) => [t.projects?.id, t.projects]).filter(([id]) => id)).values()
  ) as Project[];

  const filtered = tasks
    .filter((t) => filterStatus === 'all' || t.status === filterStatus)
    .filter((t) => filterProject === 'all' || t.projects?.id === filterProject)
    .filter((t) => !filterDateFrom || t.due_date >= filterDateFrom)
    .filter((t) => !filterDateTo || t.due_date <= filterDateTo)
    .sort((a, b) => {
      let cmp = 0;
      if (sortKey === 'due_date') cmp = a.due_date.localeCompare(b.due_date);
      else if (sortKey === 'priority') cmp = (PRIORITY_ORDER[a.priority] ?? 9) - (PRIORITY_ORDER[b.priority] ?? 9);
      else if (sortKey === 'status') cmp = (STATUS_ORDER[a.status] ?? 9) - (STATUS_ORDER[b.status] ?? 9);
      else if (sortKey === 'project') cmp = (a.projects?.name ?? '').localeCompare(b.projects?.name ?? '');
      return sortAsc ? cmp : -cmp;
    });

  const stats = {
    total: tasks.length,
    inProgress: tasks.filter((t) => t.status === 'in-progress').length,
    overdue: tasks.filter((t) => t.due_date < today && t.status !== 'completed' && t.status !== 'cancelled').length,
    completed: tasks.filter((t) => t.status === 'completed').length,
  };

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortAsc(!sortAsc);
    else { setSortKey(key); setSortAsc(true); }
  };

  const clearFilters = () => {
    setFilterStatus('all');
    setFilterProject('all');
    setFilterDateFrom('');
    setFilterDateTo('');
  };

  const hasActiveFilters = filterStatus !== 'all' || filterProject !== 'all' || filterDateFrom || filterDateTo;

  const SortIcon = ({ k }: { k: SortKey }) => {
    if (sortKey !== k) return <ArrowUpDown className="w-3 h-3 inline ml-0.5 text-gray-400" />;
    return sortAsc ? <ChevronUp className="w-3 h-3 inline ml-0.5" /> : <ChevronDown className="w-3 h-3 inline ml-0.5" />;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-teal-500" />
      </div>
    );
  }

  return (
    <div>
      {/* Welcome */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-1">
          Welcome, {teamMember?.name?.split(' ')[0]}
        </h2>
        <p className="text-gray-500 text-sm">{teamMember?.department} · {teamMember?.role}</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total Tasks', value: stats.total, icon: <ClipboardList className="w-5 h-5" />, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'In Progress', value: stats.inProgress, icon: <Clock className="w-5 h-5" />, color: 'text-yellow-600', bg: 'bg-yellow-50' },
          { label: 'Overdue', value: stats.overdue, icon: <AlertTriangle className="w-5 h-5" />, color: 'text-red-600', bg: 'bg-red-50' },
          { label: 'Completed', value: stats.completed, icon: <CheckCircle2 className="w-5 h-5" />, color: 'text-green-600', bg: 'bg-green-50' },
        ].map((c) => (
          <div key={c.label} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 flex items-center gap-3">
            <div className={`w-10 h-10 ${c.bg} rounded-lg flex items-center justify-center ${c.color} flex-shrink-0`}>
              {c.icon}
            </div>
            <div>
              <p className={`text-xl font-bold ${c.color}`}>{c.value}</p>
              <p className="text-xs text-gray-500">{c.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Task list */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100">
        <div className="p-5 border-b border-gray-100">
          <div className="flex flex-wrap items-center gap-3 mb-3">
            <div className="flex items-center gap-2">
              <CalendarDays className="w-5 h-5 text-teal-600" />
              <h3 className="font-bold text-gray-900">My Tasks</h3>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border transition-all ${
                  showFilters || hasActiveFilters
                    ? 'bg-teal-600 text-white border-teal-600'
                    : 'bg-white text-gray-600 border-gray-200 hover:border-teal-300 hover:text-teal-600'
                }`}
              >
                <Filter className="w-3.5 h-3.5" />
                Filter & Sort
                {hasActiveFilters && (
                  <span className="bg-white text-teal-700 text-xs rounded-full w-4 h-4 flex items-center justify-center font-bold">
                    {[filterStatus !== 'all', filterProject !== 'all', !!filterDateFrom, !!filterDateTo].filter(Boolean).length}
                  </span>
                )}
              </button>
              {hasActiveFilters && (
                <button
                  onClick={clearFilters}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs text-red-500 hover:bg-red-50 border border-red-200 transition-colors"
                >
                  <X className="w-3 h-3" />
                  Clear
                </button>
              )}
            </div>
          </div>

          {showFilters && (
            <div className="bg-gray-50 rounded-xl border border-gray-200 p-4 mt-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Status</label>
                  <select
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value as FilterStatus)}
                    className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400"
                  >
                    <option value="all">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="in-progress">In Progress</option>
                    <option value="review">Review</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Project</label>
                  <select
                    value={filterProject}
                    onChange={(e) => setFilterProject(e.target.value)}
                    className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400"
                  >
                    <option value="all">All Projects</option>
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Due Date From</label>
                  <input
                    type="date"
                    value={filterDateFrom}
                    onChange={(e) => setFilterDateFrom(e.target.value)}
                    className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Due Date To</label>
                  <input
                    type="date"
                    value={filterDateTo}
                    onChange={(e) => setFilterDateTo(e.target.value)}
                    className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400"
                  />
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-gray-200">
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Sort By</label>
                <div className="flex flex-wrap gap-2">
                  {([
                    { key: 'due_date', label: 'Due Date' },
                    { key: 'status', label: 'Status' },
                    { key: 'project', label: 'Project' },
                    { key: 'priority', label: 'Priority' },
                  ] as { key: SortKey; label: string }[]).map(({ key, label }) => (
                    <button
                      key={key}
                      onClick={() => toggleSort(key)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border transition-all ${
                        sortKey === key
                          ? 'bg-teal-600 text-white border-teal-600'
                          : 'bg-white text-gray-600 border-gray-200 hover:border-teal-300'
                      }`}
                    >
                      {label}
                      {sortKey === key ? (
                        sortAsc ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />
                      ) : (
                        <ArrowUpDown className="w-3.5 h-3.5 opacity-40" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {hasActiveFilters && (
            <div className="flex flex-wrap gap-1.5 mt-3">
              {filterStatus !== 'all' && (
                <span className="flex items-center gap-1 px-2 py-0.5 bg-teal-100 text-teal-700 rounded-full text-xs font-medium">
                  Status: {statusLabel(filterStatus)}
                  <button onClick={() => setFilterStatus('all')}><X className="w-3 h-3" /></button>
                </span>
              )}
              {filterProject !== 'all' && (
                <span className="flex items-center gap-1 px-2 py-0.5 bg-teal-100 text-teal-700 rounded-full text-xs font-medium">
                  Project: {projects.find((p) => p.id === filterProject)?.name}
                  <button onClick={() => setFilterProject('all')}><X className="w-3 h-3" /></button>
                </span>
              )}
              {filterDateFrom && (
                <span className="flex items-center gap-1 px-2 py-0.5 bg-teal-100 text-teal-700 rounded-full text-xs font-medium">
                  From: {fmtDate(filterDateFrom)}
                  <button onClick={() => setFilterDateFrom('')}><X className="w-3 h-3" /></button>
                </span>
              )}
              {filterDateTo && (
                <span className="flex items-center gap-1 px-2 py-0.5 bg-teal-100 text-teal-700 rounded-full text-xs font-medium">
                  To: {fmtDate(filterDateTo)}
                  <button onClick={() => setFilterDateTo('')}><X className="w-3 h-3" /></button>
                </span>
              )}
            </div>
          )}
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <CheckCircle2 className="w-14 h-14 text-green-400 mx-auto mb-4" />
            <p className="text-gray-700 font-medium">
              {!hasActiveFilters ? 'No tasks assigned yet' : 'No tasks match your filters'}
            </p>
            <p className="text-gray-400 text-sm mt-1">
              {hasActiveFilters ? (
                <button onClick={clearFilters} className="text-teal-600 hover:underline">Clear filters</button>
              ) : 'Check back later or contact your admin'}
            </p>
          </div>
        ) : (
          <>
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50">
                    <th className="text-left py-3 px-5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Task / Document</th>
                    <th onClick={() => toggleSort('project')} className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer hover:text-teal-600 select-none">
                      Project <SortIcon k="project" />
                    </th>
                    <th onClick={() => toggleSort('due_date')} className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer hover:text-teal-600 select-none">
                      Due Date <SortIcon k="due_date" />
                    </th>
                    <th onClick={() => toggleSort('priority')} className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer hover:text-teal-600 select-none">
                      Priority <SortIcon k="priority" />
                    </th>
                    <th onClick={() => toggleSort('status')} className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer hover:text-teal-600 select-none">
                      Status <SortIcon k="status" />
                    </th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">Type</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((task) => {
                    const overdue = task.due_date < today && task.status !== 'completed' && task.status !== 'cancelled';
                    const daysOver = Math.floor((Date.now() - new Date(task.due_date + 'T00:00:00').getTime()) / 86400000);
                    return (
                      <tr key={task.id} className={`border-b border-gray-100 hover:bg-gray-50 border-l-4 ${PRIORITY_BORDER[task.priority] ?? 'border-l-gray-300'}`}>
                        <td className="py-3.5 px-5">
                          <div className="font-medium text-gray-900 leading-snug">{task.document_name || task.title}</div>
                          {task.description && <div className="text-xs text-gray-400 mt-0.5 line-clamp-1">{task.description}</div>}
                          {task.notes && <div className="text-xs text-teal-600 mt-0.5 italic line-clamp-1">{task.notes}</div>}
                        </td>
                        <td className="py-3.5 px-4 text-sm text-gray-600">{task.projects?.name ?? '—'}</td>
                        <td className="py-3.5 px-4">
                          <span className={`text-sm font-medium ${overdue ? 'text-red-600' : 'text-gray-700'}`}>
                            {fmtDate(task.due_date)}
                          </span>
                          {overdue && <div className="text-xs text-red-400 mt-0.5">{daysOver}d overdue</div>}
                          {task.due_date === today && <div className="text-xs text-amber-500 mt-0.5 font-medium">Due today</div>}
                        </td>
                        <td className="py-3.5 px-4">
                          <span className={`px-2 py-0.5 rounded text-xs font-medium capitalize ${PRIORITY_BADGE[task.priority] ?? 'bg-gray-100 text-gray-600'}`}>
                            {task.priority}
                          </span>
                        </td>
                        <td className="py-3.5 px-4">
                          <span className={`px-2 py-0.5 rounded border text-xs font-medium ${STATUS_COLORS[task.status] ?? 'bg-gray-100 text-gray-700'}`}>
                            {statusLabel(task.status)}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-sm capitalize text-gray-500">{task.task_type}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="md:hidden divide-y divide-gray-100">
              {filtered.map((task) => {
                const overdue = task.due_date < today && task.status !== 'completed' && task.status !== 'cancelled';
                return (
                  <div key={task.id} className={`p-4 border-l-4 ${PRIORITY_BORDER[task.priority] ?? 'border-l-gray-300'}`}>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="font-medium text-gray-900 text-sm leading-snug">{task.document_name || task.title}</div>
                      <span className={`px-2 py-0.5 rounded border text-xs font-medium flex-shrink-0 ${STATUS_COLORS[task.status] ?? 'bg-gray-100 text-gray-700'}`}>
                        {statusLabel(task.status)}
                      </span>
                    </div>
                    <div className="text-xs text-gray-500 mb-1">{task.projects?.name}</div>
                    <div className="flex items-center justify-between">
                      <span className={`text-xs font-medium ${overdue ? 'text-red-600' : 'text-gray-600'}`}>
                        {fmtDate(task.due_date)}{overdue && ' · overdue'}
                      </span>
                      <span className={`px-1.5 py-0.5 rounded text-xs capitalize ${PRIORITY_BADGE[task.priority] ?? 'bg-gray-100 text-gray-600'}`}>
                        {task.priority}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
          <p className="text-xs text-gray-400">Showing {filtered.length} of {tasks.length} tasks</p>
          <p className="text-xs text-gray-400">View only — contact admin to make changes</p>
        </div>
      </div>
    </div>
  );
}
