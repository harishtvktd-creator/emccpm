import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../lib/supabase';
import {
  Building2,
  X,
  Plus,
  Edit2,
  Trash2,
  Wallet,
  PiggyBank,
  Banknote,
  CreditCard,
  CheckCircle2,
} from 'lucide-react';
import type { Database } from '../lib/supabase';
import { SUPPORTED_CURRENCIES, CURRENCY_SYMBOLS, CURRENCY_NAMES, formatCurrency } from '../lib/currency';

type BankAccount = Database['public']['Tables']['bank_accounts']['Row'];

const ACCOUNT_TYPE_ICONS = {
  checking: Building2,
  savings: PiggyBank,
  cash: Banknote,
  credit: CreditCard,
};

const ACCOUNT_TYPE_NAMES = {
  checking: 'Checking Account',
  savings: 'Savings Account',
  cash: 'Cash',
  credit: 'Credit Card',
};

interface BankAccountsProps {
  onBack: () => void;
}

export function BankAccounts({ onBack }: BankAccountsProps) {
  const { user } = useAuth();
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAccountModal, setShowAccountModal] = useState(false);
  const [editingAccount, setEditingAccount] = useState<BankAccount | null>(null);

  const fetchAccounts = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('bank_accounts')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: true });

      if (data) setAccounts(data);
      if (error) console.error('Error fetching accounts:', error);
    } catch (error) {
      console.error('Error fetching accounts:', error);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchAccounts();
  }, [fetchAccounts]);

  const handleDeleteAccount = async (id: string) => {
    if (!confirm('Are you sure you want to delete this account?')) return;

    try {
      await supabase.from('bank_accounts').delete().eq('id', id);
      fetchAccounts();
    } catch (error) {
      console.error('Error deleting account:', error);
    }
  };

  const handleSetDefault = async (id: string) => {
    try {
      // Remove default from all accounts
      await supabase
        .from('bank_accounts')
        .update({ is_default: false })
        .eq('user_id', user!.id);

      // Set this account as default
      await supabase
        .from('bank_accounts')
        .update({ is_default: true })
        .eq('id', id);

      fetchAccounts();
    } catch (error) {
      console.error('Error setting default account:', error);
    }
  };

  const handleAccountSaved = () => {
    setShowAccountModal(false);
    setEditingAccount(null);
    fetchAccounts();
  };

  const totalBalance = accounts.reduce((sum, acc) => sum + Number(acc.balance), 0);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50">
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="text-gray-600 hover:text-gray-900">
              <X className="w-6 h-6" />
            </button>
            <div className="flex items-center gap-2">
              <Wallet className="w-6 h-6 text-gray-600" />
              <h1 className="text-xl font-bold text-gray-900">Bank Accounts</h1>
            </div>
          </div>
          <button
            onClick={() => {
              setEditingAccount(null);
              setShowAccountModal(true);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg hover:from-teal-600 hover:to-blue-700 transition-all"
          >
            <Plus className="w-4 h-4" />
            Add Account
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Total Balance Card */}
        <div className="bg-gradient-to-r from-teal-500 to-blue-600 rounded-2xl shadow-lg p-8 mb-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm opacity-80 mb-1">Total Balance (All Accounts)</p>
              <p className="text-4xl font-bold">
                {formatCurrency(totalBalance, 'AED')}
              </p>
              <p className="text-sm opacity-80 mt-2">{accounts.length} account(s)</p>
            </div>
            <div className="w-16 h-16 bg-white bg-opacity-20 rounded-2xl flex items-center justify-center">
              <Wallet className="w-8 h-8" />
            </div>
          </div>
        </div>

        {/* Accounts Grid */}
        {accounts.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 border border-gray-100 text-center">
            <Wallet className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No Bank Accounts Yet</h3>
            <p className="text-gray-500 mb-4">Add your first bank account to start tracking transactions</p>
            <button
              onClick={() => setShowAccountModal(true)}
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg hover:from-teal-600 hover:to-blue-700 transition-all"
            >
              <Plus className="w-5 h-5" />
              Add Your First Account
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {accounts.map((account) => {
              const IconComponent = ACCOUNT_TYPE_ICONS[account.account_type];
              return (
                <div
                  key={account.id}
                  className={`bg-white rounded-2xl shadow-lg p-6 border-2 transition-all ${
                    account.is_default ? 'border-teal-500' : 'border-gray-100 hover:border-gray-200'
                  }`}
                >
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-12 h-12 rounded-xl flex items-center justify-center"
                        style={{
                          backgroundColor: account.account_type === 'checking' ? '#3B82F6' :
                                          account.account_type === 'savings' ? '#10B981' :
                                          account.account_type === 'cash' ? '#F59E0B' : '#EF4444'
                        }}
                      >
                        <IconComponent className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                          {account.name}
                          {account.is_default && (
                            <CheckCircle2 className="w-4 h-4 text-teal-500" />
                          )}
                        </h3>
                        <p className="text-xs text-gray-500">
                          {ACCOUNT_TYPE_NAMES[account.account_type]}
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setEditingAccount(account);
                          setShowAccountModal(true);
                        }}
                        className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteAccount(account.id)}
                        className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="mb-4">
                    <p className="text-sm text-gray-500 mb-1">Balance</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {formatCurrency(Number(account.balance), account.currency)}
                    </p>
                    <p className="text-xs text-gray-400">{account.currency}</p>
                  </div>

                  {!account.is_default && (
                    <button
                      onClick={() => handleSetDefault(account.id)}
                      className="w-full py-2 text-sm text-teal-600 hover:text-teal-700 font-medium border border-teal-200 rounded-lg hover:bg-teal-50 transition-all"
                    >
                      Set as Default
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </main>

      {showAccountModal && (
        <AccountModal
          account={editingAccount}
          userId={user!.id}
          onClose={() => {
            setShowAccountModal(false);
            setEditingAccount(null);
          }}
          onSave={handleAccountSaved}
          hasDefault={accounts.some((a) => a.is_default)}
        />
      )}
    </div>
  );
}

function AccountModal({
  account,
  userId,
  onClose,
  onSave,
  hasDefault,
}: {
  account: BankAccount | null;
  userId: string;
  onClose: () => void;
  onSave: () => void;
  hasDefault: boolean;
}) {
  const [name, setName] = useState(account?.name || '');
  const [accountType, setAccountType] = useState<'checking' | 'savings' | 'cash' | 'credit'>(
    account?.account_type || 'checking'
  );
  const [currency, setCurrency] = useState(account?.currency || 'AED');
  const [balance, setBalance] = useState(account?.balance.toString() || '0');
  const [isDefault, setIsDefault] = useState(account?.is_default || false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const accountData = {
        user_id: userId,
        name,
        account_type: accountType,
        currency,
        balance: parseFloat(balance) || 0,
        is_default: !hasDefault ? true : isDefault,
      };

      if (account) {
        if (isDefault && !account.is_default) {
          // Remove default from other accounts first
          await supabase
            .from('bank_accounts')
            .update({ is_default: false })
            .eq('user_id', userId);
        }
        await supabase
          .from('bank_accounts')
          .update(accountData)
          .eq('id', account.id);
      } else {
        await supabase.from('bank_accounts').insert(accountData);
      }
      onSave();
    } catch (error) {
      console.error('Error saving account:', error);
    }
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-900">
            {account ? 'Edit Account' : 'Add Bank Account'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Account Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="e.g., Main Checking, Savings Account"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Account Type
            </label>
            <div className="grid grid-cols-2 gap-2">
              {(['checking', 'savings', 'cash', 'credit'] as const).map((type) => {
                const Icon = ACCOUNT_TYPE_ICONS[type];
                return (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setAccountType(type)}
                    className={`flex items-center gap-2 p-3 border-2 rounded-lg transition-all ${
                      accountType === type
                        ? 'border-teal-500 bg-teal-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="text-sm font-medium">{ACCOUNT_TYPE_NAMES[type]}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Currency
            </label>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {SUPPORTED_CURRENCIES.map((c) => (
                <option key={c} value={c}>
                  {CURRENCY_SYMBOLS[c]} {c} - {CURRENCY_NAMES[c]}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Current Balance
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">
                {CURRENCY_SYMBOLS[currency]}
              </span>
              <input
                type="number"
                step="0.01"
                value={balance}
                onChange={(e) => setBalance(e.target.value)}
                className="w-full pl-8 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="0.00"
              />
            </div>
          </div>

          {hasDefault && !account?.is_default && (
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="default"
                checked={isDefault}
                onChange={(e) => setIsDefault(e.target.checked)}
                className="rounded border-gray-300"
              />
              <label htmlFor="default" className="text-sm text-gray-700">
                Set as default account
              </label>
            </div>
          )}

          <div className="flex gap-2 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 px-4 border-2 border-gray-200 text-gray-700 font-medium rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || !name.trim()}
              className="flex-1 py-2 px-4 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-medium rounded-lg hover:from-teal-600 hover:to-blue-700 disabled:opacity-50"
            >
              {loading ? 'Saving...' : account ? 'Update' : 'Add Account'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
