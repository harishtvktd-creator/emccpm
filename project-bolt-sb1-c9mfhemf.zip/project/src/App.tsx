import { useState } from 'react';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { Auth } from './components/Auth';
import { Dashboard } from './components/Dashboard';
import { TeamMembers } from './components/TeamMembers';
import { Projects } from './components/Projects';
import { TaskBoard } from './components/TaskBoard';
import { Reports } from './components/Reports';
import { Settings } from './components/Settings';
import { TeamMemberPortal } from './components/TeamMemberPortal';
import { PersonalDashboard } from './components/PersonalDashboard';
import { MaterialRequisitions } from './components/MaterialRequisitions';
import { ProcurementDashboard } from './components/ProcurementDashboard';
import { Timesheet } from './components/Timesheet';
import { TimesheetPost } from './components/TimesheetPost';
import { WorkforceEmployees } from './components/WorkforceEmployees';
import { WorkforceDailyAllocation } from './components/WorkforceDailyAllocation';
import { WorkforceReports } from './components/WorkforceReports';
import { WorkforceProjectAssignments } from './components/WorkforceProjectAssignments';
import { AccountsIncome } from './components/AccountsIncome';
import { AccountsExpense } from './components/AccountsExpense';
import { AccountsCashFlow } from './components/AccountsCashFlow';
import { AccountsProfitLoss } from './components/AccountsProfitLoss';
import { AccountsStatement } from './components/AccountsStatement';
import {
  LayoutDashboard,
  Users,
  FolderKanban,
  ClipboardList,
  FileText,
  Menu,
  X,
  LogOut,
  Settings as SettingsIcon,
  HardHat,
  ChevronDown,
  ShoppingCart,
  Building2,
  Clock,
  Construction,
  Briefcase,
  CalendarCheck,
  BarChart3,
  UserCog,
  Link,
  Landmark,
  TrendingUp,
  TrendingDown,
  ArrowLeftRight,
  PieChart,
  FileText as FileStatement,
  FileCheck2,
} from 'lucide-react';

type View =
  | 'dashboard'
  | 'team'
  | 'team-employees'
  | 'projects'
  | 'tasks'
  | 'reports'
  | 'procurement'
  | 'construction'
  | 'timesheets'
  | 'timesheet-employees'
  | 'timesheet-wf-assignments'
  | 'timesheet-daily'
  | 'timesheet-wf-reports'
  | 'timesheet-post'
  | 'timesheet-review'
  | 'accounts-income'
  | 'accounts-expense'
  | 'accounts-cashflow'
  | 'accounts-profit-loss'
  | 'accounts-statement'
  | 'settings';

type TeamMemberView = 'dashboard' | 'portal' | 'procurement' | 'team-employees' | 'timesheet-daily';

const ENGINEERING_VIEWS: View[] = ['tasks', 'reports'];
const TEAM_VIEWS: View[] = ['team', 'team-employees'];
const TIMESHEET_VIEWS: View[] = [
  'timesheets', 'timesheet-employees',
  'timesheet-wf-assignments', 'timesheet-daily', 'timesheet-wf-reports',
  'timesheet-post', 'timesheet-review',
];
const ACCOUNTS_VIEWS: View[] = [
  'accounts-income', 'accounts-expense', 'accounts-cashflow',
  'accounts-profit-loss', 'accounts-statement',
];

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

function AppContent() {
  const { user, loading, signOut, isAdmin, isTimeKeeper, isAccountant, teamMember, teamMemberFetching } = useAuth();
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [engineeringOpen, setEngineeringOpen] = useState(false);
  const [teamOpen, setTeamOpen] = useState(false);
  const [timesheetOpen, setTimesheetOpen] = useState(false);
  const [accountsOpen, setAccountsOpen] = useState(false);

  const navigate = (view: View) => {
    setCurrentView(view);
    setSidebarOpen(false);
    if (ENGINEERING_VIEWS.includes(view)) setEngineeringOpen(true);
    if (TEAM_VIEWS.includes(view)) setTeamOpen(true);
    if (TIMESHEET_VIEWS.includes(view)) setTimesheetOpen(true);
    if (ACCOUNTS_VIEWS.includes(view)) setAccountsOpen(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500" />
      </div>
    );
  }

  if (!user) return <Auth />;

  // Still fetching team member after sign-in — show spinner instead of error
  if (teamMemberFetching) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500" />
      </div>
    );
  }

  if (!isAdmin) {
    if (!teamMember) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
            <img src="/EMCC_Logo..jpg" alt="EMCC" className="w-16 h-16 object-contain mx-auto mb-4" />
            <h2 className="text-xl font-bold text-gray-900 mb-2">Account Not Linked</h2>
            <p className="text-gray-500 text-sm mb-6">
              Your account ({user.email}) has not been linked to a team member profile yet.
              Please contact your administrator.
            </p>
            <button
              onClick={signOut}
              className="px-5 py-2 bg-gradient-to-r from-teal-500 to-blue-600 text-white rounded-lg text-sm font-medium"
            >
              Sign Out
            </button>
          </div>
        </div>
      );
    }
    if (isTimeKeeper) return <TimekeeperApp />;
    if (isAccountant) return <AccountantApp />;
    return <TeamMemberApp />;
  }

  const renderView = () => {
    switch (currentView) {
      case 'team':
        return <TeamMembers />;
      case 'team-employees':
        return <PageShell title="Team Members" subtitle="Employees" icon={UserCog}><WorkforceEmployees /></PageShell>;
      case 'projects':
        return <Projects />;
      case 'tasks':
        return <TaskBoard />;
      case 'reports':
        return <Reports />;
      case 'settings':
        return <Settings onBack={() => navigate('dashboard')} />;
      case 'procurement':
        return <ProcurementDashboard />;
      case 'construction':
        return (
          <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 flex items-center justify-center p-8">
            <div className="bg-white rounded-2xl shadow-xl p-12 max-w-md w-full text-center border border-gray-100">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-teal-500 to-blue-600 flex items-center justify-center mx-auto mb-5 shadow-lg">
                <Building2 className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Construction</h2>
              <p className="text-gray-500 text-sm leading-relaxed">Track site progress, inspections, punch lists, and construction milestones.</p>
              <div className="mt-6 inline-flex items-center gap-2 px-4 py-2 bg-teal-50 text-teal-700 rounded-full text-xs font-semibold border border-teal-100">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-pulse" />Coming Soon
              </div>
            </div>
          </div>
        );
      case 'timesheets':
      case 'timesheet-employees':
        return <Timesheet initialTab="employees" />;
      case 'timesheet-wf-assignments':
        return <PageShell title="Timesheets" subtitle="Project Assignments" icon={Link}><WorkforceProjectAssignments /></PageShell>;
      case 'timesheet-daily':
        return <PageShell title="Timesheets" subtitle="Daily Allocation" icon={CalendarCheck}><WorkforceDailyAllocation /></PageShell>;
      case 'timesheet-wf-reports':
        return <PageShell title="Timesheets" subtitle="Reports & Dashboard" icon={BarChart3}><WorkforceReports /></PageShell>;
      case 'timesheet-post':
        return <PageShell title="Timesheets" subtitle="Post Time Sheet" icon={FileCheck2}><TimesheetPost /></PageShell>;
      case 'accounts-income':
        return <PageShell title="Accounts" subtitle="Income" icon={TrendingUp}><AccountsIncome /></PageShell>;
      case 'accounts-expense':
        return <PageShell title="Accounts" subtitle="Expense" icon={TrendingDown}><AccountsExpense /></PageShell>;
      case 'accounts-cashflow':
        return <PageShell title="Accounts" subtitle="Cash Flow" icon={ArrowLeftRight}><AccountsCashFlow /></PageShell>;
      case 'accounts-profit-loss':
        return <PageShell title="Accounts" subtitle="Profit & Loss" icon={PieChart}><AccountsProfitLoss /></PageShell>;
      case 'accounts-statement':
        return <PageShell title="Accounts" subtitle="Statement" icon={FileStatement}><AccountsStatement /></PageShell>;
      default:
        return <Dashboard onNavigate={(v) => navigate(v as View)} />;
    }
  };

  const isEngineering = ENGINEERING_VIEWS.includes(currentView);
  const isTeam = TEAM_VIEWS.includes(currentView);
  const isTimesheet = TIMESHEET_VIEWS.includes(currentView);
  const isAccounts = ACCOUNTS_VIEWS.includes(currentView);

  const navItem = (view: View, label: string, Icon: React.ElementType, indent = false) => (
    <button
      onClick={() => navigate(view)}
      className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all text-sm ${indent ? 'pl-10' : ''} ${
        currentView === view
          ? 'bg-gradient-to-r from-teal-500 to-blue-600 text-white shadow-md'
          : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
      }`}
    >
      <Icon className={`flex-shrink-0 ${indent ? 'w-4 h-4' : 'w-5 h-5'}`} />
      {label}
    </button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50">
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="fixed top-4 left-4 z-50 lg:hidden bg-white shadow-lg p-2 rounded-lg"
      >
        {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      <aside className={`fixed left-0 top-0 h-full w-64 bg-white shadow-xl z-40 transform transition-transform duration-300 ease-in-out flex flex-col ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}>
        <div className="p-5 border-b border-gray-100 flex-shrink-0">
          <div className="flex items-center gap-3">
            <img src="/EMCC_Logo..jpg" alt="EMCC Logo" className="w-10 h-10 object-contain" />
            <div>
              <h1 className="font-bold text-gray-900 text-sm leading-tight">EMCC Projects Division</h1>
              <p className="text-xs text-gray-500 mt-0.5">Project Management</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
          {navItem('dashboard', 'Dashboard', LayoutDashboard)}

          {/* Team Members group */}
          <div>
            <button
              onClick={() => setTeamOpen((o) => !o)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all text-sm ${isTeam ? 'bg-teal-50 text-teal-700 font-semibold' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
            >
              <Users className="w-5 h-5 flex-shrink-0" />
              <span className="flex-1 text-left">Team Members</span>
              <ChevronDown className={`w-4 h-4 flex-shrink-0 transition-transform duration-200 ${teamOpen ? 'rotate-180' : ''}`} />
            </button>
            {teamOpen && (
              <div className="mt-0.5 space-y-0.5">
                {navItem('team', 'Key Person List', Users, true)}
                {navItem('team-employees', 'Employees', UserCog, true)}
              </div>
            )}
          </div>

          {navItem('projects', 'Projects', FolderKanban)}

          {/* Engineering group */}
          <div>
            <button
              onClick={() => setEngineeringOpen((o) => !o)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all text-sm ${isEngineering ? 'bg-teal-50 text-teal-700 font-semibold' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
            >
              <HardHat className="w-5 h-5 flex-shrink-0" />
              <span className="flex-1 text-left">Engineering</span>
              <ChevronDown className={`w-4 h-4 flex-shrink-0 transition-transform duration-200 ${engineeringOpen ? 'rotate-180' : ''}`} />
            </button>
            {engineeringOpen && (
              <div className="mt-0.5 space-y-0.5">
                {navItem('tasks', 'Task Board', ClipboardList, true)}
                {navItem('reports', 'Reports', FileText, true)}
              </div>
            )}
          </div>

          {navItem('procurement', 'Procurement', ShoppingCart)}
          {navItem('construction', 'Construction', Construction)}

          {/* Timesheets group (merged Timesheet + Workforce) */}
          <div>
            <button
              onClick={() => setTimesheetOpen((o) => !o)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all text-sm ${isTimesheet ? 'bg-teal-50 text-teal-700 font-semibold' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
            >
              <Clock className="w-5 h-5 flex-shrink-0" />
              <span className="flex-1 text-left">Timesheets</span>
              <ChevronDown className={`w-4 h-4 flex-shrink-0 transition-transform duration-200 ${timesheetOpen ? 'rotate-180' : ''}`} />
            </button>
            {timesheetOpen && (
              <div className="mt-0.5 space-y-0.5">
                {navItem('timesheet-wf-assignments', 'Project Assignments', Link, true)}
                {navItem('timesheet-post', 'Post Time Sheet', FileCheck2, true)}
                {navItem('timesheet-daily', 'Daily Allocation', CalendarCheck, true)}
                {navItem('timesheet-wf-reports', 'Reports', BarChart3, true)}
              </div>
            )}
          </div>

          {/* Accounts group */}
          <div>
            <button
              onClick={() => setAccountsOpen((o) => !o)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all text-sm ${isAccounts ? 'bg-teal-50 text-teal-700 font-semibold' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
            >
              <Landmark className="w-5 h-5 flex-shrink-0" />
              <span className="flex-1 text-left">Accounts</span>
              <ChevronDown className={`w-4 h-4 flex-shrink-0 transition-transform duration-200 ${accountsOpen ? 'rotate-180' : ''}`} />
            </button>
            {accountsOpen && (
              <div className="mt-0.5 space-y-0.5">
                {navItem('accounts-income', 'Income', TrendingUp, true)}
                {navItem('accounts-expense', 'Expense', TrendingDown, true)}
                {navItem('accounts-cashflow', 'Cash Flow', ArrowLeftRight, true)}
                {navItem('accounts-profit-loss', 'Profit & Loss', PieChart, true)}
                {navItem('accounts-statement', 'Statement', FileStatement, true)}
              </div>
            )}
          </div>

          <div className="pt-2 mt-2 border-t border-gray-100">
            {navItem('settings', 'Settings', SettingsIcon)}
          </div>
        </nav>

        <div className="flex-shrink-0 p-3 border-t border-gray-100">
          <button
            onClick={signOut}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors text-sm"
          >
            <LogOut className="w-4 h-4" />Sign Out
          </button>
        </div>
      </aside>

      {sidebarOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      <main className="lg:ml-64">{renderView()}</main>
    </div>
  );
}

/* ── Page shell ──────────────────────────────────────────────── */
function PageShell({
  title, subtitle, icon: Icon, children,
}: {
  title: string;
  subtitle: string;
  icon: React.ElementType;
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-blue-600 rounded-xl flex items-center justify-center">
            <Icon className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-xs font-semibold text-teal-600 uppercase tracking-widest">{title}</p>
            <h2 className="text-xl font-bold text-gray-900 leading-tight">{subtitle}</h2>
          </div>
        </div>
        {children}
      </div>
    </div>
  );
}

/* ── Team Member App (non-admin layout) ──────────────────────── */
function TeamMemberApp() {
  const { signOut, teamMember } = useAuth();
  const [currentView, setCurrentView] = useState<TeamMemberView>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [timesheetOpen, setTimesheetOpen] = useState(true);

  const navigate = (view: TeamMemberView) => {
    setCurrentView(view);
    setSidebarOpen(false);
    if (view === 'team-employees' || view === 'timesheet-daily') setTimesheetOpen(true);
  };

  const navItem = (view: TeamMemberView, label: string, Icon: React.ElementType, indent = false) => (
    <button
      onClick={() => navigate(view)}
      className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all text-sm ${indent ? 'pl-10' : ''} ${
        currentView === view
          ? 'bg-gradient-to-r from-teal-500 to-blue-600 text-white shadow-md'
          : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
      }`}
    >
      <Icon className={`flex-shrink-0 ${indent ? 'w-4 h-4' : 'w-5 h-5'}`} />
      {label}
    </button>
  );

  const isTimesheetView = currentView === 'team-employees' || currentView === 'timesheet-daily';

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <PersonalDashboard />;
      case 'procurement':
        return <MaterialRequisitions />;
      case 'team-employees':
        return (
          <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 p-6 lg:p-8">
            <div className="max-w-7xl mx-auto space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-blue-600 rounded-xl flex items-center justify-center">
                  <UserCog className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-teal-600 uppercase tracking-widest">Timesheets</p>
                  <h2 className="text-xl font-bold text-gray-900">Employees</h2>
                </div>
              </div>
              <WorkforceEmployees />
            </div>
          </div>
        );
      case 'timesheet-daily':
        return (
          <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 p-6 lg:p-8">
            <div className="max-w-7xl mx-auto space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-blue-600 rounded-xl flex items-center justify-center">
                  <CalendarCheck className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-teal-600 uppercase tracking-widest">Timesheets</p>
                  <h2 className="text-xl font-bold text-gray-900">Daily Allocation</h2>
                </div>
              </div>
              <WorkforceDailyAllocation />
            </div>
          </div>
        );
      default:
        return <TeamMemberPortal />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50">
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="fixed top-4 left-4 z-50 lg:hidden bg-white shadow-lg p-2 rounded-lg"
      >
        {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      <aside className={`fixed left-0 top-0 h-full w-64 bg-white shadow-xl z-40 transform transition-transform duration-300 ease-in-out flex flex-col ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}>
        <div className="p-5 border-b border-gray-100 flex-shrink-0">
          <div className="flex items-center gap-3">
            <img src="/EMCC_Logo..jpg" alt="EMCC Logo" className="w-10 h-10 object-contain" />
            <div>
              <h1 className="font-bold text-gray-900 text-sm leading-tight">EMCC Projects Division</h1>
              <p className="text-xs text-gray-500 mt-0.5">{teamMember?.name ?? 'Team Member'}</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
          {navItem('dashboard', 'My Dashboard', LayoutDashboard)}
          {navItem('portal', 'My Portal', LayoutDashboard)}
          {navItem('procurement', 'Procurement', ShoppingCart)}

          {/* Timesheets group */}
          <div>
            <button
              onClick={() => setTimesheetOpen((o) => !o)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all text-sm ${isTimesheetView ? 'bg-teal-50 text-teal-700 font-semibold' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
            >
              <Clock className="w-5 h-5 flex-shrink-0" />
              <span className="flex-1 text-left">Timesheets</span>
              <ChevronDown className={`w-4 h-4 flex-shrink-0 transition-transform duration-200 ${timesheetOpen ? 'rotate-180' : ''}`} />
            </button>
            {timesheetOpen && (
              <div className="mt-0.5 space-y-0.5">
                {navItem('team-employees', 'Employees', UserCog, true)}
                {navItem('timesheet-daily', 'Daily Allocation', CalendarCheck, true)}
              </div>
            )}
          </div>
        </nav>

        <div className="flex-shrink-0 p-3 border-t border-gray-100">
          <button
            onClick={signOut}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors text-sm"
          >
            <LogOut className="w-4 h-4" />Sign Out
          </button>
        </div>
      </aside>

      {sidebarOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      <main className="lg:ml-64">{renderView()}</main>
    </div>
  );
}

/* ── Time Keeper App — Team Members, Projects, Timesheets (view + export only) ── */
function TimekeeperApp() {
  const { signOut, teamMember } = useAuth();
  const [currentView, setCurrentView] = useState<
    'dashboard' | 'team' | 'team-employees' | 'projects' |
    'timesheet-wf-assignments' | 'timesheet-daily' | 'timesheet-wf-reports'
  >('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [teamOpen, setTeamOpen]         = useState(false);
  const [timesheetOpen, setTimesheetOpen] = useState(true);

  const navigate = (view: typeof currentView) => {
    setCurrentView(view);
    setSidebarOpen(false);
    if (view === 'team' || view === 'team-employees') setTeamOpen(true);
    if (view === 'timesheet-wf-assignments' || view === 'timesheet-daily' || view === 'timesheet-wf-reports') setTimesheetOpen(true);
  };

  const navItem = (view: typeof currentView, label: string, Icon: React.ElementType, indent = false) => (
    <button
      onClick={() => navigate(view)}
      className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all text-sm ${indent ? 'pl-10' : ''} ${
        currentView === view
          ? 'bg-gradient-to-r from-teal-500 to-blue-600 text-white shadow-md'
          : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
      }`}
    >
      <Icon className={`flex-shrink-0 ${indent ? 'w-4 h-4' : 'w-5 h-5'}`} />
      {label}
    </button>
  );

  const isTeam      = currentView === 'team' || currentView === 'team-employees';
  const isTimesheet = ['timesheet-wf-assignments', 'timesheet-daily', 'timesheet-wf-reports'].includes(currentView);

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':         return <PersonalDashboard />;
      case 'team':           return <TeamMembers />;
      case 'team-employees': return <PageShell title="Team Members" subtitle="Employees" icon={UserCog}><WorkforceEmployees /></PageShell>;
      case 'projects':       return <Projects />;
      case 'timesheet-wf-assignments': return <PageShell title="Timesheets" subtitle="Project Assignments" icon={Link}><WorkforceProjectAssignments /></PageShell>;
      case 'timesheet-daily':          return <PageShell title="Timesheets" subtitle="Daily Allocation" icon={CalendarCheck}><WorkforceDailyAllocation /></PageShell>;
      case 'timesheet-wf-reports':     return <PageShell title="Timesheets" subtitle="Reports & Dashboard" icon={BarChart3}><WorkforceReports /></PageShell>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50">
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="fixed top-4 left-4 z-50 lg:hidden bg-white shadow-lg p-2 rounded-lg"
      >
        {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      <aside className={`fixed left-0 top-0 h-full w-64 bg-white shadow-xl z-40 transform transition-transform duration-300 ease-in-out flex flex-col ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}>
        <div className="p-5 border-b border-gray-100 flex-shrink-0">
          <div className="flex items-center gap-3">
            <img src="/EMCC_Logo..jpg" alt="EMCC Logo" className="w-10 h-10 object-contain" />
            <div>
              <h1 className="font-bold text-gray-900 text-sm leading-tight">EMCC Projects Division</h1>
              <p className="text-xs text-gray-500 mt-0.5">{teamMember?.name ?? 'Time Keeper'}</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
          {navItem('dashboard', 'My Dashboard', LayoutDashboard)}
          <div>
            <button
              onClick={() => setTeamOpen((o) => !o)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all text-sm ${isTeam ? 'bg-teal-50 text-teal-700 font-semibold' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
            >
              <Users className="w-5 h-5 flex-shrink-0" />
              <span className="flex-1 text-left">Team Members</span>
              <ChevronDown className={`w-4 h-4 flex-shrink-0 transition-transform duration-200 ${teamOpen ? 'rotate-180' : ''}`} />
            </button>
            {teamOpen && (
              <div className="mt-0.5 space-y-0.5">
                {navItem('team', 'Key Person List', Users, true)}
                {navItem('team-employees', 'Employees', UserCog, true)}
              </div>
            )}
          </div>

          {navItem('projects', 'Projects', FolderKanban)}

          <div>
            <button
              onClick={() => setTimesheetOpen((o) => !o)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all text-sm ${isTimesheet ? 'bg-teal-50 text-teal-700 font-semibold' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
            >
              <Clock className="w-5 h-5 flex-shrink-0" />
              <span className="flex-1 text-left">Timesheets</span>
              <ChevronDown className={`w-4 h-4 flex-shrink-0 transition-transform duration-200 ${timesheetOpen ? 'rotate-180' : ''}`} />
            </button>
            {timesheetOpen && (
              <div className="mt-0.5 space-y-0.5">
                {navItem('timesheet-wf-assignments', 'Project Assignments', Link, true)}
                {navItem('timesheet-post', 'Post Time Sheet', FileCheck2, true)}
                {navItem('timesheet-daily', 'Daily Allocation', CalendarCheck, true)}
                {navItem('timesheet-wf-reports', 'Reports', BarChart3, true)}
              </div>
            )}
          </div>
        </nav>

        <div className="flex-shrink-0 p-3 border-t border-gray-100">
          <div className="px-3 py-2 mb-2 bg-cyan-50 border border-cyan-200 rounded-lg">
            <p className="text-xs font-semibold text-cyan-700">Time Keeper</p>
            <p className="text-xs text-cyan-600 mt-0.5">View &amp; export access</p>
          </div>
          <button
            onClick={signOut}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors text-sm"
          >
            <LogOut className="w-4 h-4" />Sign Out
          </button>
        </div>
      </aside>

      {sidebarOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      <main className="lg:ml-64">{renderView()}</main>
    </div>
  );
}

/* ── Accountant App ──────────────────────────────────────────────── */
function AccountantApp() {
  const { signOut, teamMember } = useAuth();
  const [currentView, setCurrentView] = useState<
    'dashboard' | 'accounts-income' | 'accounts-expense' | 'accounts-cashflow' | 'accounts-profit-loss' | 'accounts-statement'
  >('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [accountsOpen, setAccountsOpen] = useState(true);

  const isAccounts = currentView !== 'dashboard';

  const navigate = (view: typeof currentView) => {
    setCurrentView(view);
    setSidebarOpen(false);
  };

  const navItem = (view: typeof currentView, label: string, Icon: React.ElementType, indent = false) => (
    <button
      onClick={() => navigate(view)}
      className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all text-sm ${indent ? 'pl-10' : ''} ${
        currentView === view
          ? 'bg-gradient-to-r from-teal-500 to-blue-600 text-white shadow-md'
          : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
      }`}
    >
      <Icon className={`flex-shrink-0 ${indent ? 'w-4 h-4' : 'w-5 h-5'}`} />
      {label}
    </button>
  );

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':            return <PersonalDashboard />;
      case 'accounts-income':      return <PageShell title="Accounts" subtitle="Income"        icon={TrendingUp}      ><AccountsIncome /></PageShell>;
      case 'accounts-expense':     return <PageShell title="Accounts" subtitle="Expense"       icon={TrendingDown}    ><AccountsExpense /></PageShell>;
      case 'accounts-cashflow':    return <PageShell title="Accounts" subtitle="Cash Flow"     icon={ArrowLeftRight}  ><AccountsCashFlow /></PageShell>;
      case 'accounts-profit-loss': return <PageShell title="Accounts" subtitle="Profit & Loss" icon={PieChart}        ><AccountsProfitLoss /></PageShell>;
      case 'accounts-statement':   return <PageShell title="Accounts" subtitle="Statement"     icon={FileStatement}   ><AccountsStatement /></PageShell>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50">
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="fixed top-4 left-4 z-50 lg:hidden bg-white shadow-lg p-2 rounded-lg"
      >
        {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      <aside className={`fixed left-0 top-0 h-full w-64 bg-white shadow-xl z-40 transform transition-transform duration-300 ease-in-out flex flex-col ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}>
        <div className="p-5 border-b border-gray-100 flex-shrink-0">
          <div className="flex items-center gap-3">
            <img src="/EMCC_Logo..jpg" alt="EMCC Logo" className="w-10 h-10 object-contain" />
            <div>
              <h1 className="font-bold text-gray-900 text-sm leading-tight">EMCC Projects Division</h1>
              <p className="text-xs text-gray-500 mt-0.5">{teamMember?.name ?? 'Accountant'}</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
          {navItem('dashboard', 'My Dashboard', LayoutDashboard)}
          {/* Accounts group — always open for accountants */}
          <div>
            <button
              onClick={() => setAccountsOpen((o) => !o)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all text-sm ${isAccounts ? 'bg-teal-50 text-teal-700 font-semibold' : 'text-gray-600 hover:bg-gray-100'}`}
            >
              <Landmark className="w-5 h-5 flex-shrink-0" />
              <span className="flex-1 text-left">Accounts</span>
              <ChevronDown className={`w-4 h-4 flex-shrink-0 transition-transform duration-200 ${accountsOpen ? 'rotate-180' : ''}`} />
            </button>
            {accountsOpen && (
              <div className="mt-0.5 space-y-0.5">
                {navItem('accounts-income',      'Income',        TrendingUp,     true)}
                {navItem('accounts-expense',     'Expense',       TrendingDown,   true)}
                {navItem('accounts-cashflow',    'Cash Flow',     ArrowLeftRight, true)}
                {navItem('accounts-profit-loss', 'Profit & Loss', PieChart,       true)}
                {navItem('accounts-statement',   'Statement',     FileStatement,  true)}
              </div>
            )}
          </div>
        </nav>

        <div className="flex-shrink-0 p-3 border-t border-gray-100">
          <div className="px-3 py-2 mb-2 bg-teal-50 border border-teal-200 rounded-lg">
            <p className="text-xs font-semibold text-teal-700">Accountant</p>
            <p className="text-xs text-teal-600 mt-0.5">Accounts module access</p>
          </div>
          <button
            onClick={signOut}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors text-sm"
          >
            <LogOut className="w-4 h-4" />Sign Out
          </button>
        </div>
      </aside>

      {sidebarOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      <main className="lg:ml-64">{renderView()}</main>
    </div>
  );
}

export default App;
