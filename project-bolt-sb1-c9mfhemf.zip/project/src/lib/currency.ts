export const DEFAULT_CURRENCY = 'AED';

export const SUPPORTED_CURRENCIES = [
  'AED', 'USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'CHF', 'CNY', 'INR', 'PKR', 'BDT', 'PHP',
];

export const CURRENCY_SYMBOLS: Record<string, string> = {
  AED: 'AED', USD: 'USD', EUR: 'EUR', GBP: 'GBP', JPY: 'JPY',
  CAD: 'CAD', AUD: 'AUD', CHF: 'CHF', CNY: 'CNY', INR: 'INR',
  PKR: 'PKR', BDT: 'BDT', PHP: 'PHP',
};

export const CURRENCY_NAMES: Record<string, string> = {
  AED: 'UAE Dirham', USD: 'US Dollar', EUR: 'Euro', GBP: 'British Pound',
  JPY: 'Japanese Yen', CAD: 'Canadian Dollar', AUD: 'Australian Dollar',
  CHF: 'Swiss Franc', CNY: 'Chinese Yuan', INR: 'Indian Rupee',
  PKR: 'Pakistani Rupee', BDT: 'Bangladeshi Taka', PHP: 'Philippine Peso',
};

// Fallback static rates (to AED) for when network is unavailable
export const FALLBACK_RATES_TO_AED: Record<string, number> = {
  AED: 1, USD: 3.6725, EUR: 3.98, GBP: 4.65, JPY: 0.024,
  CAD: 2.71, AUD: 2.42, CHF: 4.18, CNY: 0.51, INR: 0.044,
  PKR: 0.0131, BDT: 0.033, PHP: 0.064,
};

const RATES_CACHE_KEY = 'emcc_fx_rates';
const RATES_CACHE_TTL = 60 * 60 * 1000; // 1 hour

export type ExchangeRates = Record<string, number>;

/** Fetch live rates from a free, no-key API. Returns rates with AED as base. */
export async function fetchExchangeRates(): Promise<ExchangeRates> {
  try {
    const cached = localStorage.getItem(RATES_CACHE_KEY);
    if (cached) {
      const { rates, ts } = JSON.parse(cached) as { rates: ExchangeRates; ts: number };
      if (Date.now() - ts < RATES_CACHE_TTL) return rates;
    }
    // Free currency API — no key required, CDN-hosted, ~1M req/day
    const res = await fetch(
      'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/aed.json'
    );
    if (!res.ok) throw new Error('fetch failed');
    const json = await res.json();
    // json.aed = { usd: 0.272, eur: 0.251, ... }
    const raw: Record<string, number> = json.aed ?? {};
    // Build rates-to-AED map (1 / rate-from-AED)
    const rates: ExchangeRates = { AED: 1 };
    for (const cur of SUPPORTED_CURRENCIES) {
      const key = cur.toLowerCase();
      if (raw[key] && raw[key] > 0) rates[cur] = 1 / raw[key];
    }
    localStorage.setItem(RATES_CACHE_KEY, JSON.stringify({ rates, ts: Date.now() }));
    return rates;
  } catch {
    return FALLBACK_RATES_TO_AED;
  }
}

/** Convert amount from one currency to another using provided rates-to-AED map */
export function convertCurrency(
  amount: number,
  from: string,
  to: string,
  rates: ExchangeRates = FALLBACK_RATES_TO_AED
): number {
  if (from === to) return amount;
  const toAED = rates[from] ?? FALLBACK_RATES_TO_AED[from] ?? 1;
  const fromAED = rates[to] ?? FALLBACK_RATES_TO_AED[to] ?? 1;
  return (amount * toAED) / fromAED;
}

export function convertToAED(amount: number, from: string, rates: ExchangeRates = FALLBACK_RATES_TO_AED): number {
  return convertCurrency(amount, from, 'AED', rates);
}

export function getCurrencySymbol(currency: string): string {
  return CURRENCY_SYMBOLS[currency] ?? currency;
}

export function formatCurrency(amount: number, currency = DEFAULT_CURRENCY): string {
  const absAmt = Math.abs(amount);
  const formatted = absAmt.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const prefix = amount < 0 ? '-' : '';
  return `${prefix}${currency} ${formatted}`;
}

export function formatAED(amount: number): string {
  return formatCurrency(amount, 'AED');
}
