import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type MRItem = {
  description: string;
  specification?: string;
  proposed_make?: string;
  country_of_origin?: string;
  quantity: number;
  unit: string;
  unit_cost?: number;
};

export type Database = {
  public: {
    Tables: {
      team_members: {
        Row: {
          id: string;
          user_id: string | null;
          name: string;
          email: string;
          role: string;
          department: string;
          is_active: boolean;
          is_admin: boolean;
          is_procurement_lead: boolean;
          is_material_coordinator: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id?: string | null;
          name: string;
          email: string;
          role?: string;
          department?: string;
          is_active?: boolean;
          is_admin?: boolean;
          is_procurement_lead?: boolean;
          is_material_coordinator?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string | null;
          name?: string;
          email?: string;
          role?: string;
          department?: string;
          is_active?: boolean;
          is_admin?: boolean;
          is_procurement_lead?: boolean;
          is_material_coordinator?: boolean;
          created_at?: string;
        };
      };
      projects: {
        Row: {
          id: string;
          name: string;
          description: string | null;
          status: 'planning' | 'active' | 'on-hold' | 'completed' | 'cancelled';
          start_date: string;
          end_date: string | null;
          priority: 'low' | 'medium' | 'high' | 'critical';
          budget: number | null;
          created_by: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          description?: string | null;
          status?: 'planning' | 'active' | 'on-hold' | 'completed' | 'cancelled';
          start_date?: string;
          end_date?: string | null;
          priority?: 'low' | 'medium' | 'high' | 'critical';
          budget?: number | null;
          created_by: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          description?: string | null;
          status?: 'planning' | 'active' | 'on-hold' | 'completed' | 'cancelled';
          start_date?: string;
          end_date?: string | null;
          priority?: 'low' | 'medium' | 'high' | 'critical';
          budget?: number | null;
          created_by?: string;
          created_at?: string;
        };
      };
      project_members: {
        Row: {
          id: string;
          project_id: string;
          team_member_id: string;
          role_in_project: string;
          joined_at: string;
        };
        Insert: {
          id?: string;
          project_id: string;
          team_member_id: string;
          role_in_project?: string;
          joined_at?: string;
        };
        Update: {
          id?: string;
          project_id?: string;
          team_member_id?: string;
          role_in_project?: string;
          joined_at?: string;
        };
      };
      tasks: {
        Row: {
          id: string;
          project_id: string | null;
          assigned_to: string | null;
          title: string;
          description: string | null;
          task_type: 'task' | 'document' | 'milestone' | 'review' | 'procurement';
          status: 'pending' | 'in-progress' | 'review' | 'completed' | 'cancelled';
          priority: 'low' | 'medium' | 'high' | 'critical';
          due_date: string;
          completed_date: string | null;
          document_name: string | null;
          notes: string | null;
          created_by: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          project_id?: string | null;
          assigned_to?: string | null;
          title: string;
          description?: string | null;
          task_type?: 'task' | 'document' | 'milestone' | 'review' | 'procurement';
          status?: 'pending' | 'in-progress' | 'review' | 'completed' | 'cancelled';
          priority?: 'low' | 'medium' | 'high' | 'critical';
          due_date: string;
          completed_date?: string | null;
          document_name?: string | null;
          notes?: string | null;
          created_by?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          project_id?: string | null;
          assigned_to?: string | null;
          title?: string;
          description?: string | null;
          task_type?: 'task' | 'document' | 'milestone' | 'review' | 'procurement';
          status?: 'pending' | 'in-progress' | 'review' | 'completed' | 'cancelled';
          priority?: 'low' | 'medium' | 'high' | 'critical';
          due_date?: string;
          completed_date?: string | null;
          document_name?: string | null;
          notes?: string | null;
          created_by?: string | null;
          created_at?: string;
        };
      };
      material_requisitions: {
        Row: {
          id: string;
          requisition_number: string;
          created_by: string;
          project_id: string | null;
          title: string;
          purpose: string | null;
          preferred_supplier: string | null;
          items: MRItem[];
          status: 'created' | 'assigned' | 'in_progress' | 'po_released' | 'closed';
          assigned_to: string | null;
          task_id: string | null;
          notes: string | null;
          po_number: string | null;
          po_vendor: string | null;
          po_date: string | null;
          po_amount: number | null;
          po_vendor_contact_name: string | null;
          po_vendor_contact_number: string | null;
          po_vendor_location: string | null;
          delivery_status: 'assigned' | 'in_transit' | 'delivered' | null;
          material_coordinator_id: string | null;
          delivery_date: string | null;
          delivery_remarks: string | null;
          delivery_updated_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          requisition_number: string;
          created_by: string;
          project_id?: string | null;
          title: string;
          purpose?: string | null;
          preferred_supplier?: string | null;
          items?: MRItem[];
          status?: 'created' | 'assigned' | 'in_progress' | 'po_released' | 'closed';
          assigned_to?: string | null;
          task_id?: string | null;
          notes?: string | null;
          po_number?: string | null;
          po_vendor?: string | null;
          po_date?: string | null;
          po_amount?: number | null;
          po_vendor_contact_name?: string | null;
          po_vendor_contact_number?: string | null;
          po_vendor_location?: string | null;
          delivery_status?: 'assigned' | 'in_transit' | 'delivered' | null;
          material_coordinator_id?: string | null;
          delivery_date?: string | null;
          delivery_remarks?: string | null;
          delivery_updated_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          requisition_number?: string;
          created_by?: string;
          project_id?: string | null;
          title?: string;
          purpose?: string | null;
          preferred_supplier?: string | null;
          items?: MRItem[];
          status?: 'created' | 'assigned' | 'in_progress' | 'po_released' | 'closed';
          assigned_to?: string | null;
          task_id?: string | null;
          notes?: string | null;
          po_number?: string | null;
          po_vendor?: string | null;
          po_date?: string | null;
          po_amount?: number | null;
          po_vendor_contact_name?: string | null;
          po_vendor_contact_number?: string | null;
          po_vendor_location?: string | null;
          delivery_status?: 'assigned' | 'in_transit' | 'delivered' | null;
          material_coordinator_id?: string | null;
          delivery_date?: string | null;
          delivery_remarks?: string | null;
          delivery_updated_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
};
