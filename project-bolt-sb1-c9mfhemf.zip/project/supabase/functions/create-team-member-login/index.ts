import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return json({ error: 'Unauthorized' }, 401);
    }

    // Verify the caller is an authenticated admin
    const anonClient = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await anonClient.auth.getUser();
    if (authError || !user) return json({ error: 'Unauthorized' }, 401);

    const { data: caller } = await anonClient
      .from('team_members')
      .select('is_admin')
      .eq('user_id', user.id)
      .maybeSingle();

    if (!caller?.is_admin) return json({ error: 'Forbidden: admin only' }, 403);

    const body = await req.json();
    const { email, password, team_member_id } = body;

    if (!email || !password || !team_member_id) {
      return json({ error: 'email, password, and team_member_id are required' }, 400);
    }
    if (password.length < 6) {
      return json({ error: 'Password must be at least 6 characters' }, 400);
    }

    // Use service-role client for privileged operations
    const adminClient = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // Call the SQL function which does a reliable upsert directly into auth.users
    const { data: userId, error: rpcError } = await adminClient.rpc('upsert_auth_user', {
      p_email: email,
      p_password: password,
    });

    if (rpcError) {
      return json({ error: rpcError.message }, 500);
    }

    // Link the team_member row to the auth user id
    const { error: linkError } = await adminClient
      .from('team_members')
      .update({ user_id: userId })
      .eq('id', team_member_id);

    if (linkError) {
      return json({ error: `Linked failed: ${linkError.message}` }, 500);
    }

    return json({ success: true, user_id: userId });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return json({ error: message }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}
