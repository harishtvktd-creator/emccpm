import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const resendApiKey = Deno.env.get("RESEND_API_KEY");

    const supabase = createClient(supabaseUrl, serviceRoleKey);

    // Load settings
    const { data: settings } = await supabase
      .from("email_reminder_settings")
      .select("*")
      .maybeSingle();

    if (!settings?.enabled) {
      return new Response(
        JSON.stringify({ message: "Email reminders are disabled" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!resendApiKey) {
      return new Response(
        JSON.stringify({ error: "RESEND_API_KEY secret is not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const today = new Date().toISOString().split("T")[0];

    // Build query for active team members
    let membersQuery = supabase
      .from("team_members")
      .select("id, name, email")
      .eq("is_active", true)
      .not("email", "is", null);

    // Filter to included members if a non-empty list is configured
    const includedIds: string[] = settings.included_member_ids ?? [];
    if (includedIds.length > 0) {
      membersQuery = membersQuery.in("id", includedIds);
    }

    const { data: members, error: membersError } = await membersQuery;

    if (membersError) throw membersError;
    if (!members || members.length === 0) {
      return new Response(
        JSON.stringify({ message: "No eligible team members found" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const results: { member: string; status: string; taskCount?: number; error?: string }[] = [];

    for (const member of members) {
      if (!member.email) continue;

      const { data: tasks } = await supabase
        .from("tasks")
        .select("*, projects(name)")
        .eq("assigned_to", member.id)
        .not("status", "in", '("completed","cancelled")')
        .lte("due_date", today)
        .order("due_date", { ascending: true });

      if (!tasks || tasks.length === 0) continue;

      const todayTasks = tasks.filter((t: { due_date: string }) => t.due_date === today);
      const overdueTasks = tasks.filter((t: { due_date: string }) => t.due_date < today);

      const senderName = settings.sender_name || "EMCC Projects Division";
      const senderEmail = (settings.sender_email as string | undefined)?.trim() || "onboarding@resend.dev";
      const replyTo = settings.reply_to || undefined;

      const html = buildEmailHtml(member.name, todayTasks, overdueTasks, today);

      const emailPayload: Record<string, unknown> = {
        from: `${senderName} <${senderEmail}>`,
        to: [member.email],
        subject: `Task Reminder – ${formatDate(today)} | ${tasks.length} task${tasks.length !== 1 ? "s" : ""} need your attention`,
        html,
      };
      if (replyTo) emailPayload.reply_to = replyTo;

      const emailRes = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${resendApiKey}`,
        },
        body: JSON.stringify(emailPayload),
      });

      if (emailRes.ok) {
        results.push({ member: member.name, status: "sent", taskCount: tasks.length });
      } else {
        const err = await emailRes.text();
        results.push({ member: member.name, status: "failed", error: err });
      }
    }

    return new Response(
      JSON.stringify({ success: true, date: today, results }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("send-task-reminders error:", err);
    return new Response(
      JSON.stringify({ error: String(err) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

function formatDate(d: string) {
  const [y, m, day] = d.split("-");
  return `${day}/${m}/${y}`;
}

function priorityColor(p: string) {
  if (p === "critical") return "#dc2626";
  if (p === "high") return "#ea580c";
  if (p === "medium") return "#ca8a04";
  return "#6b7280";
}

function buildEmailHtml(
  name: string,
  todayTasks: Record<string, unknown>[],
  overdueTasks: Record<string, unknown>[],
  today: string
) {
  const taskRow = (task: Record<string, unknown>) => {
    const due = task.due_date as string;
    const daysOver = Math.floor((Date.now() - new Date(due + "T00:00:00").getTime()) / 86400000);
    const isOverdue = due < today;
    const project = (task.projects as { name: string } | null)?.name ?? "—";
    const title = (task.document_name as string) || (task.title as string);
    const priority = task.priority as string;
    const rawStatus = task.status as string;
    const status = rawStatus === "in-progress" ? "In Progress" : rawStatus.charAt(0).toUpperCase() + rawStatus.slice(1);
    return `
      <tr style="border-bottom:1px solid #f1f5f9;">
        <td style="padding:10px 12px;font-size:13px;color:#1e293b;max-width:220px;">${title}</td>
        <td style="padding:10px 12px;font-size:13px;color:#64748b;">${project}</td>
        <td style="padding:10px 12px;font-size:13px;color:${isOverdue ? "#dc2626" : "#374151"};font-weight:${isOverdue ? "600" : "400"};">
          ${formatDate(due)}${isOverdue ? `<br><span style="font-size:11px;color:#ef4444;">${daysOver}d overdue</span>` : ""}
        </td>
        <td style="padding:10px 12px;font-size:12px;color:${priorityColor(priority)};font-weight:600;text-transform:capitalize;">${priority}</td>
        <td style="padding:10px 12px;font-size:12px;color:#475569;">${status}</td>
      </tr>`;
  };

  const section = (title: string, color: string, tasks: Record<string, unknown>[]) =>
    tasks.length === 0
      ? ""
      : `
    <div style="margin-bottom:28px;">
      <h3 style="margin:0 0 12px;font-size:14px;font-weight:700;color:${color};text-transform:uppercase;letter-spacing:.05em;">${title} (${tasks.length})</h3>
      <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden;border:1px solid #e2e8f0;">
        <thead>
          <tr style="background:#f8fafc;">
            <th style="padding:10px 12px;text-align:left;font-size:11px;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:.05em;">Task</th>
            <th style="padding:10px 12px;text-align:left;font-size:11px;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:.05em;">Project</th>
            <th style="padding:10px 12px;text-align:left;font-size:11px;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:.05em;">Due Date</th>
            <th style="padding:10px 12px;text-align:left;font-size:11px;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:.05em;">Priority</th>
            <th style="padding:10px 12px;text-align:left;font-size:11px;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:.05em;">Status</th>
          </tr>
        </thead>
        <tbody>${tasks.map(taskRow).join("")}</tbody>
      </table>
    </div>`;

  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:32px 16px;">
    <tr><td>
      <table width="100%" cellpadding="0" cellspacing="0" style="max-width:620px;margin:0 auto;">
        <tr>
          <td style="background:linear-gradient(135deg,#0d9488,#2563eb);padding:28px 32px;border-radius:12px 12px 0 0;">
            <h1 style="margin:0;font-size:20px;font-weight:700;color:#fff;">EMCC Projects Division</h1>
            <p style="margin:4px 0 0;font-size:13px;color:#ccfbf1;opacity:.9;">Daily Task Reminder · ${formatDate(today)}</p>
          </td>
        </tr>
        <tr>
          <td style="background:#fff;padding:28px 32px;border-radius:0 0 12px 12px;border:1px solid #e2e8f0;border-top:none;">
            <p style="margin:0 0 20px;font-size:15px;color:#1e293b;">Hi <strong>${name}</strong>,</p>
            <p style="margin:0 0 24px;font-size:14px;color:#475569;line-height:1.6;">
              Here's your task summary for today. Please review your pending and overdue items.
            </p>
            ${section("Overdue Tasks", "#dc2626", overdueTasks)}
            ${section("Due Today", "#0d9488", todayTasks)}
            <p style="margin:24px 0 0;font-size:13px;color:#94a3b8;border-top:1px solid #f1f5f9;padding-top:16px;">
              This is an automated reminder from EMCC Projects Division. Log in to your portal to update task statuses.
            </p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}
