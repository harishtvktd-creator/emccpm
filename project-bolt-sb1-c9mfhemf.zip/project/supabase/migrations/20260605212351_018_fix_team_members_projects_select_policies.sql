-- Allow all authenticated users to view all team members
-- (needed for procurement lead auto-assign, MR assignment dropdowns, etc.)
CREATE POLICY "All authenticated users can view team members"
  ON team_members FOR SELECT
  TO authenticated
  USING (true);

-- Allow all authenticated users to view all projects
-- (needed for project selection in New MR form, tasks, etc.)
CREATE POLICY "All authenticated users can view projects"
  ON projects FOR SELECT
  TO authenticated
  USING (true);
