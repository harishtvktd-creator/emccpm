/*
  # Family Expense Forecast Schema

  1. New Tables
    - `categories`
      - `id` (uuid, primary key) - Unique identifier
      - `user_id` (uuid, references auth.users) - Owner of the category
      - `name` (text) - Category name (e.g., "Groceries", "Salary")
      - `type` (text) - Either 'income' or 'expense'
      - `color` (text) - Hex color code for UI display
      - `icon` (text) - Icon identifier
      - `created_at` (timestamptz) - Creation timestamp
    
    - `transactions`
      - `id` (uuid, primary key) - Unique identifier
      - `user_id` (uuid, references auth.users) - Owner of the transaction
      - `category_id` (uuid, references categories) - Category this belongs to
      - `amount` (numeric) - Transaction amount (positive for income, positive for expense; direction determined by category type)
      - `description` (text) - Optional description
      - `date` (date) - Transaction date
      - `is_recurring` (boolean) - Whether this is a recurring transaction
      - `recurrence_frequency` (text) - 'daily', 'weekly', 'monthly', 'yearly', or null
      - `created_at` (timestamptz) - Creation timestamp
    
    - `planned_budgets`
      - `id` (uuid, primary key) - Unique identifier
      - `user_id` (uuid, references auth.users) - Owner of the budget
      - `category_id` (uuid, references categories) - Category this applies to
      - `amount` (numeric) - Planned amount
      - `month` (integer) - Month (1-12) for monthly budgets, null for yearly
      - `year` (integer) - Year for the budget
      - `created_at` (timestamptz) - Creation timestamp
    
    - `opening_balances`
      - `id` (uuid, primary key) - Unique identifier
      - `user_id` (uuid, references auth.users) - Owner
      - `balance` (numeric) - Opening cash balance
      - `date` (date) - Date this balance is effective from
      - `created_at` (timestamptz) - Creation timestamp

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage only their own data
    - All operations require ownership verification via auth.uid()

  3. Important Notes
    - All tables use auth.uid() for ownership tracking
    - Cascade delete on user_id foreign keys for data integrity
    - Categories are user-specific for personalized budgeting
    - Transactions can be recurring for automated forecasting
*/

-- Create categories table
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('income', 'expense')),
  color text DEFAULT '#3B82F6',
  icon text DEFAULT 'Wallet',
  created_at timestamptz DEFAULT now()
);

-- Create transactions table
CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  category_id uuid NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  amount numeric NOT NULL CHECK (amount >= 0),
  description text DEFAULT '',
  date date NOT NULL DEFAULT CURRENT_DATE,
  is_recurring boolean DEFAULT false,
  recurrence_frequency text CHECK (recurrence_frequency IN ('daily', 'weekly', 'monthly', 'yearly')),
  created_at timestamptz DEFAULT now()
);

-- Create planned_budgets table
CREATE TABLE IF NOT EXISTS planned_budgets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  category_id uuid NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  amount numeric NOT NULL CHECK (amount >= 0),
  month integer CHECK (month >= 1 AND month <= 12),
  year integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE (user_id, category_id, month, year)
);

-- Create opening_balances table
CREATE TABLE IF NOT EXISTS opening_balances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  balance numeric NOT NULL DEFAULT 0,
  date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE planned_budgets ENABLE ROW LEVEL SECURITY;
ALTER TABLE opening_balances ENABLE ROW LEVEL SECURITY;

-- Categories policies
CREATE POLICY "Users can view own categories"
  ON categories FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own categories"
  ON categories FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own categories"
  ON categories FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own categories"
  ON categories FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Transactions policies
CREATE POLICY "Users can view own transactions"
  ON transactions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own transactions"
  ON transactions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own transactions"
  ON transactions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own transactions"
  ON transactions FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Planned budgets policies
CREATE POLICY "Users can view own planned budgets"
  ON planned_budgets FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own planned budgets"
  ON planned_budgets FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own planned budgets"
  ON planned_budgets FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own planned budgets"
  ON planned_budgets FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Opening balances policies
CREATE POLICY "Users can view own opening balances"
  ON opening_balances FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own opening balances"
  ON opening_balances FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own opening balances"
  ON opening_balances FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own opening balances"
  ON opening_balances FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_transactions_user_date ON transactions(user_id, date);
CREATE INDEX IF NOT EXISTS idx_transactions_user_category ON transactions(user_id, category_id);
CREATE INDEX IF NOT EXISTS idx_categories_user_type ON categories(user_id, type);
CREATE INDEX IF NOT EXISTS idx_planned_budgets_user_year_month ON planned_budgets(user_id, year, month);
CREATE INDEX IF NOT EXISTS idx_opening_balances_user_date ON opening_balances(user_id, date);