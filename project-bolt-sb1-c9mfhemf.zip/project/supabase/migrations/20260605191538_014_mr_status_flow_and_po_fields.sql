/*
  # Procurement MR status flow + PO fields (fixed order)

  Drop old constraint first, then migrate rows, then add new constraint.
*/

-- ── 1. Drop old constraint first ─────────────────────────────
ALTER TABLE material_requisitions
  DROP CONSTRAINT IF EXISTS material_requisitions_status_check;

-- ── 2. Migrate existing rows to new status values ─────────────
UPDATE material_requisitions SET status = 'created'     WHERE status IN ('pending','under_review');
UPDATE material_requisitions SET status = 'po_released' WHERE status = 'approved';
UPDATE material_requisitions SET status = 'closed'      WHERE status IN ('ordered','rejected');

-- ── 3. Update default and add new constraint ──────────────────
ALTER TABLE material_requisitions
  ALTER COLUMN status SET DEFAULT 'created';

ALTER TABLE material_requisitions
  ADD CONSTRAINT material_requisitions_status_check
  CHECK (status IN ('created','assigned','in_progress','po_released','closed'));

-- ── 4. Add PO fields ──────────────────────────────────────────
ALTER TABLE material_requisitions
  ADD COLUMN IF NOT EXISTS po_number  text,
  ADD COLUMN IF NOT EXISTS po_vendor  text,
  ADD COLUMN IF NOT EXISTS po_date    date,
  ADD COLUMN IF NOT EXISTS po_amount  numeric(12,2);
