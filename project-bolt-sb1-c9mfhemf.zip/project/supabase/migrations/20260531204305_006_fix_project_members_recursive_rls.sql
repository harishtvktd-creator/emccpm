/*
  # Fix infinite recursion in project_members RLS policies

  The SELECT policy on project_members referenced project_members itself
  (via a self-join alias pm2) causing infinite recursion. All policies
  are dropped and replaced with simple, non-recursive versions.

  Changes:
  - Drop all existing project_members policies
  - Add simple SELECT policy: authenticated users can view all project_members
    (projects are already protected by their own RLS)
  - Keep INSERT/UPDATE/DELETE restricted to the project creator
*/

DROP POLICY IF EXISTS "Users can view project members for accessible projects" ON project_members;
DROP POLICY IF EXISTS "Project creators can insert project members" ON project_members;
DROP POLICY IF EXISTS "Project creators can update project members" ON project_members;
DROP POLICY IF EXISTS "Project creators can delete project members" ON project_members;

-- Simple non-recursive SELECT: any authenticated user can read project_members
-- (the projects table RLS already controls which projects are visible)
CREATE POLICY "Authenticated users can view project members"
  ON project_members FOR SELECT
  TO authenticated
  USING (true);

-- Only the project creator can add/update/remove members
CREATE POLICY "Project creators can insert project members"
  ON project_members FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = project_members.project_id
        AND projects.created_by = auth.uid()
    )
  );

CREATE POLICY "Project creators can update project members"
  ON project_members FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = project_members.project_id
        AND projects.created_by = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = project_members.project_id
        AND projects.created_by = auth.uid()
    )
  );

CREATE POLICY "Project creators can delete project members"
  ON project_members FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = project_members.project_id
        AND projects.created_by = auth.uid()
    )
  );
