-- Store the password set by admin for team member logins (admin record-keeping only)
ALTER TABLE team_members ADD COLUMN IF NOT EXISTS login_password_hint TEXT;
