
-- Track which project+date allocations have been "posted" (finalized)
CREATE TABLE IF NOT EXISTS posted_allocations (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id     uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  entry_date     date NOT NULL,
  posted_at      timestamptz NOT NULL DEFAULT now(),
  posted_by      uuid REFERENCES team_members(id),
  posted_by_name text,
  notes          text,
  UNIQUE (project_id, entry_date)
);

ALTER TABLE posted_allocations ENABLE ROW LEVEL SECURITY;

-- Everyone on the project can read posted state
CREATE POLICY "select_posted_allocations" ON posted_allocations FOR SELECT
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM project_members pm
      WHERE pm.project_id = posted_allocations.project_id
        AND pm.team_member_id IN (
          SELECT id FROM team_members WHERE user_id = auth.uid()
        )
    )
    OR EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
  );

-- Only admins can insert (post)
CREATE POLICY "insert_posted_allocations" ON posted_allocations FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
  );

-- Only admins can delete (unpost)
CREATE POLICY "delete_posted_allocations" ON posted_allocations FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
  );

-- Index for fast lookup
CREATE INDEX IF NOT EXISTS idx_posted_allocations_project_date
  ON posted_allocations (project_id, entry_date);
