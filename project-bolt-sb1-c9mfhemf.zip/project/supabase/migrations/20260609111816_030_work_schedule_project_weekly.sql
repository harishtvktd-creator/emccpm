-- Per-project weekly schedule (day-of-week granularity per project)
CREATE TABLE work_schedule_project_weekly (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  day_of_week smallint NOT NULL CHECK (day_of_week >= 0 AND day_of_week <= 6),
  normal_hours numeric(4,2) NOT NULL DEFAULT 9 CHECK (normal_hours >= 0 AND normal_hours <= 24),
  is_working_day boolean NOT NULL DEFAULT true,
  updated_at timestamptz DEFAULT now(),
  UNIQUE (project_id, day_of_week)
);

ALTER TABLE work_schedule_project_weekly ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_project_weekly" ON work_schedule_project_weekly
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "insert_project_weekly" ON work_schedule_project_weekly
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM team_members tm WHERE tm.user_id = auth.uid() AND tm.role = 'admin')
  );

CREATE POLICY "update_project_weekly" ON work_schedule_project_weekly
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM team_members tm WHERE tm.user_id = auth.uid() AND tm.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM team_members tm WHERE tm.user_id = auth.uid() AND tm.role = 'admin'));

CREATE POLICY "delete_project_weekly" ON work_schedule_project_weekly
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM team_members tm WHERE tm.user_id = auth.uid() AND tm.role = 'admin'));

-- Drop old single-value project override table (superseded by per-day project schedule)
DROP TABLE IF EXISTS work_schedule_project_overrides;
