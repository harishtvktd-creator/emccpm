-- Work schedule: configurable normal working hours per day of week
-- day_of_week: 0=Sunday, 1=Monday, ..., 6=Saturday
-- normal_hours: how many hours are "regular" for that day (e.g. 8 for weekdays, 0 for Friday/rest)

CREATE TABLE IF NOT EXISTS work_schedule (
  day_of_week   smallint  PRIMARY KEY CHECK (day_of_week BETWEEN 0 AND 6),
  normal_hours  numeric(4,2) NOT NULL DEFAULT 0 CHECK (normal_hours >= 0 AND normal_hours <= 24),
  is_working_day boolean  NOT NULL DEFAULT true,
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- Seed with typical UAE construction schedule: Sat–Thu 9h, Fri 0h (rest)
INSERT INTO work_schedule (day_of_week, normal_hours, is_working_day) VALUES
  (0, 9, true),   -- Sunday
  (1, 9, true),   -- Monday
  (2, 9, true),   -- Tuesday
  (3, 9, true),   -- Wednesday
  (4, 9, true),   -- Thursday
  (5, 0, false),  -- Friday (rest)
  (6, 9, true)    -- Saturday
ON CONFLICT (day_of_week) DO NOTHING;

ALTER TABLE work_schedule ENABLE ROW LEVEL SECURITY;

-- Everyone can read (needed for allocation calculations)
CREATE POLICY "ws_select_authenticated" ON work_schedule
  FOR SELECT TO authenticated USING (true);

-- Only admins can update
CREATE POLICY "ws_update_admin" ON work_schedule
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true))
  WITH CHECK (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true));
