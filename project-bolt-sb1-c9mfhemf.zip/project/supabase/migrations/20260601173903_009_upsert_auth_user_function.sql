/*
  # Create admin SQL function: upsert_auth_user

  Creates a SECURITY DEFINER function that the edge function calls via RPC
  to create or update an auth user directly in auth.users — bypassing the
  Admin API which can fail with "Database error creating new user" on
  certain Supabase project configurations.

  The function:
  - Inserts a new auth.users row if email does not exist
  - Updates the encrypted_password if the user already exists
  - Returns the user id in both cases
  - Marks email as confirmed so the member can log in immediately
*/

CREATE OR REPLACE FUNCTION upsert_auth_user(
  p_email     text,
  p_password  text
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = auth, public, extensions
AS $$
DECLARE
  v_user_id   uuid;
  v_encrypted text;
BEGIN
  -- Encrypt the password using pgcrypto (already available in auth schema)
  v_encrypted := crypt(p_password, gen_salt('bf'));

  -- Check if user already exists
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = p_email;

  IF v_user_id IS NOT NULL THEN
    -- Update existing user's password
    UPDATE auth.users
    SET
      encrypted_password  = v_encrypted,
      updated_at          = now(),
      email_confirmed_at  = COALESCE(email_confirmed_at, now())
    WHERE id = v_user_id;
  ELSE
    -- Insert new user
    v_user_id := gen_random_uuid();

    INSERT INTO auth.users (
      id,
      instance_id,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      aud,
      role,
      created_at,
      updated_at,
      confirmation_token,
      recovery_token,
      email_change_token_new,
      email_change
    ) VALUES (
      v_user_id,
      '00000000-0000-0000-0000-000000000000',
      p_email,
      v_encrypted,
      now(),
      '{"provider":"email","providers":["email"]}'::jsonb,
      '{}'::jsonb,
      'authenticated',
      'authenticated',
      now(),
      now(),
      '',
      '',
      '',
      ''
    );
  END IF;

  RETURN v_user_id;
END;
$$;

-- Only service role (used by edge function) can call this
REVOKE ALL ON FUNCTION upsert_auth_user(text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION upsert_auth_user(text, text) TO service_role;
