ALTER TABLE material_requisitions
  ADD COLUMN IF NOT EXISTS po_vendor_contact_name   text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS po_vendor_contact_number text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS po_vendor_location       text DEFAULT NULL;
