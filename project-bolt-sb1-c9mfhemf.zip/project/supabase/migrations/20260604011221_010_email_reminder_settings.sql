/*
  # Email Reminder Settings

  1. New Tables
    - `email_reminder_settings`
      - `id` (uuid, primary key)
      - `enabled` (boolean) — master on/off switch for daily reminders
      - `sender_name` (text) — display name for the from address
      - `reply_to` (text) — reply-to email address
      - `send_time` (text) — HH:MM in UTC, default '04:30' = 8:30 AM GST (UTC+4)
      - `created_at` / `updated_at` timestamps
  
  2. Security
    - Enable RLS
    - Only authenticated (admin) users can read/write this single-row config
  
  3. Initial row
    - Insert a default disabled row so the UI always has something to load
  
  4. pg_cron schedule
    - Enable pg_cron extension
    - Schedule the edge function call at 04:30 UTC daily (8:30 AM GST/UAE)
*/

-- Enable pg_cron extension
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Create settings table
CREATE TABLE IF NOT EXISTS email_reminder_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  enabled boolean NOT NULL DEFAULT false,
  sender_name text NOT NULL DEFAULT 'EMCC Projects Division',
  reply_to text NOT NULL DEFAULT '',
  send_time text NOT NULL DEFAULT '04:30',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE email_reminder_settings ENABLE ROW LEVEL SECURITY;

-- Only authenticated users can view settings
CREATE POLICY "Authenticated users can view email settings"
  ON email_reminder_settings
  FOR SELECT
  TO authenticated
  USING (true);

-- Only authenticated users can update settings
CREATE POLICY "Authenticated users can update email settings"
  ON email_reminder_settings
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Insert default row if none exists
INSERT INTO email_reminder_settings (enabled)
SELECT false
WHERE NOT EXISTS (SELECT 1 FROM email_reminder_settings);

-- updated_at trigger
CREATE OR REPLACE FUNCTION update_email_reminder_settings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS email_reminder_settings_updated_at ON email_reminder_settings;
CREATE TRIGGER email_reminder_settings_updated_at
  BEFORE UPDATE ON email_reminder_settings
  FOR EACH ROW EXECUTE FUNCTION update_email_reminder_settings_updated_at();

-- Schedule the reminder edge function at 04:30 UTC every day (8:30 AM GST)
-- Uses pg_cron to invoke the Supabase edge function via HTTP
SELECT cron.schedule(
  'daily-task-reminders',
  '30 4 * * *',
  $$
    SELECT net.http_post(
      url := current_setting('app.supabase_url') || '/functions/v1/send-task-reminders',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer ' || current_setting('app.service_role_key')
      ),
      body := '{}'::jsonb
    ) AS request_id;
  $$
);
