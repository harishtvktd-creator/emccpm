
-- ── Accounts Invoices ─────────────────────────────────────────────────────────

CREATE TABLE accounts_invoices (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID        REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  project_id        UUID        REFERENCES projects(id) ON DELETE SET NULL,
  type              TEXT        NOT NULL DEFAULT 'invoice' CHECK (type IN ('invoice', 'credit_note')),
  invoice_number    TEXT        NOT NULL,
  client_name       TEXT,
  issue_date        DATE        NOT NULL DEFAULT CURRENT_DATE,
  due_date          DATE,
  currency          TEXT        NOT NULL DEFAULT 'AED',
  subtotal          NUMERIC(14,2) NOT NULL DEFAULT 0,
  tax_rate          NUMERIC(5,2)  NOT NULL DEFAULT 5,
  tax_amount        NUMERIC(14,2) NOT NULL DEFAULT 0,
  total             NUMERIC(14,2) NOT NULL DEFAULT 0,
  paid_amount       NUMERIC(14,2) NOT NULL DEFAULT 0,
  status            TEXT        NOT NULL DEFAULT 'draft'
                    CHECK (status IN ('draft','sent','partial','paid','overdue','cancelled')),
  notes             TEXT,
  linked_invoice_id UUID        REFERENCES accounts_invoices(id) ON DELETE SET NULL,
  created_at        TIMESTAMPTZ DEFAULT NOW(),
  updated_at        TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX accounts_invoices_project_idx  ON accounts_invoices(project_id);
CREATE INDEX accounts_invoices_user_idx     ON accounts_invoices(user_id);
CREATE INDEX accounts_invoices_status_idx   ON accounts_invoices(status);
CREATE INDEX accounts_invoices_type_idx     ON accounts_invoices(type);

ALTER TABLE accounts_invoices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_invoices" ON accounts_invoices FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_invoices" ON accounts_invoices FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_invoices" ON accounts_invoices FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_invoices" ON accounts_invoices FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ── Invoice Line Items ────────────────────────────────────────────────────────

CREATE TABLE accounts_invoice_items (
  id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id    UUID        REFERENCES accounts_invoices(id) ON DELETE CASCADE NOT NULL,
  description   TEXT        NOT NULL DEFAULT '',
  quantity      NUMERIC(10,3) NOT NULL DEFAULT 1,
  unit_price    NUMERIC(14,2) NOT NULL DEFAULT 0,
  sort_order    INTEGER     NOT NULL DEFAULT 0,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE accounts_invoice_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_invoice_items" ON accounts_invoice_items FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM accounts_invoices i WHERE i.id = invoice_id AND i.user_id = auth.uid())
  );
CREATE POLICY "insert_invoice_items" ON accounts_invoice_items FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM accounts_invoices i WHERE i.id = invoice_id AND i.user_id = auth.uid())
  );
CREATE POLICY "update_invoice_items" ON accounts_invoice_items FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM accounts_invoices i WHERE i.id = invoice_id AND i.user_id = auth.uid())
  );
CREATE POLICY "delete_invoice_items" ON accounts_invoice_items FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM accounts_invoices i WHERE i.id = invoice_id AND i.user_id = auth.uid())
  );

-- ── Payments ──────────────────────────────────────────────────────────────────

CREATE TABLE accounts_payments (
  id               UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id       UUID        REFERENCES accounts_invoices(id) ON DELETE CASCADE NOT NULL,
  user_id          UUID        REFERENCES auth.users(id) NOT NULL,
  payment_date     DATE        NOT NULL DEFAULT CURRENT_DATE,
  amount           NUMERIC(14,2) NOT NULL,
  currency         TEXT        NOT NULL DEFAULT 'AED',
  bank_account_id  UUID        REFERENCES bank_accounts(id) ON DELETE SET NULL,
  reference        TEXT,
  notes            TEXT,
  created_at       TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE accounts_payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_payments" ON accounts_payments FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_payments" ON accounts_payments FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_payments" ON accounts_payments FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_payments" ON accounts_payments FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ── Trigger: update paid_amount + status on invoices ──────────────────────────

CREATE OR REPLACE FUNCTION sync_invoice_paid_amount()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
  v_invoice_id UUID;
  v_total      NUMERIC;
  v_paid       NUMERIC;
  v_status     TEXT;
BEGIN
  v_invoice_id := COALESCE(NEW.invoice_id, OLD.invoice_id);

  SELECT total, COALESCE(SUM(p.amount), 0)
    INTO v_total, v_paid
    FROM accounts_invoices i
    LEFT JOIN accounts_payments p ON p.invoice_id = i.id
    WHERE i.id = v_invoice_id
    GROUP BY i.total;

  IF v_paid >= v_total THEN
    v_status := 'paid';
  ELSIF v_paid > 0 THEN
    v_status := 'partial';
  ELSE
    v_status := (SELECT CASE WHEN status IN ('draft','sent','partial') THEN status ELSE status END
                 FROM accounts_invoices WHERE id = v_invoice_id);
  END IF;

  UPDATE accounts_invoices
    SET paid_amount = v_paid,
        status      = CASE WHEN v_paid >= v_total THEN 'paid'
                           WHEN v_paid > 0        THEN 'partial'
                           ELSE status END,
        updated_at  = NOW()
    WHERE id = v_invoice_id;

  RETURN COALESCE(NEW, OLD);
END;
$$;

CREATE TRIGGER trg_sync_invoice_paid
  AFTER INSERT OR UPDATE OR DELETE ON accounts_payments
  FOR EACH ROW EXECUTE FUNCTION sync_invoice_paid_amount();

-- ── Auto-increment invoice number helper ─────────────────────────────────────

CREATE OR REPLACE FUNCTION next_invoice_number(p_type TEXT, p_user_id UUID)
RETURNS TEXT LANGUAGE plpgsql AS $$
DECLARE
  v_prefix TEXT;
  v_year   TEXT;
  v_seq    INTEGER;
BEGIN
  v_prefix := CASE p_type WHEN 'credit_note' THEN 'CN' ELSE 'INV' END;
  v_year   := TO_CHAR(NOW(), 'YYYY');
  SELECT COALESCE(MAX(
    NULLIF(REGEXP_REPLACE(invoice_number, '[^0-9]', '', 'g'), '')::INTEGER
  ), 0) + 1
    INTO v_seq
    FROM accounts_invoices
    WHERE user_id = p_user_id
      AND type = p_type
      AND invoice_number LIKE v_prefix || '-' || v_year || '-%';
  RETURN v_prefix || '-' || v_year || '-' || LPAD(v_seq::TEXT, 4, '0');
END;
$$;
