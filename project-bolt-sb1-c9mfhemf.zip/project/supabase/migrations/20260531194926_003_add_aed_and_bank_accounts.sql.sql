/*
  # Add AED Support and Multiple Bank Accounts

  1. Changes to Transactions Table
    - Add AED (UAE Dirham) to supported currencies
    - Add bank_account_id column to link transactions to specific accounts

  2. New Table: bank_accounts
    - Replaces the single opening_balance approach
    - Allows users to create multiple bank accounts
    - Each account has its own name, currency, and balance
    - Supports different account types (checking, savings, cash, credit)

  3. Bank Accounts Table Structure
    - `id` (uuid, primary key)
    - `user_id` (uuid, references auth.users)
    - `name` (text) - Account name (e.g., "Main Checking", "Savings Account")
    - `account_type` (text) - 'checking', 'savings', 'cash', 'credit'
    - `currency` (text) - Account currency
    - `balance` (numeric) - Current account balance
    - `is_default` (boolean) - Whether this is the default account
    - `created_at` (timestamptz)

  4. Security
    - Enable RLS on bank_accounts
    - Users can only access their own accounts
    - All CRUD operations require ownership verification

  5. Conversion Rates to AED (approximate)
    These are stored for reference but actual conversion should use real-time rates
*/

-- Add AED to transactions currency constraint
ALTER TABLE transactions 
DROP CONSTRAINT IF EXISTS transactions_currency_check;

ALTER TABLE transactions 
ADD CONSTRAINT transactions_currency_check 
CHECK (currency IN ('USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'CHF', 'CNY', 'INR', 'MXN', 'BRL', 'KRW', 'AED'));

-- Create bank_accounts table
CREATE TABLE IF NOT EXISTS bank_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  account_type text NOT NULL DEFAULT 'checking' CHECK (account_type IN ('checking', 'savings', 'cash', 'credit')),
  currency text NOT NULL DEFAULT 'AED' CHECK (currency IN ('USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'CHF', 'CNY', 'INR', 'MXN', 'BRL', 'KRW', 'AED')),
  balance numeric NOT NULL DEFAULT 0,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Add bank_account_id to transactions
ALTER TABLE transactions 
ADD COLUMN IF NOT EXISTS bank_account_id uuid REFERENCES bank_accounts(id) ON DELETE SET NULL;

-- Enable RLS on bank_accounts
ALTER TABLE bank_accounts ENABLE ROW LEVEL SECURITY;

-- Bank accounts policies
CREATE POLICY "Users can view own bank accounts"
  ON bank_accounts FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own bank accounts"
  ON bank_accounts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own bank accounts"
  ON bank_accounts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own bank accounts"
  ON bank_accounts FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_bank_accounts_user ON bank_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_bank_account ON transactions(bank_account_id);

-- Ensure only one default account per user
CREATE UNIQUE INDEX IF NOT EXISTS idx_bank_accounts_user_default 
ON bank_accounts(user_id) 
WHERE is_default = true;