/*
  # Add Currency Support to Transactions

  1. Changes
    - Add `currency` column to `transactions` table
      - Default value: 'USD'
      - NOT NULL constraint to ensure every transaction has a currency
    - Add check constraint for valid currency codes (ISO 4217 format)

  2. Supported Currencies
    - USD (US Dollar)
    - EUR (Euro)
    - GBP (British Pound)
    - JPY (Japanese Yen)
    - CAD (Canadian Dollar)
    - AUD (Australian Dollar)
    - CHF (Swiss Franc)
    - CNY (Chinese Yuan)
    - INR (Indian Rupee)
    - MXN (Mexican Peso)
    - BRL (Brazilian Real)
    - KRW (South Korean Won)

  3. Security
    - No changes to RLS policies
    - Currency is user-selectable per transaction
*/

ALTER TABLE transactions 
ADD COLUMN IF NOT EXISTS currency text NOT NULL DEFAULT 'USD';

ALTER TABLE transactions 
DROP CONSTRAINT IF EXISTS transactions_currency_check;

ALTER TABLE transactions 
ADD CONSTRAINT transactions_currency_check 
CHECK (currency IN ('USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'CHF', 'CNY', 'INR', 'MXN', 'BRL', 'KRW'));

CREATE INDEX IF NOT EXISTS idx_transactions_currency ON transactions(currency);