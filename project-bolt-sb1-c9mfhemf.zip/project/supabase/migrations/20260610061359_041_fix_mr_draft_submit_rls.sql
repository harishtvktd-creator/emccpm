-- Fix: Allow draft creator to promote their draft to 'created' (submit).
-- The old WITH CHECK required status = 'draft' on the NEW row, which blocked
-- the draft → created transition entirely for non-admin/non-lead members.

DROP POLICY IF EXISTS "mr_update_admin_or_lead_or_own_draft" ON material_requisitions;

CREATE POLICY "mr_update_admin_or_lead_or_own_draft" ON material_requisitions
  FOR UPDATE TO authenticated
  USING (
    -- Admins and procurement leads can update any MR
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND (is_admin = true OR is_procurement_lead = true))
    -- Any member can update their own draft
    OR (status = 'draft' AND created_by IN (SELECT id FROM team_members WHERE user_id = auth.uid()))
  )
  WITH CHECK (
    -- Admins and procurement leads can set any resulting status
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND (is_admin = true OR is_procurement_lead = true))
    -- Draft creator may keep draft OR promote to 'created' (submit); no further escalation
    OR (
      status IN ('draft', 'created')
      AND created_by IN (SELECT id FROM team_members WHERE user_id = auth.uid())
    )
  );
