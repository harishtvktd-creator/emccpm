-- Fix RLS policies: use is_admin = true (not role = 'admin')
DROP POLICY IF EXISTS "insert_project_weekly" ON work_schedule_project_weekly;
DROP POLICY IF EXISTS "update_project_weekly" ON work_schedule_project_weekly;
DROP POLICY IF EXISTS "delete_project_weekly" ON work_schedule_project_weekly;

CREATE POLICY "insert_project_weekly" ON work_schedule_project_weekly
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true));

CREATE POLICY "update_project_weekly" ON work_schedule_project_weekly
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true))
  WITH CHECK (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true));

CREATE POLICY "delete_project_weekly" ON work_schedule_project_weekly
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true));

-- Also fix the date_overrides policies from migration 029
DROP POLICY IF EXISTS "insert_date_overrides" ON work_schedule_date_overrides;
DROP POLICY IF EXISTS "update_date_overrides" ON work_schedule_date_overrides;
DROP POLICY IF EXISTS "delete_date_overrides" ON work_schedule_date_overrides;

CREATE POLICY "insert_date_overrides" ON work_schedule_date_overrides
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true));

CREATE POLICY "update_date_overrides" ON work_schedule_date_overrides
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true))
  WITH CHECK (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true));

CREATE POLICY "delete_date_overrides" ON work_schedule_date_overrides
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true));
