/*
  # Timesheet Module

  1. `timesheet_employees` — Employee Master (separate from team_members, for timesheet-specific staff records)
  2. `timesheet_entries`   — Monthly timesheet records (one row per employee per day)
*/

-- ── timesheet_employees ───────────────────────────────────────

CREATE TABLE IF NOT EXISTS timesheet_employees (
  id              uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
  employee_code   text        NOT NULL UNIQUE,
  name            text        NOT NULL,
  designation     text,
  department      text,
  project_id      uuid        REFERENCES projects(id),
  nationality     text,
  trade           text,
  employment_type text        NOT NULL DEFAULT 'staff'
                    CHECK (employment_type IN ('staff','labour','subcontractor')),
  basic_salary    numeric(12,2),
  joining_date    date,
  is_active       boolean     NOT NULL DEFAULT true,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION set_ts_employee_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS ts_employee_updated_at ON timesheet_employees;
CREATE TRIGGER ts_employee_updated_at
  BEFORE UPDATE ON timesheet_employees
  FOR EACH ROW EXECUTE FUNCTION set_ts_employee_updated_at();

ALTER TABLE timesheet_employees ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ts_emp_select" ON timesheet_employees
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "ts_emp_insert" ON timesheet_employees
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
  );

CREATE POLICY "ts_emp_update" ON timesheet_employees
  FOR UPDATE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
  );

CREATE POLICY "ts_emp_delete" ON timesheet_employees
  FOR DELETE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
  );

-- ── timesheet_entries ─────────────────────────────────────────

CREATE TABLE IF NOT EXISTS timesheet_entries (
  id              uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
  employee_id     uuid        NOT NULL REFERENCES timesheet_employees(id) ON DELETE CASCADE,
  work_date       date        NOT NULL,
  day_type        text        NOT NULL DEFAULT 'present'
                    CHECK (day_type IN ('present','absent','leave','holiday','rest','overtime')),
  regular_hours   numeric(4,2) NOT NULL DEFAULT 8,
  overtime_hours  numeric(4,2) NOT NULL DEFAULT 0,
  project_id      uuid        REFERENCES projects(id),
  work_description text,
  remarks         text,
  approved_by     uuid        REFERENCES team_members(id),
  approved_at     timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (employee_id, work_date)
);

CREATE OR REPLACE FUNCTION set_ts_entry_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS ts_entry_updated_at ON timesheet_entries;
CREATE TRIGGER ts_entry_updated_at
  BEFORE UPDATE ON timesheet_entries
  FOR EACH ROW EXECUTE FUNCTION set_ts_entry_updated_at();

ALTER TABLE timesheet_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ts_entry_select" ON timesheet_entries
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "ts_entry_insert" ON timesheet_entries
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
  );

CREATE POLICY "ts_entry_update" ON timesheet_entries
  FOR UPDATE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
  );

CREATE POLICY "ts_entry_delete" ON timesheet_entries
  FOR DELETE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
  );
