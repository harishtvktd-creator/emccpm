/*
  # Fix project_members RLS policies for INSERT

  The "Project creators can manage project members" policy used FOR ALL
  with only a USING clause and no WITH CHECK, causing INSERT operations
  to be silently rejected. This migration replaces it with explicit
  separate policies for INSERT, UPDATE, and DELETE that include proper
  WITH CHECK clauses.
*/

-- Drop the broken FOR ALL policy
DROP POLICY IF EXISTS "Project creators can manage project members" ON project_members;

-- Separate insert policy with WITH CHECK
CREATE POLICY "Project creators can insert project members"
  ON project_members FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = project_members.project_id
      AND projects.created_by = auth.uid()
    )
  );

-- Separate update policy
CREATE POLICY "Project creators can update project members"
  ON project_members FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = project_members.project_id
      AND projects.created_by = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = project_members.project_id
      AND projects.created_by = auth.uid()
    )
  );

-- Separate delete policy
CREATE POLICY "Project creators can delete project members"
  ON project_members FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = project_members.project_id
      AND projects.created_by = auth.uid()
    )
  );
