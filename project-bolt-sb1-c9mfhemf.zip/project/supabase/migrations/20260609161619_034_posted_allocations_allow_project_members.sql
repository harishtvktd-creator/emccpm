-- Allow project members (team leaders / site supervisors) to post allocations for today
-- Previously only admins could insert; now any authenticated project member can post for today.

DROP POLICY IF EXISTS "insert_posted_allocations" ON posted_allocations;

CREATE POLICY "insert_posted_allocations" ON posted_allocations FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
    OR (
      entry_date = CURRENT_DATE
      AND EXISTS (
        SELECT 1 FROM project_members pm
        JOIN team_members tm ON tm.id = pm.team_member_id
        WHERE tm.user_id = auth.uid() AND pm.project_id = posted_allocations.project_id
      )
    )
  );

-- Allow project members to unpost their own today entries
DROP POLICY IF EXISTS "delete_posted_allocations" ON posted_allocations;

CREATE POLICY "delete_posted_allocations" ON posted_allocations FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
    OR (
      entry_date = CURRENT_DATE
      AND EXISTS (
        SELECT 1 FROM project_members pm
        JOIN team_members tm ON tm.id = pm.team_member_id
        WHERE tm.user_id = auth.uid() AND pm.project_id = posted_allocations.project_id
      )
    )
  );
