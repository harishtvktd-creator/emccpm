-- Add confirmation tracking to posted_allocations
ALTER TABLE posted_allocations
  ADD COLUMN IF NOT EXISTS confirmed_at  timestamptz,
  ADD COLUMN IF NOT EXISTS confirmed_by  uuid REFERENCES team_members(id);

-- Add UPDATE policy so admin can confirm/unconfirm posted records
CREATE POLICY "update_posted_allocations" ON posted_allocations
  FOR UPDATE TO authenticated
  USING  (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true))
  WITH CHECK (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true));
