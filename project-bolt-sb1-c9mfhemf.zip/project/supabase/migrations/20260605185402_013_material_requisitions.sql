/*
  # Material Requisition System

  1. `team_members` — add is_procurement_lead flag
  2. `tasks` — make project_id nullable (procurement tasks may not belong to a project)
  3. `tasks` — extend task_type check to include 'procurement'
  4. `material_requisitions` — new table with RLS
*/

-- ── team_members ──────────────────────────────────────────────

ALTER TABLE team_members
  ADD COLUMN IF NOT EXISTS is_procurement_lead boolean NOT NULL DEFAULT false;

-- Ensure at most one procurement lead (partial unique index)
CREATE UNIQUE INDEX IF NOT EXISTS team_members_one_procurement_lead
  ON team_members (is_procurement_lead)
  WHERE is_procurement_lead = true;

-- ── tasks — make project_id nullable ─────────────────────────

ALTER TABLE tasks ALTER COLUMN project_id DROP NOT NULL;

-- Extend task_type enum (drop old constraint, add new one)
DO $$
BEGIN
  ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_task_type_check;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

ALTER TABLE tasks
  ADD CONSTRAINT tasks_task_type_check
  CHECK (task_type IN ('task', 'document', 'milestone', 'review', 'procurement'));

-- ── material_requisitions ─────────────────────────────────────

CREATE TABLE IF NOT EXISTS material_requisitions (
  id                  uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
  requisition_number  text        NOT NULL,
  created_by          uuid        NOT NULL REFERENCES team_members(id),
  project_id          uuid        REFERENCES projects(id),
  title               text        NOT NULL,
  purpose             text,
  items               jsonb       NOT NULL DEFAULT '[]',
  status              text        NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending','under_review','approved','rejected','ordered')),
  assigned_to         uuid        REFERENCES team_members(id),
  task_id             uuid,
  notes               text,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);

-- Updated-at trigger
CREATE OR REPLACE FUNCTION set_mr_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS mr_set_updated_at ON material_requisitions;
CREATE TRIGGER mr_set_updated_at
  BEFORE UPDATE ON material_requisitions
  FOR EACH ROW EXECUTE FUNCTION set_mr_updated_at();

-- RLS
ALTER TABLE material_requisitions ENABLE ROW LEVEL SECURITY;

-- All authenticated users can read all MRs (internal system)
CREATE POLICY "mr_select_authenticated" ON material_requisitions
  FOR SELECT TO authenticated USING (true);

-- A team member can insert an MR only for themselves
CREATE POLICY "mr_insert_own" ON material_requisitions
  FOR INSERT TO authenticated
  WITH CHECK (
    created_by IN (
      SELECT id FROM team_members WHERE user_id = auth.uid()
    )
  );

-- Only admins and the procurement lead can update status / notes
CREATE POLICY "mr_update_admin_or_lead" ON material_requisitions
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM team_members
      WHERE user_id = auth.uid()
        AND (is_admin = true OR is_procurement_lead = true)
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM team_members
      WHERE user_id = auth.uid()
        AND (is_admin = true OR is_procurement_lead = true)
    )
  );

-- Only admins can delete
CREATE POLICY "mr_delete_admin" ON material_requisitions
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM team_members
      WHERE user_id = auth.uid() AND is_admin = true
    )
  );
