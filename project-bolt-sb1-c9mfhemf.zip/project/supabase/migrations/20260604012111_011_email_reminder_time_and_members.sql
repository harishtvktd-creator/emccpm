/*
  # Email Reminder — Time Selection & Member Inclusion

  1. Changes to `email_reminder_settings`
    - Ensure `send_time` column exists (local UAE HH:MM, default '08:30')
    - Add `included_member_ids` uuid[] — empty = all active members

  2. pg_cron sync
    - Function `sync_reminder_cron()` converts local UAE time to UTC and
      reschedules 'daily-task-reminders' whenever send_time is updated

  3. Notes
    - UAE = UTC+4 (no DST)
*/

-- Ensure send_time column exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'email_reminder_settings' AND column_name = 'send_time'
  ) THEN
    ALTER TABLE email_reminder_settings ADD COLUMN send_time text NOT NULL DEFAULT '08:30';
  ELSE
    UPDATE email_reminder_settings SET send_time = '08:30' WHERE send_time = '04:30';
  END IF;
END $$;

-- Add included_member_ids column
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'email_reminder_settings' AND column_name = 'included_member_ids'
  ) THEN
    ALTER TABLE email_reminder_settings ADD COLUMN included_member_ids uuid[] NOT NULL DEFAULT '{}';
  END IF;
END $$;

-- Helper function to rebuild the cron job for a given local HH:MM time
CREATE OR REPLACE FUNCTION rebuild_reminder_cron(p_send_time text)
RETURNS void AS $func$
DECLARE
  local_hour int;
  local_min  int;
  utc_hour   int;
  cron_expr  text;
  job_cmd    text;
BEGIN
  local_hour := CAST(split_part(p_send_time, ':', 1) AS int);
  local_min  := CAST(split_part(p_send_time, ':', 2) AS int);
  utc_hour   := local_hour - 4;
  IF utc_hour < 0 THEN utc_hour := utc_hour + 24; END IF;
  cron_expr  := local_min || ' ' || utc_hour || ' * * *';

  job_cmd := 'SELECT net.http_post('
    || 'url := ''https://rxrkezmcehbwxzacqgvg.supabase.co/functions/v1/send-task-reminders'','
    || 'headers := ''{"Content-Type":"application/json","Authorization":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ4cmtlem1jZWhid3h6YWNxZ3ZnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODAyMzcyMzAsImV4cCI6MjA5NTgxMzIzMH0.7LQVrnVj_N4PdD0Kdu8qLw3Y1qVaJLaRMwVbWidrv6M"}''::jsonb,'
    || 'body := ''{}''::jsonb'
    || ') AS request_id;';

  PERFORM cron.unschedule('daily-task-reminders');
  PERFORM cron.schedule('daily-task-reminders', cron_expr, job_cmd);
END;
$func$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger function that calls the helper
CREATE OR REPLACE FUNCTION sync_reminder_cron()
RETURNS TRIGGER AS $trig$
BEGIN
  PERFORM rebuild_reminder_cron(NEW.send_time);
  RETURN NEW;
END;
$trig$ LANGUAGE plpgsql SECURITY DEFINER;

-- Attach trigger on send_time changes
DROP TRIGGER IF EXISTS sync_reminder_cron_on_update ON email_reminder_settings;
CREATE TRIGGER sync_reminder_cron_on_update
  AFTER UPDATE OF send_time ON email_reminder_settings
  FOR EACH ROW
  WHEN (OLD.send_time IS DISTINCT FROM NEW.send_time)
  EXECUTE FUNCTION sync_reminder_cron();

-- Apply current stored send_time to pg_cron immediately
DO $$
DECLARE
  current_time_val text;
BEGIN
  SELECT send_time INTO current_time_val FROM email_reminder_settings LIMIT 1;
  IF current_time_val IS NOT NULL THEN
    PERFORM rebuild_reminder_cron(current_time_val);
  END IF;
END $$;
