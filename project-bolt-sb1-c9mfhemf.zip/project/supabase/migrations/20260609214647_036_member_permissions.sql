CREATE TABLE IF NOT EXISTS member_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_member_id uuid NOT NULL REFERENCES team_members(id) ON DELETE CASCADE,
  module text NOT NULL,
  permission text NOT NULL DEFAULT 'view' CHECK (permission IN ('none', 'view', 'edit')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(team_member_id, module)
);

ALTER TABLE member_permissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_member_permissions" ON member_permissions
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "insert_member_permissions" ON member_permissions
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "update_member_permissions" ON member_permissions
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "delete_member_permissions" ON member_permissions
  FOR DELETE TO authenticated USING (true);
