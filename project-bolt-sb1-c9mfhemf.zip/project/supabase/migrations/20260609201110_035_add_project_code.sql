ALTER TABLE projects ADD COLUMN IF NOT EXISTS project_code text;
CREATE UNIQUE INDEX IF NOT EXISTS projects_project_code_key ON projects (project_code) WHERE project_code IS NOT NULL;
