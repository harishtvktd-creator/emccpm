DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'workforce_daily_allocations'::regclass
      AND contype = 'u'
      AND conname = 'workforce_daily_allocations_proj_emp_date_key'
  ) THEN
    ALTER TABLE workforce_daily_allocations
      ADD CONSTRAINT workforce_daily_allocations_proj_emp_date_key
      UNIQUE (project_id, employee_id, entry_date);
  END IF;
END $$;
