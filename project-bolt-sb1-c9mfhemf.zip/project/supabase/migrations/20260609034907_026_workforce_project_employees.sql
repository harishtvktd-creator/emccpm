
-- ── workforce_project_employees ──────────────────────────────────────────────
-- Persistent assignment of employees to projects (admin manages).
-- Team members can only add to daily allocations from this pool.

CREATE TABLE IF NOT EXISTS workforce_project_employees (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id  uuid        NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  employee_id uuid        NOT NULL REFERENCES workforce_employees(id) ON DELETE CASCADE,
  assigned_by uuid        REFERENCES team_members(id),
  assigned_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (project_id, employee_id)
);

ALTER TABLE workforce_project_employees ENABLE ROW LEVEL SECURITY;

-- Admins see all; team members see assignments only for their projects
CREATE POLICY "wf_proj_emp_select" ON workforce_project_employees
  FOR SELECT TO authenticated
  USING (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
    OR EXISTS (
      SELECT 1 FROM project_members pm
      JOIN team_members tm ON tm.id = pm.team_member_id
      WHERE tm.user_id = auth.uid() AND pm.project_id = workforce_project_employees.project_id
    )
  );

CREATE POLICY "wf_proj_emp_insert" ON workforce_project_employees
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true));

CREATE POLICY "wf_proj_emp_delete" ON workforce_project_employees
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true));
