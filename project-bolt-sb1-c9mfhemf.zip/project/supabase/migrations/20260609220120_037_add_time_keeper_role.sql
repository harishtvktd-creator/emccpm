ALTER TABLE team_members ADD COLUMN IF NOT EXISTS is_time_keeper boolean NOT NULL DEFAULT false;
