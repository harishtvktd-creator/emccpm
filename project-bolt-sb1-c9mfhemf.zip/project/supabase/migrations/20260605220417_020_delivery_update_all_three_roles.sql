-- Extend delivery tracking update access to all three roles:
-- Material Coordinator, Procurement Lead, and Admin
DROP POLICY IF EXISTS "mr_update_material_coordinator" ON material_requisitions;

CREATE POLICY "mr_update_material_coordinator" ON material_requisitions
  FOR UPDATE TO authenticated
  USING (
    delivery_status IS NOT NULL
    AND EXISTS (
      SELECT 1 FROM team_members
      WHERE team_members.user_id = auth.uid()
        AND team_members.is_active = true
        AND (
          team_members.is_material_coordinator = true
          OR team_members.is_procurement_lead   = true
          OR team_members.is_admin              = true
        )
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM team_members
      WHERE team_members.user_id = auth.uid()
        AND team_members.is_active = true
        AND (
          team_members.is_material_coordinator = true
          OR team_members.is_procurement_lead   = true
          OR team_members.is_admin              = true
        )
    )
  );
