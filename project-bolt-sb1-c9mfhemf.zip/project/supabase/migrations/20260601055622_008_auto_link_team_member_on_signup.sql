/*
  # Auto-link team_members on auth user creation

  When a new Supabase Auth user signs up, this trigger automatically finds
  any team_members row with a matching email and sets its user_id.
  This removes the need for manual linking by the admin after sign-up.
*/

CREATE OR REPLACE FUNCTION link_team_member_on_signup()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE team_members
  SET user_id = NEW.id
  WHERE email = NEW.email
    AND user_id IS NULL;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION link_team_member_on_signup();
