
-- ── workforce_employees ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS workforce_employees (
  id              uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_code   text        NOT NULL UNIQUE,
  name            text        NOT NULL,
  designation     text,
  department      text,
  trade           text,
  nationality     text,
  employment_type text        NOT NULL DEFAULT 'labour'
                    CHECK (employment_type IN ('staff', 'labour', 'subcontractor')),
  contact_phone   text,
  is_active       boolean     NOT NULL DEFAULT true,
  created_by      uuid        REFERENCES team_members(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION wf_emp_set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END;
$$;

DROP TRIGGER IF EXISTS wf_emp_updated_at ON workforce_employees;
CREATE TRIGGER wf_emp_updated_at
  BEFORE UPDATE ON workforce_employees
  FOR EACH ROW EXECUTE FUNCTION wf_emp_set_updated_at();

ALTER TABLE workforce_employees ENABLE ROW LEVEL SECURITY;

CREATE POLICY "wf_emp_select" ON workforce_employees
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "wf_emp_insert" ON workforce_employees
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true));

CREATE POLICY "wf_emp_update" ON workforce_employees
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true))
  WITH CHECK (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true));

CREATE POLICY "wf_emp_delete" ON workforce_employees
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true));

-- ── workforce_daily_allocations ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS workforce_daily_allocations (
  id              uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id      uuid        NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  employee_id     uuid        NOT NULL REFERENCES workforce_employees(id) ON DELETE RESTRICT,
  entry_date      date        NOT NULL,
  start_time      time,
  end_time        time,
  break_minutes   integer     NOT NULL DEFAULT 0 CHECK (break_minutes >= 0),
  notes           text,
  created_by      uuid        REFERENCES team_members(id),
  updated_by      uuid        REFERENCES team_members(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (project_id, employee_id, entry_date)
);

CREATE OR REPLACE FUNCTION wf_alloc_set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END;
$$;

DROP TRIGGER IF EXISTS wf_alloc_updated_at ON workforce_daily_allocations;
CREATE TRIGGER wf_alloc_updated_at
  BEFORE UPDATE ON workforce_daily_allocations
  FOR EACH ROW EXECUTE FUNCTION wf_alloc_set_updated_at();

ALTER TABLE workforce_daily_allocations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "wf_alloc_select" ON workforce_daily_allocations
  FOR SELECT TO authenticated
  USING (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
    OR EXISTS (
      SELECT 1 FROM project_members pm
      JOIN team_members tm ON tm.id = pm.team_member_id
      WHERE tm.user_id = auth.uid() AND pm.project_id = workforce_daily_allocations.project_id
    )
  );

CREATE POLICY "wf_alloc_insert" ON workforce_daily_allocations
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
    OR (
      entry_date = CURRENT_DATE
      AND EXISTS (
        SELECT 1 FROM project_members pm
        JOIN team_members tm ON tm.id = pm.team_member_id
        WHERE tm.user_id = auth.uid() AND pm.project_id = workforce_daily_allocations.project_id
      )
    )
  );

CREATE POLICY "wf_alloc_update" ON workforce_daily_allocations
  FOR UPDATE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
    OR (
      entry_date = CURRENT_DATE
      AND EXISTS (
        SELECT 1 FROM project_members pm
        JOIN team_members tm ON tm.id = pm.team_member_id
        WHERE tm.user_id = auth.uid() AND pm.project_id = workforce_daily_allocations.project_id
      )
    )
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
    OR (
      entry_date = CURRENT_DATE
      AND EXISTS (
        SELECT 1 FROM project_members pm
        JOIN team_members tm ON tm.id = pm.team_member_id
        WHERE tm.user_id = auth.uid() AND pm.project_id = workforce_daily_allocations.project_id
      )
    )
  );

CREATE POLICY "wf_alloc_delete" ON workforce_daily_allocations
  FOR DELETE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
    OR (
      entry_date = CURRENT_DATE
      AND EXISTS (
        SELECT 1 FROM project_members pm
        JOIN team_members tm ON tm.id = pm.team_member_id
        WHERE tm.user_id = auth.uid() AND pm.project_id = workforce_daily_allocations.project_id
      )
    )
  );

-- ── workforce_audit_logs ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS workforce_audit_logs (
  id                uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  action            text        NOT NULL CHECK (action IN ('INSERT', 'UPDATE', 'DELETE')),
  entity_type       text        NOT NULL,
  entity_id         uuid,
  entity_label      text,
  old_data          jsonb,
  new_data          jsonb,
  performed_by      uuid        REFERENCES team_members(id),
  performed_by_name text,
  performed_at      timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE workforce_audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "wf_audit_select" ON workforce_audit_logs
  FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true));

CREATE POLICY "wf_audit_insert" ON workforce_audit_logs
  FOR INSERT TO authenticated
  WITH CHECK (true);
