-- ── Material Coordinator role ────────────────────────────
ALTER TABLE team_members
  ADD COLUMN IF NOT EXISTS is_material_coordinator boolean NOT NULL DEFAULT false;

-- ── Delivery tracking columns on material_requisitions ───
ALTER TABLE material_requisitions
  ADD COLUMN IF NOT EXISTS delivery_status text DEFAULT NULL
    CHECK (delivery_status IN ('assigned', 'in_transit', 'delivered')),
  ADD COLUMN IF NOT EXISTS material_coordinator_id uuid DEFAULT NULL
    REFERENCES team_members(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS delivery_date date DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS delivery_remarks text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS delivery_updated_at timestamptz DEFAULT NULL;

-- ── RLS: Material Coordinators can update delivery fields on assigned MRs ──
CREATE POLICY "mr_update_material_coordinator" ON material_requisitions
  FOR UPDATE TO authenticated
  USING (
    material_coordinator_id IN (
      SELECT id FROM team_members
      WHERE user_id = auth.uid()
        AND is_material_coordinator = true
        AND is_active = true
    )
  )
  WITH CHECK (
    material_coordinator_id IN (
      SELECT id FROM team_members
      WHERE user_id = auth.uid()
        AND is_material_coordinator = true
        AND is_active = true
    )
  );
