/*
  # Team Task Management Database Schema

  1. New Tables
    - `team_members` - Stores team member information
    - `projects` - Stores project details
    - `tasks` - Stores scheduled tasks and document submissions
    - `project_members` - Junction table for project-team member relationships

  2. Team Members Table
    - `id` (uuid, primary key)
    - `user_id` (uuid, references auth.users)
    - `name` (text) - Team member full name
    - `email` (text, unique) - Team member email
    - `role` (text) - Role in the organization
    - `department` (text) - Department/team
    - `is_active` (boolean) - Whether member is active
    - `created_at` (timestamptz)

  3. Projects Table
    - `id` (uuid, primary key)
    - `name` (text) - Project name
    - `description` (text) - Project description
    - `status` (text) - 'planning', 'active', 'on-hold', 'completed', 'cancelled'
    - `start_date` (date)
    - `end_date` (date, nullable)
    - `priority` (text) - 'low', 'medium', 'high', 'critical'
    - `budget` (numeric, nullable)
    - `created_by` (uuid, references auth.users)
    - `created_at` (timestamptz)

  4. Project Members Table
    - Junction table for many-to-many relationship
    - Links projects to team members with roles

  5. Tasks Table
    - `id` (uuid, primary key)
    - `project_id` (uuid, references projects)
    - `assigned_to` (uuid, references team_members)
    - `title` (text) - Task title
    - `description` (text) - Task description
    - `task_type` (text) - 'task', 'document', 'milestone', 'review'
    - `status` (text) - 'pending', 'in-progress', 'review', 'completed', 'cancelled'
    - `priority` (text) - 'low', 'medium', 'high', 'critical'
    - `due_date` (date)
    - `completed_date` (date, nullable)
    - `document_name` (text, nullable) - For document submissions
    - `notes` (text, nullable)
    - `created_by` (uuid, references auth.users)
    - `created_at` (timestamptz)

  6. Security
    - Enable RLS on all tables
    - Users can only access data they create or are assigned to
    - Project members can view project tasks
*/

-- Team Members Table
CREATE TABLE IF NOT EXISTS team_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  email text UNIQUE NOT NULL,
  role text DEFAULT 'Team Member',
  department text DEFAULT 'General',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Projects Table
CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  status text NOT NULL DEFAULT 'planning' CHECK (status IN ('planning', 'active', 'on-hold', 'completed', 'cancelled')),
  start_date date NOT NULL DEFAULT CURRENT_DATE,
  end_date date,
  priority text NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'critical')),
  budget numeric,
  created_by uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

-- Project Members Junction Table
CREATE TABLE IF NOT EXISTS project_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  team_member_id uuid NOT NULL REFERENCES team_members(id) ON DELETE CASCADE,
  role_in_project text DEFAULT 'Member',
  joined_at timestamptz DEFAULT now(),
  UNIQUE(project_id, team_member_id)
);

-- Tasks Table
CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  assigned_to uuid REFERENCES team_members(id) ON DELETE SET NULL,
  title text NOT NULL,
  description text,
  task_type text NOT NULL DEFAULT 'task' CHECK (task_type IN ('task', 'document', 'milestone', 'review')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in-progress', 'review', 'completed', 'cancelled')),
  priority text NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'critical')),
  due_date date NOT NULL,
  completed_date date,
  document_name text,
  notes text,
  created_by uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE team_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

-- Team Members Policies
CREATE POLICY "Users can view all team members"
  ON team_members FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create team members"
  ON team_members FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update team members"
  ON team_members FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can delete team members"
  ON team_members FOR DELETE
  TO authenticated
  USING (true);

-- Projects Policies
CREATE POLICY "Users can view projects they created or are members of"
  ON projects FOR SELECT
  TO authenticated
  USING (
    created_by = auth.uid() 
    OR EXISTS (
      SELECT 1 FROM project_members pm
      JOIN team_members tm ON pm.team_member_id = tm.id
      WHERE pm.project_id = projects.id AND tm.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create projects"
  ON projects FOR INSERT
  TO authenticated
  WITH CHECK (created_by = auth.uid());

CREATE POLICY "Project creators and members can update projects"
  ON projects FOR UPDATE
  TO authenticated
  USING (
    created_by = auth.uid() 
    OR EXISTS (
      SELECT 1 FROM project_members pm
      JOIN team_members tm ON pm.team_member_id = tm.id
      WHERE pm.project_id = projects.id AND tm.user_id = auth.uid()
    )
  )
  WITH CHECK (
    created_by = auth.uid() 
    OR EXISTS (
      SELECT 1 FROM project_members pm
      JOIN team_members tm ON pm.team_member_id = tm.id
      WHERE pm.project_id = projects.id AND tm.user_id = auth.uid()
    )
  );

CREATE POLICY "Project creators can delete projects"
  ON projects FOR DELETE
  TO authenticated
  USING (created_by = auth.uid());

-- Project Members Policies
CREATE POLICY "Users can view project members for accessible projects"
  ON project_members FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = project_members.project_id
      AND (projects.created_by = auth.uid() 
        OR EXISTS (
          SELECT 1 FROM project_members pm2
          JOIN team_members tm2 ON pm2.team_member_id = tm2.id
          WHERE pm2.project_id = projects.id AND tm2.user_id = auth.uid()
        ))
    )
  );

CREATE POLICY "Project creators can manage project members"
  ON project_members FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = project_members.project_id
      AND projects.created_by = auth.uid()
    )
  );

-- Tasks Policies
CREATE POLICY "Users can view tasks in accessible projects"
  ON tasks FOR SELECT
  TO authenticated
  USING (
    created_by = auth.uid()
    OR EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = tasks.project_id
      AND (projects.created_by = auth.uid() 
        OR EXISTS (
          SELECT 1 FROM project_members pm
          JOIN team_members tm ON pm.team_member_id = tm.id
          WHERE pm.project_id = projects.id AND tm.user_id = auth.uid()
        ))
    )
  );

CREATE POLICY "Users can create tasks in accessible projects"
  ON tasks FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = tasks.project_id
      AND (projects.created_by = auth.uid() 
        OR EXISTS (
          SELECT 1 FROM project_members pm
          JOIN team_members tm ON pm.team_member_id = tm.id
          WHERE pm.project_id = projects.id AND tm.user_id = auth.uid()
        ))
    )
  );

CREATE POLICY "Users can update tasks in accessible projects"
  ON tasks FOR UPDATE
  TO authenticated
  USING (
    created_by = auth.uid()
    OR EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = tasks.project_id
      AND (projects.created_by = auth.uid() 
        OR EXISTS (
          SELECT 1 FROM project_members pm
          JOIN team_members tm ON pm.team_member_id = tm.id
          WHERE pm.project_id = projects.id AND tm.user_id = auth.uid()
        ))
    )
  );

CREATE POLICY "Project creators can delete tasks"
  ON tasks FOR DELETE
  TO authenticated
  USING (
    created_by = auth.uid()
    OR EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = tasks.project_id
      AND projects.created_by = auth.uid()
    )
  );

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_team_members_user ON team_members(user_id);
CREATE INDEX IF NOT EXISTS idx_projects_created_by ON projects(created_by);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
CREATE INDEX IF NOT EXISTS idx_project_members_project ON project_members(project_id);
CREATE INDEX IF NOT EXISTS idx_project_members_member ON project_members(team_member_id);
CREATE INDEX IF NOT EXISTS idx_tasks_project ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_tasks_assigned_to ON tasks(assigned_to);
CREATE INDEX IF NOT EXISTS idx_tasks_due_date ON tasks(due_date);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
