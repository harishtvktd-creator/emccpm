-- Allow 'draft' status and nullable requisition_number for draft MRs

ALTER TABLE material_requisitions
  DROP CONSTRAINT IF EXISTS material_requisitions_status_check;

ALTER TABLE material_requisitions
  ADD CONSTRAINT material_requisitions_status_check
  CHECK (status IN ('draft','created','assigned','in_progress','po_released','closed'));

ALTER TABLE material_requisitions
  ALTER COLUMN requisition_number DROP NOT NULL;

-- Allow creators to update and delete their own draft MRs
DROP POLICY IF EXISTS "mr_update_admin_or_lead" ON material_requisitions;

CREATE POLICY "mr_update_admin_or_lead_or_own_draft" ON material_requisitions
  FOR UPDATE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND (is_admin = true OR is_procurement_lead = true))
    OR (status = 'draft' AND created_by IN (SELECT id FROM team_members WHERE user_id = auth.uid()))
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND (is_admin = true OR is_procurement_lead = true))
    OR (status = 'draft' AND created_by IN (SELECT id FROM team_members WHERE user_id = auth.uid()))
  );

DROP POLICY IF EXISTS "mr_delete_admin" ON material_requisitions;

CREATE POLICY "mr_delete_admin_or_own_draft" ON material_requisitions
  FOR DELETE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM team_members WHERE user_id = auth.uid() AND is_admin = true)
    OR (status = 'draft' AND created_by IN (SELECT id FROM team_members WHERE user_id = auth.uid()))
  );
