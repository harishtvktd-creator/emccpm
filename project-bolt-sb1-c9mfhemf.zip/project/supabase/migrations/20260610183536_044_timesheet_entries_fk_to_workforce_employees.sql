-- Re-point timesheet_entries.employee_id FK from timesheet_employees to workforce_employees.
-- workforce_project_employees is the authoritative project-employee assignment table,
-- and workforce_employees is the single employee master used for operational tracking.

DO $$
DECLARE
  cname text;
BEGIN
  SELECT conname INTO cname
  FROM pg_constraint
  WHERE conrelid = 'timesheet_entries'::regclass
    AND confrelid = 'timesheet_employees'::regclass
    AND contype   = 'f';

  IF cname IS NOT NULL THEN
    EXECUTE 'ALTER TABLE timesheet_entries DROP CONSTRAINT ' || quote_ident(cname);
  END IF;
END $$;

-- Delete any orphaned rows that referenced timesheet_employees (dev data only)
DELETE FROM timesheet_entries
WHERE employee_id NOT IN (SELECT id FROM workforce_employees);

ALTER TABLE timesheet_entries
  ADD CONSTRAINT timesheet_entries_employee_id_fkey
  FOREIGN KEY (employee_id) REFERENCES workforce_employees(id) ON DELETE CASCADE;
