
-- ── 1. Fix mutable search_path: sync_invoice_paid_amount ─────────────────────
-- Recreate as SECURITY DEFINER with fixed search_path so it cannot be hijacked.

CREATE OR REPLACE FUNCTION public.sync_invoice_paid_amount()
  RETURNS TRIGGER
  LANGUAGE plpgsql
  SECURITY DEFINER
  SET search_path = ''
AS $$
DECLARE
  v_invoice_id UUID;
  v_total      NUMERIC;
  v_paid       NUMERIC;
BEGIN
  v_invoice_id := COALESCE(NEW.invoice_id, OLD.invoice_id);

  SELECT i.total, COALESCE(SUM(p.amount), 0)
    INTO v_total, v_paid
    FROM public.accounts_invoices i
    LEFT JOIN public.accounts_payments p ON p.invoice_id = i.id
    WHERE i.id = v_invoice_id
    GROUP BY i.total;

  UPDATE public.accounts_invoices
    SET paid_amount = v_paid,
        status      = CASE
                        WHEN v_paid >= v_total THEN 'paid'
                        WHEN v_paid > 0        THEN 'partial'
                        ELSE status
                      END,
        updated_at  = NOW()
    WHERE id = v_invoice_id;

  RETURN COALESCE(NEW, OLD);
END;
$$;

-- ── 2. Fix mutable search_path: next_invoice_number ──────────────────────────
-- Keep SECURITY DEFINER (called via authenticated RPC); add fixed search_path.

CREATE OR REPLACE FUNCTION public.next_invoice_number(p_type TEXT, p_user_id UUID)
  RETURNS TEXT
  LANGUAGE plpgsql
  SECURITY DEFINER
  SET search_path = ''
AS $$
DECLARE
  v_prefix TEXT;
  v_year   TEXT;
  v_seq    INTEGER;
BEGIN
  v_prefix := CASE p_type WHEN 'credit_note' THEN 'CN' ELSE 'INV' END;
  v_year   := TO_CHAR(NOW(), 'YYYY');

  SELECT COALESCE(MAX(
    NULLIF(REGEXP_REPLACE(invoice_number, '[^0-9]', '', 'g'), '')::INTEGER
  ), 0) + 1
    INTO v_seq
    FROM public.accounts_invoices
    WHERE user_id = p_user_id
      AND type    = p_type
      AND invoice_number LIKE v_prefix || '-' || v_year || '-%';

  RETURN v_prefix || '-' || v_year || '-' || LPAD(v_seq::TEXT, 4, '0');
END;
$$;

-- ── 3. Fix RLS policies on flash_messages ────────────────────────────────────
-- flash_messages has no user_id; restrict mutations to admin users only.

DROP POLICY IF EXISTS "delete_flash_messages" ON public.flash_messages;
DROP POLICY IF EXISTS "insert_flash_messages" ON public.flash_messages;
DROP POLICY IF EXISTS "update_flash_messages" ON public.flash_messages;

CREATE POLICY "delete_flash_messages" ON public.flash_messages
  FOR DELETE TO authenticated
  USING (public.is_admin_user());

CREATE POLICY "insert_flash_messages" ON public.flash_messages
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin_user());

CREATE POLICY "update_flash_messages" ON public.flash_messages
  FOR UPDATE TO authenticated
  USING  (public.is_admin_user())
  WITH CHECK (public.is_admin_user());

-- ── 4. Fix RLS policies on member_permissions ────────────────────────────────
-- Mutations must be restricted to admin users; SELECT already uses team_member check.

DROP POLICY IF EXISTS "delete_member_permissions" ON public.member_permissions;
DROP POLICY IF EXISTS "insert_member_permissions" ON public.member_permissions;
DROP POLICY IF EXISTS "update_member_permissions" ON public.member_permissions;

CREATE POLICY "delete_member_permissions" ON public.member_permissions
  FOR DELETE TO authenticated
  USING (public.is_admin_user());

CREATE POLICY "insert_member_permissions" ON public.member_permissions
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin_user());

CREATE POLICY "update_member_permissions" ON public.member_permissions
  FOR UPDATE TO authenticated
  USING  (public.is_admin_user())
  WITH CHECK (public.is_admin_user());

-- ── 5. Revoke public/anonymous EXECUTE on SECURITY DEFINER functions ─────────

-- Trigger-only functions: revoke from both anon and authenticated.
-- (Triggers fire as the function owner, not the invoking role — EXECUTE not needed.)
REVOKE EXECUTE ON FUNCTION public.link_team_member_on_signup()       FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.sync_reminder_cron()               FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.rebuild_reminder_cron(text)        FROM anon, authenticated;

-- is_admin_user is called during RLS policy evaluation by authenticated sessions;
-- revoke only from anon (unauthenticated callers must never reach it via RPC).
REVOKE EXECUTE ON FUNCTION public.is_admin_user()                    FROM anon;

-- next_invoice_number is called via supabase.rpc() by authenticated users;
-- revoke only from anon.
REVOKE EXECUTE ON FUNCTION public.next_invoice_number(text, uuid)    FROM anon;
