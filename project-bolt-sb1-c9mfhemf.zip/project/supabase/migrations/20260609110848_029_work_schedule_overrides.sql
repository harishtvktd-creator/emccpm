-- Project-level normal hours overrides
CREATE TABLE work_schedule_project_overrides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  normal_hours numeric(4,2) NOT NULL CHECK (normal_hours >= 0 AND normal_hours <= 24),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (project_id)
);

ALTER TABLE work_schedule_project_overrides ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_project_overrides" ON work_schedule_project_overrides
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "insert_project_overrides" ON work_schedule_project_overrides
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM team_members tm WHERE tm.user_id = auth.uid() AND tm.role = 'admin')
  );

CREATE POLICY "update_project_overrides" ON work_schedule_project_overrides
  FOR UPDATE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM team_members tm WHERE tm.user_id = auth.uid() AND tm.role = 'admin')
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM team_members tm WHERE tm.user_id = auth.uid() AND tm.role = 'admin')
  );

CREATE POLICY "delete_project_overrides" ON work_schedule_project_overrides
  FOR DELETE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM team_members tm WHERE tm.user_id = auth.uid() AND tm.role = 'admin')
  );

-- Date range overrides (can be global or project-specific)
CREATE TABLE work_schedule_date_overrides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  label text NOT NULL,
  date_from date NOT NULL,
  date_to date NOT NULL,
  normal_hours numeric(4,2) NOT NULL CHECK (normal_hours >= 0 AND normal_hours <= 24),
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CHECK (date_to >= date_from)
);

ALTER TABLE work_schedule_date_overrides ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_date_overrides" ON work_schedule_date_overrides
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "insert_date_overrides" ON work_schedule_date_overrides
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM team_members tm WHERE tm.user_id = auth.uid() AND tm.role = 'admin')
  );

CREATE POLICY "update_date_overrides" ON work_schedule_date_overrides
  FOR UPDATE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM team_members tm WHERE tm.user_id = auth.uid() AND tm.role = 'admin')
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM team_members tm WHERE tm.user_id = auth.uid() AND tm.role = 'admin')
  );

CREATE POLICY "delete_date_overrides" ON work_schedule_date_overrides
  FOR DELETE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM team_members tm WHERE tm.user_id = auth.uid() AND tm.role = 'admin')
  );
