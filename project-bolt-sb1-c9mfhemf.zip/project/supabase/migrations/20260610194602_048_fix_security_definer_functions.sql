-- Revoke public/anon/authenticated EXECUTE on the trigger function —
-- it is only called internally by the trigger, never via RPC.
REVOKE EXECUTE ON FUNCTION public.sync_invoice_paid_amount() FROM PUBLIC, anon, authenticated;

-- Switch the invoice-number helper to SECURITY INVOKER so it runs as the
-- calling user (subject to RLS) instead of the function owner.
CREATE OR REPLACE FUNCTION public.next_invoice_number(p_type TEXT, p_user_id UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  v_prefix TEXT;
  v_year   TEXT;
  v_seq    INTEGER;
BEGIN
  v_prefix := CASE p_type WHEN 'credit_note' THEN 'CN' ELSE 'INV' END;
  v_year   := TO_CHAR(NOW(), 'YYYY');
  SELECT COALESCE(MAX(
    NULLIF(REGEXP_REPLACE(invoice_number, '[^0-9]', '', 'g'), '')::INTEGER
  ), 0) + 1
    INTO v_seq
    FROM accounts_invoices
    WHERE user_id = p_user_id
      AND type = p_type
      AND invoice_number LIKE v_prefix || '-' || v_year || '-%';
  RETURN v_prefix || '-' || v_year || '-' || LPAD(v_seq::TEXT, 4, '0');
END;
$$;
