-- Add transit remarks and file attachments to material requisitions
ALTER TABLE material_requisitions
  ADD COLUMN IF NOT EXISTS transit_remarks text,
  ADD COLUMN IF NOT EXISTS attachments     jsonb NOT NULL DEFAULT '[]';

-- Storage bucket for MR file attachments
INSERT INTO storage.buckets (id, name, public)
VALUES ('mr-attachments', 'mr-attachments', true)
ON CONFLICT (id) DO NOTHING;

-- Storage RLS: all authenticated users can upload/read/delete
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'storage' AND tablename = 'objects'
      AND policyname = 'auth upload mr attachments'
  ) THEN
    EXECUTE $p$
      CREATE POLICY "auth upload mr attachments" ON storage.objects
        FOR INSERT TO authenticated
        WITH CHECK (bucket_id = 'mr-attachments');
    $p$;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'storage' AND tablename = 'objects'
      AND policyname = 'auth read mr attachments'
  ) THEN
    EXECUTE $p$
      CREATE POLICY "auth read mr attachments" ON storage.objects
        FOR SELECT TO authenticated
        USING (bucket_id = 'mr-attachments');
    $p$;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'storage' AND tablename = 'objects'
      AND policyname = 'auth delete mr attachments'
  ) THEN
    EXECUTE $p$
      CREATE POLICY "auth delete mr attachments" ON storage.objects
        FOR DELETE TO authenticated
        USING (bucket_id = 'mr-attachments');
    $p$;
  END IF;
END $$;
