CREATE TABLE IF NOT EXISTS timesheet_posted_records (
  id             uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id     uuid        NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  entry_date     date        NOT NULL,
  posted_at      timestamptz NOT NULL DEFAULT now(),
  posted_by      uuid        REFERENCES team_members(id),
  posted_by_name text,
  notes          text,
  UNIQUE (project_id, entry_date)
);

ALTER TABLE timesheet_posted_records ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ts_posted_select_admin" ON timesheet_posted_records
  FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM team_members
    WHERE user_id = auth.uid() AND is_admin = true
  ));

CREATE POLICY "ts_posted_insert_admin" ON timesheet_posted_records
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM team_members
    WHERE user_id = auth.uid() AND is_admin = true
  ));

CREATE POLICY "ts_posted_delete_admin" ON timesheet_posted_records
  FOR DELETE TO authenticated
  USING (EXISTS (
    SELECT 1 FROM team_members
    WHERE user_id = auth.uid() AND is_admin = true
  ));
