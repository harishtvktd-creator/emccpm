ALTER TABLE workforce_daily_allocations
  ADD COLUMN IF NOT EXISTS attendance_status text NOT NULL DEFAULT 'present'
    CHECK (attendance_status IN ('present','leave','sick_leave','public_holiday','annual_leave','compensation_leave'));
