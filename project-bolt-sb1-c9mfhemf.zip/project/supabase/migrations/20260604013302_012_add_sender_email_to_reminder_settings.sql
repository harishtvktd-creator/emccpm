/*
  # Add sender_email (custom domain) to email_reminder_settings

  1. Changes
    - Add `sender_email` text column
      - Stores the full "From" email address (e.g. reminders@emcc.ae)
      - Empty/null = fall back to onboarding@resend.dev (Resend default)
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'email_reminder_settings' AND column_name = 'sender_email'
  ) THEN
    ALTER TABLE email_reminder_settings ADD COLUMN sender_email text NOT NULL DEFAULT '';
  END IF;
END $$;
