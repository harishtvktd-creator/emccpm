-- Replace the MC update policy so ANY active Material Coordinator
-- can update ANY MR that has a delivery status set (not just "their own" assignment)
DROP POLICY IF EXISTS "mr_update_material_coordinator" ON material_requisitions;

CREATE POLICY "mr_update_material_coordinator" ON material_requisitions
  FOR UPDATE TO authenticated
  USING (
    delivery_status IS NOT NULL
    AND EXISTS (
      SELECT 1 FROM team_members
      WHERE team_members.user_id = auth.uid()
        AND team_members.is_material_coordinator = true
        AND team_members.is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM team_members
      WHERE team_members.user_id = auth.uid()
        AND team_members.is_material_coordinator = true
        AND team_members.is_active = true
    )
  );
